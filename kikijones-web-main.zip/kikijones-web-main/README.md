# 🌐 KikiJones Web - Site E-commerce

Site e-commerce Next.js 14 avec thème noir/blanc SHEIN-inspired.

## 🚀 Installation

```bash
# 1. Installer les dépendances
npm install

# 2. Configurer les variables d'environnement
cp .env.local.example .env.local
# Éditer .env.local avec vos paramètres

# 3. Lancer le serveur de développement
npm run dev
```

Le site sera accessible sur http://localhost:3000

## 📦 Structure

```
src/
├── app/              # App Router Next.js 14
├── components/       # Composants React
│   ├── layout/       # Header, Footer
│   ├── home/         # Page d'accueil
│   ├── products/     # Produits
│   └── ui/           # Composants UI réutilisables
├── lib/              # Utilitaires
├── hooks/            # Custom hooks
├── types/            # TypeScript types
└── styles/           # CSS global
```

## 🎨 Design System

### Couleurs
- **Noir**: #000000 (CTA, textes principaux)
- **Blanc**: #FFFFFF (Backgrounds)
- **Gris**: Échelle de gris pour textes secondaires
- **Rouge**: #FF0000 (Promos, urgence)
- **Or**: #FFD700 (VIP, badges)

### Typographie
- **Font**: Inter
- **Tailles**: 12px, 14px, 16px, 18px, 24px, 32px

### Composants
- Buttons: `.btn`, `.btn-primary`, `.btn-secondary`
- Cards: `.product-card`
- Inputs: `.input`
- Badges: `.badge-new`, `.badge-sale`, `.badge-vip`

## 🛠️ Technologies

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **State**: Zustand
- **API Calls**: Axios + React Query
- **Animations**: Framer Motion

## 📱 Pages

- `/` - Accueil
- `/nouveautes` - Nouveautés
- `/femmes` - Catégorie Femmes
- `/hommes` - Catégorie Hommes
- `/promotions` - Promotions
- `/produit/[slug]` - Page produit
- `/panier` - Panier
- `/compte` - Compte utilisateur
- `/wishlist` - Liste de souhaits

## 🔧 Scripts

```bash
npm run dev      # Développement
npm run build    # Build production
npm run start    # Serveur production
npm run lint     # Linter ESLint
```

## 🚀 Déploiement

### Vercel (Recommandé)
```bash
# Installer Vercel CLI
npm i -g vercel

# Déployer
vercel
```

### VPS (avec PM2 + Nginx)
```bash
# Build
npm run build

# PM2
pm2 start npm --name "kikijones-web" -- start

# Nginx reverse proxy sur port 3000
```

## 🌐 Variables d'environnement

```env
NEXT_PUBLIC_API_URL=https://api.kikijones.com/api
NEXT_PUBLIC_SITE_URL=https://kikijones.com
```

## 📝 To Do

- [ ] Intégration API backend
- [ ] Page produit complète
- [ ] Système de panier
- [ ] Checkout CinetPay
- [ ] Dashboard utilisateur
- [ ] Interface gamification
- [ ] Recherche produits
- [ ] Filtres avancés

## 💬 Support

support@kikijones.com
