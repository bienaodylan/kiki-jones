import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'À Propos | KikiJones',
  description: 'Découvrez l\'histoire de KikiJones',
}

export default function AboutPage() {
  return (
    <div className="bg-white min-h-screen">
      {/* Hero */}
      <div className="bg-black text-white py-20">
        <div className="container-custom text-center">
          <h1 className="text-5xl font-black uppercase mb-4">À Propos de KikiJones</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Votre destination mode pour un style unique et audacieux
          </p>
        </div>
      </div>

      {/* Notre Histoire */}
      <div className="container-custom py-16">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-black uppercase mb-6">Notre Histoire</h2>
          <div className="space-y-4 text-gray-700 leading-relaxed">
            <p>
              Fondée avec la passion de rendre la mode accessible à tous, KikiJones est devenue
              une référence incontournable pour les femmes qui aiment s'affirmer à travers leur style.
            </p>
            <p>
              Nous croyons que chaque femme mérite de se sentir belle, confiante et unique. C'est
              pourquoi nous sélectionnons avec soin des pièces qui allient tendance, qualité et
              accessibilité.
            </p>
            <p>
              De nos robes iconiques à nos accessoires statement, chaque produit est choisi pour
              vous permettre d'exprimer votre personnalité et de briller en toute occasion.
            </p>
          </div>
        </div>
      </div>

      {/* Nos Valeurs */}
      <div className="bg-gray-50 py-16">
        <div className="container-custom">
          <h2 className="text-3xl font-black uppercase mb-12 text-center">Nos Valeurs</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl font-black mb-4">💎</div>
              <h3 className="font-black uppercase text-lg mb-3">Qualité</h3>
              <p className="text-gray-600 text-sm">
                Des matières premium et une attention aux détails pour des pièces qui durent
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-black mb-4">✨</div>
              <h3 className="font-black uppercase text-lg mb-3">Style</h3>
              <p className="text-gray-600 text-sm">
                Des collections suivant les dernières tendances internationales
              </p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-black mb-4">💰</div>
              <h3 className="font-black uppercase text-lg mb-3">Prix justes</h3>
              <p className="text-gray-600 text-sm">
                La mode accessible sans compromis sur la qualité
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Pourquoi Nous Choisir */}
      <div className="container-custom py-16">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-black uppercase mb-6">Pourquoi Choisir KikiJones ?</h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="text-2xl">✓</div>
              <div>
                <h3 className="font-black uppercase text-sm mb-1">Livraison Rapide</h3>
                <p className="text-gray-600 text-sm">
                  Recevez vos commandes en 24-48h à Douala et 3-5 jours partout au Cameroun
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="text-2xl">✓</div>
              <div>
                <h3 className="font-black uppercase text-sm mb-1">Retours Faciles</h3>
                <p className="text-gray-600 text-sm">
                  14 jours pour changer d'avis, sans questions posées
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="text-2xl">✓</div>
              <div>
                <h3 className="font-black uppercase text-sm mb-1">Support Client Réactif</h3>
                <p className="text-gray-600 text-sm">
                  Notre équipe est là pour vous aider du lundi au samedi de 9h à 18h
                </p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="text-2xl">✓</div>
              <div>
                <h3 className="font-black uppercase text-sm mb-1">Paiement Sécurisé</h3>
                <p className="text-gray-600 text-sm">
                  Transactions 100% sécurisées avec plusieurs options de paiement
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-black text-white py-16">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-black uppercase mb-4">Rejoignez la Communauté KikiJones</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Plus de 10 000 femmes font déjà confiance à KikiJones pour leur style
          </p>
          <a
            href="/produits"
            className="inline-block bg-white text-black px-8 py-4 font-black uppercase text-sm hover:bg-gray-200 transition-colors"
          >
            Découvrir la collection
          </a>
        </div>
      </div>
    </div>
  )
}
