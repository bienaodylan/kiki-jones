'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Bell, Package, Tag, Gift, CheckCircle, Trash2, ArrowLeft } from 'lucide-react'
import { fetchAPI, API_ENDPOINTS } from '@/lib/api/config'
import { getAuthToken } from '@/lib/api/auth'
import { bootstrapAuth } from '@/lib/auth-store'

interface Notification {
  id: string
  type: string
  title: string
  message: string
  is_read: boolean
  data?: Record<string, any>
  created_at: string
}

const typeIcons: Record<string, any> = {
  order: Package,
  promotion: Tag,
  points: Gift,
  system: Bell,
}

export default function NotificationsPage() {
  const router = useRouter()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    bootstrapAuth().then((token) => {
      if (!token) {
        router.push('/login')
        return
      }
      fetchNotifications(token)
    })
  }, [router])

  const fetchNotifications = async (token: string) => {
    try {
      const data = await fetchAPI<any>(API_ENDPOINTS.notifications, {
        headers: { Authorization: `Bearer ${token}` },
      })
      setNotifications(data.results || data || [])
    } catch {
      setNotifications([])
    } finally {
      setLoading(false)
    }
  }

  const markAsRead = async (id: string) => {
    const token = getAuthToken()
    if (!token) return
    try {
      await fetchAPI(`${API_ENDPOINTS.notifications}${id}/mark-read/`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      setNotifications(prev =>
        prev.map(n => n.id === id ? { ...n, is_read: true } : n)
      )
    } catch {}
  }

  const markAllRead = async () => {
    const token = getAuthToken()
    if (!token) return
    try {
      await fetchAPI(`${API_ENDPOINTS.notifications}mark-all-read/`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })))
    } catch {}
  }

  const handleClick = (notif: Notification) => {
    if (!notif.is_read) markAsRead(notif.id)
    if (notif.data?.order_id) {
      router.push(`/compte/commandes/${notif.data.order_id}`)
    }
  }

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr)
    const now = new Date()
    const diffMs = now.getTime() - d.getTime()
    const diffMin = Math.floor(diffMs / 60000)
    const diffH = Math.floor(diffMin / 60)
    const diffD = Math.floor(diffH / 24)
    if (diffMin < 1) return "À l'instant"
    if (diffMin < 60) return `Il y a ${diffMin} min`
    if (diffH < 24) return `Il y a ${diffH}h`
    if (diffD < 7) return `Il y a ${diffD}j`
    return d.toLocaleDateString('fr-FR')
  }

  const unreadCount = notifications.filter(n => !n.is_read).length

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Link href="/compte" className="text-gray-600 hover:text-black">
              <ArrowLeft size={20} />
            </Link>
            <h1 className="text-2xl font-black uppercase tracking-tight">
              Notifications
            </h1>
            {unreadCount > 0 && (
              <span className="bg-black text-white text-xs px-2 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="text-sm text-gray-600 hover:text-black flex items-center gap-1"
            >
              <CheckCircle size={14} />
              Tout marquer comme lu
            </button>
          )}
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-lg p-4 animate-pulse">
                <div className="flex gap-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full" />
                  <div className="flex-1">
                    <div className="h-4 bg-gray-200 rounded w-1/3 mb-2" />
                    <div className="h-3 bg-gray-200 rounded w-2/3" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <div className="bg-white rounded-lg p-12 text-center">
            <Bell size={48} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune notification</h3>
            <p className="text-gray-500 text-sm">
              Vous n&apos;avez pas encore de notifications. Elles apparaîtront ici.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map(notif => {
              const Icon = typeIcons[notif.type] || Bell
              return (
                <button
                  key={notif.id}
                  onClick={() => handleClick(notif)}
                  className={`w-full text-left bg-white rounded-lg p-4 hover:shadow-sm transition-shadow border-l-4 ${
                    notif.is_read ? 'border-transparent opacity-70' : 'border-black'
                  }`}
                >
                  <div className="flex gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      notif.is_read ? 'bg-gray-100' : 'bg-black'
                    }`}>
                      <Icon size={18} className={notif.is_read ? 'text-gray-500' : 'text-white'} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className={`text-sm ${notif.is_read ? 'text-gray-700' : 'text-gray-900 font-medium'}`}>
                          {notif.title}
                        </p>
                        <span className="text-xs text-gray-400 whitespace-nowrap">
                          {formatDate(notif.created_at)}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5 truncate">
                        {notif.message}
                      </p>
                    </div>
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
