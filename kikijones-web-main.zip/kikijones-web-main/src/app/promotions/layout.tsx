import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Promotions | KikiJones',
  description: 'Profitez de nos promotions et offres spéciales sur la mode et les accessoires. Livraison rapide en Côte d\'Ivoire.',
}

export default function PromotionsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
