import { redirect } from 'next/navigation'

export default function PromotionsPage() {
  redirect('/produits?sort=on_sale')
}
