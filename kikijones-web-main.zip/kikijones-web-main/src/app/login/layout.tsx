import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Connexion | KikiJones',
  description: 'Connectez-vous à votre compte KikiJones pour accéder à vos commandes et profiter de nos offres exclusives.',
}

export default function LoginLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
