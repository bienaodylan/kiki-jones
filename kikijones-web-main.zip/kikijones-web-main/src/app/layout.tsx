import type { Metadata } from 'next'
import { DM_Sans } from 'next/font/google'
import { headers } from 'next/headers'
import './globals.css'
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
import Providers from '@/components/providers/Providers'
import ClientOnlyWidgets from '@/components/ClientOnlyWidgets'
import { getSiteSettings } from '@/lib/api/cms'

const inter = DM_Sans({ subsets: ['latin'], weight: ['300', '400', '500', '700'], display: 'swap' })

// Revalidate site-wide metadata periodically
export const revalidate = 60

export async function generateMetadata(): Promise<Metadata> {
  try {
    const settings = await getSiteSettings()
    return {
      title: settings.meta_title || 'KikiJones - Mode & Tendances',
      description: settings.meta_description || 'Découvrez les dernières tendances mode sur KikiJones',
      keywords: settings.meta_keywords || 'mode, vêtements, fashion, tendances, kikijones',
      metadataBase: new URL('https://kikijones.com'),
      openGraph: {
        type: 'website',
        locale: 'fr_CI',
        url: 'https://kikijones.com',
        siteName: 'KikiJones',
        title: settings.meta_title || 'KikiJones - Mode & Tendances',
        description: settings.meta_description || 'Découvrez les dernières tendances mode sur KikiJones',
      },
      twitter: {
        card: 'summary_large_image',
        title: settings.meta_title || 'KikiJones - Mode & Tendances',
        description: settings.meta_description || 'Découvrez les dernières tendances mode sur KikiJones',
      },
    }
  } catch (error) {
    return {
      title: 'KikiJones - Mode & Tendances',
      description: 'Découvrez les dernières tendances mode sur KikiJones',
      keywords: 'mode, vêtements, fashion, tendances, kikijones',
      metadataBase: new URL('https://kikijones.com'),
      openGraph: {
        type: 'website',
        locale: 'fr_CI',
        url: 'https://kikijones.com',
        siteName: 'KikiJones',
        title: 'KikiJones - Mode & Tendances',
        description: 'Découvrez les dernières tendances mode sur KikiJones',
      },
      twitter: {
        card: 'summary_large_image',
        title: 'KikiJones - Mode & Tendances',
        description: 'Découvrez les dernières tendances mode sur KikiJones',
      },
    }
  }
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  let siteSettings
  try {
    siteSettings = await getSiteSettings()
  } catch (error) {
    console.error('Failed to load site settings:', error)
  }

  // Strip sensitive fields before passing to client components (C3 fix)
  const { maintenance_bypass_key, ...publicSettings } = siteSettings || {} as any

  // Check if middleware flagged this as maintenance mode
  const headersList = await headers()
  const isMaintenance = headersList.get('x-maintenance-mode') === '1'

  if (isMaintenance) {
    return (
      <html lang="fr">
        <body className={inter.className}>
          {children}
        </body>
      </html>
    )
  }

  return (
    <html lang="fr">
      <body className={inter.className}>
        <Providers>
          <div className="flex flex-col min-h-screen">
            <Header siteSettings={publicSettings} />
            <main className="flex-1">
              {children}
            </main>
            <Footer siteSettings={publicSettings} />
            <ClientOnlyWidgets />
          </div>
        </Providers>
      </body>
    </html>
  )
}
