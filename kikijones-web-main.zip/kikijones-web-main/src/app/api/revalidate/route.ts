import { NextRequest, NextResponse } from 'next/server'
import { revalidatePath, revalidateTag } from 'next/cache'
import { timingSafeEqual } from 'crypto'

// Called by the Django backend after any CMS / catalogue change so the site
// shows the new content immediately instead of waiting for the cache to expire.
export async function POST(request: NextRequest) {
  const expected = process.env.REVALIDATE_SECRET || ''
  const provided = request.headers.get('x-revalidate-secret') || ''
  const a = Buffer.from(provided)
  const b = Buffer.from(expected)
  if (!expected || a.length !== b.length || !timingSafeEqual(a, b)) {
    return NextResponse.json({ ok: false }, { status: 401 })
  }
  revalidateTag('api-data')
  revalidatePath('/', 'layout')
  return NextResponse.json({ ok: true, at: new Date().toISOString() })
}
