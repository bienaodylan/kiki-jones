import { NextRequest, NextResponse } from 'next/server'

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'https://admin.kikijones.com/api'

export async function POST(request: NextRequest) {
  try {
    const refreshToken = request.cookies.get('refresh_token')?.value

    // Best-effort: blacklist the refresh token on Django
    if (refreshToken) {
      // Read access token from Authorization header (sent by client from memory)
      const authHeader = request.headers.get('Authorization') || ''

      await fetch(`${API_BASE}/auth/logout/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(authHeader ? { Authorization: authHeader } : {}),
        },
        body: JSON.stringify({ refresh: refreshToken }),
      }).catch(() => {})
    }

    // Always clear cookies regardless of Django response
    const response = NextResponse.json({ ok: true })
    response.cookies.delete('refresh_token')
    response.cookies.delete('is_logged_in')
    return response
  } catch {
    const response = NextResponse.json({ ok: true })
    response.cookies.delete('refresh_token')
    response.cookies.delete('is_logged_in')
    return response
  }
}
