import { NextRequest, NextResponse } from 'next/server'

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'https://admin.kikijones.com/api'
const IS_PROD = process.env.NODE_ENV === 'production'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Forward login to Django
    const res = await fetch(`${API_BASE}/auth/login/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })

    const data = await res.json()

    if (!res.ok) {
      return NextResponse.json(data, { status: res.status })
    }

    const accessToken = data.tokens?.access || data.access
    const refreshToken = data.tokens?.refresh || data.refresh

    // Return access token + user to the client (stored in memory only)
    const response = NextResponse.json({
      access: accessToken,
      user: data.user || data,
    })

    // Set refresh token as httpOnly cookie (XSS-proof)
    if (refreshToken) {
      response.cookies.set('refresh_token', refreshToken, {
        httpOnly: true,
        secure: IS_PROD,
        sameSite: 'lax',
        path: '/',
        maxAge: 60 * 60 * 24 * 7, // 7 days — matches Django REFRESH_TOKEN_LIFETIME
      })
    }

    // Session indicator (non-httpOnly so JS can show UI state)
    response.cookies.set('is_logged_in', '1', {
      httpOnly: false,
      secure: IS_PROD,
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 7,
    })

    return response
  } catch {
    return NextResponse.json({ error: 'Erreur de connexion' }, { status: 500 })
  }
}
