import { NextRequest, NextResponse } from 'next/server'

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'https://admin.kikijones.com/api'
const IS_PROD = process.env.NODE_ENV === 'production'

export async function POST(request: NextRequest) {
  try {
    const refreshToken = request.cookies.get('refresh_token')?.value

    if (!refreshToken) {
      return NextResponse.json({ error: 'No session' }, { status: 401 })
    }

    // Ask Django for a new access token
    const res = await fetch(`${API_BASE}/auth/token/refresh/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh: refreshToken }),
    })

    if (!res.ok) {
      // Refresh token is expired / blacklisted — clear cookies
      const response = NextResponse.json({ error: 'Session expired' }, { status: 401 })
      response.cookies.delete('refresh_token')
      response.cookies.delete('is_logged_in')
      return response
    }

    const data = await res.json()

    const response = NextResponse.json({ access: data.access })

    // If Django rotated the refresh token, update the cookie
    if (data.refresh) {
      response.cookies.set('refresh_token', data.refresh, {
        httpOnly: true,
        secure: IS_PROD,
        sameSite: 'lax',
        path: '/',
        maxAge: 60 * 60 * 24 * 7,
      })
    }

    // Keep session indicator alive
    response.cookies.set('is_logged_in', '1', {
      httpOnly: false,
      secure: IS_PROD,
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 24 * 7,
    })

    return response
  } catch {
    return NextResponse.json({ error: 'Refresh failed' }, { status: 500 })
  }
}
