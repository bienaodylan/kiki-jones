﻿'use client'

import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import {
  Package, Truck, CheckCircle, Clock, Settings, Search, ArrowLeft,
} from 'lucide-react'
import {
  searchOrderByNumber, getOrderTracking,
  type Order, type TrackingInfo, type TrackingStep,
  getStatusLabel,
} from '@/lib/api/orders'

const stepIcons: Record<string, any> = {
  pending: Clock,
  confirmed: CheckCircle,
  processing: Settings,
  shipped: Truck,
  delivered: Package,
}

function TrackingProgress({ steps }: { steps: TrackingStep[] }) {
  return (
    <div className="relative">
      {/* Progress Bar */}
      <div className="flex items-center justify-between mb-2">
        {steps.map((step, i) => {
          const Icon = stepIcons[step.status] || Package
          return (
            <div key={step.status} className="flex flex-col items-center relative z-10 flex-1">
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                  step.done
                    ? step.current
                      ? 'bg-black text-white ring-4 ring-black/20'
                      : 'bg-green-500 text-white'
                    : 'bg-gray-200 text-gray-400'
                }`}
              >
                <Icon size={20} />
              </div>
              <span
                className={`text-xs mt-2 font-medium text-center ${
                  step.done ? (step.current ? 'text-black' : 'text-green-600') : 'text-gray-400'
                }`}
              >
                {step.label}
              </span>
              {step.date && (
                <span className="text-[10px] text-gray-400 mt-0.5">
                  {new Date(step.date).toLocaleDateString('fr-FR', {
                    day: 'numeric',
                    month: 'short',
                  })}
                </span>
              )}
            </div>
          )
        })}
      </div>
      {/* Connecting lines */}
      <div className="absolute top-6 left-0 right-0 flex px-[8%]" style={{ zIndex: 0 }}>
        {steps.slice(0, -1).map((step, i) => (
          <div key={i} className="flex-1 mx-1">
            <div
              className={`h-1 rounded-full transition-all ${
                steps[i + 1]?.done ? 'bg-green-500' : step.done ? 'bg-green-500' : 'bg-gray-200'
              }`}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

export default function TrackOrderPage() {
  const searchParams = useSearchParams()
  const [orderNumber, setOrderNumber] = useState(searchParams.get('order') || '')
  const [loading, setLoading] = useState(false)
  const [order, setOrder] = useState<Order | null>(null)
  const [tracking, setTracking] = useState<TrackingInfo | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Auto-search if order param is provided
  useEffect(() => {
    const num = searchParams.get('order')
    if (num) {
      setOrderNumber(num)
      handleSearch(num)
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const handleSearch = async (num?: string) => {
    const searchNum = (num || orderNumber).trim()
    if (!searchNum) return
    setLoading(true)
    setError(null)
    setOrder(null)
    setTracking(null)

    try {
      const foundOrder = await searchOrderByNumber(searchNum)
      if (foundOrder) {
        setOrder(foundOrder)
        // Fetch tracking info
        try {
          const trackingInfo = await getOrderTracking(foundOrder.id)
          setTracking(trackingInfo)
        } catch {
          // Tracking endpoint may fail — still show order
        }
      } else {
        setError('Commande introuvable. Vérifiez votre numéro de commande.')
      }
    } catch {
      setError('Erreur lors de la recherche. Veuillez réessayer.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-gray-600 hover:text-black mb-6 transition-colors"
        >
          <ArrowLeft size={18} />
          Retour à l&apos;accueil
        </Link>

        <h1 className="text-3xl font-light mb-8">Suivre ma commande</h1>

        {/* Search Form */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <p className="text-gray-600 text-sm mb-4">
            Entrez votre numéro de commande (ex: ORD-12345678) pour voir l&apos;avancement de votre livraison.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSearch()
            }}
            className="flex gap-3"
          >
            <input
              type="text"
              value={orderNumber}
              onChange={(e) => setOrderNumber(e.target.value)}
              placeholder="ORD-12345678"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-sm"
            />
            <button
              type="submit"
              disabled={loading || !orderNumber.trim()}
              className="px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 disabled:opacity-50 transition-colors flex items-center gap-2"
            >
              <Search size={16} />
              {loading ? 'Recherche...' : 'Suivre'}
            </button>
          </form>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-8 text-sm">
            {error}
          </div>
        )}

        {/* Tracking Results */}
        {order && (
          <div className="space-y-6">
            {/* Order Header */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-xl font-medium">Commande #{order.order_number}</h2>
                <span className="text-sm text-gray-500">
                  {new Date(order.created_at).toLocaleDateString('fr-FR', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </span>
              </div>
              <p className="text-sm text-gray-500">
                Statut : <strong>{getStatusLabel(order.status)}</strong>
              </p>
            </div>

            {/* Visual Tracking Steps */}
            {tracking && tracking.steps.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm p-8">
                <h3 className="text-lg font-medium mb-8">Suivi de livraison</h3>
                <TrackingProgress steps={tracking.steps} />

                {/* Tracking Number */}
                {tracking.tracking_number && (
                  <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm font-medium text-blue-800">
                      <Truck size={16} className="inline mr-2" />
                      Numéro de suivi : <strong>{tracking.tracking_number}</strong>
                      {tracking.carrier && ` (${tracking.carrier})`}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Status History */}
            {tracking && tracking.history.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-medium mb-4">Historique détaillé</h3>
                <div className="space-y-4">
                  {tracking.history.map((entry, i) => (
                    <div key={entry.id} className="flex items-start gap-3">
                      <div
                        className={`w-3 h-3 rounded-full mt-1.5 flex-shrink-0 ${
                          i === 0 ? 'bg-black' : 'bg-gray-300'
                        }`}
                      />
                      <div>
                        <p className="font-medium text-sm">{getStatusLabel(entry.status)}</p>
                        {entry.note && <p className="text-sm text-gray-500">{entry.note}</p>}
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(entry.created_at).toLocaleDateString('fr-FR', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Link to full order page */}
            <div className="text-center">
              <Link
                href={`/compte/commandes/${order.id}`}
                className="text-sm text-black underline hover:text-gray-600 transition-colors"
              >
                Voir le détail complet de ma commande
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
