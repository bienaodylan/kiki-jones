﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function CentreAidePage() {
  return <StaticPageLayout slug="centre-aide" />
}
