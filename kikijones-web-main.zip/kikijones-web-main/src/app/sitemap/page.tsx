﻿'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { getParentCategories, Category } from '@/lib/api'

type LinkItem = { href: string; label: string }

const SECTIONS: { title: string; links: LinkItem[] }[] = [
  {
    title: 'Boutique',
    links: [
      { href: '/produits', label: 'Tous les produits' },
      { href: '/produits?sort=newest', label: 'Nouveautés' },
      { href: '/tendances', label: 'Tendances' },
      { href: '/promotions', label: 'Promotions' },
      { href: '/gift-cards', label: 'Cartes cadeaux' },
      { href: '/gift-card-balance', label: 'Vérifier le solde d’une carte cadeau' },
    ],
  },
  {
    title: 'Mon compte',
    links: [
      { href: '/login', label: 'Se connecter' },
      { href: '/register', label: 'Créer un compte' },
      { href: '/compte', label: 'Mon compte' },
      { href: '/wishlist', label: 'Mes favoris' },
      { href: '/panier', label: 'Mon panier' },
      { href: '/track-order', label: 'Suivre ma commande' },
      { href: '/recompenses', label: 'Récompenses' },
      { href: '/roue-chance', label: 'Roue de la chance' },
    ],
  },
  {
    title: 'Besoin d’aide',
    links: [
      { href: '/centre-aide', label: 'Centre d’aide' },
      { href: '/livraison', label: 'Informations de livraison' },
      { href: '/retours', label: 'Retours' },
      { href: '/guide-tailles', label: 'Guide des tailles' },
      { href: '/contact', label: 'Nous contacter' },
    ],
  },
  {
    title: 'Entreprise',
    links: [
      { href: '/about', label: 'À propos' },
      { href: '/magasins', label: 'Nos magasins' },
      { href: '/carrieres', label: 'Carrières' },
      { href: '/collab', label: 'Envie de collaborer ?' },
    ],
  },
  {
    title: 'Informations légales',
    links: [
      { href: '/terms', label: 'Conditions d’utilisation' },
      { href: '/privacy', label: 'Politique de confidentialité' },
      { href: '/privacy-choices', label: 'Vos choix de confidentialité' },
      { href: '/promo-terms', label: 'Conditions des promotions' },
      { href: '/supply-chain', label: 'Loi sur la chaîne d’approvisionnement' },
    ],
  },
]

export default function SitemapPage() {
  const [categories, setCategories] = useState<Category[]>([])

  useEffect(() => {
    getParentCategories()
      .then((c) => setCategories(c || []))
      .catch(() => setCategories([]))
  }, [])

  return (
    <main className="container-custom py-10 md:py-16">
      <h1 className="text-3xl md:text-4xl font-black uppercase tracking-tight text-center mb-2">Plan du site</h1>
      <p className="text-center text-gray-600 mb-10 md:mb-14">Retrouvez rapidement toutes les pages de KikiJones.</p>

      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {categories.length > 0 && (
          <section>
            <h2 className="text-sm font-black uppercase tracking-widest border-b-2 border-black pb-2 mb-4">Catégories</h2>
            <ul className="space-y-2">
              {categories.map((c) => (
                <li key={c.id}>
                  <Link href={`/categories/${c.slug}`} className="text-gray-700 hover:text-black hover:underline">
                    {c.name}
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        )}

        {SECTIONS.map((section) => (
          <section key={section.title}>
            <h2 className="text-sm font-black uppercase tracking-widest border-b-2 border-black pb-2 mb-4">{section.title}</h2>
            <ul className="space-y-2">
              {section.links.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="text-gray-700 hover:text-black hover:underline">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </main>
  )
}
