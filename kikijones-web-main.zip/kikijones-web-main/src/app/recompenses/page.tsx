'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Gift, Star, Calendar, Package, ChevronRight, Zap, Trophy } from 'lucide-react'
import { fetchAPI, API_ENDPOINTS } from '@/lib/api/config'
import { isAuthenticated } from '@/lib/api/auth'
import { bootstrapAuth } from '@/lib/auth-store'

interface CheckinStatus {
  checked_in_today: boolean
  current_streak: number
  next_points: number
  streak_bonuses: Record<number, number>
  special_bonuses: Record<number, string>
  calendar: { date: string; streak_day: number; points_earned: number; bonus_earned: string }[]
}

interface MysteryBox {
  id: string
  name: string
  box_type: string
  box_type_display: string
  description: string
  points_cost: number
  is_active: boolean
  max_opens_per_day: number
  image: string | null
}

interface PointsData {
  points: number
  level: string
  current_tier: any
  next_tier: any
  points_to_next: number
  history: any[]
}

interface Reward {
  id: string
  name: string
  description: string
  reward_type: string
  reward_type_display: string
  points_cost: number
  discount_value: number
  is_percentage: boolean
  stock: number
  image: string | null
}

const boxColors: Record<string, string> = {
  bronze: ' ',
  silver: 'from-gray-400 to-gray-600',
  gold: ' ',
  vip: ' ',
}

const boxEmojis: Record<string, string> = {
  bronze: '🎁',
  silver: '🎀',
  gold: '👑',
  vip: '💎',
}

export default function RewardsPage() {
  const [authed, setAuthed] = useState(false)
  const [checkinStatus, setCheckinStatus] = useState<CheckinStatus | null>(null)
  const [mysteryBoxes, setMysteryBoxes] = useState<MysteryBox[]>([])
  const [pointsData, setPointsData] = useState<PointsData | null>(null)
  const [rewards, setRewards] = useState<Reward[]>([])
  const [loading, setLoading] = useState(true)
  const [checkinLoading, setCheckinLoading] = useState(false)
  const [boxOpenLoading, setBoxOpenLoading] = useState<string | null>(null)
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null)
  const [prizeAnimation, setPrizeAnimation] = useState<{ emoji: string; label: string } | null>(null)

  useEffect(() => {
    bootstrapAuth().then(() => {
      setAuthed(isAuthenticated())
    })
  }, [])

  useEffect(() => {
    const controller = new AbortController()
    const load = async () => {
      try {
        await bootstrapAuth()
        const promises: Promise<any>[] = [
          fetchAPI<MysteryBox[]>(API_ENDPOINTS.gamificationMysteryBoxes).catch(() => []),
          fetchAPI<Reward[]>(`${API_ENDPOINTS.gamificationRewards}`).catch(() => ({ results: [] })),
        ]
        if (isAuthenticated()) {
          promises.push(
            fetchAPI<CheckinStatus>(API_ENDPOINTS.gamificationCheckinStatus).catch(() => null),
            fetchAPI<PointsData>(API_ENDPOINTS.gamificationPoints).catch(() => null),
          )
        }
        const [boxes, rewardsRes, checkin, points] = await Promise.all(promises)
        if (controller.signal.aborted) return
        setMysteryBoxes(Array.isArray(boxes) ? boxes : [])
        setRewards(Array.isArray(rewardsRes) ? rewardsRes : rewardsRes?.results || [])
        if (checkin) setCheckinStatus(checkin)
        if (points) setPointsData(points)
      } catch (e) {
        if (!controller.signal.aborted) console.error('Failed to load gamification data:', e)
      } finally {
        if (!controller.signal.aborted) setLoading(false)
      }
    }
    load()
    return () => controller.abort()
  }, [])

  const handleCheckin = async () => {
    if (checkinLoading) return
    setCheckinLoading(true)
    try {
      const result = await fetchAPI<any>(API_ENDPOINTS.gamificationCheckin, { method: 'POST' })
      setNotification({ type: 'success', message: result.message })
      // Refresh data
      const [checkin, points] = await Promise.all([
        fetchAPI<CheckinStatus>(API_ENDPOINTS.gamificationCheckinStatus).catch(() => null),
        fetchAPI<PointsData>(API_ENDPOINTS.gamificationPoints).catch(() => null),
      ])
      if (checkin) setCheckinStatus(checkin)
      if (points) setPointsData(points)
      
      if (result.coupon_code) {
        setTimeout(() => {
          setNotification({ type: 'success', message: `Bonus de série ! Code: ${result.coupon_code}` })
        }, 2000)
      }
    } catch (e: any) {
      setNotification({ type: 'error', message: e?.body?.error || 'Erreur lors du check-in' })
    } finally {
      setCheckinLoading(false)
      setTimeout(() => setNotification(null), 5000)
    }
  }

  const handleOpenBox = async (box: MysteryBox) => {
    if (boxOpenLoading) return
    setBoxOpenLoading(box.id)
    try {
      const result = await fetchAPI<any>(API_ENDPOINTS.gamificationOpenBox(box.id), { method: 'POST' })
      setPrizeAnimation({ emoji: result.prize?.emoji || '🎁', label: result.prize?.label || result.message })
      // Refresh points
      const points = await fetchAPI<PointsData>(API_ENDPOINTS.gamificationPoints).catch(() => null)
      if (points) setPointsData(points)
      
      setTimeout(() => {
        setPrizeAnimation(null)
        if (result.coupon_code) {
          setNotification({ type: 'success', message: `Code promo : ${result.coupon_code}` })
          setTimeout(() => setNotification(null), 8000)
        }
      }, 3000)
    } catch (e: any) {
      setNotification({ type: 'error', message: e?.body?.error || 'Erreur lors de l\'ouverture' })
      setTimeout(() => setNotification(null), 5000)
    } finally {
      setBoxOpenLoading(null)
    }
  }

  const handleRedeem = async (reward: Reward) => {
    if (!confirm(`Échanger ${reward.points_cost} points contre "${reward.name}" ?`)) return
    try {
      const result = await fetchAPI<any>(`${API_ENDPOINTS.gamificationRewards}${reward.id}/redeem/`, { method: 'POST' })
      setNotification({ type: 'success', message: result.message + (result.coupon_code ? ` Code: ${result.coupon_code}` : '') })
      const points = await fetchAPI<PointsData>(API_ENDPOINTS.gamificationPoints).catch(() => null)
      if (points) setPointsData(points)
    } catch (e: any) {
      setNotification({ type: 'error', message: e?.body?.error || 'Erreur lors de l\'échange' })
    }
    setTimeout(() => setNotification(null), 8000)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5F5F5] py-12">
        <div className="container mx-auto px-4 max-w-5xl flex justify-center py-20">
          <div className="animate-spin rounded-none h-10 w-10 border-b-2 border-black" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white py-8 grayscale">
      <div className="container mx-auto px-4 max-w-5xl">
        {/* Notification */}
        {notification && (
          <div className={`fixed top-4 right-4 z-50 px-6 py-3 rounded-none  text-white text-sm font-medium animate-slide-in ${
            notification.type === 'success' ? 'bg-black' : 'bg-black'
          }`}>
            {notification.message}
          </div>
        )}

        {/* Prize Animation Overlay */}
        {prizeAnimation && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
            <div className="bg-white rounded-none p-12 text-center animate-bounce-in ">
              <div className="text-8xl mb-4 animate-pulse">{prizeAnimation.emoji}</div>
              <h2 className="text-2xl font-bold mb-2">Félicitations !</h2>
              <p className="text-black/55">{prizeAnimation.label}</p>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold mb-3">
            <span className="   text-black text-black">
              KikiRewards
            </span>
          </h1>
          <p className="text-black/55">Gagnez des points, ouvrez des cadeaux, profitez de réductions exclusives !</p>
          
          {/* Points Badge */}
          {authed && pointsData && (
            <div className="inline-flex items-center gap-3 mt-4 bg-black text-white px-6 py-3 rounded-none">
              <Star size={20} className="text-black" />
              <span className="font-bold text-lg">{pointsData.points.toLocaleString()} points</span>
              {pointsData.current_tier && (
                <span className="bg-white/20 px-3 py-0.5 rounded-none text-xs font-medium">
                  {pointsData.current_tier.badge_icon} {pointsData.current_tier.name}
                </span>
              )}
            </div>
          )}
        </div>

        {!authed && (
          <div className="bg-white rounded-none  p-8 text-center mb-8">
            <Gift size={48} className="mx-auto mb-4 text-black/55" />
            <h2 className="text-xl font-medium mb-2">Connectez-vous pour profiter des récompenses</h2>
            <p className="text-black/55 text-sm mb-4">Check-in quotidien, boîtes mystères, roue de la chance et plus !</p>
            <a href="/login" className="inline-block bg-black text-white px-8 py-3 rounded-none hover:bg-gray-800 transition">
              Se connecter
            </a>
          </div>
        )}

        {/* Quick Actions Grid */}
        <div className="grid md:grid-cols-3 gap-4 mb-10">
          {/* Daily Check-in Card */}
          <div className="bg-white rounded-none  p-6 border-2 border-transparent hover:border-black transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-[#F5F5F5] rounded-none flex items-center justify-center">
                <Calendar size={24} className="text-black" />
              </div>
              <div>
                <h3 className="font-bold">Check-in Quotidien</h3>
                <p className="text-xs text-black/55">
                  {checkinStatus?.checked_in_today
                    ? `Série de ${checkinStatus.current_streak} jour${checkinStatus.current_streak > 1 ? 's' : ''} !`
                    : `+${checkinStatus?.next_points || 5} points aujourd'hui`
                  }
                </p>
              </div>
            </div>
            
            {/* Streak dots */}
            {checkinStatus && (
              <div className="flex gap-1.5 mb-4">
                {[1, 2, 3, 4, 5, 6, 7].map((day) => {
                  const cycleDay = ((checkinStatus.current_streak) % 7) || 7
                  const isDone = checkinStatus.checked_in_today ? day <= (cycleDay) : day <= (cycleDay)
                  const isToday = checkinStatus.checked_in_today ? day === cycleDay : day === cycleDay + 1
                  return (
                    <div
                      key={day}
                      className={`flex-1 h-8 rounded-none flex items-center justify-center text-xs font-bold ${
                        isDone && checkinStatus.checked_in_today
                          ? 'bg-black text-black'
                          : isToday && !checkinStatus.checked_in_today
                          ? 'bg-[#F5F5F5] text-black ring-2 ring-black'
                          : 'bg-[#F5F5F5] text-black/55'
                      }`}
                    >
                      {checkinStatus.streak_bonuses?.[day] || 5}
                    </div>
                  )
                })}
              </div>
            )}

            <button
              onClick={handleCheckin}
              disabled={!authed || checkinStatus?.checked_in_today || checkinLoading}
              className={`w-full py-2.5 rounded-none font-medium text-sm transition-all ${
                checkinStatus?.checked_in_today
                  ? 'bg-[#F5F5F5] text-black cursor-default'
                  : 'bg-black text-black hover:bg-black/85 disabled:opacity-50'
              }`}
            >
              {checkinLoading ? 'Chargement...' : checkinStatus?.checked_in_today ? '✓ Check-in fait !' : 'Check-in'}
            </button>
          </div>

          {/* Lucky Wheel Card */}
          <Link
            href="/roue-chance"
            className="bg-white rounded-none  p-6 border-2 border-transparent hover:border-black transition-all group"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-[#F5F5F5] rounded-none flex items-center justify-center">
                <Zap size={24} className="text-black" />
              </div>
              <div>
                <h3 className="font-bold">Roue de la Chance</h3>
                <p className="text-xs text-black/55">Tournez pour gagner des prix</p>
              </div>
            </div>
            <div className="text-6xl text-center mb-3 group-hover:animate-spin-slow">🎡</div>
            <div className="w-full py-2.5 bg-black text-white rounded-none font-medium text-sm text-center group-hover:bg-black/85 transition">
              Jouer
            </div>
          </Link>

          {/* Loyalty Progress Card */}
          <div className="bg-white rounded-none  p-6 border-2 border-transparent hover:border-black transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-[#F5F5F5] rounded-none flex items-center justify-center">
                <Trophy size={24} className="text-black" />
              </div>
              <div>
                <h3 className="font-bold">Mon Niveau</h3>
                <p className="text-xs text-black/55">
                  {pointsData?.current_tier?.name || 'Débutant'}
                </p>
              </div>
            </div>
            {pointsData?.next_tier && (
              <>
                <div className="mb-2">
                  <div className="flex justify-between text-xs text-black/55 mb-1">
                    <span>{pointsData.current_tier?.name || 'Débutant'}</span>
                    <span>{pointsData.next_tier.name}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-none h-2.5">
                    <div
                      className="bg-black h-2.5 rounded-none transition-all"
                      style={{
                        width: `${Math.min(100, ((pointsData.points - (pointsData.current_tier?.min_points || 0)) / (pointsData.next_tier.min_points - (pointsData.current_tier?.min_points || 0))) * 100)}%`
                      }}
                    />
                  </div>
                </div>
                <p className="text-xs text-black/55 text-center">
                  Plus que <strong>{pointsData.points_to_next}</strong> points pour le prochain niveau
                </p>
              </>
            )}
            {!pointsData?.next_tier && pointsData?.current_tier && (
              <p className="text-sm text-center text-black font-medium">
                {pointsData.current_tier.badge_icon} Niveau maximum atteint !
              </p>
            )}
          </div>
        </div>

        {/* Mystery Gift Boxes */}
        {mysteryBoxes.length > 0 && (
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Gift size={28} /> Boîtes Mystères
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {mysteryBoxes.map((box) => (
                <div
                  key={box.id}
                  className="bg-white rounded-none  overflow-hidden border hover:shadow-md transition-all"
                >
                  <div className={`h-32  ${boxColors[box.box_type] || 'from-gray-400 to-gray-600'} flex items-center justify-center`}>
                    <span className="text-6xl">{boxEmojis[box.box_type] || '🎁'}</span>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-sm">{box.name}</h3>
                    <p className="text-xs text-black/55 mb-3">{box.description || box.box_type_display}</p>
                    <button
                      onClick={() => handleOpenBox(box)}
                      disabled={!authed || boxOpenLoading === box.id}
                      className="w-full py-2 bg-black text-white rounded-none text-sm font-medium hover:bg-gray-800 disabled:opacity-50 transition"
                    >
                      {boxOpenLoading === box.id ? 'Ouverture...' : box.points_cost > 0 ? `Ouvrir (${box.points_cost} pts)` : 'Ouvrir gratuitement'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Rewards Shop */}
        {rewards.length > 0 && (
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Package size={28} /> Boutique Récompenses
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {rewards.map((reward) => (
                <div
                  key={reward.id}
                  className="bg-white rounded-none  p-5 border hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-sm">{reward.name}</h3>
                      <p className="text-xs text-black/55">{reward.reward_type_display}</p>
                    </div>
                    <span className="bg-[#F5F5F5] text-black text-xs font-bold px-2.5 py-1 rounded-none">
                      {reward.points_cost} pts
                    </span>
                  </div>
                  {reward.description && (
                    <p className="text-xs text-black/55 mb-3">{reward.description}</p>
                  )}
                  {reward.discount_value > 0 && (
                    <p className="text-lg font-bold text-black mb-3">
                      -{reward.discount_value}{reward.is_percentage ? '%' : ' FCFA'}
                    </p>
                  )}
                  <button
                    onClick={() => handleRedeem(reward)}
                    disabled={!authed || (pointsData ? pointsData.points < reward.points_cost : true)}
                    className="w-full py-2 bg-black text-white rounded-none text-sm font-medium hover:bg-gray-800 disabled:opacity-50 transition"
                  >
                    Échanger
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* How it Works */}
        <div className="bg-white rounded-none  p-8 mb-10">
          <h2 className="text-xl font-bold mb-6 text-center">Comment ça marche ?</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { icon: '🛒', title: 'Achetez', desc: 'Gagnez des points sur chaque achat' },
              { icon: '📅', title: 'Check-in', desc: 'Points bonus chaque jour de connexion' },
              { icon: '🎡', title: 'Jouez', desc: 'Tournez la roue pour des surprises' },
              { icon: '🎁', title: 'Échangez', desc: 'Convertissez vos points en réductions' },
            ].map((item) => (
              <div key={item.title} className="text-center">
                <div className="text-4xl mb-3">{item.icon}</div>
                <h3 className="font-bold text-sm mb-1">{item.title}</h3>
                <p className="text-xs text-black/55">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
