﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function LivraisonPage() {
  return <StaticPageLayout slug="livraison" />
}
