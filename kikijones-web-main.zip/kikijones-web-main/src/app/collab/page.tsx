﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function CollabPage() {
  return <StaticPageLayout slug="collaboration" />
}
