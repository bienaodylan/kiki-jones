'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { sanitizeHTML } from '@/lib/sanitize';
import { API_ENDPOINTS } from '@/lib/api/config';

interface StaticPage {
  id: string;
  title: string;
  slug: string;
  content: string;
  meta_title: string;
  meta_description: string;
  updated_at: string;
}

export default function StaticPageView() {
  const params = useParams();
  const slug = params.slug as string;
  const [page, setPage] = useState<StaticPage | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;

    const fetchPage = async () => {
      try {
        setLoading(true);
        const response = await fetch(
          `${API_ENDPOINTS.pages}${slug}/`
        );

        if (!response.ok) {
          if (response.status === 404) {
            setError('Page non trouvée');
          } else {
            setError('Erreur lors du chargement de la page');
          }
          return;
        }

        const data = await response.json();
        setPage(data);
      } catch (err) {
        console.error('Error fetching page:', err);
        setError('Erreur de connexion');
      } finally {
        setLoading(false);
      }
    };

    fetchPage();
  }, [slug]);

  // Update page title dynamically
  useEffect(() => {
    if (page) {
      document.title = page.meta_title || page.title || 'KikiJones'
    }
  }, [page])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">404</h1>
          <p className="text-gray-600 mb-4">{error || 'Page non trouvée'}</p>
          <a href="/" className="text-black underline">
            Retour à l'accueil
          </a>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-white">
        {/* Breadcrumb */}
        <div className="border-b">
          <div className="container mx-auto px-4 py-3">
            <nav className="text-sm">
              <a href="/" className="text-gray-500 hover:text-black">
                Accueil
              </a>
              <span className="mx-2 text-gray-400">/</span>
              <span className="text-black">{page.title}</span>
            </nav>
          </div>
        </div>

        {/* Page Content */}
        <div className="container mx-auto px-4 py-8 max-w-5xl">
          <article className="prose prose-lg max-w-none">
            <div
              dangerouslySetInnerHTML={{ __html: sanitizeHTML(page.content) }}
              className="static-page-content"
            />
          </article>

          {/* Last updated */}
          <div className="mt-12 pt-6 border-t text-sm text-gray-500">
            Dernière mise à jour :{' '}
            {new Date(page.updated_at).toLocaleDateString('fr-FR', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </div>
        </div>
      </div>

      <style jsx global>{`
        /* Styles pour le contenu des pages statiques */
        .static-page-content {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          line-height: 1.8;
          color: #1a1a1a;
        }

        .static-page-content h1 {
          font-size: 2.5rem;
          font-weight: 700;
          margin-bottom: 2rem;
          color: #000;
        }

        .static-page-content h2 {
          font-size: 2rem;
          font-weight: 600;
          margin-top: 3rem;
          margin-bottom: 1.5rem;
          color: #000;
        }

        .static-page-content h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-top: 2rem;
          margin-bottom: 1rem;
          color: #000;
        }

        .static-page-content p {
          margin-bottom: 1.5rem;
          color: #333;
        }

        .static-page-content ul,
        .static-page-content ol {
          margin-bottom: 1.5rem;
          padding-left: 2rem;
        }

        .static-page-content li {
          margin-bottom: 0.5rem;
        }

        .static-page-content a {
          color: #000;
          text-decoration: underline;
        }

        .static-page-content a:hover {
          color: #666;
        }

        .static-page-content table {
          width: 100%;
          margin: 2rem 0;
          border-collapse: collapse;
        }

        .static-page-content table th,
        .static-page-content table td {
          padding: 1rem;
          border: 1px solid #ddd;
          text-align: left;
        }

        .static-page-content table th {
          background-color: #f5f5f5;
          font-weight: 600;
        }

        .static-page-content table tbody tr:nth-child(even) {
          background-color: #fafafa;
        }

        .static-page-content section {
          margin-bottom: 3rem;
        }

        .static-page-content .faq-item,
        .static-page-content .help-item,
        .static-page-content .benefit,
        .static-page-content .feature,
        .static-page-content .value,
        .static-page-content .stat,
        .static-page-content .store,
        .static-page-content .job-listing,
        .static-page-content .collab-type {
          background: #f9f9f9;
          padding: 1.5rem;
          border-radius: 8px;
          margin-bottom: 1.5rem;
        }

        .static-page-content form {
          background: #f9f9f9;
          padding: 2rem;
          border-radius: 8px;
        }

        .static-page-content .form-group {
          margin-bottom: 1.5rem;
        }

        .static-page-content label {
          display: block;
          font-weight: 600;
          margin-bottom: 0.5rem;
          color: #000;
        }

        .static-page-content input,
        .static-page-content textarea,
        .static-page-content select {
          width: 100%;
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: 4px;
          font-size: 1rem;
        }

        .static-page-content input:focus,
        .static-page-content textarea:focus,
        .static-page-content select:focus {
          outline: none;
          border-color: #000;
        }

        .static-page-content button,
        .static-page-content .apply-btn,
        .static-page-content .collab-btn,
        .static-page-content .buy-btn,
        .static-page-content .check-btn,
        .static-page-content .submit-btn {
          background: #000;
          color: #fff;
          padding: 0.75rem 2rem;
          border: none;
          border-radius: 4px;
          font-weight: 600;
          cursor: pointer;
          display: inline-block;
          text-decoration: none;
          transition: background 0.3s;
        }

        .static-page-content button:hover,
        .static-page-content .apply-btn:hover,
        .static-page-content .collab-btn:hover,
        .static-page-content .buy-btn:hover,
        .static-page-content .check-btn:hover,
        .static-page-content .submit-btn:hover {
          background: #333;
        }

        .static-page-content small {
          font-size: 0.875rem;
          color: #666;
        }

        /* Grid layouts */
        .static-page-content .benefits-grid,
        .static-page-content .features-grid,
        .static-page-content .values-grid,
        .static-page-content .stats-grid,
        .static-page-content .amounts-grid,
        .static-page-content .tips-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
          margin: 2rem 0;
        }

        .static-page-content .contact-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 3rem;
          margin: 2rem 0;
        }

        .static-page-content .sitemap-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 2rem;
          margin: 2rem 0;
        }

        @media (max-width: 768px) {
          .static-page-content h1 {
            font-size: 2rem;
          }

          .static-page-content h2 {
            font-size: 1.5rem;
          }

          .static-page-content .contact-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </>
  );
}
