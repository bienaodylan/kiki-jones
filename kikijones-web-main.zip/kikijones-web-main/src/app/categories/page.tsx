'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight } from 'lucide-react'
import { getParentCategories, Category } from '@/lib/api'

/** "Acheter par Catégorie": the theme's 4-column photo grid, with the sub-categories under each tile name. */
export default function CategoriesPage() {
  const router = useRouter()
  const [categories, setCategories] = useState<Category[]>([])
  useEffect(() => { getParentCategories().then(setCategories).catch(() => {}) }, [])
  return (
    <main className="bg-white text-black min-h-screen pb-12">
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 pt-8 pb-6 border-b border-black/10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <p className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-black/45">KIKI JONES · Répertoire Garde-Robe</p>
            <h1 className="text-3xl sm:text-5xl font-bold tracking-[-0.025em] text-black leading-[1.04]">Acheter par Catégorie</h1>
            <p className="text-xs sm:text-sm font-light text-black/65 leading-relaxed">Parcourez nos essentiels par type de pièce — Robes, Ensembles, Combinaisons, Sport, Shorts, Jeans, Chaussures, Lunettes, Sacs et Bijoux.</p>
          </div>
          <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-black/50 tabular-nums">{categories.length} Catégories</p>
        </div>
      </section>
      <section className="w-full bg-black">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-0">
          {categories.map((cat) => {
            const photo = (cat.display_image || cat.image) as string | null
            const subs = cat.subcategories || []
            return (
              <button key={cat.id} type="button" onClick={() => router.push(`/produits?category=${cat.slug}`)} className="group relative aspect-[3/4] w-full overflow-hidden bg-black text-left cursor-pointer border-r border-b border-white/10">
                {photo && <img src={photo} alt={cat.name} className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]" />}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 md:bottom-7 md:left-6 md:right-6 space-y-2">
                  {subs.length > 0 && <p className="text-[9.5px] font-bold uppercase tracking-[0.2em] text-white/75 line-clamp-2">{subs.slice(0, 3).map((s) => s.name).join(' · ')}</p>}
                  <div className="flex items-end justify-between gap-2">
                    <h2 className="text-xl sm:text-2xl font-bold uppercase tracking-[0.06em] text-white underline decoration-white/60 underline-offset-[6px] group-hover:decoration-white">{cat.name}</h2>
                    <span className="w-8 h-8 rounded-full bg-white text-black inline-flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:translate-x-0.5"><ArrowRight className="w-3.5 h-3.5" /></span>
                  </div>
                </div>
              </button>
            )
          })}
        </div>
      </section>
    </main>
  )
}
