import { redirect } from 'next/navigation'

// A category page is the theme's catalogue filtered on that category (works even when the category is still empty).
export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  redirect(`/produits?category=${encodeURIComponent(slug)}`)
}
