import { redirect } from 'next/navigation'

export default function NouveautesPage() {
  redirect('/produits?sort=newest')
}
