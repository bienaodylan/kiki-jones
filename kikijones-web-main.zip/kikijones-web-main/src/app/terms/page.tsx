'use client'

import { useEffect, useState } from 'react'
import { sanitizeHTML } from '@/lib/sanitize'

export default function TermsPage() {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setContent(`
      <div>
        <h2>1. Acceptation des Conditions</h2>
        
        <p>En accédant et en utilisant le site kikijones.com, vous acceptez d'être lié par ces conditions d'utilisation. Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser notre site.</p>
        
        <h2>2. Utilisation du Site</h2>
        
        <h3>Vous vous engagez à:</h3>
        <ul>
          <li>Fournir des informations exactes et à jour</li>
          <li>Maintenir la confidentialité de votre compte</li>
          <li>Utiliser le site de manière légale et éthique</li>
          <li>Ne pas perturber le fonctionnement du site</li>
          <li>Ne pas copier ou distribuer le contenu sans autorisation</li>
        </ul>
        
        <h2>3. Commandes et Paiements</h2>
        
        <h3>Passation de Commande</h3>
        <p>Une commande constitue une offre d'achat. Nous nous réservons le droit d'accepter ou de refuser toute commande pour quelque raison que ce soit.</p>
        
        <h3>Prix</h3>
        <ul>
          <li>Tous les prix sont en Francs CFA (XOF)</li>
          <li>Les prix peuvent changer sans préavis</li>
          <li>Le prix applicable est celui affiché au moment de la commande</li>
          <li>Les prix incluent la TVA</li>
        </ul>
        
        <h3>Paiement</h3>
        <ul>
          <li>Paiement sécurisé par carte bancaire ou mobile money</li>
          <li>Votre commande est confirmée après validation du paiement</li>
          <li>En cas d'échec du paiement, la commande sera annulée</li>
        </ul>
        
        <h2>4. Livraison</h2>
        
        <p>Les délais de livraison sont indicatifs et peuvent varier. Consultez notre <a href="/livraison">page livraison</a> pour plus de détails.</p>
        
        <ul>
          <li>Livraison standard: 3-5 jours ouvrables</li>
          <li>Livraison express: 1-2 jours ouvrables</li>
          <li>Retrait en magasin: Disponible sous 2h</li>
        </ul>
        
        <h2>5. Retours et Remboursements</h2>
        
        <p>Vous disposez de 30 jours pour retourner un article. Consultez notre <a href="/retours">politique de retour complète</a>.</p>
        
        <h3>Conditions de Retour</h3>
        <ul>
          <li>Article non porté et non lavé</li>
          <li>Étiquettes intactes</li>
          <li>Emballage d'origine</li>
          <li>Preuve d'achat</li>
        </ul>
        
        <h2>6. Propriété Intellectuelle</h2>
        
        <p>Tout le contenu du site (textes, images, logos, designs) est la propriété de KikiJones ou de ses partenaires et est protégé par les lois sur la propriété intellectuelle.</p>
        
        <h3>Vous ne pouvez pas:</h3>
        <ul>
          <li>Copier, reproduire ou distribuer le contenu</li>
          <li>Utiliser nos marques sans autorisation écrite</li>
          <li>Extraire des données du site de manière automatisée</li>
        </ul>
        
        <h2>7. Limitation de Responsabilité</h2>
        
        <p>KikiJones ne peut être tenu responsable de:</p>
        <ul>
          <li>Dommages indirects ou consécutifs</li>
          <li>Interruption du service</li>
          <li>Erreurs ou inexactitudes dans le contenu</li>
          <li>Actions de tiers</li>
        </ul>
        
        <h2>8. Protection des Données</h2>
        
        <p>Vos données personnelles sont traitées conformément à notre <a href="/privacy">Politique de Confidentialité</a>.</p>
        
        <h2>9. Modifications</h2>
        
        <p>Nous nous réservons le droit de modifier ces conditions à tout moment. Les modifications prendront effet dès leur publication sur cette page.</p>
        
        <h2>10. Droit Applicable</h2>
        
        <p>Ces conditions sont régies par les lois de la Côte d'Ivoire. Tout litige sera soumis à la juridiction exclusive des tribunaux d'Abidjan.</p>
        
        <h2>11. Contact</h2>
        
        <p>Pour toute question concernant ces conditions:</p>
        <ul>
          <li>Email: <a href="mailto:contact@kikijones.com">contact@kikijones.com</a></li>
          <li>Téléphone: +225 0172147737</li>
          <li>Adresse: Abidjan, Côte d'Ivoire</li>
        </ul>
        
        <p><strong>Date d'entrée en vigueur:</strong> 27 janvier 2026</p>
      </div>
    `)
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-white">
        <div className="max-w-3xl mx-auto px-5 md:px-10 pt-12 pb-6">
          <nav className="text-[10.5px] font-bold uppercase tracking-[0.24em] mb-3 flex items-center gap-2 text-black/50">
            <a href="/" className="hover:text-black transition-colors">Accueil</a>
            <span>/</span>
            <span className="text-black">Conditions d'Utilisation</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl font-bold tracking-[-0.025em] text-black">
            Conditions d'Utilisation
          </h1>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-5 md:px-10 pb-24">
        <div className="static-content" dangerouslySetInnerHTML={{ __html: sanitizeHTML(content) }} />
      </div>

      <style jsx global>{`
        .static-content { color: rgba(0,0,0,0.8); line-height: 1.8; font-size: 15px; font-weight: 300; }
        .static-content h2 { text-transform: uppercase; letter-spacing: 0.08em; font-size: 1.125rem; font-weight: 700; color: #000; margin-top: 3rem; margin-bottom: 1.5rem; padding-bottom: 0.75rem; border-bottom: 1px solid rgba(0,0,0,0.1); }
        .static-content h3 { font-size: 1rem; font-weight: 700; color: #000; margin-top: 2.5rem; margin-bottom: 1rem; }
        .static-content p { margin-bottom: 1.5rem; color: rgba(0,0,0,0.8); }
        .static-content ul { margin-bottom: 1.5rem; padding-left: 1.5rem; }
        .static-content li { margin-bottom: 0.75rem; color: rgba(0,0,0,0.8); }
        .static-content a { color: #000; text-decoration: underline; }
        .static-content strong { font-weight: 600; color: #000; }
      `}</style>
    </div>
  )
}
