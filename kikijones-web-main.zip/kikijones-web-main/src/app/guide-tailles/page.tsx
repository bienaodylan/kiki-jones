﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function GuideTaillesPage() {
  return <StaticPageLayout slug="guide-tailles" />
}
