'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Truck } from 'lucide-react'
import { useCart } from '@/contexts/CartContext'
import { useCurrency } from '@/contexts/CurrencyContext'
import Toast, { ToastType } from '@/components/Toast'
import { API_ENDPOINTS, getMediaUrl } from '@/lib/api/config'
import { setWithTtl } from '@/lib/ttlStorage'

interface CouponDiscount {
  valid: boolean
  coupon_code: string
  coupon_name: string
  discount_amount: number
  discount_type: string
  discount_value: number
  free_shipping: boolean
  message: string
}

export default function PanierPage() {
  const { items, removeFromCart, updateQuantity, totalPrice, clearCart } = useCart()
  const { formatPrice, currency } = useCurrency()
  const [promoCode, setPromoCode] = useState('')
  const [appliedCoupon, setAppliedCoupon] = useState<CouponDiscount | null>(null)
  const [isValidating, setIsValidating] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null)

  // Shipping constants — should ideally come from site settings API
  const FREE_SHIPPING_THRESHOLD = 50000
  // Estimate only: the exact fee depends on the destination country chosen at checkout
  const [shippingBase, setShippingBase] = useState(3000)
  useEffect(() => {
    fetch(`${API_ENDPOINTS.orders}shipping-rates/`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { const est = typeof d?.estimate === 'number' ? d.estimate : d?.default; if (typeof est === 'number') setShippingBase(est) })
      .catch(() => {})
  }, [])

  const getSubtotal = () => {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  }

  const getShipping = () => {
    // Free shipping if coupon provides it or above threshold
    if (appliedCoupon?.free_shipping) {
      return 0
    }
    
    const subtotal = getSubtotal()
    return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : shippingBase
  }
  
  const getDiscount = () => {
    return appliedCoupon?.discount_amount || 0
  }

  const getTotal = () => {
    return Math.max(0, getSubtotal() - getDiscount() + getShipping())
  }

  const validateCoupon = async () => {
    if (!promoCode.trim()) {
      setToast({ message: 'Veuillez entrer un code promo', type: 'error' })
      return
    }

    setIsValidating(true)

    try {
      const response = await fetch(API_ENDPOINTS.validateCoupon, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code: promoCode,
          cart_total: getSubtotal(),
        }),
      })

      const data = await response.json()

      if (response.ok && data.valid) {
        const couponData = {
          valid: data.valid,
          coupon_code: data.coupon_code,
          coupon_name: data.coupon_name,
          discount_amount: data.discount_amount,
          discount_type: data.discount_type,
          discount_value: data.discount_value,
          free_shipping: data.free_shipping,
          message: data.message,
        }
        
        setAppliedCoupon(couponData)
        
        // Sauvegarder dans localStorage pour le checkout
        setWithTtl('appliedCoupon', couponData)
        setToast({ message: data.message, type: 'success' })
      } else {
        setToast({ message: data.error || 'Code promo invalide', type: 'error' })
      }
    } catch (error) {
      console.error('Erreur validation coupon:', error)
      setToast({ message: 'Erreur lors de la validation du code', type: 'error' })
    } finally {
      setIsValidating(false)
    }
  }

  const removeCoupon = () => {
    setAppliedCoupon(null)
    setPromoCode('')
    localStorage.removeItem('appliedCoupon')
    setToast({ message: 'Code promo retiré', type: 'info' })
  }

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  const subtotal = getSubtotal()
  const remainingForFree = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal)
  const progressPct = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100))
  const quickMenuLinks = [
    { label: 'Nouveautés', href: '/produits?is_new=true' },
    { label: 'Robes', href: '/categories/robe' },
    { label: 'Ensembles', href: '/categories/ensemble' },
    { label: 'Chaussures', href: '/categories/chaussures' },
    { label: 'Marques', href: '/brands' },
    { label: 'Catégories', href: '/categories' },
    { label: 'Soldes', href: '/promotions' },
  ]

  return (
    <main className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 pb-20 min-h-[75vh] overflow-x-clip bg-white text-black">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Quick menu ribbon */}
      <div className="w-full min-w-0 mt-5 mb-5 pb-3 border-b border-black/10">
        <nav aria-label="Accès rapide aux rayons" className="flex items-center gap-2 overflow-x-auto py-0.5" style={{ scrollbarWidth: 'none' }}>
          {quickMenuLinks.map((link) => (
            <Link key={link.href} href={link.href} className="shrink-0 whitespace-nowrap px-3 py-1.5 border border-black/15 bg-white text-[10.5px] font-medium uppercase tracking-[0.1em] text-black/80 hover:border-black hover:text-black transition-colors">{link.label}</Link>
          ))}
        </nav>
      </div>

      {/* Page header */}
      <div className="pb-5 border-b border-black/10 flex flex-col sm:flex-row sm:items-end justify-between gap-2.5">
        <div className="min-w-0">
          <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-black/45">KIKI JONES &middot; {totalItems} {totalItems > 1 ? 'articles' : 'article'}</p>
          <h1 className="text-2xl sm:text-4xl font-bold tracking-[-0.025em] text-black mt-0.5 leading-tight">Votre panier</h1>
        </div>
        <Link href="/produits" className="self-start sm:self-auto text-[11px] font-bold uppercase tracking-[0.16em] text-black underline underline-offset-4 hover:opacity-65 whitespace-nowrap">Continuer vos achats</Link>
      </div>

      {items.length === 0 ? (
        <div className="py-16 sm:py-20 text-center space-y-5 max-w-md mx-auto">
          <p className="text-2xl sm:text-3xl font-bold tracking-[-0.025em] text-black">Votre panier est vide</p>
          <p className="text-xs sm:text-sm font-light text-black/65 leading-relaxed">Explorez nos rayons Femme, Homme, Curve, Sport, Enfants et Accessoires depuis le menu ci-dessus.</p>
          <div className="flex flex-wrap justify-center gap-2.5 pt-1">
            <Link href="/produits?is_new=true" className="px-6 py-3.5 bg-black text-white text-xs font-bold uppercase tracking-[0.18em] hover:bg-black/85 transition-colors">Voir les nouveautés</Link>
            <Link href="/categories" className="px-6 py-3.5 border border-black text-black text-xs font-bold uppercase tracking-[0.18em] hover:bg-black hover:text-white transition-colors">Parcourir les catégories</Link>
          </div>
        </div>
      ) : (
        <div className="pt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-start">
          {/* Line items */}
          <div className="lg:col-span-8 space-y-3.5 min-w-0 w-full">
            {items.map((item, index) => (
              <div key={`${item.product.id}-${item.variantId || index}`} className="w-full min-w-0 p-3.5 sm:p-4 bg-[#F7F7F7]/75 border border-black/[0.06] flex gap-3.5 sm:gap-5 items-start">
                <Link href={`/produits/${item.product.slug}`} className="w-20 sm:w-24 aspect-[4/5] bg-[#EFEFEF] shrink-0 overflow-hidden block">
                  {item.product.main_image ? (
                    <img src={getMediaUrl(item.product.main_image)} alt={item.product.name} className="w-full h-full object-cover object-top block" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[9px] font-bold uppercase tracking-[0.14em] text-black/50">KIKI JONES</div>
                  )}
                </Link>
                <div className="flex-1 min-w-0 flex flex-col justify-between gap-2.5">
                  <div className="space-y-0.5 min-w-0">
                    <div className="flex items-start justify-between gap-2 min-w-0">
                      <Link href={`/produits/${item.product.slug}`} className="flex-1 min-w-0 font-bold text-[13px] sm:text-sm text-black leading-snug line-clamp-2 hover:opacity-65 text-left">{item.product.name}</Link>
                      <button type="button" onClick={() => removeFromCart(item.product.id, item.variantId)} aria-label="Retirer l’article" className="shrink-0 -mt-1 -mr-1.5 min-w-[36px] min-h-[36px] inline-flex items-center justify-center text-black/45 hover:text-black">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    {(item.selectedColor || item.selectedSize) && (
                      <p className="text-[11.5px] font-light text-black/65 truncate">{[item.selectedColor, item.selectedSize ? `Taille ${item.selectedSize}` : null].filter(Boolean).join(' · ')}</p>
                    )}
                    <p className="text-[11.5px] font-light tabular-nums text-black/75 pt-0.5">{formatPrice(item.price)} / unité</p>
                  </div>
                  <div className="flex items-center justify-between gap-2 flex-wrap pt-1 border-t border-black/[0.06]">
                    <div className="inline-flex items-center bg-white border border-black/15 shrink-0">
                      <button type="button" onClick={() => updateQuantity(item.product.id, item.quantity - 1, item.variantId)} aria-label="Diminuer la quantité" className="w-8 h-8 flex items-center justify-center hover:bg-black/5"><Minus className="w-3 h-3" /></button>
                      <span className="w-7 text-center text-xs font-bold tabular-nums">{item.quantity}</span>
                      <button type="button" onClick={() => updateQuantity(item.product.id, item.quantity + 1, item.variantId)} aria-label="Augmenter la quantité" className="w-8 h-8 flex items-center justify-center hover:bg-black/5"><Plus className="w-3 h-3" /></button>
                    </div>
                    <span className="text-[13px] sm:text-sm font-bold tabular-nums text-black whitespace-nowrap shrink-0 ml-auto">{formatPrice(item.price * item.quantity)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order summary */}
          <div className="lg:col-span-4 w-full min-w-0 bg-[#F7F7F7] border border-black/[0.06] p-4 sm:p-6 space-y-4 h-fit">
            <h2 className="text-xl sm:text-2xl font-bold tracking-[-0.02em] text-black">Récapitulatif</h2>

            <div className="space-y-1.5 pb-3 border-b border-black/10">
              <p className="text-[11.5px] font-light text-black/75 leading-snug">
                {remainingForFree === 0 || appliedCoupon?.free_shipping ? 'Livraison standard offerte débloquée.' : `Ajoutez ${formatPrice(remainingForFree)} pour la livraison standard offerte.`}
              </p>
              <div className="h-[2px] bg-black/15 w-full overflow-hidden"><div className="h-full bg-black transition-all duration-300" style={{ width: `${progressPct}%` }} /></div>
            </div>

            {/* Promo code */}
            <div className="pb-3 border-b border-black/10">
              {appliedCoupon ? (
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold">{appliedCoupon.coupon_code}</span>
                  <button type="button" onClick={removeCoupon} className="text-black/60 hover:text-black underline underline-offset-4">Retirer</button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <input id="promoCode" value={promoCode} onChange={(e) => setPromoCode(e.target.value.toUpperCase())} placeholder="Code promo" className="flex-1 min-w-0 bg-white border border-black/25 px-3 py-2.5 text-base sm:text-xs font-light placeholder:text-black/40 focus:outline-none focus:border-black" />
                  <button type="button" onClick={validateCoupon} disabled={isValidating} className="px-4 bg-black text-white text-[10.5px] font-bold uppercase tracking-[0.14em] hover:bg-black/85 disabled:opacity-60">{isValidating ? '…' : 'Appliquer'}</button>
                </div>
              )}
            </div>

            <div className="space-y-2.5 text-xs sm:text-sm pb-2 border-b border-black/10">
              <div className="flex items-baseline justify-between gap-3"><span className="font-light text-black/75 min-w-0">Sous-total</span><span className="tabular-nums font-bold whitespace-nowrap shrink-0">{formatPrice(subtotal)}</span></div>
              {getDiscount() > 0 && <div className="flex items-baseline justify-between gap-3"><span className="font-light text-black/75 min-w-0">Remise ({appliedCoupon?.coupon_code})</span><span className="tabular-nums font-light whitespace-nowrap shrink-0">-{formatPrice(getDiscount())}</span></div>}
              <div className="flex items-baseline justify-between gap-3"><span className="font-light text-black/75 min-w-0">Livraison standard</span><span className="tabular-nums font-light whitespace-nowrap shrink-0">{getShipping() === 0 ? 'Offerte' : formatPrice(getShipping())}</span></div>
            </div>

            <div className="flex items-baseline justify-between gap-3 text-sm sm:text-base font-bold">
              <span className="min-w-0">Total estimé</span>
              <span className="tabular-nums whitespace-nowrap shrink-0">{formatPrice(getTotal())}</span>
            </div>

            <Link href="/checkout" className="w-full min-h-[48px] py-3.5 px-5 bg-black text-white text-xs font-bold uppercase tracking-[0.18em] flex items-center justify-center gap-2 hover:bg-black/85 transition-colors">
              <span>Passer la commande</span>
              <ArrowRight className="w-3.5 h-3.5 shrink-0" />
            </Link>
          </div>
        </div>
      )}
    </main>
  )
}
