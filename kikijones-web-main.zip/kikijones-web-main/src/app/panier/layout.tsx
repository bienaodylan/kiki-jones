import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Mon Panier | KikiJones',
  description: 'Consultez votre panier et passez à la caisse sur KikiJones.',
}

export default function PanierLayout({ children }: { children: React.ReactNode }) {
  return children
}
