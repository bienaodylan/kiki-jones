'use client'

import { useRouter } from 'next/navigation'
import { ArrowRight } from 'lucide-react'

const A = '/assets/theme/'
const BRANDS = [
  { slug: 'kiki-men', name: 'Kiki Men', tagline: 'Mode Homme Audacieuse · Streetwear & Soirée Climat Chaud', img: 'crinkle-accordion-button-up-shirt__0.jpg', description: 'Chemises à col ouvert, ensembles plissés texturés, jeans évasés stacked, t-shirts boxy vintage et mocassins soignés pensés pour les climats chauds.' },
  { slug: 'kiki-luxe', name: 'Kiki Luxe', tagline: 'Soirée, Gala & Resort · Robes, Combinaisons & Talons', img: 'alexis-rhinestone-maxi-dress__0.jpg', description: 'Robes de gala brodées, caftans fluides en satin, robes maxi à strass, combi-shorts ajustés, ensembles plissés, talons aiguilles et lunettes en acétate.' },
  { slug: 'kiki-curve', name: 'Kiki Curve', tagline: 'Silhouettes Assumées · Robes de Sortie & Ensembles', img: 'fn_campaign_curve_mini.jpg', description: 'Mini-robes asymétriques, robes longues de gala, jupes doublées et ensembles lounge sans couture conçus pour une coupe audacieuse et respirante.' },
  { slug: 'kiki-sculpt', name: 'Kiki Sculpt', tagline: 'Compression Seconde Peau · Corsets, Jorts & Baskets', img: 'jackie-lace-strapless-corset-bodysuit__0.jpg', description: 'Bodys sculptants sans couture, corsets structurés en dentelle, jorts en denim 90s et baskets minimalistes pensés pour galber avec aisance.' },
  { slug: 'kiki-sport', name: 'Kiki Sport', tagline: 'Activewear Respirant · Cyclistes & Performance', img: 'fn_campaign_sport_crop.jpg', description: 'Shorts cyclistes sans couture, essentiels studio respirants et silhouettes street-sport légères conçues pour la chaleur et le mouvement.' },
  { slug: 'kiki-kids', name: 'Kiki Kids', tagline: 'Filles & Garçons · Ensembles Street & Quotidien Junior', img: 'mini-be-amazing-pant-set__0.jpg', description: 'Ensembles deux pièces coordonnés, pantalons évasés et ensembles jogger graphiques pour filles et garçons prêts pour chaque week-end.' },
]

export default function BrandsPage() {
  const router = useRouter()
  return (
    <main className="bg-white text-black min-h-screen pb-12">
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 pt-8 pb-6 border-b border-black/10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <p className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-black/45">KIKI JONES · Nos Maisons</p>
            <h1 className="text-3xl sm:text-5xl font-bold tracking-[-0.025em] text-black leading-[1.04]">Acheter par Marque</h1>
            <p className="text-xs sm:text-sm font-light text-black/65 leading-relaxed">Six marques KIKI JONES pensées pour un style contemporain sous les climats chauds — Kiki Men, Kiki Luxe, Kiki Curve, Kiki Sculpt, Kiki Sport et Kiki Kids.</p>
          </div>
          <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-black/50 tabular-nums">{BRANDS.length} Marques Signatures</p>
        </div>
      </section>
      <section className="w-full bg-black">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          {BRANDS.map((b) => (
            <div key={b.slug} onClick={() => router.push(`/produits?brand=${b.slug}`)} className="group relative overflow-hidden bg-black cursor-pointer aspect-[4/5] sm:aspect-[5/6] border-r border-b border-white/10">
              <img src={`${A}${b.img}`} alt={b.name} className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.03]" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
              <div className="absolute bottom-6 left-5 right-5 md:bottom-10 md:left-10 z-10 max-w-xl space-y-2.5">
                <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/75">{b.tagline}</p>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold uppercase tracking-[-0.02em] text-white leading-[1.02]">{b.name}</h2>
                <p className="text-xs sm:text-sm font-light text-white/85 leading-relaxed max-w-md">{b.description}</p>
                <div className="pt-1">
                  <button type="button" onClick={(e) => { e.stopPropagation(); router.push(`/produits?brand=${b.slug}`) }} className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-white text-black text-[11px] font-bold uppercase tracking-[0.14em] hover:bg-white/90 transition-colors">
                    <span>Découvrir {b.name}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  )
}
