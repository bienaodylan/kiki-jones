import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Créer un compte | KikiJones',
  description: 'Inscrivez-vous sur KikiJones et découvrez les dernières tendances mode. Livraison en Côte d\'Ivoire et en Afrique de l\'Ouest.',
}

export default function RegisterLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
