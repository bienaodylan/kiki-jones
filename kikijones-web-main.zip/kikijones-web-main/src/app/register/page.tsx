'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Eye, EyeOff, Loader2, Gift, CheckCircle, AlertCircle } from 'lucide-react'
import { setAccessToken } from '@/lib/auth-store'
import { API_ENDPOINTS } from '@/lib/api/config'

export default function RegisterPage() {
  const searchParams = useSearchParams()
  const [formData, setFormData] = useState({
    first_name: '', last_name: '', email: '', phone: '', password: '', password2: '', referral_code: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [codeStatus, setCodeStatus] = useState<'idle' | 'validating' | 'valid' | 'invalid'>('idle')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
    if (e.target.name === 'referral_code') setCodeStatus('idle')
  }

  const validateReferralCode = async () => {
    if (!formData.referral_code.trim()) return
    setCodeStatus('validating')
    try {
      const res = await fetch(API_ENDPOINTS.referralValidate, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: formData.referral_code.trim().toUpperCase() }),
      })
      const data = await res.json()
      setCodeStatus(data.valid ? 'valid' : 'invalid')
    } catch {
      setCodeStatus('invalid')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    if (formData.password !== formData.password2) {
      setError('Les mots de passe ne correspondent pas')
      return
    }
    if (formData.password.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères')
      return
    }

    setLoading(true)

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
        credentials: 'include',
      })

      const data = await response.json()

      if (response.ok) {
        if (data.access) {
          setAccessToken(data.access)
        }
        // Only persist minimal, non-sensitive fields needed for display (e.g. header greeting).
        // Full profile data (phone, address, city, country, postal_code) is never cached
        // client-side — pages that need it fetch it fresh from the API.
        const u = data.user || data
        localStorage.setItem('user', JSON.stringify({ id: u.id, first_name: u.first_name, email: u.email }))
        window.dispatchEvent(new Event('auth-change'))
        setSuccess('Compte créé avec succès ! Redirection...')
        // Only same-site paths: blocks open redirects (protocol-relative, backslash and absolute URLs)
        const requested = searchParams.get('redirect') || ''
        const redirect = /^\/(?![/\\])/.test(requested) ? requested : '/compte'
        setTimeout(() => window.location.assign(redirect), 1500)
      } else {
        const errorMsg = data.email?.[0] || data.password?.[0] || data.error || data.detail || 'Erreur lors de la création du compte'
        setError(errorMsg)
      }
    } catch {
      setError('Erreur de connexion. Veuillez réessayer.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-black uppercase tracking-tight text-gray-900">
            Créer un compte
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Déjà membre ?{' '}
            <Link href="/login" className="font-medium text-black hover:underline">
              Connectez-vous
            </Link>
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md text-sm">{error}</div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-md text-sm">{success}</div>
        )}

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prénom *</label>
                <input name="first_name" type="text" required value={formData.first_name} onChange={handleChange}
                  className="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm" placeholder="Prénom" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nom *</label>
                <input name="last_name" type="text" required value={formData.last_name} onChange={handleChange}
                  className="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm" placeholder="Nom" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Adresse email *</label>
              <input name="email" type="email" autoComplete="email" required value={formData.email} onChange={handleChange}
                className="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm" placeholder="votre@email.com" />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Téléphone (optionnel)</label>
              <input name="phone" type="tel" value={formData.phone} onChange={handleChange}
                className="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm" placeholder="+225 XX XX XX XX XX" />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mot de passe *</label>
              <div className="relative">
                <input name="password" type={showPassword ? 'text' : 'password'} autoComplete="new-password" required
                  value={formData.password} onChange={handleChange}
                  className="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm pr-10" placeholder="••••••••" />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <p className="mt-1 text-xs text-gray-500">Minimum 8 caractères</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Confirmer le mot de passe *</label>
              <input name="password2" type="password" autoComplete="new-password" required
                value={formData.password2} onChange={handleChange}
                className="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm" placeholder="••••••••" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <Gift size={14} className="inline mr-1.5 text-gray-400" />
                Code de parrainage (optionnel)
              </label>
              <div className="relative">
                <input
                  name="referral_code"
                  type="text"
                  value={formData.referral_code}
                  onChange={handleChange}
                  onBlur={validateReferralCode}
                  className={`w-full px-3 py-3 border rounded-md focus:outline-none sm:text-sm uppercase pr-10 ${
                    codeStatus === 'valid' ? 'border-green-500 focus:ring-green-500 focus:border-green-500' :
                    codeStatus === 'invalid' ? 'border-red-400 focus:ring-red-400 focus:border-red-400' :
                    'border-gray-300 focus:ring-black focus:border-black'
                  }`}
                  placeholder="Ex: KJ-ABC123"
                />
                {codeStatus === 'validating' && (
                  <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 animate-spin text-gray-400" size={16} />
                )}
                {codeStatus === 'valid' && (
                  <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 text-green-500" size={16} />
                )}
                {codeStatus === 'invalid' && (
                  <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 text-red-400" size={16} />
                )}
              </div>
              {codeStatus === 'valid' && (
                <p className="mt-1 text-xs text-green-600">✓ Code valide — vous recevrez 500 FCFA de crédit !</p>
              )}
              {codeStatus === 'invalid' && (
                <p className="mt-1 text-xs text-red-600">Code invalide ou inexistant.</p>
              )}
            </div>          </div>

          <div className="flex items-center">
            <input id="terms" type="checkbox" required className="h-4 w-4 text-black focus:ring-black border-gray-300 rounded" />
            <label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
              J&apos;accepte les{' '}
              <Link href="/terms" className="text-black hover:underline">conditions d&apos;utilisation</Link>
              {' '}et la{' '}
              <Link href="/privacy" className="text-black hover:underline">politique de confidentialité</Link>
            </label>
          </div>

          <button type="submit" disabled={loading}
            className="w-full flex justify-center py-3 px-4 border border-transparent text-sm font-black uppercase tracking-wider rounded-md text-white bg-black hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black disabled:opacity-50">
            {loading && <Loader2 className="animate-spin mr-2" size={18} />}
            {loading ? 'Création...' : 'Créer mon compte'}
          </button>
        </form>
      </div>
    </div>
  )
}
