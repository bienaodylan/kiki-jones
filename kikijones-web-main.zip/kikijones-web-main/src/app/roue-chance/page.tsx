import { Metadata } from 'next'
import LuckyWheel from '@/components/home/LuckyWheel'

export const metadata: Metadata = {
  title: 'Roue de la Chance | KikiJones',
  description: 'Tentez votre chance et gagnez des récompenses exclusives avec la Roue de la Chance KikiJones !',
}

export default function LuckyWheelPage() {
  return <LuckyWheel />
}
