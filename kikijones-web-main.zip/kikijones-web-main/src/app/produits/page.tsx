'use client'

import { useState, useEffect } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { getProducts, getActiveCategories, getFilterOptions, Product, Category, FilterColor } from '@/lib/api'
import ProductCard from '@/components/products/ProductCard'
import { SlidersHorizontal, X, Check, Loader2 } from 'lucide-react'
import Link from 'next/link'
import { THEME_BRANDS } from '@/lib/themeBrands'
import { THEME_COLLECTIONS, ThemeCollection } from '@/lib/themeCollections'
import { loadCollections } from '@/lib/collections'

export default function ProductsPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const categoryFilter = searchParams.get('category')
  const searchQuery = searchParams.get('search')
  const sortParam = searchParams.get('sort')
  const isNewParam = searchParams.get('is_new')
  const brandParam = searchParams.get('brand')
  const brand = THEME_BRANDS.find((b) => b.slug === brandParam)
  const collectionParam = searchParams.get('collection')
  const [allCollections, setAllCollections] = useState<ThemeCollection[]>(THEME_COLLECTIONS)
  useEffect(() => { loadCollections().then(setAllCollections) }, [])
  const collection = allCollections.find((c) => c.slug === collectionParam)
  
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isLoadingProducts, setIsLoadingProducts] = useState(false)
  const [showMobileFilters, setShowMobileFilters] = useState(false)
  const [sortBy, setSortBy] = useState(sortParam || 'newest')
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(false)
  const [isLoadingMore, setIsLoadingMore] = useState(false)
  const [totalCount, setTotalCount] = useState(0)
  const PAGE_SIZE = 12
  
  // Color and size filters
  const [availableColors, setAvailableColors] = useState<FilterColor[]>([])
  const [availableSizes, setAvailableSizes] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [selectedSizes, setSelectedSizes] = useState<string[]>([])
  const [availability, setAvailability] = useState<'all' | 'in_stock' | 'new' | 'bestseller' | 'sale'>('all')
  const [maxPrice, setMaxPrice] = useState(150000)

  const toggleColor = (color: string) => {
    setSelectedColors(prev => 
      prev.includes(color) ? prev.filter(c => c !== color) : [...prev, color]
    )
  }

  const toggleSize = (size: string) => {
    setSelectedSizes(prev => 
      prev.includes(size) ? prev.filter(s => s !== size) : [...prev, size]
    )
  }

  const clearFilters = () => {
    setSelectedColors([])
    setSelectedSizes([])
    setAvailability('all')
    setMaxPrice(150000)
  }

  const activeFilterCount = selectedColors.length + selectedSizes.length + (availability !== 'all' ? 1 : 0) + (maxPrice < 150000 ? 1 : 0)

  // Handler to change category without scroll
  const handleCategoryChange = (slug: string | null) => {
    if (slug) {
      router.push(`/produits?category=${slug}`, { scroll: false })
    } else {
      router.push('/produits', { scroll: false })
    }
  }

  // Load categories once on mount
  useEffect(() => {
    getActiveCategories()
      .then((categoriesData) => {
        setCategories(categoriesData)
      })
      .catch((error) => {
        console.error('Failed to fetch categories:', error)
      })
  }, [])

  // Load products when category filter or color/size filters or search change
  useEffect(() => {
    if (categories.length === 0 && !searchQuery) return // Wait for categories to load first (unless searching)
    
    setIsLoadingProducts(true)
    
    // Find category ID from slug
    const params: any = {}
    if (categoryFilter) {
      const selectedCat = categories.find((cat: Category) => cat.slug === categoryFilter)
      if (selectedCat) {
        params.category = selectedCat.id
      }
    }

    // Add search query
    if (searchQuery) {
      params.search = searchQuery
    }
    
    // Add color and size filters
    if (selectedColors.length > 0) {
      params.color = selectedColors.join(',')
    }
    if (selectedSizes.length > 0) {
      params.size = selectedSizes.join(',')
    }

    // Add sorting
    const sortMapping: Record<string, string> = {
      'newest': '-created_at',
      'price_asc': 'base_price',
      'price_desc': '-base_price',
      'popular': '-sales_count',
      'on_sale': '-created_at',
    }
    // Filter by products on sale
    if (sortBy === 'on_sale') {
      params.has_sale_price = true
    }
    // Filter by new products from URL param
    if (isNewParam === 'true') {
      params.is_new = true
    }
    if (sortBy && sortMapping[sortBy]) {
      params.ordering = sortMapping[sortBy]
    }
    
    if (brandParam) params.brand = brandParam
    if (collectionParam) params.collection = collectionParam
    if (availability === 'new') params.is_new = true
    if (availability === 'bestseller') params.is_bestseller = true
    if (availability === 'sale') params.has_sale_price = true
    if (maxPrice < 150000) params.max_price = maxPrice
    params.page = 1
    params.page_size = PAGE_SIZE
    
    getProducts(params)
      .then((productsData) => {
        setProducts(productsData.results)
        setTotalCount(productsData.count)
        setHasMore(!!productsData.next)
        setPage(1)
      })
      .catch((error) => {
        console.error('Failed to fetch products:', error)
      })
      .finally(() => {
        setIsLoadingProducts(false)
        setIsLoading(false)
      })
  }, [categoryFilter, categories, selectedColors, selectedSizes, searchQuery, sortBy, brandParam, collectionParam, availability, maxPrice])

  // Load More handler
  const handleLoadMore = () => {
    if (isLoadingMore || !hasMore) return
    setIsLoadingMore(true)
    
    const nextPage = page + 1
    const params: any = { page: nextPage, page_size: PAGE_SIZE }
    if (brandParam) params.brand = brandParam
    if (collectionParam) params.collection = collectionParam
    if (availability === 'new') params.is_new = true
    if (availability === 'bestseller') params.is_bestseller = true
    if (availability === 'sale') params.has_sale_price = true
    if (maxPrice < 150000) params.max_price = maxPrice
    if (categoryFilter) {
      const selectedCat = categories.find((cat: Category) => cat.slug === categoryFilter)
      if (selectedCat) params.category = selectedCat.id
    }
    if (searchQuery) params.search = searchQuery
    if (selectedColors.length > 0) params.color = selectedColors.join(',')
    if (selectedSizes.length > 0) params.size = selectedSizes.join(',')
    
    const sortMapping: Record<string, string> = {
      'newest': '-created_at',
      'price_asc': 'base_price',
      'price_desc': '-base_price',
      'popular': '-sales_count',
      'on_sale': '-created_at',
    }
    if (sortBy === 'on_sale') {
      params.has_sale_price = true
    }
    if (isNewParam === 'true') {
      params.is_new = true
    }
    if (sortBy && sortMapping[sortBy]) {
      params.ordering = sortMapping[sortBy]
    }
    
    getProducts(params)
      .then((productsData) => {
        setProducts(prev => [...prev, ...productsData.results])
        setHasMore(!!productsData.next)
        setPage(nextPage)
      })
      .catch((error) => {
        console.error('Failed to load more products:', error)
      })
      .finally(() => {
        setIsLoadingMore(false)
      })
  }

  // Load filter options when category changes
  useEffect(() => {
    if (categories.length === 0) return
    
    const selectedCat = categoryFilter 
      ? categories.find((cat: Category) => cat.slug === categoryFilter)
      : undefined
    
    getFilterOptions(selectedCat?.id)
      .then((options) => {
        setAvailableColors(options.colors || [])
        setAvailableSizes(options.sizes || [])
        // Reset selections when category changes
        setSelectedColors([])
        setSelectedSizes([])
      })
      .catch((error) => {
        console.error('Failed to fetch filter options:', error)
      })
  }, [categoryFilter, categories])

  const selectedCategory = categories.find((cat) => cat.slug === categoryFilter) || categories.flatMap((c) => c.subcategories || []).find((c) => c.slug === categoryFilter)
  const count = totalCount > 0 ? totalCount : products.length
  const title = searchQuery ? `Résultats pour « ${searchQuery} »` : isNewParam ? 'Nouveautés' : selectedCategory ? selectedCategory.name : 'Boutique'
  const eyebrow = searchQuery ? 'Recherche' : isNewParam ? 'Vient d’arriver' : selectedCategory ? 'Catégorie' : 'KIKI JONES'
  const heroImg = (selectedCategory?.display_image || selectedCategory?.image || null) as string | null

  const Section = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="space-y-2.5">
      <p className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-black/50">{label}</p>
      {children}
    </div>
  )

  return (
    <div className="bg-white min-h-screen">
      {/* Brand banner (the theme's brand page: split campaign photos, tagline, description) */}
      {brand && (
        <section className="relative w-full overflow-hidden bg-black">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            <div className="relative aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black"><img src={brand.hero} alt={brand.name} className="w-full h-full object-cover object-top" /></div>
            <div className="relative hidden md:block aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black"><img src={brand.second} alt={`${brand.name} campagne`} className="w-full h-full object-cover object-top" /></div>
          </div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
          <div className="absolute bottom-8 left-5 right-5 md:bottom-12 md:left-10 z-10 max-w-xl space-y-3">
            <p className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-white/75">{brand.tagline}</p>
            <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold uppercase tracking-[-0.025em] text-white leading-[1.02]">{brand.name}</h1>
            <p className="text-xs sm:text-sm font-light text-white/85 leading-relaxed max-w-md">{brand.description}</p>
          </div>
        </section>
      )}

      {/* Collection banner */}
      {collection && !brand && (
        <section className="relative w-full overflow-hidden bg-black">
          <div className="w-full aspect-[16/10] sm:aspect-[2/1] lg:aspect-[1800/780]">
            <img src={collection.image} alt={collection.title} className="w-full h-full object-cover object-center" />
          </div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 max-w-[1440px] mx-auto px-5 sm:px-8 xl:px-10 pb-8 md:pb-12 space-y-2 text-white">
            <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/75">{collection.seasonTag} &middot; {collection.audiences}</p>
            <h1 className="text-3xl sm:text-5xl font-bold tracking-[-0.025em] leading-tight">{collection.title}</h1>
            <p className="text-xs sm:text-sm font-light text-white/85 max-w-xl leading-relaxed">{collection.description}</p>
          </div>
        </section>
      )}

      {/* Category banner (photo) */}
      {selectedCategory && !brand && !collection && (
        <div className="relative w-full aspect-[16/9] sm:aspect-[21/9] max-h-[380px] bg-black overflow-hidden">
          {heroImg && <img src={heroImg} alt={selectedCategory.name} className="w-full h-full object-cover object-top" />}
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 max-w-[1440px] mx-auto px-4 sm:px-6 pb-5 text-white space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/75">{eyebrow}</p>
            <h1 className="text-3xl sm:text-5xl font-bold tracking-[-0.025em] text-white leading-tight">{selectedCategory.name}</h1>
          </div>
        </div>
      )}

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6">
        {/* Title row + sort + filter */}
        <div className="pt-4 pb-3 border-b border-black/10 flex flex-col md:flex-row md:items-end justify-between gap-3">
          <div className="space-y-1 max-w-2xl">
            {!selectedCategory && !brand && !collection && <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-black/45">{eyebrow}</p>}
            {!selectedCategory && !brand && !collection && (
              <div className="flex items-start gap-1.5">
                <h1 className="text-2xl sm:text-3xl font-bold tracking-[-0.025em] text-black leading-tight">{title}</h1>
                <sup className="text-xs font-bold text-black/50 tabular-nums mt-1.5">{count}</sup>
              </div>
            )}
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-black/55 tabular-nums">{count} pièce{count > 1 ? 's' : ''} disponible{count > 1 ? 's' : ''}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2 self-start md:self-end shrink-0 max-w-full">
            <select
              aria-label="Trier les produits"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="border border-black/15 bg-white px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.12em] text-black focus:outline-none focus:border-black cursor-pointer"
            >
              <option value="newest">Nouveautés</option>
              <option value="price_asc">Prix croissant</option>
              <option value="price_desc">Prix décroissant</option>
              <option value="popular">Recommandés</option>
            </select>
            <button
              type="button"
              onClick={() => setShowMobileFilters(true)}
              className="inline-flex items-center gap-1.5 border border-black bg-black text-white px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-[0.14em] hover:bg-black/85 transition-colors cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Filtrer{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
            </button>
          </div>
        </div>

        {/* Category ribbon */}
        <div className="py-2.5 border-b border-black/10 flex items-center gap-4 overflow-x-auto text-xs" style={{ scrollbarWidth: 'none' }}>
          <button onClick={() => handleCategoryChange(null)} className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${!categoryFilter ? 'font-bold text-black border-b border-black' : 'font-medium text-black/60 hover:text-black'}`}>Tout</button>
          {categories.map((c) => (
            <button key={c.id} onClick={() => handleCategoryChange(c.slug)} className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${categoryFilter === c.slug ? 'font-bold text-black border-b border-black' : 'font-medium text-black/60 hover:text-black'}`}>{c.name}</button>
          ))}
        </div>

        {/* Grid */}
        <div className="pt-3.5">
          {isLoading || isLoadingProducts ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5 sm:gap-2">
              {Array.from({ length: 8 }).map((_, k) => <div key={k} className="aspect-[4/5] bg-[#F5F5F5] animate-pulse" />)}
            </div>
          ) : products.length === 0 ? (
            <div className="bg-[#F7F7F7] px-5 py-12 text-center space-y-3">
              <p className="text-2xl sm:text-3xl font-bold tracking-[-0.025em] text-black">Aucune pièce pour le moment</p>
              <p className="text-xs font-light text-black/60 max-w-md mx-auto">Cette sélection se remplit au fil des arrivages. Modifiez les filtres ou découvrez toute la boutique.</p>
              <div className="flex flex-wrap justify-center gap-2.5 pt-1">
                {activeFilterCount > 0 && <button onClick={clearFilters} className="px-5 py-2.5 bg-black text-white text-xs font-bold uppercase tracking-[0.18em]">Réinitialiser</button>}
                <button onClick={() => handleCategoryChange(null)} className="px-5 py-2.5 border border-black text-black text-xs font-bold uppercase tracking-[0.18em]">Toute la boutique</button>
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-x-1.5 gap-y-4 sm:gap-x-2 sm:gap-y-5 items-stretch">
                {products.filter((p) => availability !== 'in_stock' || p.is_in_stock).map((product) => <ProductCard key={product.id} product={product} />)}
              </div>
              {hasMore && (
                <div className="text-center mt-10">
                  <button onClick={handleLoadMore} disabled={isLoadingMore} className="inline-flex items-center gap-2 px-10 py-3 bg-black text-white text-xs font-bold uppercase tracking-[0.18em] hover:bg-black/85 transition-colors disabled:opacity-50">
                    {isLoadingMore ? <><Loader2 size={16} className="animate-spin" /> Chargement…</> : <>Voir plus ({products.length} / {totalCount})</>}
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        <div className="mt-8 pt-6 mb-12 border-t border-black/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-black/45">Sélection éditoriale</p>
            <p className="text-2xl font-bold tracking-[-0.02em] text-black mt-0.5">Découvrir les collections KIKI JONES</p>
          </div>
          <Link href="/produits?is_new=true" className="px-5 py-2.5 border border-black text-black text-[11px] font-bold uppercase tracking-[0.16em] hover:bg-black hover:text-white transition-colors self-start sm:self-auto">Voir les nouveautés</Link>
        </div>
      </div>

      {/* Slide-over filter drawer (the theme's "Filtrer & Affiner") */}
      {showMobileFilters && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="fixed inset-0 bg-black/45" onClick={() => setShowMobileFilters(false)} />
          <div className="relative w-80 max-w-[88vw] bg-white h-full flex flex-col shadow-2xl">
            <div className="px-6 py-5 border-b border-black/10 flex items-center justify-between shrink-0">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-black">Filtrer &amp; Affiner</span>
              <button type="button" onClick={() => setShowMobileFilters(false)} aria-label="Fermer les filtres" className="p-1.5 text-black/70 hover:text-black cursor-pointer"><X className="w-5 h-5" strokeWidth={1.6} /></button>
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-7">
              <Section label="Catégorie">
                <div className="flex flex-col gap-1.5 text-xs">
                  <button type="button" onClick={() => handleCategoryChange(null)} className={`text-left py-1 cursor-pointer ${!categoryFilter ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>Toutes les catégories</button>
                  {categories.map((c) => (
                    <div key={c.id}>
                      <button type="button" onClick={() => handleCategoryChange(c.slug)} className={`text-left py-1 cursor-pointer ${categoryFilter === c.slug ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>{c.name}</button>
                      {(c.subcategories || []).length > 0 && (
                        <div className="pl-3 flex flex-col gap-0.5">
                          {(c.subcategories || []).map((sub) => (
                            <button key={sub.id} type="button" onClick={() => handleCategoryChange(sub.slug)} className={`text-left py-0.5 cursor-pointer ${categoryFilter === sub.slug ? 'font-bold text-black' : 'font-light text-black/55 hover:text-black'}`}>{sub.name}</button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </Section>

              <Section label="Marque">
                <div className="flex flex-col gap-1.5 text-xs">
                  <button type="button" onClick={() => router.push(categoryFilter ? `/produits?category=${categoryFilter}` : '/produits', { scroll: false })} className={`text-left py-1 cursor-pointer ${!brandParam ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>Toutes les marques</button>
                  {THEME_BRANDS.map((b) => (
                    <button key={b.slug} type="button" onClick={() => router.push(`/produits?brand=${b.slug}${categoryFilter ? `&category=${categoryFilter}` : ''}`, { scroll: false })} className={`text-left py-1 cursor-pointer ${brandParam === b.slug ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>{b.name}</button>
                  ))}
                </div>
              </Section>

              <Section label="Collection">
                <div className="flex flex-col gap-1.5 text-xs">
                  <button type="button" onClick={() => router.push('/produits', { scroll: false })} className={`text-left py-1 cursor-pointer ${!collection ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>Toutes les collections</button>
                  {allCollections.map((c) => (
                    <button key={c.slug} type="button" onClick={() => router.push(`/produits?collection=${c.slug}`, { scroll: false })} className={`text-left py-1 cursor-pointer ${collection?.slug === c.slug ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>{c.title}</button>
                  ))}
                </div>
              </Section>

              <Section label="Taille">
                <div className="flex flex-wrap gap-1.5">
                  <button type="button" onClick={() => setSelectedSizes([])} className={`px-3 py-1.5 text-xs font-bold cursor-pointer ${selectedSizes.length === 0 ? 'bg-black text-white' : 'bg-[#F5F5F5] text-black hover:bg-black/10'}`}>Toutes</button>
                  {availableSizes.map((size) => (
                    <button key={size} type="button" onClick={() => toggleSize(size)} className={`px-3 py-1.5 text-xs font-bold cursor-pointer ${selectedSizes.includes(size) ? 'bg-black text-white' : 'bg-[#F5F5F5] text-black hover:bg-black/10'}`}>{size}</button>
                  ))}
                </div>
              </Section>

              <Section label="Couleur">
                <div className="flex flex-col gap-1.5 text-xs max-h-40 overflow-y-auto">
                  <button type="button" onClick={() => setSelectedColors([])} className={`text-left py-1 cursor-pointer ${selectedColors.length === 0 ? 'font-bold text-black' : 'font-light text-black/65'}`}>Toutes les couleurs</button>
                  {availableColors.map((c) => (
                    <button key={c.name} type="button" onClick={() => toggleColor(c.name)} className={`text-left py-1 cursor-pointer ${selectedColors.includes(c.name) ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>{c.name}</button>
                  ))}
                </div>
              </Section>

              <Section label="Disponibilité">
                <div className="flex flex-col gap-1.5 text-xs">
                  {([
                    { id: 'all', label: 'Toutes les pièces' },
                    { id: 'in_stock', label: 'En stock uniquement' },
                    { id: 'new', label: 'Nouveautés' },
                    { id: 'bestseller', label: 'Best-Sellers' },
                    { id: 'sale', label: 'En promotion' },
                  ] as const).map((o) => (
                    <button key={o.id} type="button" onClick={() => setAvailability(o.id)} className={`text-left py-1 cursor-pointer ${availability === o.id ? 'font-bold text-black' : 'font-light text-black/65 hover:text-black'}`}>{o.label}</button>
                  ))}
                </div>
              </Section>

              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-[10.5px] font-bold uppercase tracking-[0.18em] text-black/50">
                  <span>Prix maximum</span>
                  <span className="tabular-nums text-black">{maxPrice.toLocaleString('fr-FR')} FCFA</span>
                </div>
                <input type="range" min={10000} max={150000} step={2500} value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} className="w-full accent-black" />
              </div>
            </div>

            <div className="p-5 border-t border-black/10 flex gap-2.5 shrink-0">
              <button type="button" onClick={clearFilters} className="flex-1 py-3 bg-[#F5F5F5] text-xs font-bold uppercase tracking-[0.14em] text-black hover:bg-black/10 cursor-pointer">Réinitialiser</button>
              <button type="button" onClick={() => setShowMobileFilters(false)} className="flex-1 py-3 bg-black text-white text-xs font-bold uppercase tracking-[0.14em] hover:bg-black/85 cursor-pointer">Appliquer ({count})</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
