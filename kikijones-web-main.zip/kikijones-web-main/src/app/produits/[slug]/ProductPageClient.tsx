'use client'

import { useState, useEffect } from 'react'
import { getProducts, Product } from '@/lib/api'
import ThemeProductPage from '@/components/products/ThemeProductPage'
import { addToRecentlyViewed } from '@/components/products/RecentlyViewed'

interface ProductPageClientProps {
  product: Product
}

export default function ProductPageClient({ product }: ProductPageClientProps) {
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([])

  useEffect(() => {
    // Track as recently viewed
    addToRecentlyViewed(product)

    // Get related products from same category
    async function loadRelated() {
      // Linked pieces (chosen by hand in the admin) come first
      if (product.complementary_products && product.complementary_products.length > 0) {
        setRelatedProducts(product.complementary_products.slice(0, 4))
        return
      }
      if (product.category) {
        try {
          const relatedProductsData = await getProducts({ category: product.category })
          const related = relatedProductsData.results
            .filter(p => p.id !== product.id)
            .slice(0, 4)
          setRelatedProducts(related)
        } catch {
          // Ignore error, related products are not critical
        }
      }
    }
    loadRelated()
  }, [product])

  return <ThemeProductPage product={product} related={relatedProducts} />
}
