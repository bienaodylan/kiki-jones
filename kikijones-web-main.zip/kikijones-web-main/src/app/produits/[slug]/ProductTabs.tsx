'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { ChevronDown, Star, ThumbsUp, Package, RotateCcw, X } from 'lucide-react'
import { Product, API_ENDPOINTS, fetchAPI } from '@/lib/api'
import { getAccessToken, bootstrapAuth } from '@/lib/auth-store'
import { sanitizeHTML } from '@/lib/sanitize'

interface Review {
  id: string
  user_name: string
  rating: number
  title?: string
  comment: string
  is_approved: boolean
  helpful_count: number
  created_at: string
}

interface ProductTabsProps {
  product: Product
}

export default function ProductTabs({ product }: ProductTabsProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<'description' | 'shipping' | 'reviews'>('description')
  const [reviews, setReviews] = useState<Review[]>([])
  const [reviewsLoading, setReviewsLoading] = useState(false)

  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [canReview, setCanReview] = useState(false)
  const [canReviewReason, setCanReviewReason] = useState('')
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [reviewRating, setReviewRating] = useState(5)
  const [reviewTitle, setReviewTitle] = useState('')
  const [reviewComment, setReviewComment] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState('')

  const fetchReviews = () => {
    setReviewsLoading(true)
    fetch(API_ENDPOINTS.productReviews(product.id))
      .then(r => r.json())
      .then(data => {
        const results = data.results || data || []
        setReviews(Array.isArray(results) ? results : [])
      })
      .catch(() => setReviews([]))
      .finally(() => setReviewsLoading(false))
  }

  useEffect(() => {
    if (activeTab === 'reviews' && reviews.length === 0) {
      fetchReviews()
    }
  }, [activeTab, product.id])

  useEffect(() => {
    if (activeTab !== 'reviews') return
    bootstrapAuth().then((token) => {
      setIsLoggedIn(!!token)
      if (!token) return
      fetchAPI<{ can_review: boolean; reason: string }>(API_ENDPOINTS.canReview(product.id))
        .then(data => {
          setCanReview(data.can_review)
          setCanReviewReason(data.reason || '')
        })
        .catch(() => {
          setCanReview(false)
          setCanReviewReason('')
        })
    })
  }, [activeTab, product.id])

  const handleSubmitReview = async () => {
    const token = await bootstrapAuth()
    if (!token) {
      router.push('/login')
      return
    }
    setSubmitting(true)
    setSubmitError('')
    try {
      await fetchAPI(API_ENDPOINTS.reviews, {
        method: 'POST',
        body: JSON.stringify({
          product: product.id,
          rating: reviewRating,
          title: reviewTitle,
          comment: reviewComment,
        }),
      })
      setShowReviewModal(false)
      setReviewRating(5)
      setReviewTitle('')
      setReviewComment('')
      setCanReview(false)
      setCanReviewReason('Vous avez déjà donné un avis pour ce produit.')
      fetchReviews()
    } catch (err: any) {
      setSubmitError(err?.body?.detail || err?.body?.rating?.[0] || err?.message || 'Erreur lors de l\'envoi de votre avis.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="bg-white border-t border-gray-200">
      {/* Tab Headers */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab('description')}
          className={`flex-1 py-4 px-2 font-bold uppercase text-xs md:text-sm tracking-wider transition-all ${
            activeTab === 'description'
              ? 'text-black border-b-2 border-black'
              : 'text-gray-500 hover:text-black border-b-2 border-transparent'
          }`}
        >
          Description
        </button>
        <button
          onClick={() => setActiveTab('shipping')}
          className={`flex-1 py-4 px-2 font-bold uppercase text-xs md:text-sm tracking-wider transition-all ${
            activeTab === 'shipping'
              ? 'text-black border-b-2 border-black'
              : 'text-gray-500 hover:text-black border-b-2 border-transparent'
          }`}
        >
          Livraison & Retours
        </button>
        <button
          onClick={() => setActiveTab('reviews')}
          className={`flex-1 py-4 px-2 font-bold uppercase text-xs md:text-sm tracking-wider transition-all ${
            activeTab === 'reviews'
              ? 'text-black border-b-2 border-black'
              : 'text-gray-500 hover:text-black border-b-2 border-transparent'
          }`}
        >
          Avis ({product.reviews_count})
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-8">
        {/* Description Tab */}
        {activeTab === 'description' && (
          <div className="space-y-6">
            {product.description ? (
              <div 
                className="prose prose-gray max-w-none leading-relaxed"
                dangerouslySetInnerHTML={{ __html: sanitizeHTML(product.description) }}
              />
            ) : (
              <p className="text-gray-600 leading-relaxed">{product.short_description || 'Aucune description disponible.'}</p>
            )}

            {/* Product Details */}
            <div className="grid md:grid-cols-2 gap-4 pt-6 border-t">
              <div>
                <h3 className="font-bold uppercase text-sm mb-3 tracking-wider">Détails du produit</h3>
                <dl className="space-y-2 text-sm">
                  <div className="flex gap-2">
                    <dt className="text-gray-500 font-medium">Référence:</dt>
                    <dd className="font-bold">{product.id}</dd>
                  </div>
                  {product.category_name && (
                    <div className="flex gap-2">
                      <dt className="text-gray-500 font-medium">Catégorie:</dt>
                      <dd className="font-bold">{product.category_name}</dd>
                    </div>
                  )}
                  {!product.is_external_stock && (
                    <div className="flex gap-2">
                      <dt className="text-gray-500 font-medium">Stock:</dt>
                      <dd className="font-bold">{product.total_stock} unités</dd>
                    </div>
                  )}
                </dl>
              </div>

              <div>
                <h3 className="font-bold uppercase text-sm mb-3 tracking-wider">Entretien</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Laver à l'eau froide</li>
                  <li>• Ne pas utiliser d'eau de javel</li>
                  <li>• Sécher à plat</li>
                  <li>• Repasser à basse température</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Shipping Tab */}
        {activeTab === 'shipping' && (
          <div className="space-y-8">
            {/* Shipping Info */}
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center flex-shrink-0">
                  <Package className="text-white" size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-2">Informations de livraison</h3>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Livraison standard gratuite pour les commandes de 50 000 FCFA et plus</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Livraison express disponible (2-3 jours ouvrés) - 5 000 FCFA</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Les commandes sont expédiées du lundi au vendredi</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Suivi de commande disponible par email</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Délai de traitement: 1-2 jours ouvrés</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg border-2 border-gray-200">
                <h4 className="font-bold text-sm uppercase mb-3 tracking-wider">Délais de livraison estimés</h4>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Dakar et environs</span>
                    <span className="font-bold">1-2 jours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Autres régions du Sénégal</span>
                    <span className="font-bold">3-5 jours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Afrique de l'Ouest</span>
                    <span className="font-bold">5-10 jours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">International</span>
                    <span className="font-bold">10-21 jours</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Returns Info */}
            <div className="border-t-2 pt-8 space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center flex-shrink-0">
                  <RotateCcw className="text-white" size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg mb-2">Politique de retours</h3>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Retours gratuits sous 30 jours pour tous les articles</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Les articles doivent être non portés, non lavés avec étiquettes</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Remboursement complet sur le mode de paiement original</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Échanges disponibles pour taille ou couleur différente</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-black font-bold">•</span>
                      <span>Remboursement traité sous 5-7 jours ouvrés après réception</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-yellow-50 p-6 rounded-lg border-2 border-yellow-200">
                <p className="text-sm font-medium">
                  <span className="font-bold">Note importante:</span> Les articles en promotion finale ne peuvent pas être retournés ou échangés. 
                  Veuillez contacter notre service client pour toute question.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Reviews Tab */}
        {activeTab === 'reviews' && (
          <div className="space-y-8">
            {/* Reviews Summary */}
            <div className="grid md:grid-cols-2 gap-8 pb-8 border-b-2">
              <div className="text-center">
                <div className="text-6xl font-black mb-2">{product.average_rating}</div>
                <div className="flex justify-center gap-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={24}
                      className={i < Math.floor(parseFloat(product.average_rating)) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                    />
                  ))}
                </div>
                <p className="text-sm text-gray-600">Basé sur {product.reviews_count} avis</p>
              </div>
              
              <div className="space-y-2">
                {[5, 4, 3, 2, 1].map((stars) => {
                  const count = reviews.filter(r => r.rating === stars).length
                  const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0
                  return (
                    <div key={stars} className="flex items-center gap-3">
                      <span className="text-sm font-medium w-8">{stars}★</span>
                      <div className="flex-1 h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-yellow-400"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 w-12 text-right">
                        {Math.round(percentage)}%
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* Write a review */}
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">Avis des clients</h3>
              {!isLoggedIn ? (
                <button
                  onClick={() => router.push('/login')}
                  className="text-sm font-bold uppercase tracking-wider underline hover:no-underline"
                >
                  Se connecter pour laisser un avis
                </button>
              ) : canReview ? (
                <button
                  onClick={() => setShowReviewModal(true)}
                  className="text-sm font-bold uppercase tracking-wider underline hover:no-underline"
                >
                  Écrire un avis
                </button>
              ) : canReviewReason ? (
                <span className="text-sm text-gray-500">{canReviewReason}</span>
              ) : null}
            </div>

            {/* Real Reviews */}
            <div className="space-y-6">
              {reviewsLoading ? (
                <div className="text-center py-12">
                  <div className="w-8 h-8 border-2 border-gray-200 border-t-black rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-gray-500 text-sm">Chargement des avis...</p>
                </div>
              ) : reviews.length > 0 ? (
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b pb-6 last:border-b-0">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex gap-1 mb-1">
                            {[...Array(5)].map((_, starIdx) => (
                              <Star
                                key={starIdx}
                                size={16}
                                className={starIdx < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                              />
                            ))}
                          </div>
                          <p className="font-bold">{review.user_name || 'Client vérifié'}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(review.created_at).toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
                          </p>
                        </div>
                        <button className="flex items-center gap-1 text-sm text-gray-600 hover:text-black transition">
                          <ThumbsUp size={16} />
                          <span>Utile ({review.helpful_count || 0})</span>
                        </button>
                      </div>
                      {review.title && <p className="font-semibold mb-1">{review.title}</p>}
                      <p className="text-gray-700 leading-relaxed">{review.comment}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-gray-200">
                  <Star size={48} className="mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 font-medium mb-2">Aucun avis pour le moment</p>
                  <p className="text-sm text-gray-500">Soyez le premier à laisser un avis sur ce produit</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Write a review modal */}
      {showReviewModal && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 p-4"
          onClick={() => !submitting && setShowReviewModal(false)}
        >
          <div
            className="w-full max-w-lg rounded-lg bg-white p-6 md:p-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-6">
              <h3 className="text-xl font-bold">Écrire un avis</h3>
              <button
                onClick={() => !submitting && setShowReviewModal(false)}
                className="text-gray-400 hover:text-black transition"
              >
                <X size={24} />
              </button>
            </div>

            <div className="mb-6">
              <p className="text-sm font-medium mb-2">Votre note</p>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} type="button" onClick={() => setReviewRating(star)}>
                    <Star
                      size={32}
                      className={star <= reviewRating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-4">
              <label className="text-sm font-medium mb-2 block">Titre (optionnel)</label>
              <input
                type="text"
                value={reviewTitle}
                onChange={(e) => setReviewTitle(e.target.value)}
                maxLength={100}
                className="w-full border-2 border-gray-200 rounded-lg px-4 py-2 focus:outline-none focus:border-black"
                placeholder="Résumé de votre avis"
              />
            </div>

            <div className="mb-6">
              <label className="text-sm font-medium mb-2 block">Votre commentaire</label>
              <textarea
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                rows={4}
                className="w-full border-2 border-gray-200 rounded-lg px-4 py-2 focus:outline-none focus:border-black resize-none"
                placeholder="Décrivez votre expérience..."
              />
            </div>

            {submitError && (
              <div className="mb-4 bg-red-50 border-2 border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">
                {submitError}
              </div>
            )}

            <button
              onClick={handleSubmitReview}
              disabled={submitting || !reviewComment.trim()}
              className="w-full bg-black text-white font-bold uppercase tracking-wider text-sm py-4 rounded-lg hover:bg-gray-800 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? 'Envoi...' : 'Publier mon avis'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
