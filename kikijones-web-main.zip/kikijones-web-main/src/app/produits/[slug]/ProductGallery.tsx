'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { createPortal } from 'react-dom'
import Image from 'next/image'
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, X } from 'lucide-react'

interface ProductGalleryProps {
  images: (string | null)[]
  productName: string
  selectedColorHex?: string | null
}

export default function ProductGallery({ images, productName, selectedColorHex }: ProductGalleryProps) {
  const [selectedImage, setSelectedImage] = useState(0)
  const [isZoomed, setIsZoomed] = useState(false)
  const [magnified, setMagnified] = useState(false)
  const [pan, setPan] = useState({ x: 50, y: 50 })
  const [mounted, setMounted] = useState(false)
  const touchStartX = useRef<number | null>(null)

  useEffect(() => setMounted(true), [])

  // Reset to first image when color changes
  useEffect(() => {
    if (selectedColorHex) {
      setSelectedImage(0)
    }
  }, [selectedColorHex])

  const validImages = images.filter(Boolean) as string[]
  const count = validImages.length

  const closeZoom = useCallback(() => {
    setIsZoomed(false)
    setMagnified(false)
    setPan({ x: 50, y: 50 })
  }, [])

  const goNext = useCallback(() => {
    setMagnified(false)
    setSelectedImage((prev) => (count ? (prev + 1) % count : 0))
  }, [count])

  const goPrev = useCallback(() => {
    setMagnified(false)
    setSelectedImage((prev) => (count ? (prev - 1 + count) % count : 0))
  }, [count])

  // Zoom modal: Escape closes, arrows navigate, page scroll is locked while open
  useEffect(() => {
    if (!isZoomed) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeZoom()
      else if (e.key === 'ArrowRight') goNext()
      else if (e.key === 'ArrowLeft') goPrev()
    }
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
    }
  }, [isZoomed, closeZoom, goNext, goPrev])

  if (count === 0) {
    return (
      <div className="lg:sticky lg:top-4">
        <div className="aspect-[3/4] bg-[#f2f2f2] flex items-center justify-center">
          <span className="text-4xl text-gray-300">Pas d&apos;image</span>
        </div>
      </div>
    )
  }

  return (
    <div className="lg:sticky lg:top-4 space-y-4">
      {/* Main Image */}
      <div className="relative aspect-[3/4] bg-[#f2f2f2] overflow-hidden group">
        <Image
          src={validImages[selectedImage]}
          alt={`${productName} - ${selectedImage + 1}`}
          fill
          sizes="(max-width: 1024px) 100vw, 50vw"
          className="object-cover cursor-zoom-in"
          priority
          onClick={() => setIsZoomed(true)}
        />

        {/* Navigation Arrows */}
        {count > 1 && (
          <>
            <button
              onClick={goPrev}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg lg:opacity-0 lg:group-hover:opacity-100 transition-opacity"
              aria-label="Image précédente"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={goNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg lg:opacity-0 lg:group-hover:opacity-100 transition-opacity"
              aria-label="Image suivante"
            >
              <ChevronRight size={20} />
            </button>
          </>
        )}

        {/* Zoom Button */}
        <button
          onClick={() => setIsZoomed(true)}
          className="absolute top-4 right-4 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg lg:opacity-0 lg:group-hover:opacity-100 transition-opacity"
          aria-label="Zoomer"
        >
          <ZoomIn size={20} />
        </button>

        {/* Image Counter */}
        {count > 1 && (
          <div className="absolute bottom-4 right-4 px-3 py-1 bg-black/70 text-white text-sm rounded-full">
            {selectedImage + 1} / {count}
          </div>
        )}
      </div>

      {/* Thumbnail Grid */}
      {count > 1 && (
        <div className="grid grid-cols-3 md:grid-cols-4 gap-2 md:gap-3">
          {validImages.map((image, index) => (
            <button
              key={index}
              onClick={() => setSelectedImage(index)}
              className={`aspect-square bg-[#f2f2f2] overflow-hidden relative cursor-pointer transition-all ${
                selectedImage === index ? 'ring-2 ring-black' : 'hover:ring-2 hover:ring-gray-400'
              }`}
            >
              <Image src={image} alt={`${productName} - ${index + 1}`} fill sizes="120px" className="object-cover" />
            </button>
          ))}
        </div>
      )}

      {/* Zoom Modal (portal so it always sits above the header) */}
      {isZoomed &&
        mounted &&
        createPortal(
          <div
            className="fixed inset-0 z-[1000] bg-black/95 flex flex-col"
            role="dialog"
            aria-modal="true"
            aria-label={`${productName} - zoom`}
            onClick={closeZoom}
          >
            {/* Top bar */}
            <div className="flex items-center justify-between px-4 py-3 text-white" onClick={(e) => e.stopPropagation()}>
              <span className="text-sm tracking-wide opacity-80">
                {selectedImage + 1} / {count}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setMagnified((m) => !m)}
                  className="w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition"
                  aria-label={magnified ? 'Réduire' : 'Agrandir'}
                >
                  {magnified ? <ZoomOut size={20} /> : <ZoomIn size={20} />}
                </button>
                <button
                  onClick={closeZoom}
                  className="w-11 h-11 rounded-full bg-white text-black hover:bg-gray-200 flex items-center justify-center transition"
                  aria-label="Fermer"
                >
                  <X size={22} />
                </button>
              </div>
            </div>

            {/* Image area: tap on the image toggles magnification, tap outside closes */}
            <div
              className="relative flex-1 min-h-0 overflow-hidden"
              onTouchStart={(e) => {
                touchStartX.current = e.touches[0].clientX
              }}
              onTouchEnd={(e) => {
                if (touchStartX.current === null || magnified) return
                const dx = e.changedTouches[0].clientX - touchStartX.current
                touchStartX.current = null
                if (Math.abs(dx) > 60) {
                  if (dx < 0) goNext()
                  else goPrev()
                }
              }}
            >
              <div
                className={`absolute inset-0 ${magnified ? 'cursor-zoom-out' : 'cursor-zoom-in'}`}
                onClick={(e) => {
                  e.stopPropagation()
                  setMagnified((m) => !m)
                }}
                onMouseMove={(e) => {
                  if (!magnified) return
                  const r = e.currentTarget.getBoundingClientRect()
                  setPan({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 })
                }}
                onTouchMove={(e) => {
                  if (!magnified) return
                  const r = e.currentTarget.getBoundingClientRect()
                  const t = e.touches[0]
                  setPan({ x: ((t.clientX - r.left) / r.width) * 100, y: ((t.clientY - r.top) / r.height) * 100 })
                }}
              >
                <Image
                  src={validImages[selectedImage]}
                  alt={`${productName} - Zoom`}
                  fill
                  sizes="100vw"
                  className="object-contain transition-transform duration-200 select-none"
                  style={{ transform: magnified ? 'scale(2.2)' : 'scale(1)', transformOrigin: `${pan.x}% ${pan.y}%` }}
                  draggable={false}
                />
              </div>

              {count > 1 && !magnified && (
                <>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      goPrev()
                    }}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-11 h-11 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition"
                    aria-label="Image précédente"
                  >
                    <ChevronLeft size={22} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      goNext()
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-11 h-11 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition"
                    aria-label="Image suivante"
                  >
                    <ChevronRight size={22} />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnails */}
            {count > 1 && (
              <div className="flex justify-center gap-2 px-4 py-3 overflow-x-auto" onClick={(e) => e.stopPropagation()}>
                {validImages.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setMagnified(false)
                      setSelectedImage(index)
                    }}
                    className={`relative w-14 h-14 shrink-0 rounded-md overflow-hidden transition ${
                      selectedImage === index ? 'ring-2 ring-white opacity-100' : 'opacity-50 hover:opacity-90'
                    }`}
                    aria-label={`Image ${index + 1}`}
                  >
                    <Image src={image} alt="" fill sizes="56px" className="object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>,
          document.body
        )}
    </div>
  )
}
