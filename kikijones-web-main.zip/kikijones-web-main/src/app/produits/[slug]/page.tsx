import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getProductBySlug } from '@/lib/api'
import ProductPageClient from './ProductPageClient'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://kikijones.com'

interface ProductPageProps {
  params: Promise<{
    slug: string
  }>
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const { slug } = await params
  const product = await getProductBySlug(slug)

  if (!product) {
    return {
      title: 'Produit introuvable - KikiJones',
    }
  }

  const hasDiscount = product.sale_price && parseFloat(product.sale_price) < parseFloat(product.base_price)
  const finalPrice = hasDiscount ? parseFloat(product.sale_price!) : parseFloat(product.base_price)
  const description = product.short_description || product.description?.replace(/<[^>]*>/g, '').slice(0, 160) || `${product.name} - KikiJones`

  return {
    title: `${product.name} - KikiJones`,
    description,
    openGraph: {
      title: product.name,
      description,
      url: `${SITE_URL}/produits/${product.slug}`,
      siteName: 'KikiJones',
      images: product.main_image ? [
        {
          url: product.main_image,
          width: 800,
          height: 800,
          alt: product.name,
        }
      ] : [],
      locale: 'fr_FR',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: product.name,
      description,
      images: product.main_image ? [product.main_image] : [],
    },
    other: {
      'product:price:amount': finalPrice.toString(),
      'product:price:currency': 'XOF',
      'product:availability': product.is_in_stock ? 'in stock' : 'out of stock',
    },
  }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { slug } = await params
  const product = await getProductBySlug(slug)

  if (!product) {
    notFound()
  }

  return <ProductPageClient product={product} />
}
