'use client'

import { useState, useEffect, useRef } from 'react'
import Image from 'next/image'
import { ShoppingCart, Heart, Share2, Truck, Shield, RotateCcw, Star, Facebook, Twitter, Copy, Check, Flame, Zap } from 'lucide-react'
import { Product } from '@/lib/api'
import { useCart } from '@/contexts/CartContext'
import { useWishlist } from '@/contexts/WishlistContext'
import { useCurrency } from '@/contexts/CurrencyContext'

interface ProductInfoProps {
  product: Product
  onColorChange?: (colorHex: string | null) => void
  /** 'head' = title/price/description, 'buy' = options + add to bag, 'all' = everything (default) */
  part?: 'head' | 'buy' | 'all'
}

export default function ProductInfo({ product, onColorChange, part = 'all' }: ProductInfoProps) {
  const show = (p: 'head' | 'buy') => part === 'all' || part === p
  const { addToCart } = useCart()
  const { isInWishlist, toggleWishlist } = useWishlist()
  const { formatPrice } = useCurrency()
  const [quantity, setQuantity] = useState(1)
  const [showShareMenu, setShowShareMenu] = useState(false)
  const [copied, setCopied] = useState(false)
  const [selectedColor, setSelectedColor] = useState<string | null>(null)
  const [selectedSize, setSelectedSize] = useState<string | null>(null)
  const [showAddedToCart, setShowAddedToCart] = useState(false)
  const addBtnRef = useRef<HTMLButtonElement>(null)
  const [stickyTop, setStickyTop] = useState(false)

  // Mini bar glued to the top once the main "add" button has scrolled out of view (like the reference)
  useEffect(() => {
    const el = addBtnRef.current
    if (!el) return
    const io = new IntersectionObserver(
      ([entry]) => setStickyTop(!entry.isIntersecting && entry.boundingClientRect.top < 0),
      { threshold: 0 }
    )
    io.observe(el)
    return () => io.disconnect()
  }, [])

  const isFavorite = isInWishlist(product.id)
  const toggleFavorite = () => toggleWishlist(product)

  // Notify parent when color changes (toggle on/off)
  const handleColorChange = (colorHex: string) => {
    const newColor = selectedColor === colorHex ? null : colorHex
    setSelectedColor(newColor)
    onColorChange?.(newColor)
  }

  // Toggle size selection
  const handleSizeChange = (size: string) => {
    setSelectedSize(selectedSize === size ? null : size)
  }

  // Add to cart handler
  const handleAddToCart = () => {
    if (!canAddToCart) return
    // Calculate price based on variant and discount
    const itemPrice = finalPrice
    
    // Add to cart
    addToCart({
      product: product,
      variantId: selectedVariant?.id,
      selectedColor: selectedColor,
      selectedSize: selectedSize,
      quantity: quantity,
      price: itemPrice
    })
    
    // Show success notification
    setShowAddedToCart(true)
    
    // Auto-hide after 3 seconds
    setTimeout(() => {
      setShowAddedToCart(false)
    }, 3000)
  }

  // Extract unique colors and sizes from variants
  const availableColors = product.variants
    ? Array.from(new Map(
        product.variants
          .filter(v => v.color && v.color_hex)
          .map(v => [v.color_hex, { name: v.color!, hex: v.color_hex! }])
      ).values())
    : []

  const availableSizes = product.variants
    ? Array.from(new Set(
        product.variants
          .filter(v => v.size)
          .map(v => v.size!)
      ))
    : []

  // A choice is required whenever the product offers sizes / colors. Without it the
  // old lookup fell back to variants[0], so "Ajouter" with nothing selected put an
  // arbitrary size (maybe an unavailable one) in the cart.
  const needsSize = availableSizes.length > 0
  const needsColor = availableColors.length > 0
  const selectionComplete = (!needsSize || !!selectedSize) && (!needsColor || !!selectedColor)

  // Get selected variant (only once the required choices are made)
  const selectedVariant = selectionComplete
    ? product.variants?.find(
        v => (!selectedColor || v.color_hex === selectedColor) && (!selectedSize || v.size === selectedSize)
      )
    : undefined

  // A single possible size / color needs no click
  useEffect(() => {
    if (availableSizes.length === 1) setSelectedSize(prev => prev ?? availableSizes[0])
    if (availableColors.length === 1) setSelectedColor(prev => prev ?? availableColors[0].hex)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product.id, availableSizes.length, availableColors.length])

  const variantAvailable = !selectedVariant || selectedVariant.in_stock
  const canAddToCart = product.is_in_stock && product.total_stock > 0 && selectionComplete && variantAvailable
  const addToCartLabel = !(product.is_in_stock && product.total_stock > 0)
    ? 'Rupture de stock'
    : !selectionComplete
      ? (needsSize && !selectedSize ? 'Choisissez une taille' : 'Choisissez une couleur')
      : !variantAvailable
        ? 'Rupture de stock'
        : 'Ajouter au panier'

  const hasDiscount = product.sale_price && parseFloat(product.sale_price) < parseFloat(product.base_price)
  const basePrice = selectedVariant?.price_adjustment 
    ? parseFloat(product.base_price) + parseFloat(selectedVariant.price_adjustment.toString())
    : parseFloat(product.base_price)
  const finalPrice = hasDiscount ? parseFloat(product.sale_price!) : basePrice

  const handleShare = async (platform?: string) => {
    const url = window.location.href
    const text = `Découvrez ${product.name} sur KikiJones`

    if (platform === 'copy') {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      return
    }

    const shareUrls: Record<string, string> = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      twitter: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
      instagram: url // Instagram doesn't support direct sharing
    }

    if (platform && shareUrls[platform]) {
      window.open(shareUrls[platform], '_blank', 'width=600,height=400')
    }

    setShowShareMenu(false)
  }

  return (
    <div className="space-y-6">
      {/* Success Toast Notification */}
      {showAddedToCart && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-5 fade-in duration-300">
          <div className="bg-black text-white px-6 py-4 rounded-lg shadow-2xl flex items-center gap-3 min-w-[300px]">
            <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm">Ajouté au panier !</p>
              <p className="text-xs text-gray-300 mt-0.5">{quantity} × {product.name}</p>
            </div>
            <button 
              onClick={() => setShowAddedToCart(false)}
              className="text-gray-400 hover:text-white transition"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {show('head') && (<>
      {/* Badges */}
      <div className="flex flex-wrap gap-2">
        {product.is_new && (
          <span className="px-2 py-0.5 bg-black text-white text-[10px] font-bold tracking-[0.14em] uppercase">
            Nouveau
          </span>
        )}
        {hasDiscount && (
          <span className="px-2 py-0.5 bg-white text-black border border-black/15 text-[10px] font-bold tracking-[0.14em] uppercase">
            -{product.discount_percentage}% OFF
          </span>
        )}
        {product.is_featured && (
          <span className="px-2 py-0.5 bg-black text-white text-[10px] font-bold tracking-[0.14em] uppercase">
            En vedette
          </span>
        )}
        {product.is_bestseller && (
          <span className="px-2 py-0.5 bg-black text-white text-[10px] font-bold tracking-[0.14em] uppercase">
            <Flame size={14} className="inline -mt-0.5 mr-1" />Meilleure vente
          </span>
        )}
      </div>

      {/* Social Proof */}
      {product.sales_count > 0 && (
        <div className="flex flex-wrap items-center gap-4 text-sm">
          <div className="flex items-center gap-1.5 text-black/70">
            <Flame size={16} />
            <span className="font-medium">{product.sales_count}+ vendus</span>
          </div>
        </div>
      )}

      {/* Product Name */}
      <div>
        <h1 className="text-xl md:text-2xl font-bold tracking-[-0.02em] leading-tight">
          {product.name}
        </h1>
        
        {/* Reviews */}
        <div className="flex items-center gap-2 mt-2">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={16}
                className={i < Math.floor(parseFloat(product.average_rating)) ? 'fill-black text-black' : 'text-black/20'}
              />
            ))}
          </div>
          <span className="text-xs font-light text-black/60">
            {product.average_rating} ({product.reviews_count} avis)
          </span>
        </div>
      </div>

      {/* Price */}
      <div className="flex items-baseline gap-3 flex-wrap">
        {hasDiscount ? (
          <>
            <span className="text-xl font-bold text-black tabular-nums">
              {formatPrice(finalPrice)}
            </span>
            <span className="text-sm font-light text-black/45 line-through tabular-nums">
              {formatPrice(parseFloat(product.base_price))}
            </span>
            <span className="text-xs text-black/70 font-medium">
              Économisez {formatPrice(parseFloat(product.base_price) - finalPrice)}
            </span>
          </>
        ) : (
          <span className="text-xl font-bold tabular-nums">
            {formatPrice(finalPrice)}
          </span>
        )}
      </div>

      {/* Stock Status */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm">
          {product.is_in_stock && product.total_stock > 0 ? (
            <>
              <div className="w-2 h-2 bg-black rounded-full"></div>
              <span className="font-medium text-black">
                {product.is_external_stock ? 'En stock' : `En stock (${product.total_stock} unités disponibles)`}
              </span>
            </>
          ) : (
            <>
              <div className="w-2 h-2 bg-black/30 rounded-full"></div>
              <span className="font-medium text-black/60">Rupture de stock</span>
            </>
          )}
        </div>
        {/* Low stock urgency bar */}
        {!product.is_external_stock && product.is_in_stock && product.total_stock > 0 && product.total_stock <= 10 && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <div className="flex items-center gap-2 text-amber-800 text-sm font-medium mb-2">
              <Zap size={16} />
              <span>Plus que {product.total_stock} en stock — Dépêchez-vous !</span>
            </div>
            <div className="w-full bg-amber-200 rounded-full h-1.5">
              <div 
                className="bg-amber-600 h-1.5 rounded-full transition-all"
                style={{ width: `${Math.min(product.total_stock * 10, 100)}%` }} 
              />
            </div>
          </div>
        )}
      </div>

      {/* Short Description */}
      {product.short_description && (
        <div className="text-gray-600 leading-relaxed border-l-4 border-black pl-4">
          {product.short_description}
        </div>
      )}

      </>)}
      {show('buy') && (<>
      {/* Color Selector */}
      {availableColors.length > 0 && (
        <div className="space-y-3">
          <label className="text-[11px] font-bold uppercase tracking-[0.16em] text-black/55">
            Couleur{selectedColor ? <span className="font-medium normal-case tracking-normal text-black"> · {availableColors.find(c => c.hex === selectedColor)?.name}</span> : null}
          </label>
          <div className="flex flex-wrap gap-2">
            {availableColors.map((color) => (
              <button
                key={color.hex}
                onClick={() => handleColorChange(color.hex)}
                title={color.name}
                className={`relative w-7 h-7 rounded-full border transition-all ${
                  selectedColor === color.hex ? 'border-black ring-1 ring-black ring-offset-2' : 'border-black/20'
                }`}
                style={{ backgroundColor: color.hex }}
              >
                {selectedColor === color.hex && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full shadow-sm"></div>
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Size Selector */}
      {availableSizes.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-bold uppercase tracking-[0.16em] text-black/55">Taille</label>
            <a href="/guide-tailles" className="text-[11px] font-bold uppercase tracking-[0.12em] underline underline-offset-4 text-black">Guide des tailles</a>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {availableSizes.map((size) => (
              <button
                key={size}
                onClick={() => handleSizeChange(size)}
                className={`py-2.5 border border-black/15 rounded-none text-xs font-bold transition-colors hover:border-black ${
                  selectedSize === size
                    ? 'border-black bg-black text-white'
                    : 'bg-white text-black'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
          {selectedSize && (
            <p className="text-xs font-light text-black/60">
              Taille sélectionnée: <span className="font-medium">{selectedSize}</span>
            </p>
          )}
        </div>
      )}

      {/* Variant Stock Info */}
      {selectedVariant && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">Variante sélectionnée</p>
              <p className="text-xs text-gray-500 mt-1">
                SKU: {selectedVariant.sku}
              </p>
            </div>
            <div className="text-right">
              {selectedVariant.in_stock ? (
                <span className="inline-flex items-center gap-1 text-sm font-medium text-black">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  {product.is_external_stock ? 'Disponible' : `${selectedVariant.stock} en stock`}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-sm font-medium text-red-600">
                  <div className="w-2 h-2 bg-black rounded-full"></div>
                  Rupture de stock
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quantity Selector */}
      <div className="space-y-2">
        <label className="text-[11px] font-bold uppercase tracking-[0.16em] text-black/55">Quantité</label>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            className="w-10 h-11 border border-black/15 rounded-none font-bold hover:border-black transition"
            disabled={quantity <= 1}
          >
            -
          </button>
          <span className="w-12 text-center text-sm font-bold tabular-nums">{quantity}</span>
          <button
            onClick={() => setQuantity(Math.min(product.total_stock, quantity + 1))}
            className="w-10 h-11 border border-black/15 rounded-none font-bold hover:border-black transition"
            disabled={quantity >= product.total_stock}
          >
            +
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3 pt-4">
        <button
          ref={addBtnRef}
          onClick={handleAddToCart}
          className="w-full bg-black text-white py-4 rounded-none font-bold uppercase tracking-wider hover:bg-black/85 transition-all flex items-center justify-center gap-2 text-xs tracking-[0.2em] disabled:bg-gray-400 disabled:cursor-not-allowed"
          disabled={!canAddToCart}
        >
          <ShoppingCart size={22} />
          {addToCartLabel}
        </button>

        <div className="grid grid-cols-2 gap-2 md:gap-3">
          <button
            onClick={toggleFavorite}
            className={`border py-3 rounded-none font-medium transition-all flex items-center justify-center gap-2 ${
              isFavorite
                ? 'border-black bg-white text-black'
                : 'border-gray-300 hover:border-black'
            }`}
          >
            <Heart size={18} className={isFavorite ? 'fill-black' : ''} />
            {isFavorite ? 'Ajouté' : 'Favoris'}
          </button>
          
          <div className="relative">
            <button
              onClick={() => setShowShareMenu(!showShareMenu)}
              className="w-full border border-gray-300 py-3 rounded-none font-medium hover:border-black transition flex items-center justify-center gap-2"
            >
              <Share2 size={18} />
              Partager
            </button>
            
            {showShareMenu && (
              <div className="absolute top-full mt-2 right-0 bg-white border-2 border-gray-200 rounded-lg shadow-xl p-4 z-10 w-56">
                <p className="text-xs font-bold uppercase text-gray-500 mb-3">Partager sur</p>
                <div className="space-y-2">
                  <button
                    onClick={() => handleShare('facebook')}
                    className="w-full flex items-center gap-3 p-2 hover:bg-gray-50 rounded transition"
                  >
                    <Facebook size={20} className="text-blue-600" />
                    <span className="text-sm font-medium">Facebook</span>
                  </button>
                  <button
                    onClick={() => handleShare('twitter')}
                    className="w-full flex items-center gap-3 p-2 hover:bg-gray-50 rounded transition"
                  >
                    <Twitter size={20} className="text-blue-400" />
                    <span className="text-sm font-medium">Twitter</span>
                  </button>
                  <button
                    onClick={() => handleShare('copy')}
                    className="w-full flex items-center gap-3 p-2 hover:bg-gray-50 rounded transition"
                  >
                    {copied ? (
                      <>
                        <Check size={20} className="text-green-600" />
                        <span className="text-sm font-medium text-green-600">Copié!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={20} className="text-gray-600" />
                        <span className="text-sm font-medium">Copier le lien</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="border-t border-b py-6 space-y-4">
        <div className="flex items-start gap-3">
          <Truck className="w-6 h-6 text-gray-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold uppercase text-sm tracking-wider">Livraison gratuite</p>
            <p className="text-sm text-gray-600 mt-1">
              Pour les commandes supérieures à {formatPrice(50000)} • Livraison en 2-5 jours
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Shield className="w-6 h-6 text-gray-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold uppercase text-sm tracking-wider">Paiement 100% sécurisé</p>
            <p className="text-sm text-gray-600 mt-1">
              Transactions sécurisées • Protection de vos données
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <RotateCcw className="w-6 h-6 text-gray-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold uppercase text-sm tracking-wider">Retours faciles sous 30 jours</p>
            <p className="text-sm text-gray-600 mt-1">
              Retours gratuits • Remboursement complet
            </p>
          </div>
        </div>
      </div>

      {/* Category Link */}
      {product.category && (
        <div className="text-sm">
          <span className="text-gray-500">Catégorie: </span>
          <a
            href={`/produits?category=${product.category}`}
            className="font-medium hover:underline"
          >
            {product.category_name}
          </a>
        </div>
      )}

      </>)}
      {/* Mini bar at the top: photo, name, price and the add button (appears after the main button scrolls away) */}
      <div
        className={`fixed top-0 inset-x-0 z-[70] bg-white border-b border-gray-200 shadow-md transition-transform duration-200 ${stickyTop ? 'translate-y-0' : '-translate-y-full'}`}
        aria-hidden={!stickyTop}
      >
        <div className="container-custom flex items-center gap-3 py-2">
          {product.main_image && (
            <div className="relative w-10 h-[3.35rem] shrink-0 bg-[#f2f2f2]">
              <Image src={product.main_image} alt={product.name} fill sizes="40px" className="object-cover" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-xs leading-tight line-clamp-2 text-black">{product.name}</p>
            <p className="text-sm font-bold leading-tight mt-0.5">
              {hasDiscount ? (
                <>
                  <span className="text-[#000000]">{formatPrice(finalPrice)}</span>{' '}
                  <span className="text-xs font-normal text-gray-500 line-through">{formatPrice(parseFloat(product.base_price))}</span>
                </>
              ) : (
                <>{formatPrice(finalPrice)}</>
              )}
            </p>
          </div>
          <button
            onClick={handleAddToCart}
            disabled={!canAddToCart}
            className="shrink-0 bg-black text-white px-5 py-3 text-xs font-bold uppercase tracking-wide disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            {addToCartLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
