'use client'

import { useRef } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { ChevronLeft, ChevronRight, Heart, Star } from 'lucide-react'
import { Product } from '@/lib/api'
import { useCurrency } from '@/contexts/CurrencyContext'

interface RelatedProductsProps {
  products: Product[]
}

export default function RelatedProducts({ products }: RelatedProductsProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const { formatPrice } = useCurrency()

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 320
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      })
    }
  }

  if (!products || products.length === 0) {
    return null
  }

  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-black uppercase tracking-tight">Vous aimerez aussi</h2>
            <p className="text-gray-600 mt-2">Découvrez des produits similaires</p>
          </div>
          
          {products.length > 4 && (
            <div className="hidden md:flex gap-2">
              <button
                onClick={() => scroll('left')}
                className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-black hover:bg-black hover:text-white transition-all"
                aria-label="Précédent"
              >
                <ChevronLeft size={24} />
              </button>
              <button
                onClick={() => scroll('right')}
                className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-black hover:bg-black hover:text-white transition-all"
                aria-label="Suivant"
              >
                <ChevronRight size={24} />
              </button>
            </div>
          )}
        </div>

        <div
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto scrollbar-hide pb-4 scroll-smooth"
          style={{
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            WebkitOverflowScrolling: 'touch'
          }}
        >
          {products.map((product) => {
            const hasDiscount = product.sale_price && parseFloat(product.sale_price) < parseFloat(product.base_price)
            const finalPrice = hasDiscount ? parseFloat(product.sale_price!) : parseFloat(product.base_price)
            
            return (
              <div
                key={product.id}
                className="flex-shrink-0 w-[280px] group"
              >
                <Link href={`/produits/${product.slug}`} className="block">
                  <div className="relative bg-white rounded-lg overflow-hidden border-2 border-gray-200 group-hover:border-black transition-all mb-4">
                    {/* Product Image */}
                    <div className="aspect-[3/4] relative overflow-hidden bg-gray-100">
                      {(() => {
                        // Main photo first (the only photo for single-photo products),
                        // then the extra images; same order as the product cards.
                        const gallery = [
                          ...(product.main_image ? [{ image: product.main_image, alt_text: product.name }] : []),
                          ...(product.images || []),
                        ]
                        if (gallery.length === 0) return null
                        return (
                          <>
                            <Image
                              src={gallery[0].image}
                              alt={gallery[0].alt_text || product.name}
                              fill
                              sizes="280px"
                              className="object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            {/* Hover: Show second image if available */}
                            {gallery.length > 1 && (
                              <Image
                                src={gallery[1].image}
                                alt={gallery[1].alt_text || product.name}
                                fill
                                sizes="280px"
                                className="object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                              />
                            )}
                          </>
                        )
                      })() || (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                          Aucune image
                        </div>
                      )}

                      {/* Badges */}
                      <div className="absolute top-3 left-3 flex flex-col gap-2">
                        {product.is_new && (
                          <span className="px-2 py-1 bg-blue-600 text-white text-xs font-bold rounded uppercase">
                            Nouveau
                          </span>
                        )}
                        {hasDiscount && (
                          <span className="px-2 py-1 bg-black text-white text-xs font-bold rounded uppercase">
                            -{product.discount_percentage}%
                          </span>
                        )}
                      </div>

                      {/* Quick Actions */}
                      <div className="absolute top-3 right-3">
                        <button
                          onClick={(e) => {
                            e.preventDefault()
                            // Add to wishlist logic here
                          }}
                          className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all hover:bg-black hover:text-white"
                          aria-label="Ajouter aux favoris"
                        >
                          <Heart size={18} />
                        </button>
                      </div>

                      {/* Quick View Button */}
                      <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => {
                            e.preventDefault()
                            // Quick view modal logic here
                          }}
                          className="w-full bg-white text-black py-2 px-4 rounded-lg font-bold text-sm uppercase tracking-wider hover:bg-black hover:text-white transition-all"
                        >
                          Aperçu rapide
                        </button>
                      </div>
                    </div>

                    {/* Stock Indicator */}
                    {!product.is_in_stock && (
                      <div className="absolute inset-0 bg-white/90 flex items-center justify-center">
                        <span className="bg-black text-white px-4 py-2 rounded-lg font-bold uppercase text-sm">
                          Rupture de stock
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="space-y-2">
                    {/* Category */}
                    {product.category_name && (
                      <p className="text-xs uppercase text-gray-500 font-bold tracking-wider">
                        {product.category_name}
                      </p>
                    )}

                    {/* Product Name */}
                    <h3 className="font-bold text-base leading-tight line-clamp-2 group-hover:underline">
                      {product.name}
                    </h3>

                    {/* Rating */}
                    {product.reviews_count > 0 && (
                      <div className="flex items-center gap-1">
                        <div className="flex items-center gap-0.5">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              size={12}
                              className={i < Math.floor(parseFloat(product.average_rating)) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-gray-600">({product.reviews_count})</span>
                      </div>
                    )}

                    {/* Price */}
                    <div className="flex items-baseline gap-2">
                      {hasDiscount ? (
                        <>
                          <span className="text-xl font-black text-red-600">
                            {formatPrice(finalPrice)}
                          </span>
                          <span className="text-sm text-gray-400 line-through">
                            {formatPrice(parseFloat(product.base_price))}
                          </span>
                        </>
                      ) : (
                        <span className="text-xl font-black">
                          {formatPrice(finalPrice)}
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              </div>
            )
          })}
        </div>

        {/* Mobile scroll indicator */}
        <div className="md:hidden mt-4 text-center">
          <p className="text-sm text-gray-500">Faites défiler pour voir plus →</p>
        </div>
      </div>

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </section>
  )
}
