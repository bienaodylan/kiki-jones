import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Nos Produits | KikiJones',
  description: 'Découvrez notre collection de mode féminine : robes, tops, accessoires et plus. Livraison rapide en Afrique de l\'Ouest.',
  openGraph: {
    title: 'Nos Produits | KikiJones',
    description: 'Parcourez notre catalogue de vêtements et accessoires tendance.',
    type: 'website',
  },
}

export default function ProduitsLayout({ children }: { children: React.ReactNode }) {
  return children
}
