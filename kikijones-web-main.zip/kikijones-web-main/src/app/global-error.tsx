'use client'

import { useEffect } from 'react'

/**
 * Last-resort error page (replaces Next's "Application error: a client-side exception..." screen).
 * When the error comes from a site update (old page asking for files that no longer exist), it reloads once by itself.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    const msg = String(error?.message || '')
    const looksLikeUpdate = /ChunkLoadError|Loading chunk|Loading CSS chunk|Failed to fetch dynamically imported|Unexpected token '<'/i.test(msg)
    try {
      if (looksLikeUpdate && !sessionStorage.getItem('kj_reloaded_after_update')) {
        sessionStorage.setItem('kj_reloaded_after_update', '1')
        window.location.reload()
        return
      }
    } catch {}
    // Otherwise try again by itself in a few seconds (the shop is often just restarting)
    const t = setTimeout(() => window.location.reload(), 20000)
    return () => clearTimeout(t)
  }, [error])

  return (
    <html lang="fr">
      <body
        style={{
          margin: 0,
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          padding: '32px 24px',
          background: '#000',
          color: '#fff',
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
        }}
      >
        <div style={{ fontSize: 'clamp(2rem, 8vw, 3.2rem)', fontWeight: 900, letterSpacing: '0.14em' }}>
          KIKI <span style={{ color: '#9b1b30' }}>JONES</span>
        </div>
        <div style={{ width: 64, height: 3, background: '#9b1b30', margin: '28px auto' }} />
        <h1 style={{ fontSize: 'clamp(1.1rem, 4.5vw, 1.5rem)', margin: '0 0 12px' }}>
          Un instant, la boutique se met à jour
        </h1>
        <p style={{ maxWidth: 420, lineHeight: 1.7, color: '#b5b5b5', margin: 0 }}>
          Quelque chose n&apos;a pas pu se charger. Cela arrive pendant une mise à jour. Rechargez la page, ou revenez dans quelques minutes.
        </p>
        <div style={{ display: 'flex', gap: 12, marginTop: 28, flexWrap: 'wrap', justifyContent: 'center' }}>
          <button
            onClick={() => window.location.reload()}
            style={{ padding: '14px 28px', background: '#fff', color: '#000', border: 0, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em', cursor: 'pointer' }}
          >
            Recharger la page
          </button>
          <a
            href="/"
            style={{ padding: '13px 28px', border: '1px solid #fff', color: '#fff', textDecoration: 'none', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.08em' }}
          >
            Accueil
          </a>
        </div>
      </body>
    </html>
  )
}
