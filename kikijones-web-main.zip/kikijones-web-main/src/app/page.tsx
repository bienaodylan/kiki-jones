import ThemeHome from '@/components/home/ThemeHome'
import { getSiteVisuals } from '@/lib/siteVisuals'

export const dynamic = "force-dynamic"

// Home page = the theme's home page. Images and texts come from "Visuels du site" in the admin.
export default async function Home() {
  const visuals = await getSiteVisuals()
  return <ThemeHome visuals={visuals} />
}
