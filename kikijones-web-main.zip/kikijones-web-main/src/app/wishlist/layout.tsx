import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Ma Liste de Souhaits | KikiJones',
  description: 'Retrouvez tous les articles que vous avez ajoutés à votre liste de souhaits KikiJones.',
}

export default function WishlistLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
