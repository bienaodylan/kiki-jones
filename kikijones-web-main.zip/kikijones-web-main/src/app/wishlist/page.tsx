'use client'

import Link from 'next/link'
import { Heart, ArrowRight } from 'lucide-react'
import ProductCard from '@/components/products/ProductCard'
import { useWishlist } from '@/contexts/WishlistContext'

export default function WishlistPage() {
  const { items: wishlistItems, clearWishlist } = useWishlist()
  return (
    <main className="w-full max-w-[1440px] mx-auto px-4 sm:px-6 pb-12 min-h-screen overflow-x-clip bg-white text-black">
      <div className="pt-4 pb-5 border-b border-black/10 flex flex-col sm:flex-row sm:items-end justify-between gap-3">
        <div className="space-y-1">
          <p className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-black/45">Sélection enregistrée</p>
          <div className="flex items-start gap-1.5">
            <h1 className="text-3xl sm:text-4xl font-bold tracking-[-0.025em] text-black">Favoris</h1>
            <sup className="text-xs font-bold text-black/50 tabular-nums mt-2">{wishlistItems.length}</sup>
          </div>
        </div>
        {wishlistItems.length > 0 && (
          <div className="flex items-center gap-5">
            <button type="button" onClick={clearWishlist} className="text-[11px] font-bold uppercase tracking-[0.16em] text-black/55 hover:text-black underline underline-offset-4">Tout supprimer</button>
            <Link href="/produits?is_new=true" className="inline-flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.16em] text-black hover:opacity-65">
              <span>Continuer l’exploration</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        )}
      </div>

      {wishlistItems.length === 0 ? (
        <div className="py-24 flex flex-col items-center justify-center text-center space-y-5">
          <div className="w-12 h-12 border border-black/15 flex items-center justify-center">
            <Heart className="w-5 h-5 text-black/60" strokeWidth={1.5} />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-[-0.025em] text-black">Votre liste de favoris est vide</h2>
            <p className="text-xs sm:text-sm font-light text-black/65 max-w-md">Cliquez sur l’icône cœur sur n’importe quelle pièce KIKI JONES pour la retrouver facilement ici.</p>
          </div>
          <div className="flex flex-wrap justify-center gap-3 pt-2">
            <Link href="/produits?is_new=true" className="px-6 py-3 bg-black text-white text-xs font-bold uppercase tracking-[0.18em] hover:bg-black/85 transition-colors">Voir les nouveautés</Link>
            <Link href="/categories" className="px-6 py-3 border border-black text-black text-xs font-bold uppercase tracking-[0.18em] hover:bg-black hover:text-white transition-colors">Explorer les catégories</Link>
          </div>
        </div>
      ) : (
        <div className="pt-4 grid grid-cols-2 md:grid-cols-4 gap-x-1.5 gap-y-4 sm:gap-x-2 sm:gap-y-5 items-stretch">
          {wishlistItems.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </main>
  )
}
