﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function RetoursPage() {
  return <StaticPageLayout slug="retours" />
}
