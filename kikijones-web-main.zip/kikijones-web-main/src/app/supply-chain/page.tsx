'use client'

import { useEffect, useState } from 'react'
import { sanitizeHTML } from '@/lib/sanitize'

export default function SupplyChainPage() {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setContent(`
      <div>
        <h2>Notre Engagement</h2>
        
        <p>KikiJones s'engage à respecter les normes les plus élevées en matière de pratiques commerciales éthiques et de transparence dans toute notre chaîne d'approvisionnement.</p>
        
        <h2>Transparence de la Chaîne d'Approvisionnement</h2>
        
        <h3>Nos Partenaires</h3>
        <p>Nous travaillons avec des fournisseurs et fabricants qui partagent nos valeurs:</p>
        <ul>
          <li><strong>Conditions de travail équitables</strong>: Salaires justes et environnement de travail sûr</li>
          <li><strong>Interdiction du travail forcé</strong>: Aucune forme de travail forcé ou obligatoire</li>
          <li><strong>Interdiction du travail des enfants</strong>: Respect strict des lois sur l'âge minimum</li>
          <li><strong>Liberté d'association</strong>: Droit des travailleurs à se syndiquer</li>
          <li><strong>Non-discrimination</strong>: Égalité de traitement pour tous</li>
        </ul>
        
        <h3>Audits et Contrôles</h3>
        <p>Nous effectuons régulièrement:</p>
        <ul>
          <li>Audits sociaux de nos fournisseurs</li>
          <li>Inspections des installations de production</li>
          <li>Évaluations des conditions de travail</li>
          <li>Vérifications de conformité aux normes internationales</li>
        </ul>
        
        <h2>Durabilité Environnementale</h2>
        
        <h3>Nos Initiatives</h3>
        <ul>
          <li><strong>Matériaux durables</strong>: Utilisation croissante de matériaux recyclés et biologiques</li>
          <li><strong>Réduction des déchets</strong>: Programmes de recyclage et de réutilisation</li>
          <li><strong>Emballages responsables</strong>: Minimisation et utilisation de matériaux recyclables</li>
          <li><strong>Efficacité énergétique</strong>: Réduction de notre empreinte carbone</li>
        </ul>
        
        <h2>Traçabilité</h2>
        
        <h3>Origine des Produits</h3>
        <p>Nous nous efforçons de garantir la traçabilité de nos produits:</p>
        <ul>
          <li>Identification des sites de production</li>
          <li>Documentation des matières premières</li>
          <li>Suivi de la chaîne logistique</li>
          <li>Transparence sur les pays d'origine</li>
        </ul>
        
        <h2>Conformité Légale</h2>
        
        <h3>Réglementations Respectées</h3>
        <ul>
          <li>Lois ivoiriennes sur le travail</li>
          <li>Conventions de l'Organisation Internationale du Travail (OIT)</li>
          <li>Normes internationales de commerce équitable</li>
          <li>Réglementations sur la sécurité des produits</li>
        </ul>
        
        <h2>Programme de Conformité</h2>
        
        <h3>Nos Actions</h3>
        <ul>
          <li><strong>Formation</strong>: Sensibilisation de nos partenaires aux bonnes pratiques</li>
          <li><strong>Support</strong>: Aide à la mise en conformité</li>
          <li><strong>Amélioration continue</strong>: Plans d'action correctifs</li>
          <li><strong>Sanctions</strong>: Rupture des contrats en cas de violations graves</li>
        </ul>
        
        <h2>Engagement Communautaire</h2>
        
        <p>Nous contribuons au développement des communautés:</p>
        <ul>
          <li>Programmes d'éducation pour les travailleurs</li>
          <li>Initiatives de santé et sécurité</li>
          <li>Soutien aux entreprises locales</li>
          <li>Projets de développement communautaire</li>
        </ul>
        
        <h2>Signalement</h2>
        
        <h3>Hotline de Signalement</h3>
        <p>Si vous avez connaissance de violations de notre code de conduite:</p>
        <ul>
          <li>Email confidentiel: <a href="mailto:ethics@kikijones.com">ethics@kikijones.com</a></li>
          <li>Téléphone: +225 0172147737</li>
          <li>Tous les signalements sont traités de manière confidentielle</li>
        </ul>
        
        <h2>Rapports Annuels</h2>
        
        <p>Nous publions annuellement un rapport sur notre chaîne d'approvisionnement incluant:</p>
        <ul>
          <li>Liste de nos principaux fournisseurs</li>
          <li>Résultats des audits</li>
          <li>Progrès réalisés</li>
          <li>Objectifs futurs</li>
        </ul>
        
        <h2>Objectifs 2026</h2>
        
        <ul>
          <li>100% de nos fournisseurs audités annuellement</li>
          <li>50% de matériaux durables dans nos collections</li>
          <li>Réduction de 30% de notre empreinte carbone</li>
          <li>Emballages 100% recyclables</li>
        </ul>
        
        <h2>Contact</h2>
        
        <p>Pour plus d'informations sur notre chaîne d'approvisionnement:</p>
        <ul>
          <li>Email: <a href="mailto:sustainability@kikijones.com">sustainability@kikijones.com</a></li>
          <li>Adresse: Abidjan, Côte d'Ivoire</li>
        </ul>
        
        <p><strong>Dernière mise à jour:</strong> 27 janvier 2026</p>
      </div>
    `)
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-4xl">
          <nav className="text-xs uppercase tracking-wider mb-8 flex items-center gap-2 text-gray-500">
            <a href="/" className="hover:text-black transition-colors">Accueil</a>
            <span>/</span>
            <span className="text-black">Chaîne d'Approvisionnement</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-light text-gray-900 tracking-tight">
            Loi sur la Chaîne d'Approvisionnement
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 md:py-20 max-w-4xl">
        <div className="static-content" dangerouslySetInnerHTML={{ __html: sanitizeHTML(content) }} />
      </div>

      <style jsx global>{`
        .static-content { color: #1f2937; line-height: 1.8; font-size: 16px; }
        .static-content h2 { font-size: 2rem; font-weight: 300; color: #111827; margin-top: 3rem; margin-bottom: 1.5rem; padding-bottom: 0.75rem; border-bottom: 1px solid #e5e7eb; }
        .static-content h3 { font-size: 1.5rem; font-weight: 400; color: #111827; margin-top: 2.5rem; margin-bottom: 1rem; }
        .static-content p { margin-bottom: 1.5rem; color: #4b5563; }
        .static-content ul { margin-bottom: 1.5rem; padding-left: 1.5rem; }
        .static-content li { margin-bottom: 0.75rem; color: #4b5563; }
        .static-content a { color: #000; text-decoration: underline; }
        .static-content strong { font-weight: 600; color: #111827; }
      `}</style>
    </div>
  )
}
