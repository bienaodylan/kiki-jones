'use client'

import Link from 'next/link'
import { useState, FormEvent } from 'react'
import { useSearchParams } from 'next/navigation'
import { fetchAPI } from '@/lib/api/config'
import { API_ENDPOINTS } from '@/lib/api/config'

export default function ResetPasswordPage() {
  const searchParams = useSearchParams()
  const uid = searchParams.get('uid') || ''
  const token = searchParams.get('token') || ''

  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')

    if (password.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères.')
      return
    }

    if (password !== confirmPassword) {
      setError('Les mots de passe ne correspondent pas.')
      return
    }

    if (!uid || !token) {
      setError('Lien de réinitialisation invalide ou expiré.')
      return
    }

    setLoading(true)
    try {
      await fetchAPI(API_ENDPOINTS.resetPassword, {
        method: 'POST',
        body: JSON.stringify({ uid, token, password, password2: confirmPassword }),
      })
      setSuccess(true)
    } catch (err: any) {
      setError('Le lien de réinitialisation est invalide ou a expiré. Veuillez en demander un nouveau.')
    } finally {
      setLoading(false)
    }
  }

  if (!uid || !token) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8 text-center">
          <div className="bg-white p-8 rounded-lg shadow-sm">
            <div className="text-4xl mb-4">⚠️</div>
            <h2 className="text-2xl font-black uppercase tracking-tight text-gray-900 mb-4">
              Lien invalide
            </h2>
            <p className="text-sm text-gray-600 mb-6">
              Ce lien de réinitialisation est invalide ou a expiré.
            </p>
            <Link
              href="/forgot-password"
              className="inline-block w-full py-3 px-4 text-sm font-black uppercase tracking-wider text-white bg-black hover:bg-gray-800 rounded-md text-center"
            >
              Demander un nouveau lien
            </Link>
          </div>
        </div>
      </div>
    )
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8 text-center">
          <div className="bg-white p-8 rounded-lg shadow-sm">
            <div className="text-4xl mb-4">✅</div>
            <h2 className="text-2xl font-black uppercase tracking-tight text-gray-900 mb-4">
              Mot de passe modifié !
            </h2>
            <p className="text-sm text-gray-600 mb-6">
              Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.
            </p>
            <Link
              href="/login"
              className="inline-block w-full py-3 px-4 text-sm font-black uppercase tracking-wider text-white bg-black hover:bg-gray-800 rounded-md text-center"
            >
              Se connecter
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-black uppercase tracking-tight text-gray-900">
            Nouveau mot de passe
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Choisissez un nouveau mot de passe pour votre compte.
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Nouveau mot de passe
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm"
                placeholder="Minimum 8 caractères"
              />
            </div>
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                Confirmer le mot de passe
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type="password"
                required
                minLength={8}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-black focus:border-black sm:text-sm"
                placeholder="Retapez le mot de passe"
              />
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-sm text-center bg-red-50 p-3 rounded-md">{error}</div>
          )}

          <div>
            <button
              type="submit"
              disabled={loading}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-black uppercase tracking-wider rounded-md text-white bg-black hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-black disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Modification en cours...' : 'Réinitialiser le mot de passe'}
            </button>
          </div>

          <div className="text-center">
            <Link href="/login" className="font-medium text-black hover:underline text-sm">
              Retour à la connexion
            </Link>
          </div>
        </form>
      </div>
    </div>
  )
}
