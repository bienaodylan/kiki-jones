import { getProducts, getCategories } from '@/lib/api'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://kikijones.com'

export default async function sitemap() {
  // Static pages
  const staticPages = [
    { url: SITE_URL, lastModified: new Date(), changeFrequency: 'daily', priority: 1 },
    { url: `${SITE_URL}/produits`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.9 },
    { url: `${SITE_URL}/contact`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
    { url: `${SITE_URL}/about`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
    { url: `${SITE_URL}/terms`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.3 },
    { url: `${SITE_URL}/privacy`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.3 },
    { url: `${SITE_URL}/centre-aide`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.4 },
  ]

  // Product pages
  let productPages: Array<{ url: string; lastModified: Date; changeFrequency: string; priority: number }> = []
  try {
    // Paginate through all products for complete sitemap
    let page = 1
    let hasMore = true
    while (hasMore) {
      const { results, next } = await getProducts({ page_size: 100, page })
      productPages.push(...results.map((product: any) => ({
        url: `${SITE_URL}/produits/${product.slug}`,
        lastModified: new Date(product.created_at),
        changeFrequency: 'weekly' as const,
        priority: 0.8,
      })))
      hasMore = !!next
      page++
    }
  } catch {
    // Products unavailable, skip
  }

  // Category pages
  let categoryPages: Array<{ url: string; lastModified: Date; changeFrequency: string; priority: number }> = []
  try {
    const categories = await getCategories()
    categoryPages = categories.map((cat) => ({
      url: `${SITE_URL}/categories/${cat.slug}`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    }))
  } catch {
    // Categories unavailable, skip
  }

  return [...staticPages, ...productPages, ...categoryPages]
}
