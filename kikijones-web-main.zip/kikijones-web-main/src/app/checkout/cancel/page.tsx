'use client'

import Link from 'next/link'
import { XCircle } from 'lucide-react'

export default function CheckoutCancelPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <XCircle size={48} className="text-orange-600" />
          </div>
          <h1 className="text-3xl font-light mb-4">Paiement annulé</h1>
          <p className="text-gray-600 mb-2">Votre paiement a été annulé</p>
          <p className="text-sm text-gray-500 mb-8">
            Aucun montant n&apos;a été débité. Votre commande est en attente.
          </p>

          <div className="bg-gray-50 rounded-lg p-6 mb-8 text-left max-w-md mx-auto">
            <h3 className="font-medium mb-3">Que souhaitez-vous faire ?</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Réessayer le paiement depuis vos commandes</li>
              <li>• Modifier votre panier</li>
              <li>• Choisir un autre moyen de paiement</li>
            </ul>
          </div>

          <div className="flex gap-4 justify-center flex-wrap">
            <Link
              href="/compte/commandes"
              className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
            >
              Voir mes commandes
            </Link>
            <Link
              href="/panier"
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
            >
              Retour au panier
            </Link>
            <Link
              href="/produits"
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
            >
              Continuer mes achats
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
