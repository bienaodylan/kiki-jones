'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { ShoppingBag, ArrowLeft, CreditCard, Truck, CheckCircle } from 'lucide-react'
import { useCart } from '@/contexts/CartContext'
import { useCurrency } from '@/contexts/CurrencyContext'
import { API_ENDPOINTS, getMediaUrl, fetchAPI } from '@/lib/api/config'
import { getWithTtl, setWithTtl, TTL } from '@/lib/ttlStorage'
import { bootstrapAuth, getAccessToken } from '@/lib/auth-store'

// Saved addresses store ISO country codes, the checkout form uses country names
const COUNTRY_CODES: Record<string, string> = {
  "Côte d'Ivoire": 'CI', 'Sénégal': 'SN', 'Burkina Faso': 'BF', 'Mali': 'ML', 'Guinée': 'GN', 'Niger': 'NE', 'Togo': 'TG',
  'Bénin': 'BJ', 'Gambie': 'GM', 'Guinée-Bissau': 'GW', 'Cap-Vert': 'CV', 'Sierra Leone': 'SL', 'Liberia': 'LR', 'Ghana': 'GH',
  'Nigeria': 'NG', 'Mauritanie': 'MR', 'Cameroun': 'CM', 'Gabon': 'GA', 'Congo-Brazzaville': 'CG', 'RD Congo': 'CD', 'Tchad': 'TD',
  'Centrafrique': 'CF', 'Guinée équatoriale': 'GQ', 'São Tomé-et-Príncipe': 'ST', 'Maroc': 'MA', 'Algérie': 'DZ', 'Tunisie': 'TN',
  'Libye': 'LY', 'Égypte': 'EG', 'Soudan': 'SD', 'Kenya': 'KE', 'Tanzanie': 'TZ', 'Ouganda': 'UG', 'Rwanda': 'RW', 'Burundi': 'BI',
  'Éthiopie': 'ET', 'Somalie': 'SO', 'Djibouti': 'DJ', 'Érythrée': 'ER', 'Soudan du Sud': 'SS', 'Madagascar': 'MG', 'Maurice': 'MU',
  'Seychelles': 'SC', 'Comores': 'KM', 'Afrique du Sud': 'ZA', 'Angola': 'AO', 'Mozambique': 'MZ', 'Zambie': 'ZM', 'Zimbabwe': 'ZW',
  'Botswana': 'BW', 'Namibie': 'NA', 'Eswatini': 'SZ', 'Lesotho': 'LS', 'Malawi': 'MW', 'France': 'FR', 'Belgique': 'BE', 'Suisse': 'CH',
  'Luxembourg': 'LU', 'Monaco': 'MC', 'Allemagne': 'DE', 'Royaume-Uni': 'GB', 'Espagne': 'ES', 'Italie': 'IT', 'Portugal': 'PT',
  'Pays-Bas': 'NL', 'États-Unis': 'US', 'Canada': 'CA', 'Émirats arabes unis': 'AE', 'Turquie': 'TR', 'Liban': 'LB', 'Chine': 'CN',
}
const CODE_TO_COUNTRY: Record<string, string> = Object.fromEntries(Object.entries(COUNTRY_CODES).map(([name, code]) => [code, name]))

interface CouponDiscount {
  valid: boolean
  discount_amount: number
  discount_type: string
  discount_value: number
  message: string
  coupon_name: string
  coupon_code: string
  free_shipping: boolean
}

export default function CheckoutPage() {
  const router = useRouter()
  const { items, clearCart, totalItems } = useCart()
  const { formatPrice } = useCurrency()
  const [step, setStep] = useState<'info' | 'payment' | 'confirmation'>('info')
  const [loading, setLoading] = useState(false)
  const [appliedCoupon, setAppliedCoupon] = useState<CouponDiscount | null>(null)
  const [promoCode, setPromoCode] = useState('')
  const [couponLoading, setCouponLoading] = useState(false)
  const [couponError, setCouponError] = useState('')
  const [giftCardCode, setGiftCardCode] = useState('')
  const [giftCardLoading, setGiftCardLoading] = useState(false)
  const [giftCardApplied, setGiftCardApplied] = useState<{ code: string; balance: number; amount: number } | null>(null)
  const [showPostalCodeModal, setShowPostalCodeModal] = useState(false)
  const [tempPostalCode, setTempPostalCode] = useState('')
  const [errorMessage, setErrorMessage] = useState('')
  const [purchasesDisabled, setPurchasesDisabled] = useState(false)
  const [purchasesDisabledMessage, setPurchasesDisabledMessage] = useState('')
  const [paymentTestMode, setPaymentTestMode] = useState(false)
  const [paymentAvailable, setPaymentAvailable] = useState(true)

  useEffect(() => {
    fetchAPI<{ purchases_disabled?: boolean; purchases_disabled_message?: string; payment_test_mode?: boolean; payment_available?: boolean }>(API_ENDPOINTS.siteSettings)
      .then((data) => {
        setPaymentTestMode(!!data.payment_test_mode)
        if (data.payment_available === false) setPaymentAvailable(false)
        if (data.purchases_disabled) {
          setPurchasesDisabled(true)
          setPurchasesDisabledMessage(data.purchases_disabled_message || '')
        }
      })
      .catch(() => {})
  }, [])

  // Form states
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    country: "Côte d'Ivoire",
    notes: ''
  })

  // Saved addresses of the logged-in customer (pre-fill + one-click choice)
  const [savedAddresses, setSavedAddresses] = useState<any[]>([])

  const applySavedAddress = (addr: any) => {
    setFormData((prev) => ({
      ...prev,
      phone: addr.phone || prev.phone,
      address: addr.address_line1 || '',
      city: addr.city || '',
      postalCode: addr.postal_code || '',
      country: CODE_TO_COUNTRY[addr.country] || prev.country,
    }))
  }

  // Pre-fill the form from the customer's profile and default address (only fields still empty)
  useEffect(() => {
    let cancelled = false
    bootstrapAuth().then(async (token) => {
      if (!token || cancelled) return
      try {
        const [profile, addrData] = await Promise.all([
          fetchAPI<any>(API_ENDPOINTS.profile).catch(() => null),
          fetchAPI<any>(API_ENDPOINTS.addresses).catch(() => null),
        ])
        if (cancelled) return
        const list: any[] = Array.isArray(addrData) ? addrData : addrData?.results || []
        setSavedAddresses(list)
        const addr = list.find((a) => a.is_default) || list[0]
        const nameParts = String(addr?.full_name || '').trim().split(' ')
        setFormData((prev) => ({
          ...prev,
          firstName: prev.firstName || profile?.first_name || nameParts[0] || '',
          lastName: prev.lastName || profile?.last_name || nameParts.slice(1).join(' ') || '',
          email: prev.email || profile?.email || '',
          phone: prev.phone || addr?.phone || profile?.phone || '',
          address: prev.address || addr?.address_line1 || '',
          city: prev.city || addr?.city || '',
          postalCode: prev.postalCode || addr?.postal_code || '',
          country: !prev.address && addr ? (CODE_TO_COUNTRY[addr.country] || prev.country) : prev.country,
        }))
      } catch {
        // pre-fill is a convenience: never block the checkout
      }
    })
    return () => { cancelled = true }
  }, [])

  // Keep the address typed at checkout in the customer's address book (once, if it is new)
  const saveAddressIfNew = async (postalCode: string) => {
    try {
      if (!getAccessToken()) return
      const code = COUNTRY_CODES[formData.country]
      if (!code) return
      const norm = (s: string) => (s || '').trim().toLowerCase()
      const exists = savedAddresses.some((a) => norm(a.address_line1) === norm(formData.address) && norm(a.city) === norm(formData.city))
      if (exists) return
      await fetchAPI(API_ENDPOINTS.addressCreate, {
        method: 'POST',
        body: JSON.stringify({
          full_name: `${formData.firstName} ${formData.lastName}`.trim(),
          phone: formData.phone,
          address_line1: formData.address,
          city: formData.city,
          postal_code: postalCode || '',
          country: code,
          is_default: savedAddresses.length === 0,
        }),
      })
    } catch {
      // never block the order because the address could not be stored
    }
  }

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'mobile'>('card')
  const [formErrors, setFormErrors] = useState<Record<string, string>>({})

  // Shipping constants — should ideally come from site settings API
  const FREE_SHIPPING_THRESHOLD = 50000
  // Delivery fee depends on the destination country (grid served by the API)
  const [shippingBase, setShippingBase] = useState(3000)
  useEffect(() => {
    let cancelled = false
    fetch(`${API_ENDPOINTS.orders}shipping-rates/?country=${encodeURIComponent(formData.country || '')}&city=${encodeURIComponent(formData.city || '')}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (!cancelled && d && typeof d.fee === 'number') setShippingBase(d.fee) })
      .catch(() => {})
    return () => { cancelled = true }
  }, [formData.country, formData.city])

  // Récupérer le coupon depuis localStorage
  useEffect(() => {
    const storedCoupon = getWithTtl<CouponDiscount>('appliedCoupon', TTL.SEVEN_DAYS)
    if (storedCoupon) {
      setAppliedCoupon(storedCoupon)
    }
  }, [])

  // Code promo saisi directement à la page de paiement (même contrôle que dans le panier)
  const applyCoupon = async () => {
    const code = promoCode.trim()
    if (!code) {
      setCouponError('Veuillez entrer un code promo')
      return
    }
    setCouponLoading(true)
    setCouponError('')
    try {
      const response = await fetch(API_ENDPOINTS.validateCoupon, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, cart_total: items.reduce((sum, item) => sum + item.price * item.quantity, 0) }),
      })
      const data = await response.json()
      if (response.ok && data.valid) {
        const couponData: CouponDiscount = {
          valid: data.valid,
          coupon_code: data.coupon_code,
          coupon_name: data.coupon_name,
          discount_amount: data.discount_amount,
          discount_type: data.discount_type,
          discount_value: data.discount_value,
          free_shipping: data.free_shipping,
          message: data.message,
        }
        setAppliedCoupon(couponData)
        setPromoCode('')
        try { setWithTtl('appliedCoupon', couponData) } catch {}
      } else {
        setCouponError(data.error || 'Code promo invalide')
      }
    } catch {
      setCouponError('Erreur lors de la validation du code')
    } finally {
      setCouponLoading(false)
    }
  }

  const removeCoupon = () => {
    setAppliedCoupon(null)
    setPromoCode('')
    setCouponError('')
    try { localStorage.removeItem('appliedCoupon') } catch {}
  }

  const getSubtotal = () => {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  }

  const getDiscount = () => {
    return appliedCoupon?.discount_amount || 0
  }

  const getShipping = () => {
    // Livraison gratuite si coupon free_shipping OU montant >= seuil
    if (appliedCoupon?.free_shipping) return 0
    const subtotal = getSubtotal()
    return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : shippingBase
  }

  const getGiftCardDeduction = () => {
    return giftCardApplied?.amount || 0
  }

  const getTotal = () => {
    return Math.max(0, getSubtotal() - getDiscount() - getGiftCardDeduction() + getShipping())
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmitInfo = (e: React.FormEvent) => {
    e.preventDefault()
    const errors: Record<string, string> = {}
    if (!formData.firstName.trim()) errors.firstName = 'Le pr\u00e9nom est requis'
    if (!formData.lastName.trim()) errors.lastName = 'Le nom est requis'
    if (!formData.email.trim()) errors.email = 'L\'email est requis'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) errors.email = 'Email invalide'
    if (!formData.phone.trim()) errors.phone = 'Le t\u00e9l\u00e9phone est requis'
    if (!formData.address.trim()) errors.address = 'L\'adresse est requise'
    if (!formData.city.trim()) errors.city = 'La ville est requise'
    setFormErrors(errors)
    if (Object.keys(errors).length > 0) return
    setStep('payment')
  }

  // One page: validate delivery details, then pay.
  const handleSubmitAll = async (e: React.FormEvent) => {
    e.preventDefault()
    const errors: Record<string, string> = {}
    if (!formData.firstName.trim()) errors.firstName = 'Le prénom est requis'
    if (!formData.lastName.trim()) errors.lastName = 'Le nom est requis'
    if (!formData.email.trim()) errors.email = "L'email est requis"
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) errors.email = 'Email invalide'
    if (!formData.phone.trim()) errors.phone = 'Le téléphone est requis'
    if (!formData.address.trim()) errors.address = "L'adresse est requise"
    if (!formData.city.trim()) errors.city = 'La ville est requise'
    setFormErrors(errors)
    if (Object.keys(errors).length > 0) {
      setErrorMessage('Veuillez compléter les champs obligatoires.')
      window.scrollTo({ top: 0, behavior: 'smooth' })
      return
    }
    setErrorMessage('')
    await handleSubmitPayment(e)
  }

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Vérifier si le code postal est requis pour le paiement par carte
    if (paymentMethod === 'card' && !formData.postalCode.trim()) {
      setTempPostalCode('')
      setShowPostalCodeModal(true)
      return
    }
    
    await processPayment()
  }

  const handlePostalCodeSubmit = async () => {
    if (!tempPostalCode.trim()) {
      setErrorMessage('Veuillez entrer un code postal')
      return
    }
    setErrorMessage('')
    
    setShowPostalCodeModal(false)
    
    // Mettre à jour le formData avec le code postal et traiter le paiement
    const updatedFormData = {
      ...formData,
      postalCode: tempPostalCode
    }
    setFormData(updatedFormData)
    
    await processPaymentWithPostalCode(tempPostalCode)
  }

  const processPayment = async () => {
    await processPaymentWithPostalCode(formData.postalCode)
  }

  const processPaymentWithPostalCode = async (postalCode: string) => {
    setLoading(true)

    try {
      // Créer la commande et initier le paiement Paystack
      // On va créer une commande temporaire qui sera confirmée après paiement
      const orderData = {
        shipping_first_name: formData.firstName,
        shipping_last_name: formData.lastName,
        shipping_email: formData.email,
        shipping_phone: formData.phone,
        shipping_address_line1: formData.address,
        shipping_city: formData.city,
        shipping_postal_code: postalCode,
        shipping_country: formData.country,
        customer_notes: formData.notes,
        payment_method: paymentMethod,
        status: 'pending', // En attente de paiement
        coupon_code: appliedCoupon?.coupon_code || '',
        items: items.map(item => ({
          product_id: item.product.id,
          variant_id: item.variantId || null,
          quantity: item.quantity,
        }))
      }

      const order = await fetchAPI<any>(API_ENDPOINTS.orders, {
          method: 'POST',
          body: JSON.stringify(orderData)
        })

      // Remember this address for the next order (does not wait, never blocks the payment)
      void saveAddressIfNew(postalCode)

      // Appliquer la carte cadeau sur la commande réelle avant paiement —
      // le champ gift_card_code envoyé plus haut n'est pas pris en compte
      // par le backend, il faut passer par l'endpoint de redemption dédié.
      if (giftCardApplied?.code) {
        try {
          await fetchAPI(API_ENDPOINTS.giftcardRedeem, {
            method: 'POST',
            body: JSON.stringify({ code: giftCardApplied.code, order_id: order.id }),
          })
        } catch (giftCardError) {
          console.error('Erreur application carte cadeau:', giftCardError)
          setErrorMessage('La carte cadeau n\'a pas pu être appliquée. Veuillez réessayer.')
          setLoading(false)
          return
        }
      }

      // Initier le paiement Paystack
      const paymentData = {
        order_id: order.id,
        return_url: `${window.location.origin}/checkout/success`,
      }

      const paymentResult = await fetchAPI<any>(API_ENDPOINTS.initPayment(order.id), {
        method: 'POST',
        body: JSON.stringify(paymentData)
      })

      // Rediriger vers la page de paiement Paystack
      if (paymentResult.payment_url) {
        // Store order ID so we can clear cart on success page
        try { setWithTtl('pendingOrderId', order.id) } catch {}
        try { localStorage.removeItem('appliedCoupon') } catch {}
        window.location.href = paymentResult.payment_url
        return
      }

      throw new Error('URL de paiement non reçue')

    } catch (error: any) {
      console.error('Erreur:', error)
      // Parse server validation errors
      let msg = 'Une erreur est survenue. Veuillez réessayer.'
      if (error?.message) {
        try {
          const parsed = JSON.parse(error.message.replace('API Error: ', ''))
          if (parsed.detail) msg = parsed.detail
          else if (parsed.error) msg = parsed.error
        } catch {
          if (error.message.includes('API Error:')) {
            msg = error.message.replace('API Error: ', '')
          }
        }
      }
      setErrorMessage(msg)
    } finally {
      setLoading(false)
    }
  }

  const handleFinish = () => {
    clearCart()
    try { localStorage.removeItem('appliedCoupon') } catch {}
    router.push('/')
  }

  if (purchasesDisabled) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="bg-white rounded-none shadow-sm p-12 text-center">
            <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingBag size={40} className="text-amber-600" />
            </div>
            <h1 className="text-2xl font-bold uppercase tracking-[-0.02em] mb-4">Achats temporairement indisponibles</h1>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              {purchasesDisabledMessage || "Nous sommes actuellement en phase d'évaluation. Les achats sont temporairement désactivés."}
            </p>
            <Link href="/" className="inline-flex items-center gap-2 px-8 py-3 bg-black text-white rounded-none hover:bg-black/85 transition-colors">
              Retour à l'accueil
            </Link>
          </div>
        </div>
      </div>
    )
  }

  if (items.length === 0 && step !== 'confirmation') {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="bg-white rounded-none shadow-sm p-12 text-center">
            <ShoppingBag size={64} className="mx-auto mb-6 opacity-20" />
            <h1 className="text-2xl font-bold uppercase tracking-[-0.02em] mb-4">Votre panier est vide</h1>
            <p className="text-gray-600 mb-8">Ajoutez des produits pour passer commande</p>
            <Link href="/produits" className="inline-flex items-center gap-2 px-8 py-3 bg-black text-white rounded-none hover:bg-black/85 transition-colors">
              Découvrir nos produits
            </Link>
          </div>
        </div>
      </div>
    )
  }

  if (step === 'confirmation') {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="bg-white rounded-none shadow-sm p-12 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={48} className="text-black/70" />
            </div>
            <h1 className="text-2xl font-bold uppercase tracking-[-0.02em] mb-4">Commande confirmée !</h1>
            <p className="text-gray-600 mb-2">Merci pour votre commande</p>
            <p className="text-sm text-gray-500 mb-8">
              Vous recevrez un email de confirmation à <strong>{formData.email}</strong>
            </p>
            
            <div className="bg-gray-50 rounded-none p-6 mb-8 text-left max-w-md mx-auto">
              <h3 className="font-medium mb-4">Résumé de la commande</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Articles</span>
                  <span>{totalItems}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total</span>
                  <span className="font-medium">{formatPrice(getTotal())}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Mode de paiement</span>
                  <span>
                    {paymentMethod === 'card' ? 'Carte bancaire' : 'Mobile Money'}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={handleFinish}
              className="px-8 py-3 bg-black text-white rounded-none hover:bg-black/85 transition-colors"
            >
              Retour à l'accueil
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <div className="pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="min-w-0">
            <p className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-black/50">Paiement KIKI JONES</p>
            <h1 className="text-2xl sm:text-4xl font-bold tracking-[-0.025em] text-black mt-1">Livraison &amp; Paiement</h1>
          </div>
          <Link href="/panier" className="self-start sm:self-auto text-[11px] font-bold uppercase tracking-[0.16em] text-black underline underline-offset-4 hover:opacity-65 whitespace-nowrap">Retour au panier</Link>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 pt-6">
          {/* Error Banner */}
          {errorMessage && (
            <div className="lg:col-span-3 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
              <span>{errorMessage}</span>
              <button onClick={() => setErrorMessage('')} className="absolute top-3 right-3 text-red-400 hover:text-red-600">&times;</button>
            </div>
          )}
          {/* Main Form */}
          <div className="lg:col-span-7">
            {items.length > 0 && (
              <form onSubmit={handleSubmitAll} className="bg-white space-y-12">
              <section>
                <h2 className="text-xl sm:text-2xl font-bold tracking-[-0.025em] text-black mb-6">1. Coordonnées &amp; adresse de livraison</h2>

                {savedAddresses.length > 1 && (
                  <div className="mb-4">
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">Mes adresses enregistrées</label>
                    <select
                      defaultValue=""
                      onChange={(e) => {
                        const addr = savedAddresses.find((a) => String(a.id) === e.target.value)
                        if (addr) applySavedAddress(addr)
                      }}
                      className="w-full px-4 py-3 text-sm font-light bg-white border border-black/25 rounded-none focus:outline-none focus:border-black"
                    >
                      <option value="">Choisir une adresse…</option>
                      {savedAddresses.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.address_line1}, {a.city}{a.is_default ? ' (par défaut)' : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Prénom *
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-3 text-sm font-light bg-white border rounded-none focus:outline-none focus:border-black ${formErrors.firstName ? 'border-red-500' : 'border-black/25'}`}
                    />
                    {formErrors.firstName && <p className="text-red-500 text-xs mt-1">{formErrors.firstName}</p>}
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Nom *
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-3 text-sm font-light bg-white border rounded-none focus:outline-none focus:border-black ${formErrors.lastName ? 'border-red-500' : 'border-black/25'}`}
                    />
                    {formErrors.lastName && <p className="text-red-500 text-xs mt-1">{formErrors.lastName}</p>}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-3 text-sm font-light bg-white border rounded-none focus:outline-none focus:border-black ${formErrors.email ? 'border-red-500' : 'border-black/25'}`}
                    />
                    {formErrors.email && <p className="text-red-500 text-xs mt-1">{formErrors.email}</p>}
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Téléphone *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-3 text-sm font-light bg-white border rounded-none focus:outline-none focus:border-black ${formErrors.phone ? 'border-red-500' : 'border-black/25'}`}
                    />
                    {formErrors.phone && <p className="text-red-500 text-xs mt-1">{formErrors.phone}</p>}
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                    Adresse de livraison *
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    required
                    className={`w-full px-4 py-3 text-sm font-light bg-white border rounded-none focus:outline-none focus:border-black ${formErrors.address ? 'border-red-500' : 'border-black/25'}`}
                  />
                  {formErrors.address && <p className="text-red-500 text-xs mt-1">{formErrors.address}</p>}
                </div>

                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Ville *
                    </label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-3 text-sm font-light bg-white border rounded-none focus:outline-none focus:border-black ${formErrors.city ? 'border-red-500' : 'border-black/25'}`}
                    />
                    {formErrors.city && <p className="text-red-500 text-xs mt-1">{formErrors.city}</p>}
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Code postal
                    </label>
                    <input
                      type="text"
                      name="postalCode"
                      value={formData.postalCode}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 text-sm font-light bg-white border border-black/25 rounded-none focus:outline-none focus:border-black"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                      Pays *
                    </label>
                    <select
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 text-sm font-light bg-white border border-black/25 rounded-none focus:outline-none focus:border-black"
                    >
                      <optgroup label="Afrique de l'Ouest">
                        <option value="Côte d'Ivoire">🇨🇮 Côte d'Ivoire</option>
                        <option value="Sénégal">🇸🇳 Sénégal</option>
                        <option value="Burkina Faso">🇧🇫 Burkina Faso</option>
                        <option value="Mali">🇲🇱 Mali</option>
                        <option value="Guinée">🇬🇳 Guinée</option>
                        <option value="Niger">🇳🇪 Niger</option>
                        <option value="Togo">🇹🇬 Togo</option>
                        <option value="Bénin">🇧🇯 Bénin</option>
                        <option value="Gambie">🇬🇲 Gambie</option>
                        <option value="Guinée-Bissau">🇬🇼 Guinée-Bissau</option>
                        <option value="Cap-Vert">🇨🇻 Cap-Vert</option>
                        <option value="Sierra Leone">🇸🇱 Sierra Leone</option>
                        <option value="Liberia">🇱🇷 Liberia</option>
                        <option value="Ghana">🇬🇭 Ghana</option>
                        <option value="Nigeria">🇳🇬 Nigeria</option>
                        <option value="Mauritanie">🇲🇷 Mauritanie</option>
                      </optgroup>
                      <optgroup label="Afrique centrale">
                        <option value="Cameroun">🇨🇲 Cameroun</option>
                        <option value="Gabon">🇬🇦 Gabon</option>
                        <option value="Congo-Brazzaville">🇨🇬 Congo-Brazzaville</option>
                        <option value="RD Congo">🇨🇩 RD Congo</option>
                        <option value="Tchad">🇹🇩 Tchad</option>
                        <option value="Centrafrique">🇨🇫 Centrafrique</option>
                        <option value="Guinée équatoriale">🇬🇶 Guinée équatoriale</option>
                        <option value="São Tomé-et-Príncipe">🇸🇹 São Tomé-et-Príncipe</option>
                      </optgroup>
                      <optgroup label="Afrique du Nord">
                        <option value="Maroc">🇲🇦 Maroc</option>
                        <option value="Algérie">🇩🇿 Algérie</option>
                        <option value="Tunisie">🇹🇳 Tunisie</option>
                        <option value="Libye">🇱🇾 Libye</option>
                        <option value="Égypte">🇪🇬 Égypte</option>
                        <option value="Soudan">🇸🇩 Soudan</option>
                      </optgroup>
                      <optgroup label="Afrique de l'Est">
                        <option value="Kenya">🇰🇪 Kenya</option>
                        <option value="Tanzanie">🇹🇿 Tanzanie</option>
                        <option value="Ouganda">🇺🇬 Ouganda</option>
                        <option value="Rwanda">🇷🇼 Rwanda</option>
                        <option value="Burundi">🇧🇮 Burundi</option>
                        <option value="Éthiopie">🇪🇹 Éthiopie</option>
                        <option value="Somalie">🇸🇴 Somalie</option>
                        <option value="Djibouti">🇩🇯 Djibouti</option>
                        <option value="Érythrée">🇪🇷 Érythrée</option>
                        <option value="Soudan du Sud">🇸🇸 Soudan du Sud</option>
                        <option value="Madagascar">🇲🇬 Madagascar</option>
                        <option value="Maurice">🇲🇺 Maurice</option>
                        <option value="Seychelles">🇸🇨 Seychelles</option>
                        <option value="Comores">🇰🇲 Comores</option>
                      </optgroup>
                      <optgroup label="Afrique australe">
                        <option value="Afrique du Sud">🇿🇦 Afrique du Sud</option>
                        <option value="Angola">🇦🇴 Angola</option>
                        <option value="Mozambique">🇲🇿 Mozambique</option>
                        <option value="Zambie">🇿🇲 Zambie</option>
                        <option value="Zimbabwe">🇿🇼 Zimbabwe</option>
                        <option value="Botswana">🇧🇼 Botswana</option>
                        <option value="Namibie">🇳🇦 Namibie</option>
                        <option value="Eswatini">🇸🇿 Eswatini</option>
                        <option value="Lesotho">🇱🇸 Lesotho</option>
                        <option value="Malawi">🇲🇼 Malawi</option>
                      </optgroup>
                      <optgroup label="Europe">
                        <option value="France">🇫🇷 France</option>
                        <option value="Belgique">🇧🇪 Belgique</option>
                        <option value="Suisse">🇨🇭 Suisse</option>
                        <option value="Luxembourg">🇱🇺 Luxembourg</option>
                        <option value="Monaco">🇲🇨 Monaco</option>
                        <option value="Allemagne">🇩🇪 Allemagne</option>
                        <option value="Royaume-Uni">🇬🇧 Royaume-Uni</option>
                        <option value="Espagne">🇪🇸 Espagne</option>
                        <option value="Italie">🇮🇹 Italie</option>
                        <option value="Portugal">🇵🇹 Portugal</option>
                        <option value="Pays-Bas">🇳🇱 Pays-Bas</option>
                        <option value="Autriche">🇦🇹 Autriche</option>
                        <option value="Suède">🇸🇪 Suède</option>
                        <option value="Norvège">🇳🇴 Norvège</option>
                        <option value="Danemark">🇩🇰 Danemark</option>
                        <option value="Finlande">🇫🇮 Finlande</option>
                        <option value="Irlande">🇮🇪 Irlande</option>
                        <option value="Pologne">🇵🇱 Pologne</option>
                        <option value="Tchéquie">🇨🇿 Tchéquie</option>
                        <option value="Roumanie">🇷🇴 Roumanie</option>
                        <option value="Grèce">🇬🇷 Grèce</option>
                        <option value="Hongrie">🇭🇺 Hongrie</option>
                        <option value="Croatie">🇭🇷 Croatie</option>
                        <option value="Bulgarie">🇧🇬 Bulgarie</option>
                        <option value="Serbie">🇷🇸 Serbie</option>
                        <option value="Slovaquie">🇸🇰 Slovaquie</option>
                        <option value="Slovénie">🇸🇮 Slovénie</option>
                      </optgroup>
                      <optgroup label="Amérique">
                        <option value="États-Unis">🇺🇸 États-Unis</option>
                        <option value="Canada">🇨🇦 Canada</option>
                        <option value="Mexique">🇲🇽 Mexique</option>
                        <option value="Brésil">🇧🇷 Brésil</option>
                        <option value="Argentine">🇦🇷 Argentine</option>
                        <option value="Colombie">🇨🇴 Colombie</option>
                        <option value="Chili">🇨🇱 Chili</option>
                        <option value="Pérou">🇵🇪 Pérou</option>
                        <option value="Haïti">🇭🇹 Haïti</option>
                        <option value="Guadeloupe">🇬🇵 Guadeloupe</option>
                        <option value="Martinique">🇲🇶 Martinique</option>
                        <option value="Guyane française">🇬🇫 Guyane française</option>
                        <option value="La Réunion">🇷🇪 La Réunion</option>
                        <option value="Mayotte">🇾🇹 Mayotte</option>
                        <option value="Nouvelle-Calédonie">🇳🇨 Nouvelle-Calédonie</option>
                        <option value="Polynésie française">🇵🇫 Polynésie française</option>
                      </optgroup>
                      <optgroup label="Asie & Moyen-Orient">
                        <option value="Émirats arabes unis">🇦🇪 Émirats arabes unis</option>
                        <option value="Arabie saoudite">🇸🇦 Arabie saoudite</option>
                        <option value="Qatar">🇶🇦 Qatar</option>
                        <option value="Turquie">🇹🇷 Turquie</option>
                        <option value="Liban">🇱🇧 Liban</option>
                        <option value="Chine">🇨🇳 Chine</option>
                        <option value="Japon">🇯🇵 Japon</option>
                        <option value="Inde">🇮🇳 Inde</option>
                        <option value="Corée du Sud">🇰🇷 Corée du Sud</option>
                      </optgroup>
                      <optgroup label="Océanie">
                        <option value="Australie">🇦🇺 Australie</option>
                        <option value="Nouvelle-Zélande">🇳🇿 Nouvelle-Zélande</option>
                      </optgroup>
                    </select>
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                    Notes de commande (optionnel)
                  </label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-4 py-3 text-sm font-light bg-white border border-black/25 rounded-none focus:outline-none focus:border-black"
                    placeholder="Instructions spéciales pour la livraison..."
                  />
                </div>

              </section>

              <section>
                <h2 className="text-xl sm:text-2xl font-bold tracking-[-0.025em] text-black mb-6">2. Moyen de paiement (FCFA)</h2>

                <div className="space-y-4 mb-6">
                  <label className={`flex items-center gap-4 p-4 border rounded-none cursor-pointer transition-colors ${paymentMethod === 'card' ? 'border-black bg-gray-50' : 'border-gray-200'}`}>
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="card"
                      checked={paymentMethod === 'card'}
                      onChange={(e) => setPaymentMethod(e.target.value as 'card')}
                      className="w-4 h-4"
                    />
                    <div className="flex-1">
                      <div className="font-medium">Carte bancaire</div>
                      <div className="text-sm text-gray-500">Visa, Mastercard, American Express</div>
                    </div>
                  </label>

                  <label className={`flex items-center gap-4 p-4 border rounded-none cursor-pointer transition-colors ${paymentMethod === 'mobile' ? 'border-black bg-gray-50' : 'border-gray-200'}`}>
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="mobile"
                      checked={paymentMethod === 'mobile'}
                      onChange={(e) => setPaymentMethod(e.target.value as 'mobile')}
                      className="w-4 h-4"
                    />
                    <div className="flex-1">
                      <div className="font-medium">Mobile Money</div>
                      <div className="text-sm text-gray-500">Orange Money, Wave, Free Money</div>
                    </div>
                  </label>


                </div>

                {/* Gift Card */}
                <div className="border-t border-gray-200 pt-6 mt-6">
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-700 mb-4 flex items-center gap-2">
                    🎁 Carte cadeau
                  </h3>
                  {giftCardApplied ? (
                    <div className="bg-[#F5F5F5] border border-black/10 rounded-none p-4 flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold text-black">
                          Carte appliquée : -{formatPrice(giftCardApplied.amount)}
                        </p>
                        <p className="text-xs text-gray-500 font-mono mt-1">{giftCardApplied.code}</p>
                        <p className="text-xs text-black/70 mt-1">
                          Solde restant après achat : {formatPrice(giftCardApplied.balance - giftCardApplied.amount)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => { setGiftCardApplied(null); setGiftCardCode('') }}
                        className="text-sm text-red-600 font-semibold hover:underline"
                      >
                        Retirer
                      </button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={giftCardCode}
                        onChange={(e) => setGiftCardCode(e.target.value.toUpperCase())}
                        placeholder="KIKI-XXXX-XXXX-XXXX"
                        maxLength={19}
                        className="flex-1 px-4 py-2 border border-gray-300 rounded font-mono tracking-wider focus:ring-2 focus:ring-black focus:border-transparent"
                      />
                      <button
                        type="button"
                        disabled={giftCardLoading || !giftCardCode.trim()}
                        onClick={async () => {
                          setGiftCardLoading(true)
                          try {
                            const data = await fetchAPI<any>(API_ENDPOINTS.giftcardCheckBalance, {
                              method: 'POST',
                              body: JSON.stringify({ code: giftCardCode.trim() }),
                            })
                            if (data.status !== 'active') {
                              setErrorMessage('Cette carte n\'est pas active')
                              return
                            }
                            if (data.balance <= 0) {
                              setErrorMessage('Le solde de cette carte est épuisé')
                              return
                            }
                            const maxApplicable = Math.max(0, getSubtotal() - getDiscount() + getShipping())
                            setGiftCardApplied({
                              code: data.code || giftCardCode.trim(),
                              balance: data.balance,
                              amount: Math.min(data.balance, maxApplicable),
                            })
                            setErrorMessage('')
                          } catch (err: any) {
                            setErrorMessage(err?.body?.error || 'Code invalide')
                          } finally {
                            setGiftCardLoading(false)
                          }
                        }}
                        className="px-4 py-2 bg-black text-white rounded-none text-sm font-medium hover:bg-black/85 disabled:opacity-50 transition-colors"
                      >
                        {giftCardLoading ? '...' : 'Appliquer'}
                      </button>
                    </div>
                  )}
                </div>

                {paymentTestMode && paymentAvailable && (
                  <div className="mt-6 rounded bg-yellow-100 px-4 py-3 text-sm font-semibold text-yellow-800 text-center">
                    MODE TEST : aucun vrai paiement n&apos;est débité
                  </div>
                )}
                {!paymentAvailable && (
                  <div className="mt-6 rounded bg-red-100 px-4 py-3 text-sm font-semibold text-red-800 text-center">
                    Le paiement en ligne n&apos;est pas encore disponible
                  </div>
                )}

                <div className="mt-6">
                  <button
                    type="submit"
                    disabled={loading || !paymentAvailable}
                    className="w-full min-h-[48px] py-3.5 bg-black text-white rounded-none text-xs font-bold uppercase tracking-[0.2em] hover:bg-black/85 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Traitement...' : 'Confirmer la commande'}
                  </button>
                </div>
              </section>
              </form>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-5">
            <div className="bg-[#F7F7F7] border border-black/[0.06] p-4 sm:p-6 lg:sticky lg:top-28">
              <h2 className="text-xl sm:text-2xl font-bold tracking-[-0.02em] text-black mb-6">Récapitulatif</h2>

              <div className="space-y-4 mb-6">
                {items.slice(0, 3).map((item, index) => (
                  <div key={`${item.product.id}-${index}`} className="flex gap-3">
                    <div className="w-16 h-16 bg-gray-100 rounded flex-shrink-0 relative overflow-hidden">
                      {item.product.main_image && (
                        <Image
                          src={getMediaUrl(item.product.main_image)}
                          alt={item.product.name}
                          fill
                          className="object-cover"
                        />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.product.name}</p>
                      <p className="text-xs text-gray-500">Qté: {item.quantity}</p>
                      <p className="text-sm font-medium mt-1">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                  </div>
                ))}
                {items.length > 3 && (
                  <p className="text-sm text-gray-500 text-center">
                    +{items.length - 3} autres articles
                  </p>
                )}
              </div>

              <div className="border-t border-gray-200 pt-4 mb-4">
                <label htmlFor="checkoutPromoCode" className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">Code promo</label>
                {appliedCoupon ? (
                  <div className="flex items-center justify-between p-3 bg-[#F5F5F5] border border-black/10 rounded-none">
                    <div className="min-w-0 pr-2">
                      <p className="font-medium text-black text-sm truncate">{appliedCoupon.coupon_code}</p>
                      <p className="text-xs text-black/70 truncate">{appliedCoupon.coupon_name}</p>
                    </div>
                    <button type="button" onClick={removeCoupon} className="text-red-600 hover:text-red-800 text-xs font-medium whitespace-nowrap">
                      Retirer
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        id="checkoutPromoCode"
                        value={promoCode}
                        onChange={(e) => { setPromoCode(e.target.value.toUpperCase()); setCouponError('') }}
                        onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); applyCoupon() } }}
                        placeholder="Entrez votre code"
                        className="flex-1 min-w-0 px-3 py-2 text-sm border border-black/20 rounded-none focus:ring-0 focus:border-black"
                        disabled={couponLoading}
                      />
                      <button
                        type="button"
                        onClick={applyCoupon}
                        disabled={couponLoading}
                        className="px-4 py-2 text-sm bg-black text-white rounded-none hover:bg-black/85 transition-colors whitespace-nowrap disabled:bg-gray-400"
                      >
                        {couponLoading ? '...' : 'Appliquer'}
                      </button>
                    </div>
                    {couponError && <p className="text-xs text-red-600 mt-1">{couponError}</p>}
                  </div>
                )}
              </div>

              <div className="border-t border-gray-200 pt-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Sous-total</span>
                  <span>{formatPrice(getSubtotal())}</span>
                </div>
                {appliedCoupon && appliedCoupon.discount_amount > 0 && (
                  <div className="flex justify-between text-sm text-black/70">
                    <span>Remise ({appliedCoupon.coupon_code})</span>
                    <span>-{formatPrice(appliedCoupon.discount_amount)}</span>
                  </div>
                )}
                {giftCardApplied && (
                  <div className="flex justify-between text-sm text-black">
                    <span>Carte cadeau</span>
                    <span>-{formatPrice(giftCardApplied.amount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Livraison</span>
                  <span>{getShipping() === 0 ? 'GRATUITE' : formatPrice(getShipping())}</span>
                </div>
                <div className="border-t border-gray-200 pt-3 flex justify-between text-lg font-medium">
                  <span>Total</span>
                  <span>{formatPrice(getTotal())}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Code Postal */}
      {showPostalCodeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-none shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-semibold mb-4">Code postal requis</h3>
            <p className="text-gray-600 mb-4">
              Pour le paiement par carte bancaire, le code postal est obligatoire. Veuillez l'indiquer ci-dessous :
            </p>
            
            <div className="mb-6">
              <label className="block text-xs font-bold uppercase tracking-[0.14em] text-black/60 mb-1.5">
                Code postal *
              </label>
              <input
                type="text"
                value={tempPostalCode}
                onChange={(e) => setTempPostalCode(e.target.value)}
                placeholder="Ex: 12000"
                className="w-full px-4 py-3 text-sm font-light bg-white border border-black/25 rounded-none focus:outline-none focus:border-black"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault()
                    handlePostalCodeSubmit()
                  }
                }}
              />
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowPostalCodeModal(false)
                  setTempPostalCode('')
                }}
                className="flex-1 px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handlePostalCodeSubmit}
                className="flex-1 px-4 py-2 bg-black text-white rounded-none hover:bg-black/85 transition-colors"
              >
                Valider
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
