'use client'

import Link from 'next/link'
import { AlertTriangle } from 'lucide-react'

export default function CheckoutFailurePage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertTriangle size={48} className="text-red-600" />
          </div>
          <h1 className="text-3xl font-light mb-4">Échec du paiement</h1>
          <p className="text-gray-600 mb-2">Votre paiement n&apos;a pas pu être traité</p>
          <p className="text-sm text-gray-500 mb-8">
            Vérifiez vos informations de paiement et réessayez, ou choisissez un autre moyen de paiement.
          </p>

          <div className="bg-red-50 rounded-lg p-6 mb-8 text-left max-w-md mx-auto">
            <h3 className="font-medium mb-3 text-red-800">Causes possibles</h3>
            <ul className="space-y-2 text-sm text-red-700">
              <li>• Solde insuffisant</li>
              <li>• Informations de carte incorrectes</li>
              <li>• Problème temporaire avec le fournisseur de paiement</li>
              <li>• Transaction refusée par votre banque</li>
            </ul>
          </div>

          <div className="flex gap-4 justify-center flex-wrap">
            <Link
              href="/checkout"
              className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
            >
              Réessayer le paiement
            </Link>
            <Link
              href="/panier"
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
            >
              Retour au panier
            </Link>
            <Link
              href="/contact"
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
            >
              Contacter le support
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
