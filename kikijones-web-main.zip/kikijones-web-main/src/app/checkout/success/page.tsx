'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { CheckCircle, XCircle, Loader2, Clock } from 'lucide-react'
import Link from 'next/link'
import { useCart } from '@/contexts/CartContext'
import { API_BASE_URL } from '@/lib/api/config'
import { getAccessToken, bootstrapAuth } from '@/lib/auth-store'
import { getWithTtl, TTL } from '@/lib/ttlStorage'

// Payment statuses (normalised by the API) that mean the payment definitively did not go through.
// Anything else that is not ACCEPTED (PENDING...) is still
// in progress: Mobile Money confirmations often arrive well after the redirect.
const FINAL_FAILURE = ['REFUSED', 'CANCELED', 'CANCELLED', 'FAILED', 'EXPIRED']
const MAX_AUTO_CHECKS = 24 // 24 x 5 s = 2 minutes of automatic re-checking

// The pending order id is stored either wrapped with a timestamp (setWithTtl) or,
// by older checkouts, as a bare string. getWithTtl() cannot read the bare form
// (not valid JSON), so fall back to the raw value instead of losing the order.
function readPendingOrderId(): string | null {
  const wrapped = getWithTtl<string>('pendingOrderId', TTL.ONE_HOUR)
  if (wrapped) return wrapped
  try {
    const raw = localStorage.getItem('pendingOrderId')
    if (raw && !raw.startsWith('{') && !raw.startsWith('"')) return raw
  } catch {
    // ignore storage errors
  }
  return null
}

export default function CheckoutSuccessPage() {
  const { clearCart } = useCart()
  const [status, setStatus] = useState<'loading' | 'success' | 'pending' | 'failed'>('loading')
  const [orderNumber, setOrderNumber] = useState<string | null>(null)
  const [checking, setChecking] = useState(false)
  const attempts = useRef(0)

  // Verifies the payment with the backend. Returns true when the answer is final.
  // The pending order id is only forgotten on a FINAL answer: it used to be erased
  // on the first non-ACCEPTED reply, so a payment confirmed 30 s later could never
  // be re-checked and the customer ended up paying twice.
  const verify = useCallback(async (): Promise<boolean> => {
    // pendingOrderId expires after 1h (when written with a timestamp) — an abandoned
    // payment that old shouldn't silently verify against a stale order later.
    // Paystack sends the customer back with ?reference=...: it identifies the payment on its own, so the
    // page also works after a reload or in another browser. Without it, fall back to the pending order id.
    const reference = typeof window !== 'undefined'
      ? new URLSearchParams(window.location.search).get('reference') || new URLSearchParams(window.location.search).get('trxref')
      : null
    const orderId = readPendingOrderId()
    if (!reference && !orderId) {
      // No pending order — direct navigation
      setStatus('failed')
      return true
    }
    try {
      // Ensure access token is available (page load may have cleared memory)
      let token = getAccessToken()
      if (!token) token = await bootstrapAuth()
      const url = reference
        ? `${API_BASE_URL}/orders/payment-status/?reference=${encodeURIComponent(reference)}`
        : `${API_BASE_URL}/orders/${orderId}/check_payment/`
      const res = await fetch(url, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      if (res.ok) {
        const data = await res.json()
        if (data.status === 'ACCEPTED' || data.payment_status === 'paid') {
          clearCart()
          localStorage.removeItem('appliedCoupon')
          localStorage.removeItem('pendingOrderId')
          setOrderNumber(data.order_number || null)
          setStatus('success')
          return true
        }
        if (FINAL_FAILURE.includes(data.status) || data.payment_status === 'failed') {
          localStorage.removeItem('pendingOrderId')
          setStatus('failed')
          return true
        }
        setStatus('pending')
        return false
      }
      if (res.status === 404) {
        // No payment was ever started for this order
        localStorage.removeItem('pendingOrderId')
        setStatus('failed')
        return true
      }
      // Temporary error (payment provider unreachable...): keep the order, retry
      setStatus('pending')
      return false
    } catch {
      setStatus('pending')
      return false
    }
  }, [clearCart])

  useEffect(() => {
    let cancelled = false
    let timer: ReturnType<typeof setTimeout> | undefined
    const run = async () => {
      const done = await verify()
      attempts.current += 1
      if (!done && !cancelled && attempts.current < MAX_AUTO_CHECKS) {
        timer = setTimeout(run, 5000)
      }
    }
    run()
    return () => {
      cancelled = true
      if (timer) clearTimeout(timer)
    }
  }, [verify])

  const checkAgain = async () => {
    setChecking(true)
    await verify()
    setChecking(false)
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <Loader2 size={48} className="animate-spin text-gray-400 mx-auto mb-6" />
            <h1 className="text-2xl font-light mb-2">Vérification du paiement...</h1>
            <p className="text-gray-500 text-sm">Veuillez patienter</p>
          </div>
        </div>
      </div>
    )
  }

  if (status === 'pending') {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Clock size={48} className="text-amber-600" />
            </div>
            <h1 className="text-3xl font-light mb-4">Paiement en cours de confirmation</h1>
            <p className="text-gray-600 mb-2">
              Si vous avez validé le paiement (Mobile Money, carte), la confirmation peut prendre quelques instants.
            </p>
            <p className="text-sm text-gray-500 mb-8">
              Ne payez pas une seconde fois : cette page se met à jour automatiquement, et vous pouvez aussi vérifier à nouveau.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <button
                onClick={checkAgain}
                disabled={checking}
                className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors disabled:opacity-60 flex items-center gap-2"
              >
                {checking && <Loader2 size={16} className="animate-spin" />}
                Vérifier à nouveau
              </button>
              <Link
                href="/compte/commandes"
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
              >
                Mes commandes
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (status === 'failed') {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <XCircle size={48} className="text-red-600" />
            </div>
            <h1 className="text-3xl font-light mb-4">Paiement non confirmé</h1>
            <p className="text-gray-600 mb-2">Le paiement n'a pas abouti ou n'a pas pu être vérifié.</p>
            <p className="text-sm text-gray-500 mb-8">
              Vous pouvez réessayer depuis « Mes commandes ». Si vous avez été débité, veuillez contacter notre service client.
            </p>
            <div className="flex gap-4 justify-center">
              <Link
                href="/compte/commandes"
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
              >
                Mes commandes
              </Link>
              <Link
                href="/"
                className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
              >
                Retour à l'accueil
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={48} className="text-green-600" />
          </div>
          <h1 className="text-3xl font-light mb-4">Paiement réussi !</h1>
          <p className="text-gray-600 mb-2">Merci pour votre commande</p>
          {orderNumber && (
            <p className="text-sm text-gray-500 mb-2">Commande n° <strong>{orderNumber}</strong></p>
          )}
          <p className="text-sm text-gray-500 mb-8">
            Vous recevrez un email de confirmation
          </p>

          <div className="bg-gray-50 rounded-lg p-6 mb-8 text-left max-w-md mx-auto">
            <h3 className="font-medium mb-4">Prochaines étapes</h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-600 mt-0.5 flex-shrink-0" />
                <span>Vous recevrez un email de confirmation</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-600 mt-0.5 flex-shrink-0" />
                <span>Votre commande sera préparée dans les 24h</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle size={16} className="text-green-600 mt-0.5 flex-shrink-0" />
                <span>Livraison sous 2-5 jours ouvrés</span>
              </li>
            </ul>
          </div>

          <div className="flex gap-4 justify-center">
            <Link
              href="/produits"
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
            >
              Continuer mes achats
            </Link>
            <Link
              href="/"
              className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
            >
              Retour à l'accueil
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
