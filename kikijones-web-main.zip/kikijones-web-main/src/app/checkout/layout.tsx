import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Paiement | KikiJones',
  description: 'Finalisez votre commande en toute sécurité sur KikiJones. Paiement par carte, Mobile Money ou à la livraison.',
}

export default function CheckoutLayout({ children }: { children: React.ReactNode }) {
  return children
}
