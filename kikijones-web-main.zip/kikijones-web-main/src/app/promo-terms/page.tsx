'use client'

import { useEffect, useState } from 'react'
import { sanitizeHTML } from '@/lib/sanitize'

export default function PromoTermsPage() {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setContent(`
      <div>
        <h2>Conditions des Promotions</h2>
        
        <p>Les promotions et offres spéciales de KikiJones sont soumises aux conditions générales suivantes:</p>
        
        <h3>1. Validité des Offres</h3>
        <p>Toutes les promotions sont valables uniquement pendant la période indiquée. KikiJones se réserve le droit de prolonger, modifier ou annuler toute promotion sans préavis.</p>
        
        <h3>2. Codes Promotionnels</h3>
        <ul>
          <li>Un seul code promo par commande</li>
          <li>Les codes ne sont pas cumulables avec d'autres offres sauf indication contraire</li>
          <li>Les codes sont sensibles à la casse</li>
          <li>Les codes expirés ne peuvent pas être réactivés</li>
        </ul>
        
        <h3>3. Exclusions</h3>
        <p>Sauf indication contraire, les promotions ne s'appliquent pas à:</p>
        <ul>
          <li>Les cartes cadeaux</li>
          <li>Les articles déjà en promotion ou en solde</li>
          <li>Les frais de livraison</li>
          <li>Les commandes précédentes</li>
        </ul>
        
        <h3>4. Livraison Gratuite</h3>
        <p>Les offres de livraison gratuite:</p>
        <ul>
          <li>S'appliquent uniquement sur le territoire ivoirien</li>
          <li>Nécessitent un montant minimum d'achat de 50 000 XOF</li>
          <li>Calcul basé sur le total après réductions</li>
        </ul>
        
        <h3>5. Quantités Limitées</h3>
        <p>Certaines promotions peuvent être limitées en quantité. Les articles sont vendus selon le principe "premier arrivé, premier servi".</p>
        
        <h3>6. Retours et Remboursements</h3>
        <p>Les articles achetés pendant une promotion peuvent être retournés selon notre <a href="/retours">politique de retour standard</a>. Les remboursements seront effectués au prix payé après application de la promotion.</p>
        
        <h3>7. Modifications</h3>
        <p>KikiJones se réserve le droit de modifier ces conditions à tout moment. Les modifications seront publiées sur cette page.</p>
      </div>
    `)
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-4xl">
          <nav className="text-xs uppercase tracking-wider mb-8 flex items-center gap-2 text-gray-500">
            <a href="/" className="hover:text-black transition-colors">Accueil</a>
            <span>/</span>
            <span className="text-black">Conditions des Promotions</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-light text-gray-900 tracking-tight">
            Conditions des Promotions
          </h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 md:py-20 max-w-4xl">
        <div className="static-content" dangerouslySetInnerHTML={{ __html: sanitizeHTML(content) }} />
      </div>

      <style jsx global>{`
        .static-content { color: #1f2937; line-height: 1.8; font-size: 16px; }
        .static-content h2 { font-size: 2rem; font-weight: 300; color: #111827; margin-top: 3rem; margin-bottom: 1.5rem; padding-bottom: 0.75rem; border-bottom: 1px solid #e5e7eb; }
        .static-content h3 { font-size: 1.5rem; font-weight: 400; color: #111827; margin-top: 2.5rem; margin-bottom: 1rem; }
        .static-content p { margin-bottom: 1.5rem; color: #4b5563; }
        .static-content ul { margin-bottom: 1.5rem; padding-left: 1.5rem; }
        .static-content li { margin-bottom: 0.75rem; color: #4b5563; }
        .static-content a { color: #000; text-decoration: underline; }
      `}</style>
    </div>
  )
}
