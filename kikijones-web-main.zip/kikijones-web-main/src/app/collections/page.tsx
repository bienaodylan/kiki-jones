'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight } from 'lucide-react'
import { THEME_COLLECTIONS, ThemeCollection } from '@/lib/themeCollections'
import { loadCollections } from '@/lib/collections'

export default function CollectionsPage() {
  const router = useRouter()
  const [cols, setCols] = useState<ThemeCollection[]>(THEME_COLLECTIONS)
  useEffect(() => { loadCollections().then(setCols) }, [])
  const lead = cols[0]
  const rest = cols.slice(1)
  if (!lead) return null
  const open = (slug: string) => router.push(`/produits?collection=${slug}`)
  return (
    <main className="w-full max-w-full overflow-x-clip bg-white text-black min-h-screen pb-12">
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 pt-5 pb-5 border-b border-black/10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <p className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-black/50">KIKI JONES · Archives &amp; Capsules Saisonnières</p>
            <h1 className="text-3xl sm:text-5xl font-bold tracking-[-0.025em] text-black leading-[1.02]">Collections</h1>
            <p className="text-sm font-light text-black/70 leading-relaxed pt-1">Des capsules mode sélectionnées pour Femme, Homme, Filles et Garçons, pensées pour chaque saison.</p>
          </div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-black/50 tabular-nums">{cols.length} Éditions actives</p>
        </div>
      </section>

      <section className="w-full bg-black">
        <div className="group relative w-full aspect-[16/10] sm:aspect-[2/1] lg:aspect-[1800/780] overflow-hidden bg-black">
          <img src={lead.image} alt={lead.title} className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-[1.02]" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 max-w-[1440px] mx-auto px-5 sm:px-8 xl:px-10 pb-8 md:pb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-xl space-y-2">
              <p className="text-[10px] font-bold uppercase tracking-[0.24em] text-white/75">{lead.seasonTag} &middot; {lead.audiences}</p>
              <h2 className="text-3xl sm:text-5xl font-bold tracking-[-0.025em] text-white leading-tight">{lead.title}</h2>
              <p className="text-xs sm:text-sm font-light text-white/85 leading-relaxed">{lead.description}</p>
            </div>
            <button type="button" onClick={() => open(lead.slug)} className="px-7 py-3.5 bg-white text-black text-[11px] font-bold uppercase tracking-[0.18em] inline-flex items-center gap-2 hover:bg-white/85 transition-colors shrink-0">
              <span>Voir la collection</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-8">
        {rest.map((col, idx) => {
          const reversed = idx % 2 === 1
          return (
            <article key={col.slug} className="space-y-4 border-b border-black/10 pb-8 last:border-b-0">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center">
                <div className={`lg:col-span-7 overflow-hidden bg-[#F5F5F5] ${reversed ? 'lg:order-2' : 'lg:order-1'}`}>
                  <button type="button" onClick={() => open(col.slug)} className="group block w-full aspect-[16/10] overflow-hidden">
                    <img src={col.image} alt={col.title} className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.03]" />
                  </button>
                </div>
                <div className={`lg:col-span-5 space-y-3 ${reversed ? 'lg:order-1 lg:pr-4' : 'lg:order-2 lg:pl-4'}`}>
                  <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-black/45">{String(idx + 2).padStart(2, '0')} &middot; {col.seasonTag} &middot; {col.audiences}</p>
                  <h2 className="text-2xl sm:text-4xl font-bold tracking-[-0.025em] text-black leading-tight">{col.title}</h2>
                  <p className="text-xs font-bold uppercase tracking-[0.14em] text-black/60">{col.subtitle}</p>
                  <p className="text-sm font-light text-black/75 leading-relaxed">{col.description}</p>
                  <div className="pt-1">
                    <button type="button" onClick={() => open(col.slug)} className="px-5 py-2.5 bg-black text-white text-[11px] font-bold uppercase tracking-[0.18em] inline-flex items-center gap-2 hover:bg-black/85 transition-colors">
                      <span>Voir {col.title}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </article>
          )
        })}
      </div>
    </main>
  )
}
