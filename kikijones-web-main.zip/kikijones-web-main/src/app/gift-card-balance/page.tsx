'use client'

import { useState } from 'react'
import Link from 'next/link'
import { CreditCard, Search, CheckCircle, AlertCircle, Clock, Gift } from 'lucide-react'
import { API_ENDPOINTS } from '@/lib/api/config'
import { useCurrency } from '@/contexts/CurrencyContext'

interface CardInfo {
  balance: number
  initial_amount: number
  status: string
  expires_at: string
  code: string
}

export default function GiftCardBalancePage() {
  const { formatPrice } = useCurrency()
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [cardInfo, setCardInfo] = useState<CardInfo | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleCodeChange = (text: string) => {
    let cleaned = text.toUpperCase().replace(/[^A-Z0-9-]/g, '')
    if (cleaned.length > 4 && cleaned[4] !== '-') cleaned = cleaned.slice(0, 4) + '-' + cleaned.slice(4)
    if (cleaned.length > 9 && cleaned[9] !== '-') cleaned = cleaned.slice(0, 9) + '-' + cleaned.slice(9)
    if (cleaned.length > 14 && cleaned[14] !== '-') cleaned = cleaned.slice(0, 14) + '-' + cleaned.slice(14)
    setCode(cleaned.slice(0, 19))
  }

  const checkBalance = async () => {
    if (!code.trim() || code.trim().length < 10) {
      setError('Veuillez entrer un code valide (KIKI-XXXX-XXXX-XXXX)')
      return
    }

    setLoading(true)
    setCardInfo(null)
    setError(null)

    try {
      const res = await fetch(API_ENDPOINTS.giftcardCheckBalance, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: code.trim() }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || data.detail || 'Code invalide ou carte introuvable')
        return
      }
      setCardInfo(data)
    } catch {
      setError('Erreur de connexion. Veuillez réessayer.')
    } finally {
      setLoading(false)
    }
  }

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'active': return { label: 'Active', color: 'text-green-600', bg: 'bg-green-50 border-green-200' }
      case 'used': return { label: 'Épuisée', color: 'text-red-600', bg: 'bg-red-50 border-red-200' }
      case 'expired': return { label: 'Expirée', color: 'text-amber-600', bg: 'bg-amber-50 border-amber-200' }
      case 'pending_payment': return { label: 'Paiement en attente', color: 'text-blue-600', bg: 'bg-blue-50 border-blue-200' }
      default: return { label: status, color: 'text-gray-600', bg: 'bg-gray-50 border-gray-200' }
    }
  }

  const usagePercent = cardInfo ? Math.round((1 - cardInfo.balance / cardInfo.initial_amount) * 100) : 0

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <div className="bg-gradient-to-b from-gray-900 to-gray-800 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-4xl text-center">
          <nav className="text-xs uppercase tracking-wider mb-8 flex items-center justify-center gap-2 text-gray-400">
            <Link href="/" className="hover:text-white transition-colors">Accueil</Link>
            <span>/</span>
            <span className="text-white">Vérifier ma carte</span>
          </nav>
          <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-6">
            <CreditCard size={40} className="text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-light tracking-tight mb-4">Vérifier le solde</h1>
          <p className="text-gray-400 max-w-lg mx-auto">
            Entrez le code de votre carte cadeau pour consulter votre solde instantanément
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-2xl">
        {/* Code Input */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <h2 className="text-lg font-medium mb-6 flex items-center gap-2">
            <Search size={20} />
            Code de la carte
          </h2>

          <div className="flex items-center gap-3 border-2 border-gray-200 rounded-lg px-4 mb-4 focus-within:border-black transition-colors">
            <CreditCard size={20} className="text-gray-400 flex-shrink-0" />
            <input
              type="text"
              value={code}
              onChange={(e) => handleCodeChange(e.target.value)}
              placeholder="KIKI-XXXX-XXXX-XXXX"
              maxLength={19}
              onKeyDown={(e) => e.key === 'Enter' && checkBalance()}
              className="w-full py-4 text-xl font-mono font-bold tracking-widest focus:outline-none"
            />
          </div>

          <button
            onClick={checkBalance}
            disabled={loading}
            className="w-full py-4 bg-black text-white rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors disabled:opacity-50"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            ) : (
              <>
                <Search size={18} />
                VÉRIFIER LE SOLDE
              </>
            )}
          </button>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 mb-8 flex items-start gap-4">
            <AlertCircle size={24} className="text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-red-700">Carte non trouvée</h3>
              <p className="text-red-600 text-sm mt-1">{error}</p>
            </div>
          </div>
        )}

        {/* Card Result */}
        {cardInfo && (
          <div className="space-y-6">
            {/* Card Visual */}
            <div className="bg-black rounded-2xl p-8 text-white shadow-xl">
              <div className="flex justify-between items-start mb-8">
                <span className="text-sm font-bold tracking-[0.3em]">KIKIJONES</span>
                <span className="text-[10px] text-gray-400 tracking-[0.2em]">CARTE CADEAU</span>
              </div>
              <div className="text-4xl md:text-5xl font-bold mb-6">{formatPrice(cardInfo.balance)}</div>
              <div className="font-mono text-lg tracking-[0.25em] text-gray-300">{cardInfo.code}</div>
            </div>

            {/* Details */}
            <div className="bg-white rounded-xl shadow-sm p-6 space-y-0 divide-y divide-gray-100">
              <div className="flex justify-between items-center py-4">
                <span className="text-gray-600">Statut</span>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusConfig(cardInfo.status).bg} ${getStatusConfig(cardInfo.status).color}`}>
                  {getStatusConfig(cardInfo.status).label}
                </span>
              </div>
              <div className="flex justify-between items-center py-4">
                <span className="text-gray-600">Montant initial</span>
                <span className="font-semibold">{formatPrice(cardInfo.initial_amount)}</span>
              </div>
              <div className="flex justify-between items-center py-4">
                <span className="text-gray-600">Solde restant</span>
                <span className="font-bold text-green-600 text-lg">{formatPrice(cardInfo.balance)}</span>
              </div>
              <div className="py-4">
                <div className="flex justify-between text-sm text-gray-500 mb-2">
                  <span>Utilisation</span>
                  <span>{usagePercent}%</span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-black rounded-full transition-all duration-500" style={{ width: `${usagePercent}%` }}></div>
                </div>
                <p className="text-xs text-gray-400 mt-2 text-center">
                  {formatPrice(cardInfo.initial_amount - cardInfo.balance)} dépensé sur {formatPrice(cardInfo.initial_amount)}
                </p>
              </div>
              <div className="flex justify-between items-center py-4">
                <span className="text-gray-600">Expire le</span>
                <span className="font-medium">
                  {cardInfo.expires_at
                    ? new Date(cardInfo.expires_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
                    : 'N/A'}
                </span>
              </div>
            </div>

            {/* Buy more */}
            <Link
              href="/gift-cards"
              className="block text-center py-4 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors font-medium"
            >
              🎁 Acheter une nouvelle carte cadeau
            </Link>
          </div>
        )}

        {/* Info (when no result) */}
        {!cardInfo && !error && (
          <div className="bg-white rounded-xl shadow-sm p-8">
            <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
              <span className="text-xl">ℹ️</span> Bon à savoir
            </h2>
            <ul className="space-y-3">
              {[
                'Le code se trouve sur votre email de confirmation',
                'Format du code : KIKI-XXXX-XXXX-XXXX',
                'Les cartes sont valables 1 an après activation',
                'Utilisez le solde lors du paiement de vos commandes',
              ].map((info, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-600">
                  <div className="w-1.5 h-1.5 rounded-full bg-black mt-2 flex-shrink-0"></div>
                  <span>{info}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 text-center">
              <Link
                href="/gift-cards"
                className="inline-flex items-center gap-2 text-gray-600 hover:text-black transition-colors underline underline-offset-4"
              >
                <Gift size={16} />
                Acheter une carte cadeau
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
