import { redirect } from 'next/navigation'

export default function AccountMessagesRedirect() {
  redirect('/compte/messages')
}
