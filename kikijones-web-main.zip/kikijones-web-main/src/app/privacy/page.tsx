'use client'

import { useEffect, useState } from 'react'
import { sanitizeHTML } from '@/lib/sanitize'

export default function PrivacyPage() {
  const [content, setContent] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setContent(`
      <div>
        <h2>1. Collecte des Informations</h2>
        
        <p>KikiJones collecte les informations suivantes:</p>
        
        <h3>Informations que vous nous fournissez</h3>
        <ul>
          <li>Nom, prénom et informations de contact</li>
          <li>Adresse de livraison et de facturation</li>
          <li>Informations de paiement (traitées de manière sécurisée)</li>
          <li>Historique d'achat et préférences</li>
          <li>Communications avec notre service client</li>
        </ul>
        
        <h3>Informations collectées automatiquement</h3>
        <ul>
          <li>Adresse IP et données de navigation</li>
          <li>Type de navigateur et appareil</li>
          <li>Pages visitées et temps passé</li>
          <li>Cookies et technologies similaires</li>
        </ul>
        
        <h2>2. Utilisation des Informations</h2>
        
        <p>Nous utilisons vos informations pour:</p>
        <ul>
          <li>Traiter et livrer vos commandes</li>
          <li>Communiquer sur l'état de vos commandes</li>
          <li>Personnaliser votre expérience d'achat</li>
          <li>Vous envoyer des offres promotionnelles (avec votre consentement)</li>
          <li>Améliorer nos services et notre site web</li>
          <li>Prévenir la fraude et assurer la sécurité</li>
        </ul>
        
        <h2>3. Partage des Informations</h2>
        
        <p>Nous ne vendons jamais vos données personnelles. Nous pouvons partager vos informations avec:</p>
        <ul>
          <li><strong>Prestataires de services</strong>: Livraison, paiement, marketing</li>
          <li><strong>Partenaires commerciaux</strong>: Uniquement avec votre consentement explicite</li>
          <li><strong>Autorités légales</strong>: Si requis par la loi</li>
        </ul>
        
        <h2>4. Cookies</h2>
        
        <p>Nous utilisons des cookies pour:</p>
        <ul>
          <li>Mémoriser vos préférences</li>
          <li>Maintenir votre session de connexion</li>
          <li>Analyser le trafic du site</li>
          <li>Personnaliser le contenu et les publicités</li>
        </ul>
        
        <p>Vous pouvez gérer vos préférences de cookies dans les paramètres de votre navigateur.</p>
        
        <h2>5. Vos Droits</h2>
        
        <p>Conformément aux lois sur la protection des données, vous avez le droit de:</p>
        <ul>
          <li><strong>Accéder</strong> à vos données personnelles</li>
          <li><strong>Rectifier</strong> les informations inexactes</li>
          <li><strong>Supprimer</strong> vos données ("droit à l'oubli")</li>
          <li><strong>Limiter</strong> le traitement de vos données</li>
          <li><strong>Vous opposer</strong> au traitement</li>
          <li><strong>Porter</strong> vos données vers un autre service</li>
        </ul>
        
        <p>Pour exercer ces droits, contactez-nous à <a href="mailto:privacy@kikijones.com">privacy@kikijones.com</a></p>
        
        <h2>6. Sécurité</h2>
        
        <p>Nous mettons en œuvre des mesures de sécurité techniques et organisationnelles pour protéger vos données contre tout accès, modification, divulgation ou destruction non autorisé.</p>
        
        <h2>7. Conservation des Données</h2>
        
        <p>Nous conservons vos données personnelles aussi longtemps que nécessaire pour:</p>
        <ul>
          <li>Fournir nos services</li>
          <li>Respecter nos obligations légales</li>
          <li>Résoudre les litiges</li>
          <li>Faire respecter nos accords</li>
        </ul>
        
        <h2>8. Modifications</h2>
        
        <p>Nous pouvons mettre à jour cette politique de confidentialité périodiquement. Les modifications seront publiées sur cette page avec la date de la dernière mise à jour.</p>
        
        <p><strong>Dernière mise à jour:</strong> 27 janvier 2026</p>
        
        <h2>9. Contact</h2>
        
        <p>Pour toute question concernant cette politique de confidentialité:</p>
        <ul>
          <li>Email: <a href="mailto:contact@kikijones.com">contact@kikijones.com</a></li>
          <li>Téléphone: +225 0172147737</li>
          <li>Adresse: Abidjan, Côte d'Ivoire</li>
        </ul>
      </div>
    `)
    setLoading(false)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-white">
        <div className="max-w-3xl mx-auto px-5 md:px-10 pt-12 pb-6">
          <nav className="text-[10.5px] font-bold uppercase tracking-[0.24em] mb-3 flex items-center gap-2 text-black/50">
            <a href="/" className="hover:text-black transition-colors">Accueil</a>
            <span>/</span>
            <span className="text-black">Politique de Confidentialité</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl font-bold tracking-[-0.025em] text-black">
            Politique de Confidentialité
          </h1>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-5 md:px-10 pb-24">
        <div className="static-content" dangerouslySetInnerHTML={{ __html: sanitizeHTML(content) }} />
      </div>

      <style jsx global>{`
        .static-content { color: rgba(0,0,0,0.8); line-height: 1.8; font-size: 15px; font-weight: 300; }
        .static-content h2 { text-transform: uppercase; letter-spacing: 0.08em; font-size: 1.125rem; font-weight: 700; color: #000; margin-top: 3rem; margin-bottom: 1.5rem; padding-bottom: 0.75rem; border-bottom: 1px solid rgba(0,0,0,0.1); }
        .static-content h3 { font-size: 1rem; font-weight: 700; color: #000; margin-top: 2.5rem; margin-bottom: 1rem; }
        .static-content p { margin-bottom: 1.5rem; color: rgba(0,0,0,0.8); }
        .static-content ul { margin-bottom: 1.5rem; padding-left: 1.5rem; }
        .static-content li { margin-bottom: 0.75rem; color: rgba(0,0,0,0.8); }
        .static-content a { color: #000; text-decoration: underline; }
        .static-content strong { font-weight: 600; color: #000; }
      `}</style>
    </div>
  )
}
