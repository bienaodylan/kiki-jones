﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function MagasinsPage() {
  return <StaticPageLayout slug="magasins" />
}
