import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Tendances | KikiJones',
  description: 'Découvrez les tendances mode du moment sur KikiJones. Articles populaires et collections en vogue.',
}

export default function TendancesLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
