﻿import StaticPageLayout from '@/components/StaticPageLayout'

export default function CarrieresPage() {
  return <StaticPageLayout slug="carrieres" />
}
