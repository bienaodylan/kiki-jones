const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://kikijones.com'

export default function robots() {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/compte/', '/checkout/', '/panier/', '/api/'],
      },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
  }
}
