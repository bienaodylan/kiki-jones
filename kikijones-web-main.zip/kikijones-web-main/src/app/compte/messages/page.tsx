'use client'

import { useState, useEffect } from 'react'
import {
  getConversations,
  getDisputes,
  type Conversation,
  type Dispute,
} from '@/lib/api/chat'
import { isAuthenticated } from '@/lib/api/auth'
import { bootstrapAuth } from '@/lib/auth-store'
import { useRouter } from 'next/navigation'

const statusLabel: Record<string, string> = {
  active: 'Actif',
  waiting: 'En attente',
  resolved: 'Résolu',
  closed: 'Fermé',
}
const statusColor: Record<string, string> = {
  active: 'bg-green-100 text-green-800',
  waiting: 'bg-yellow-100 text-yellow-800',
  resolved: 'bg-blue-100 text-blue-800',
  closed: 'bg-gray-100 text-gray-600',
}

const disputeStatusLabel: Record<string, string> = {
  open: 'Ouvert',
  in_progress: 'En cours',
  waiting_customer: 'En attente client',
  resolved: 'Résolu',
  rejected: 'Rejeté',
  refunded: 'Remboursé',
}
const disputeStatusColor: Record<string, string> = {
  open: 'bg-red-100 text-red-800',
  in_progress: 'bg-yellow-100 text-yellow-800',
  waiting_customer: 'bg-orange-100 text-orange-800',
  resolved: 'bg-green-100 text-green-800',
  rejected: 'bg-gray-100 text-gray-600',
  refunded: 'bg-blue-100 text-blue-800',
}

const priorityLabel: Record<string, string> = {
  low: 'Bas',
  medium: 'Moyen',
  high: 'Élevé',
  urgent: 'Urgent',
}

export default function CompteMessagesPage() {
  const router = useRouter()
  const [tab, setTab] = useState<'conversations' | 'disputes'>('conversations')
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [disputes, setDisputes] = useState<Dispute[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    bootstrapAuth().then(() => {
      if (!isAuthenticated()) {
        router.push('/login')
        return
      }
      loadData()
    })
  }, [router])

  async function loadData() {
    setLoading(true)
    try {
      const [convData, dispData] = await Promise.all([getConversations(), getDisputes()])
      setConversations(Array.isArray(convData) ? convData : [])
      setDisputes(Array.isArray(dispData) ? dispData : [])
    } catch {
      /* silent */
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-light mb-8">Messages & Litiges</h1>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setTab('conversations')}
          className={`px-6 py-3 text-sm font-bold uppercase rounded-lg transition ${
            tab === 'conversations'
              ? 'bg-black text-white'
              : 'bg-white text-gray-700 hover:bg-gray-100'
          }`}
        >
          Conversations
          {conversations.filter(c => c.unread_count > 0).length > 0 && (
            <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
              {conversations.filter(c => c.unread_count > 0).length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab('disputes')}
          className={`px-6 py-3 text-sm font-bold uppercase rounded-lg transition ${
            tab === 'disputes'
              ? 'bg-black text-white'
              : 'bg-white text-gray-700 hover:bg-gray-100'
          }`}
        >
          Litiges
          {disputes.filter(d => d.status === 'open' || d.status === 'waiting_customer').length > 0 && (
            <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-2 py-0.5">
              {disputes.filter(d => d.status === 'open' || d.status === 'waiting_customer').length}
            </span>
          )}
        </button>
      </div>

      {loading ? (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-black border-t-transparent rounded-full mx-auto"></div>
          <p className="text-gray-500 mt-4 text-sm">Chargement...</p>
        </div>
      ) : (
        <>
          {/* Conversations Tab */}
          {tab === 'conversations' && (
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              {conversations.length === 0 ? (
                <div className="p-12 text-center text-gray-400">
                  <svg className="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  <p className="text-lg font-semibold">Aucune conversation</p>
                  <p className="text-sm mt-1">Utilisez le bouton de chat en bas à droite pour démarrer une conversation.</p>
                </div>
              ) : (
                <div className="divide-y">
                  {conversations.map((conv) => (
                    <div
                      key={conv.id}
                      className="px-6 py-5 hover:bg-gray-50 transition cursor-pointer flex items-start gap-4"
                      onClick={() => {
                        window.dispatchEvent(new CustomEvent('open-chat', { detail: conv.id }))
                      }}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-3">
                          <h3 className="font-semibold text-sm truncate">
                            {conv.unread_count > 0 && (
                              <span className="inline-block w-2 h-2 bg-black rounded-full mr-2 align-middle"></span>
                            )}
                            {conv.subject}
                          </h3>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${statusColor[conv.status]}`}>
                            {statusLabel[conv.status]}
                          </span>
                        </div>
                        {conv.last_message && (
                          <p className="text-sm text-gray-500 truncate mt-1">
                            {conv.last_message.is_from_admin ? 'Support: ' : 'Vous: '}
                            {conv.last_message.content}
                          </p>
                        )}
                        <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                          <span>{new Date(conv.updated_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                          {conv.order_number && <span>Commande #{conv.order_number}</span>}
                          {conv.has_dispute && (
                            <span className="text-red-500 font-medium">⚠ Litige ouvert</span>
                          )}
                        </div>
                      </div>
                      <svg className="w-5 h-5 text-gray-300 flex-shrink-0 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Disputes Tab */}
          {tab === 'disputes' && (
            <div className="space-y-4">
              {disputes.length === 0 ? (
                <div className="bg-white rounded-lg shadow-sm p-12 text-center text-gray-400">
                  <svg className="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                  <p className="text-lg font-semibold">Aucun litige</p>
                  <p className="text-sm mt-1">Vous pouvez ouvrir un litige depuis vos commandes si nécessaire.</p>
                </div>
              ) : (
                disputes.map((dispute) => (
                  <div key={dispute.id} className="bg-white rounded-lg shadow-sm p-6">
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div>
                        <h3 className="font-bold text-sm">{dispute.dispute_number}</h3>
                        <p className="text-xs text-gray-500 mt-0.5">Commande #{dispute.order_number}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${disputeStatusColor[dispute.status]}`}>
                          {disputeStatusLabel[dispute.status] || dispute.status}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-gray-100 font-medium">
                          {priorityLabel[dispute.priority] || dispute.priority}
                        </span>
                      </div>
                    </div>
                    <div className="mb-3">
                      <span className="text-xs font-semibold text-gray-600 uppercase">Raison:</span>
                      <span className="text-sm text-gray-700 ml-2">{dispute.reason_display}</span>
                    </div>
                    <p className="text-sm text-gray-600 leading-relaxed">{dispute.description}</p>
                    {dispute.resolution_note && (
                      <div className="mt-4 bg-green-50 border border-green-200 rounded-lg p-3">
                        <p className="text-xs font-semibold text-green-800 uppercase mb-1">Résolution</p>
                        <p className="text-sm text-green-700">{dispute.resolution_note}</p>
                        {dispute.refund_amount && (
                          <p className="text-sm font-bold text-green-800 mt-1">
                            Remboursement: {dispute.refund_amount} FCFA
                          </p>
                        )}
                      </div>
                    )}
                    <div className="mt-4 flex items-center justify-between text-xs text-gray-400">
                      <span>Créé le {new Date(dispute.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                      {dispute.resolved_at && (
                        <span>Résolu le {new Date(dispute.resolved_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}
    </div>
  )
}
