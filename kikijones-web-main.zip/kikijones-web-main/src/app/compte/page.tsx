'use client'

import { useEffect, useState, useRef } from 'react'
import Link from 'next/link'
import { Package, Heart, AlertCircle, Star, Gift, ChevronRight, Trophy, Sparkles, Search } from 'lucide-react'
import { getOrders, Order } from '@/lib/api/orders'
import { getStatusLabel, getStatusColor } from '@/lib/api/orders'
import { getAuthToken } from '@/lib/api/auth'
import { API_ENDPOINTS, fetchAPI } from '@/lib/api/config'

interface PointsHistory {
  id: string
  points: number
  type: string
  action: string
  description: string
  created_at: string
}

interface LoyaltyTier {
  name: string
  level: string
  min_points: number
  discount_percentage: string
  free_shipping: boolean
  badge_color: string
  badge_icon: string
  description: string
}

interface PointsData {
  points: number
  level: string
  total_spent: string
  current_tier: LoyaltyTier | null
  next_tier: LoyaltyTier | null
  points_to_next: number
  history: PointsHistory[]
}

export default function ComptePage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [wishlistCount, setWishlistCount] = useState<number>(0)
  const [pointsData, setPointsData] = useState<PointsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const token = getAuthToken()
    if (!token) return

    const controller = new AbortController()
    const signal = controller.signal

    Promise.all([
      getOrders()
        .then((data) => { if (!signal.aborted) setOrders(data.results || []) })
        .catch(() => { if (!signal.aborted) setError('Impossible de charger les commandes') }),
      fetchAPI<any>(API_ENDPOINTS.wishlist, {
        headers: { Authorization: `Bearer ${token}` },
        signal,
      })
        .then((data) => {
          if (signal.aborted) return
          const items = data.results || data || []
          setWishlistCount(Array.isArray(items) ? items.length : 0)
        })
        .catch(() => {}),
      fetchAPI<PointsData>(API_ENDPOINTS.gamificationPoints, {
        headers: { Authorization: `Bearer ${token}` },
        signal,
      })
        .then((data) => { if (!signal.aborted) setPointsData(data) })
        .catch(() => {}),
    ]).finally(() => { if (!signal.aborted) setLoading(false) })

    return () => controller.abort()
  }, [])

  const recentOrders = orders.slice(0, 3)

  const levelLabels: Record<string, string> = {
    debutant: 'Débutant',
    silver: 'Silver',
    gold: 'Gold',
    vip: 'VIP',
    elite: 'Élite',
  }

  const levelColors: Record<string, string> = {
    debutant: 'from-gray-400 to-gray-500',
    silver: 'from-gray-300 to-gray-500',
    gold: 'from-yellow-400 to-amber-500',
    vip: 'from-purple-500 to-indigo-600',
    elite: 'from-rose-500 to-red-600',
  }

  const progressPercent = pointsData && pointsData.next_tier
    ? Math.min(100, Math.round(((pointsData.points) / (pointsData.points + pointsData.points_to_next)) * 100))
    : 100

  return (
    <>
      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-[#F7F7F7] border border-black/[0.06] p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-black text-white flex items-center justify-center">
              <Package size={20} />
            </div>
            <div>
              <p className="text-2xl font-semibold">{orders.length}</p>
              <p className="text-xs text-black/55 uppercase tracking-wide">Commandes</p>
            </div>
          </div>
        </div>

        <div className="bg-[#F7F7F7] border border-black/[0.06] p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-black text-white flex items-center justify-center">
              <Heart size={20} />
            </div>
            <div>
              <p className="text-2xl font-semibold">{wishlistCount}</p>
              <p className="text-xs text-black/55 uppercase tracking-wide">Favoris</p>
            </div>
          </div>
        </div>

        <div className="bg-[#F7F7F7] border border-black/[0.06] p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-black text-white flex items-center justify-center">
              <Star size={20} />
            </div>
            <div>
              <p className="text-2xl font-semibold">{pointsData?.points ?? 0}</p>
              <p className="text-xs text-black/55 uppercase tracking-wide">Points Kiki</p>
            </div>
          </div>
        </div>
      </div>

      {/* Loyalty Card */}
      {pointsData && (
        <div className={`relative overflow-hidden bg-black text-white p-6 mb-6`}>
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 translate-y-1/2 -translate-x-1/2" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Trophy size={18} />
                  <span className="text-xs font-medium uppercase tracking-widest opacity-80">Programme Fidélité</span>
                </div>
                <h3 className="text-2xl font-bold">
                  {pointsData.current_tier?.badge_icon || '⭐'} {pointsData.current_tier?.name || levelLabels[pointsData.level] || 'Débutant'}
                </h3>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold">{pointsData.points.toLocaleString()}</p>
                <p className="text-xs opacity-80">points</p>
              </div>
            </div>

            {/* Progress to next tier */}
            {pointsData.next_tier && pointsData.points_to_next > 0 ? (
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5 opacity-90">
                  <span>{levelLabels[pointsData.level] || pointsData.level}</span>
                  <span>{pointsData.next_tier.name}</span>
                </div>
                <div className="w-full h-[2px] bg-white/25 overflow-hidden">
                  <div
                    className="h-full bg-white transition-all duration-700"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <p className="text-xs mt-1.5 opacity-80">
                  Encore <strong>{pointsData.points_to_next.toLocaleString()}</strong> points pour atteindre {pointsData.next_tier.name}
                </p>
              </div>
            ) : (
              <p className="text-sm opacity-80">🎉 Vous avez atteint le niveau maximum !</p>
            )}

            {/* Tier benefits */}
            {pointsData.current_tier && (
              <div className="flex items-center gap-3 mt-4 pt-3 border-t border-white/20 text-xs">
                {Number(pointsData.current_tier.discount_percentage) > 0 && (
                  <span className="bg-white/15 px-2 py-1">
                    -{pointsData.current_tier.discount_percentage}% sur tout
                  </span>
                )}
                {pointsData.current_tier.free_shipping && (
                  <span className="bg-white/15 px-2 py-1">
                    Livraison gratuite
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <Link href="/roue-chance" className="bg-black text-white p-4 text-center hover:bg-black/85 transition-colors">
          <Sparkles size={24} className="mx-auto mb-2" />
          <p className="text-[11px] font-bold uppercase tracking-[0.14em]">Roue de la Chance</p>
          <p className="text-xs opacity-80 mt-0.5">Gagnez des points</p>
        </Link>
        <Link href="/recompenses" className="bg-black text-white p-4 text-center hover:bg-black/85 transition-colors">
          <Gift size={24} className="mx-auto mb-2" />
          <p className="text-[11px] font-bold uppercase tracking-[0.14em]">Récompenses</p>
          <p className="text-xs opacity-80 mt-0.5">Échangez vos points</p>
        </Link>
        <Link href="/track-order" className="bg-white border border-black/15 p-4 text-center hover:border-black transition-colors">
          <Search size={24} className="mx-auto mb-2 text-black" />
          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-black">Suivi commande</p>
          <p className="text-xs text-black/55 mt-0.5">Suivre un colis</p>
        </Link>
        <Link href="/compte/messages" className="bg-white border border-black/15 p-4 text-center hover:border-black transition-colors">
          <ChevronRight size={24} className="mx-auto mb-2 text-black" />
          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-black">Messages</p>
          <p className="text-xs text-black/55 mt-0.5">Voir les messages</p>
        </Link>
      </div>

      {/* Points History */}
      {pointsData && pointsData.history.length > 0 && (
        <div className="bg-[#F7F7F7] border border-black/[0.06] p-6 mb-6">
          <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black mb-4 flex items-center gap-2">
            <Gift size={18} />
            Dernières activités points
          </h2>
          <div className="space-y-3">
            {pointsData.history.slice(0, 5).map((h) => (
              <div key={h.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-black truncate">{h.description || h.action}</p>
                  <p className="text-xs text-black/55">
                    {new Date(h.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                </div>
                <span className={`text-sm font-bold flex-shrink-0 ml-3 ${h.type === 'earn' ? 'text-black' : 'text-black/55'}`}>
                  {h.type === 'earn' ? '+' : '-'}{h.points} pts
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Orders */}
      <div className="bg-white border border-black/10 p-5 sm:p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl sm:text-2xl font-bold tracking-[-0.025em] text-black">Dernières commandes</h2>
          {orders.length > 0 && (
            <Link href="/compte/commandes" className="text-[11px] font-bold uppercase tracking-[0.16em] text-black underline underline-offset-4 hover:opacity-65">
              Voir tout
            </Link>
          )}
        </div>
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <AlertCircle size={48} className="mx-auto mb-4 text-black/30" />
            <p className="text-black/70 mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="inline-block px-6 py-3 bg-black text-white text-xs font-bold uppercase tracking-[0.18em] hover:bg-black/85 transition-colors"
            >
              Réessayer
            </button>
          </div>
        ) : recentOrders.length === 0 ? (
          <div className="text-center py-12 text-black/55">
            <Package size={48} className="mx-auto mb-4 opacity-30" />
            <p className="mb-4">Aucune commande pour le moment</p>
            <Link
              href="/produits"
              className="inline-block px-6 py-3 bg-black text-white text-xs font-bold uppercase tracking-[0.18em] hover:bg-black/85 transition-colors"
            >
              Découvrir nos produits
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {recentOrders.map((order) => (
              <Link
                key={order.id}
                href={`/compte/commandes/${order.id}`}
                className="block border border-black/10 p-4 hover:border-black transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">#{order.order_number}</p>
                    <p className="text-sm text-black/55">
                      {new Date(order.created_at).toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                      })}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className={`inline-block px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] border border-black/20 text-black`}>
                      {getStatusLabel(order.status)}
                    </span>
                    <p className="text-sm font-medium mt-1">
                      {Number(order.total_amount).toLocaleString()} {order.currency}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
