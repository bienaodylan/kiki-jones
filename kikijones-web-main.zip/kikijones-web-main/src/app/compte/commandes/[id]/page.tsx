'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, Package, Truck, CheckCircle, Clock, Settings } from 'lucide-react'
import { getOrder, getOrderTracking, Order, TrackingInfo, TrackingStep, getStatusLabel, getStatusColor } from '@/lib/api/orders'
import { fetchAPI, API_ENDPOINTS } from '@/lib/api/config'
import { setWithTtl } from '@/lib/ttlStorage'

const statusIcons: Record<string, any> = {
  pending: Clock,
  confirmed: CheckCircle,
  processing: Settings,
  shipped: Truck,
  delivered: Package,
}

const stepIcons: Record<string, any> = {
  pending: Clock,
  confirmed: CheckCircle,
  processing: Settings,
  shipped: Truck,
  delivered: Package,
}

function TrackingProgress({ steps }: { steps: TrackingStep[] }) {
  return (
    <div className="relative">
      <div className="flex items-center justify-between mb-2">
        {steps.map((step) => {
          const Icon = stepIcons[step.status] || Package
          return (
            <div key={step.status} className="flex flex-col items-center relative z-10 flex-1">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  step.done
                    ? step.current
                      ? 'bg-black text-white ring-4 ring-black/20'
                      : 'bg-green-500 text-white'
                    : 'bg-gray-200 text-gray-400'
                }`}
              >
                <Icon size={18} />
              </div>
              <span
                className={`text-[10px] mt-1.5 font-medium text-center ${
                  step.done ? (step.current ? 'text-black' : 'text-green-600') : 'text-gray-400'
                }`}
              >
                {step.label}
              </span>
              {step.date && (
                <span className="text-[9px] text-gray-400">
                  {new Date(step.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                </span>
              )}
            </div>
          )
        })}
      </div>
      <div className="absolute top-5 left-0 right-0 flex px-[8%]" style={{ zIndex: 0 }}>
        {steps.slice(0, -1).map((step, i) => (
          <div key={i} className="flex-1 mx-1">
            <div
              className={`h-1 rounded-full ${
                steps[i + 1]?.done ? 'bg-green-500' : step.done ? 'bg-green-500' : 'bg-gray-200'
              }`}
            />
          </div>
        ))}
      </div>
    </div>
  )
}

export default function OrderDetailPage() {
  const params = useParams()
  const [order, setOrder] = useState<Order | null>(null)
  const [tracking, setTracking] = useState<TrackingInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [paying, setPaying] = useState(false)
  const [payError, setPayError] = useState<string | null>(null)

  useEffect(() => {
    if (params.id) {
      const controller = new AbortController()
      Promise.all([
        getOrder(params.id as string).then((d) => { if (!controller.signal.aborted) setOrder(d) }).catch(() => {}),
        getOrderTracking(params.id as string).then((d) => { if (!controller.signal.aborted) setTracking(d) }).catch(() => {}),
      ]).finally(() => { if (!controller.signal.aborted) setLoading(false) })
      return () => controller.abort()
    }
  }, [params.id])

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black"></div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-500 mb-4">Commande introuvable</p>
        <Link href="/compte/commandes" className="text-black hover:underline">
          Retour à mes commandes
        </Link>
      </div>
    )
  }

  const StatusIcon = statusIcons[order.status] || Package

  // An online order that was never paid (abandoned payment, provider error) can be
  // paid again from here: the "Réessayer le paiement" the cancel page promises.
  const canPay =
    order.payment_status !== 'paid' &&
    !['cancelled', 'refunded', 'shipped', 'delivered'].includes(order.status) &&
    ['card', 'mobile', 'credit_card', 'paypal', 'bank_transfer'].includes(order.payment_method)

  const handlePay = async () => {
    if (paying) return
    setPaying(true)
    setPayError(null)
    try {
      const result = await fetchAPI<any>(API_ENDPOINTS.initPayment(order.id), {
        method: 'POST',
        body: JSON.stringify({
          order_id: order.id,
          return_url: `${window.location.origin}/checkout/success`,
        }),
      })
      if (result.payment_url) {
        setWithTtl('pendingOrderId', order.id)
        window.location.href = result.payment_url
        return // stay disabled while the browser navigates (no double payment link)
      }
      throw new Error('URL de paiement non reçue')
    } catch (error: any) {
      let msg = "Le paiement n'a pas pu être lancé. Veuillez réessayer dans quelques minutes."
      try {
        const parsed = JSON.parse(String(error?.message || '').replace('API Error: ', ''))
        if (parsed.error) msg = parsed.error
        else if (parsed.detail) msg = parsed.detail
      } catch {
        // keep the generic message
      }
      setPayError(msg)
      setPaying(false)
    }
  }

  return (
    <div>
      <Link
        href="/compte/commandes"
        className="inline-flex items-center gap-2 text-gray-600 hover:text-black mb-6 transition-colors"
      >
        <ArrowLeft size={18} />
        Retour aux commandes
      </Link>

      {canPay && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-5 mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="font-medium text-amber-900">Cette commande n'est pas encore payée</p>
            <p className="text-sm text-amber-800 mt-1">
              Vous pouvez finaliser le paiement maintenant. Les commandes impayées sont annulées automatiquement après un certain délai.
            </p>
            {payError && <p className="text-sm text-red-700 mt-2">{payError}</p>}
          </div>
          <button
            onClick={handlePay}
            disabled={paying}
            className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors disabled:opacity-60 whitespace-nowrap"
          >
            {paying ? 'Redirection…' : 'Payer maintenant'}
          </button>
        </div>
      )}

      {/* Order header */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-light">Commande #{order.order_number}</h2>
            <p className="text-sm text-gray-500 mt-1">
              Passée le{' '}
              {new Date(order.created_at).toLocaleDateString('fr-FR', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
          </div>
          <span
            className={`inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-full ${getStatusColor(order.status)}`}
          >
            <StatusIcon size={16} />
            {getStatusLabel(order.status)}
          </span>
        </div>

        {/* Tracking */}
        {order.tracking_number && (
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm font-medium text-blue-800">
              <Truck size={16} className="inline mr-2" />
              Numéro de suivi : {order.tracking_number}
              {order.carrier && ` (${order.carrier})`}
            </p>
          </div>
        )}

        {/* Visual Tracking Progress */}
        {tracking && tracking.steps.length > 0 && (
          <div className="mt-6 pt-6 border-t">
            <h3 className="text-sm font-medium text-gray-700 mb-4">Suivi de livraison</h3>
            <TrackingProgress steps={tracking.steps} />
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Items */}
        <div className="md:col-span-2">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-medium mb-4">Articles</h3>
            <div className="divide-y">
              {order.order_items?.map((item) => (
                <div key={item.id} className="flex items-center gap-4 py-4">
                  <div className="relative w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                    {item.product?.images?.[0] ? (
                      <Image
                        src={item.product.images[0].image}
                        alt={item.product_name}
                        fill
                        sizes="64px"
                        className="object-cover"
                      />
                    ) : (
                      <Package size={24} className="text-gray-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{item.product_name}</p>
                    {item.variant_details && (
                      <p className="text-sm text-gray-500">{item.variant_details}</p>
                    )}
                    <p className="text-sm text-gray-500">Qté: {item.quantity}</p>
                  </div>
                  <p className="font-medium">
                    {Number(item.total_price).toLocaleString()} {order.currency}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Status History */}
          {order.status_history_list && order.status_history_list.length > 0 && (
            <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
              <h3 className="text-lg font-medium mb-4">Historique</h3>
              <div className="space-y-4">
                {order.status_history_list.map((entry, i) => (
                  <div key={entry.id} className="flex items-start gap-3">
                    <div
                      className={`w-3 h-3 rounded-full mt-1.5 ${
                        i === 0 ? 'bg-black' : 'bg-gray-300'
                      }`}
                    />
                    <div>
                      <p className="font-medium text-sm">{getStatusLabel(entry.status)}</p>
                      {entry.note && <p className="text-sm text-gray-500">{entry.note}</p>}
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(entry.created_at).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Summary */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h3 className="text-lg font-medium mb-4">Récapitulatif</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Sous-total</span>
                <span>{Number(order.subtotal).toLocaleString()} {order.currency}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Livraison</span>
                <span>
                  {Number(order.shipping_cost) === 0
                    ? 'Gratuit'
                    : `${Number(order.shipping_cost).toLocaleString()} ${order.currency}`}
                </span>
              </div>
              {Number(order.discount_amount) > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Réduction</span>
                  <span>-{Number(order.discount_amount).toLocaleString()} {order.currency}</span>
                </div>
              )}
              <div className="border-t pt-3 flex justify-between font-medium text-base">
                <span>Total</span>
                <span>{Number(order.total_amount).toLocaleString()} {order.currency}</span>
              </div>
            </div>
          </div>

          {/* Shipping Address */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-medium mb-4">Adresse de livraison</h3>
            <div className="text-sm text-gray-600 space-y-1">
              <p className="font-medium text-black">
                {order.shipping_first_name} {order.shipping_last_name}
              </p>
              <p>{order.shipping_address_line1}</p>
              {order.shipping_address_line2 && <p>{order.shipping_address_line2}</p>}
              <p>
                {order.shipping_city}
                {order.shipping_postal_code && `, ${order.shipping_postal_code}`}
              </p>
              <p>{order.shipping_country}</p>
              {order.shipping_phone && <p className="mt-2">Tél: {order.shipping_phone}</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
