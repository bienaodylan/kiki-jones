'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Package, ChevronRight } from 'lucide-react'
import { getOrders, Order, getStatusLabel, getStatusColor } from '@/lib/api/orders'

export default function CommandesPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const controller = new AbortController()
    getOrders()
      .then((data) => { if (!controller.signal.aborted) setOrders(data.results || []) })
      .catch(() => {})
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div>
      <h2 className="text-2xl font-light mb-6">Mes Commandes</h2>

      {orders.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <Package size={64} className="mx-auto mb-4 text-gray-300" />
          <p className="text-gray-500 mb-6">Vous n&apos;avez pas encore de commande</p>
          <Link
            href="/produits"
            className="inline-block px-8 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
          >
            Découvrir nos produits
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <Link
              key={order.id}
              href={`/compte/commandes/${order.id}`}
              className="block bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <p className="font-medium text-lg">#{order.order_number}</p>
                    <span
                      className={`inline-block px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(order.status)}`}
                    >
                      {getStatusLabel(order.status)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500">
                    {new Date(order.created_at).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                    <span>{order.order_items?.length || 0} article(s)</span>
                    <span className="font-medium text-black">
                      {Number(order.total_amount).toLocaleString()} {order.currency}
                    </span>
                  </div>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
