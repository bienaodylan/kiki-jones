'use client'

import { useEffect, useState } from 'react'
import { MapPin, Plus, Trash2, Edit, Check } from 'lucide-react'
import { getAuthToken } from '@/lib/api/auth'
import { API_ENDPOINTS, fetchAPI } from '@/lib/api/config'

interface Address {
  id: string
  label: string
  first_name: string
  last_name: string
  phone: string
  address_line1: string
  address_line2: string
  city: string
  state: string
  postal_code: string
  country: string
  is_default: boolean
}

const emptyAddress: Omit<Address, 'id'> = {
  label: '',
  first_name: '',
  last_name: '',
  phone: '',
  address_line1: '',
  address_line2: '',
  city: '',
  state: '',
  postal_code: '',
  country: 'CI',
  is_default: false,
}

export default function AdressesPage() {
  const [addresses, setAddresses] = useState<Address[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(emptyAddress)
  const [saving, setSaving] = useState(false)

  const getHeaders = () => {
    const t = getAuthToken()
    return { Authorization: `Bearer ${t || ''}`, 'Content-Type': 'application/json' }
  }

  const loadAddresses = async () => {
    const t = getAuthToken()
    if (!t) { setLoading(false); return }
    try {
      const data = await fetchAPI<any>(API_ENDPOINTS.addresses, {
        headers: { Authorization: `Bearer ${t}` },
      })
      setAddresses(data.results || data || [])
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAddresses()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const token = getAuthToken()
      const url = editingId
        ? API_ENDPOINTS.addressDetail(editingId)
        : API_ENDPOINTS.addressCreate
      await fetchAPI(url, {
        method: editingId ? 'PUT' : 'POST',
        headers: { Authorization: `Bearer ${token || ''}` },
        body: JSON.stringify(form),
      })
      await loadAddresses()
      setShowForm(false)
      setEditingId(null)
      setForm(emptyAddress)
    } catch (e) {
      console.error(e)
    } finally {
      setSaving(false)
    }
  }

  const handleEdit = (address: Address) => {
    setForm(address)
    setEditingId(address.id)
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer cette adresse ?')) return
    try {
      const token = getAuthToken()
      await fetchAPI(API_ENDPOINTS.addressDetail(id), {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token || ''}` },
      })
      setAddresses((prev) => prev.filter((a) => a.id !== id))
    } catch (e) {
      console.error(e)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-light">Mes Adresses</h2>
        {!showForm && (
          <button
            onClick={() => {
              setForm(emptyAddress)
              setEditingId(null)
              setShowForm(true)
            }}
            className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded hover:bg-gray-800 transition-colors text-sm"
          >
            <Plus size={16} />
            Ajouter
          </button>
        )}
      </div>

      {showForm && (
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-medium mb-4">
            {editingId ? 'Modifier l\'adresse' : 'Nouvelle adresse'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nom de l&apos;adresse</label>
              <input
                type="text"
                value={form.label}
                onChange={(e) => setForm({ ...form, label: e.target.value })}
                placeholder="Ex: Maison, Bureau..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prénom</label>
                <input
                  type="text"
                  value={form.first_name}
                  onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nom</label>
                <input
                  type="text"
                  value={form.last_name}
                  onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Adresse</label>
              <input
                type="text"
                value={form.address_line1}
                onChange={(e) => setForm({ ...form, address_line1: e.target.value })}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ville</label>
                <input
                  type="text"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pays</label>
                <select
                  value={form.country}
                  onChange={(e) => setForm({ ...form, country: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-black focus:border-black"
                >
                  <option value="CI">Côte d&apos;Ivoire</option>
                  <option value="SN">Sénégal</option>
                  <option value="ML">Mali</option>
                  <option value="BF">Burkina Faso</option>
                  <option value="GN">Guinée</option>
                  <option value="TG">Togo</option>
                  <option value="BJ">Bénin</option>
                  <option value="CM">Cameroun</option>
                </select>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="is_default"
                checked={form.is_default}
                onChange={(e) => setForm({ ...form, is_default: e.target.checked })}
                className="rounded border-gray-300"
              />
              <label htmlFor="is_default" className="text-sm text-gray-700">Adresse par défaut</label>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2 bg-black text-white rounded hover:bg-gray-800 transition-colors disabled:opacity-50"
              >
                {saving ? 'Enregistrement...' : editingId ? 'Modifier' : 'Ajouter'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false)
                  setEditingId(null)
                  setForm(emptyAddress)
                }}
                className="px-6 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      )}

      {addresses.length === 0 && !showForm ? (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <MapPin size={64} className="mx-auto mb-4 text-gray-300" />
          <p className="text-gray-500 mb-6">Aucune adresse enregistrée</p>
          <button
            onClick={() => setShowForm(true)}
            className="inline-block px-8 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
          >
            Ajouter une adresse
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {addresses.map((address) => (
            <div
              key={address.id}
              className={`bg-white rounded-lg shadow-sm p-5 border-2 ${
                address.is_default ? 'border-black' : 'border-transparent'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-gray-500" />
                  <span className="font-medium">{address.label || 'Adresse'}</span>
                  {address.is_default && (
                    <span className="flex items-center gap-1 text-xs bg-black text-white px-2 py-0.5 rounded-full">
                      <Check size={10} />
                      Par défaut
                    </span>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(address)}
                    className="p-1.5 text-gray-400 hover:text-black transition-colors"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    onClick={() => handleDelete(address.id)}
                    className="p-1.5 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="text-sm text-gray-600 space-y-0.5">
                <p>{address.first_name} {address.last_name}</p>
                <p>{address.address_line1}</p>
                <p>{address.city}, {address.country}</p>
                {address.phone && <p className="text-gray-500">{address.phone}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
