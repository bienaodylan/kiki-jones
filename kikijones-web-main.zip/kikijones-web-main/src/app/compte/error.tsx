'use client'

import Link from 'next/link'

export default function CompteError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <div className="text-center py-16">
      <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
        <span className="text-2xl">⚠️</span>
      </div>
      <h2 className="text-xl font-semibold mb-2">Erreur de chargement</h2>
      <p className="text-gray-500 mb-6">
        Impossible de charger cette page de votre compte. Veuillez réessayer.
      </p>
      <div className="flex gap-3 justify-center">
        <button
          onClick={() => reset()}
          className="px-5 py-2.5 bg-black text-white rounded hover:bg-gray-800 transition-colors text-sm font-medium"
        >
          Réessayer
        </button>
        <Link
          href="/compte"
          className="px-5 py-2.5 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors text-sm font-medium"
        >
          Tableau de bord
        </Link>
      </div>
    </div>
  )
}
