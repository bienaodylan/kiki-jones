'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Heart, Trash2 } from 'lucide-react'
import { getAuthToken } from '@/lib/api/auth'
import { API_ENDPOINTS, fetchAPI } from '@/lib/api/config'

interface WishlistItem {
  id: string
  product_details: {
    id: string
    name: string
    slug: string
    main_image: string | null
    final_price: number
  }
  created_at: string
}

export default function FavorisPage() {
  const [items, setItems] = useState<WishlistItem[]>([])
  const [loading, setLoading] = useState(true)

  const loadWishlist = async () => {
    try {
      const token = getAuthToken()
      if (!token) return
      const data = await fetchAPI<any>(API_ENDPOINTS.wishlist, {
        headers: { Authorization: `Bearer ${token}` },
      })
      setItems(data.results || data || [])
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadWishlist()
  }, [])

  const removeFromWishlist = async (id: string) => {
    try {
      const token = getAuthToken()
      await fetchAPI(`${API_ENDPOINTS.wishlist}${id}/`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token || ''}` },
      })
      setItems((prev) => prev.filter((item) => item.id !== id))
    } catch (e) {
      console.error(e)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <div>
      <h2 className="text-2xl font-light mb-6">Mes Favoris</h2>

      {items.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <Heart size={64} className="mx-auto mb-4 text-gray-300" />
          <p className="text-gray-500 mb-6">Votre liste de favoris est vide</p>
          <Link
            href="/produits"
            className="inline-block px-8 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors"
          >
            Découvrir nos produits
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((item) => (
            <div key={item.id} className="bg-white rounded-lg shadow-sm overflow-hidden group">
              <Link href={`/produits/${item.product_details?.slug || item.product_details?.id}`}>
                <div className="aspect-square bg-gray-100 relative">
                  {item.product_details?.main_image ? (
                    <Image
                      src={item.product_details.main_image}
                      alt={item.product_details.name}
                      fill
                      sizes="(max-width: 768px) 50vw, 33vw"
                      className="object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <Heart size={48} />
                    </div>
                  )}
                </div>
              </Link>
              <div className="p-4">
                <Link href={`/produits/${item.product_details?.slug || item.product_details?.id}`}>
                  <h3 className="font-medium text-sm truncate hover:underline">{item.product_details?.name}</h3>
                </Link>
                <div className="flex items-center justify-between mt-2">
                  <p className="font-light text-lg">
                    {item.product_details?.final_price != null
                      ? Number(item.product_details.final_price).toLocaleString()
                      : '—'} FCFA
                  </p>
                  <button
                    onClick={() => removeFromWishlist(item.id)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                    title="Retirer des favoris"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
