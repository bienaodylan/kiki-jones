'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Gift, RotateCw, Ticket, Copy, Check, Clock, XCircle, Tag, Truck, Percent, AlertCircle } from 'lucide-react'
import { fetchAPI, API_ENDPOINTS } from '@/lib/api/config'

interface Spin {
  id: string
  prize_type: string
  prize_value: number
  prize_label: string
  coupon_code: string
  is_claimed: boolean
  created_at: string
}

interface Coupon {
  id: string
  code: string
  name: string
  description: string
  discount_type: string
  discount_value: number
  minimum_order_amount: number
  valid_from: string
  valid_until: string
  is_used: boolean
  is_expired: boolean
  status: 'active' | 'used' | 'expired'
}

type Tab = 'coupons' | 'spins'

const PRIZE_ICONS: Record<string, string> = {
  points: '\u{1F4B0}',
  discount_percent: '\u{1F3AF}',
  discount_fixed: '\u{1F4B5}',
  free_shipping: '\u{1F69A}',
  nothing: '\u{1F615}',
  coupon: '\u{1F3AB}',
}

const STATUS_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  active: { bg: 'bg-green-100', text: 'text-green-700', label: 'Actif' },
  used: { bg: 'bg-gray-100', text: 'text-gray-500', label: 'Utilisé' },
  expired: { bg: 'bg-red-100', text: 'text-red-600', label: 'Expiré' },
}

export default function MesRecompensesPage() {
  const [tab, setTab] = useState<Tab>('coupons')
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [spins, setSpins] = useState<Spin[]>([])
  const [loading, setLoading] = useState(true)
  const [copiedCode, setCopiedCode] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    setLoading(true)
    try {
      const [couponsRes, spinsRes] = await Promise.all([
        fetchAPI<Coupon[]>(API_ENDPOINTS.myCoupons, {}).catch(() => null),
        fetchAPI<Spin[]>(API_ENDPOINTS.gamificationSpinHistory, {}).catch(() => null),
      ])
      if (couponsRes) setCoupons(Array.isArray(couponsRes) ? couponsRes : [])
      if (spinsRes) setSpins(Array.isArray(spinsRes) ? spinsRes : [])
    } catch (e) {
      console.error(e)
    }
    setLoading(false)
  }

  function copyCode(code: string) {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    setTimeout(() => setCopiedCode(null), 2000)
  }

  function formatDate(dateStr: string) {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
  }

  function formatDiscount(coupon: Coupon) {
    if (coupon.discount_type === 'percentage') return `-${coupon.discount_value}%`
    if (coupon.discount_type === 'fixed') return `-${Math.round(coupon.discount_value)} XOF`
    if (coupon.discount_type === 'free_shipping') return 'Livraison gratuite'
    return coupon.discount_type
  }

  function getDiscountIcon(type: string) {
    if (type === 'percentage') return <Percent size={18} />
    if (type === 'free_shipping') return <Truck size={18} />
    return <Tag size={18} />
  }

  const activeCoupons = coupons.filter(c => c.status === 'active')
  const usedExpiredCoupons = coupons.filter(c => c.status !== 'active')

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8 flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-xl font-bold text-black">Mes Récompenses</h1>
            <p className="text-sm text-gray-500 mt-1">
              Vos coupons gagnés et historique de la roue de la chance
            </p>
          </div>
          <Link
            href="/roue-chance"
            className="inline-flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-900 transition-colors"
          >
            <RotateCw size={16} />
            Tourner la roue
          </Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{activeCoupons.length}</div>
          <div className="text-xs text-gray-500 mt-1">Coupons actifs</div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4 text-center">
          <div className="text-2xl font-bold text-gray-400">{usedExpiredCoupons.length}</div>
          <div className="text-xs text-gray-500 mt-1">Utilisés / Expirés</div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4 text-center">
          <div className="text-2xl font-bold text-purple-600">{spins.length}</div>
          <div className="text-xs text-gray-500 mt-1">Tours joués</div>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-4 text-center">
          <div className="text-2xl font-bold text-amber-600">
            {spins.filter(s => s.prize_type !== 'nothing').length}
          </div>
          <div className="text-xs text-gray-500 mt-1">Prix gagnés</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setTab('coupons')}
            className={`flex-1 py-3 text-sm font-medium text-center transition-colors ${
              tab === 'coupons'
                ? 'border-b-2 border-black text-black'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Ticket size={16} className="inline mr-2" />
            Mes Coupons ({coupons.length})
          </button>
          <button
            onClick={() => setTab('spins')}
            className={`flex-1 py-3 text-sm font-medium text-center transition-colors ${
              tab === 'spins'
                ? 'border-b-2 border-black text-black'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <RotateCw size={16} className="inline mr-2" />
            Historique Roue ({spins.length})
          </button>
        </div>

        <div className="p-4 md:p-6">
          {/* COUPONS TAB */}
          {tab === 'coupons' && (
            <>
              {coupons.length === 0 ? (
                <div className="text-center py-12">
                  <Ticket size={48} className="mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500 mb-2">Aucun coupon pour le moment</p>
                  <p className="text-sm text-gray-400 mb-6">
                    Tournez la roue de la chance ou échangez vos points pour gagner des coupons !
                  </p>
                  <div className="flex justify-center gap-3">
                    <Link href="/roue-chance" className="bg-black text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-900">
                      Roue de la Chance
                    </Link>
                    <Link href="/recompenses" className="border border-black text-black px-4 py-2 rounded-lg text-sm hover:bg-gray-50">
                      Boutique Récompenses
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Active coupons */}
                  {activeCoupons.length > 0 && (
                    <div>
                      <h3 className="text-sm font-semibold text-green-700 uppercase tracking-wider mb-3">
                        Coupons actifs
                      </h3>
                      <div className="space-y-3">
                        {activeCoupons.map(coupon => (
                          <CouponCard
                            key={coupon.id}
                            coupon={coupon}
                            copiedCode={copiedCode}
                            onCopy={copyCode}
                            formatDate={formatDate}
                            formatDiscount={formatDiscount}
                            getDiscountIcon={getDiscountIcon}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Used / Expired coupons */}
                  {usedExpiredCoupons.length > 0 && (
                    <div>
                      <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
                        Utilisés / Expirés
                      </h3>
                      <div className="space-y-3">
                        {usedExpiredCoupons.map(coupon => (
                          <CouponCard
                            key={coupon.id}
                            coupon={coupon}
                            copiedCode={copiedCode}
                            onCopy={copyCode}
                            formatDate={formatDate}
                            formatDiscount={formatDiscount}
                            getDiscountIcon={getDiscountIcon}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* SPINS TAB */}
          {tab === 'spins' && (
            <>
              {spins.length === 0 ? (
                <div className="text-center py-12">
                  <RotateCw size={48} className="mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500 mb-2">Aucun tour joué</p>
                  <p className="text-sm text-gray-400 mb-6">
                    Tentez votre chance à la Roue KikiJones !
                  </p>
                  <Link href="/roue-chance" className="bg-black text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-900">
                    Jouer maintenant
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {spins.map(spin => (
                    <div
                      key={spin.id}
                      className={`flex items-center justify-between p-4 rounded-lg border ${
                        spin.prize_type === 'nothing'
                          ? 'border-gray-200 bg-gray-50'
                          : 'border-green-200 bg-green-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{PRIZE_ICONS[spin.prize_type] || '\u{1F381}'}</span>
                        <div>
                          <p className={`font-medium text-sm ${
                            spin.prize_type === 'nothing' ? 'text-gray-400' : 'text-black'
                          }`}>
                            {spin.prize_label || 'Tour de roue'}
                          </p>
                          {spin.coupon_code && (
                            <div className="flex items-center gap-2 mt-1">
                              <code className="text-xs bg-white px-2 py-0.5 rounded border font-mono">
                                {spin.coupon_code}
                              </code>
                              <button
                                onClick={() => copyCode(spin.coupon_code)}
                                className="text-gray-400 hover:text-black"
                              >
                                {copiedCode === spin.coupon_code ? <Check size={14} className="text-green-600" /> : <Copy size={14} />}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-400">{formatDate(spin.created_at)}</p>
                        {spin.prize_type !== 'nothing' && spin.prize_value > 0 && (
                          <p className="text-sm font-bold text-green-600 mt-1">
                            {spin.prize_type === 'points' ? `+${spin.prize_value} pts` :
                             spin.prize_type === 'discount_percent' ? `-${spin.prize_value}%` :
                             spin.prize_type === 'discount_fixed' ? `-${Math.round(spin.prize_value)} XOF` :
                             spin.prize_type === 'free_shipping' ? 'Livraison gratuite' :
                             `${spin.prize_value}`}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Info */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle size={20} className="text-amber-600 mt-0.5 flex-shrink-0" />
        <div className="text-sm text-amber-800">
          <p className="font-medium mb-1">Comment obtenir des coupons ?</p>
          <ul className="list-disc list-inside space-y-1 text-amber-700">
            <li>Tournez la <Link href="/roue-chance" className="underline font-medium">Roue de la Chance</Link> chaque jour</li>
            <li>Échangez vos KikiPoints dans la <Link href="/recompenses" className="underline font-medium">Boutique Récompenses</Link></li>
            <li>Faites votre check-in quotidien pour débloquer des bonus</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

/* Coupon Card Component */
function CouponCard({
  coupon,
  copiedCode,
  onCopy,
  formatDate,
  formatDiscount,
  getDiscountIcon,
}: {
  coupon: Coupon
  copiedCode: string | null
  onCopy: (code: string) => void
  formatDate: (d: string) => string
  formatDiscount: (c: Coupon) => string
  getDiscountIcon: (type: string) => React.ReactNode
}) {
  const statusStyle = STATUS_COLORS[coupon.status] || STATUS_COLORS.active
  const isActive = coupon.status === 'active'

  return (
    <div className={`rounded-lg border p-4 ${isActive ? 'border-green-200 bg-white' : 'border-gray-200 bg-gray-50 opacity-70'}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
            isActive ? 'bg-green-100 text-green-600' : 'bg-gray-200 text-gray-400'
          }`}>
            {getDiscountIcon(coupon.discount_type)}
          </div>
          <div className="min-w-0 flex-1">
            <p className={`font-medium text-sm truncate ${isActive ? 'text-black' : 'text-gray-400'}`}>
              {coupon.name}
            </p>
            <p className={`text-lg font-bold ${isActive ? 'text-green-600' : 'text-gray-400'}`}>
              {formatDiscount(coupon)}
            </p>
          </div>
        </div>
        <span className={`text-xs px-2 py-1 rounded-full font-medium ${statusStyle.bg} ${statusStyle.text}`}>
          {statusStyle.label}
        </span>
      </div>

      {/* Code */}
      {isActive && (
        <div className="mt-3 flex items-center gap-2">
          <div className="flex-1 bg-gray-100 border border-dashed border-gray-300 rounded-lg px-3 py-2 flex items-center justify-between">
            <code className="font-mono text-sm font-bold tracking-wider">{coupon.code}</code>
            <button
              onClick={() => onCopy(coupon.code)}
              className="text-gray-400 hover:text-black transition-colors"
              title="Copier le code"
            >
              {copiedCode === coupon.code ? (
                <Check size={16} className="text-green-600" />
              ) : (
                <Copy size={16} />
              )}
            </button>
          </div>
        </div>
      )}

      {/* Details */}
      <div className="mt-2 flex items-center gap-4 text-xs text-gray-400">
        <span className="flex items-center gap-1">
          <Clock size={12} />
          Expire le {formatDate(coupon.valid_until)}
        </span>
        {coupon.minimum_order_amount > 0 && (
          <span>Min. {Math.round(coupon.minimum_order_amount)} XOF</span>
        )}
      </div>
    </div>
  )
}
