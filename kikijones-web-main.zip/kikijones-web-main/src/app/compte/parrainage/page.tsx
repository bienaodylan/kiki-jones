'use client'

import { useState, useEffect } from 'react'
import { Copy, Share2, Users, Gift, CheckCircle, Clock, AlertCircle, Star } from 'lucide-react'
import { fetchAPI, API_ENDPOINTS } from '@/lib/api/config'
import { getAccessToken, bootstrapAuth } from '@/lib/auth-store'

// ─── Types ───────────────────────────────────────────────────────────────────
interface ReferralEntry {
  id: string
  status: 'pending' | 'first_order_pending' | 'validated' | 'blocked'
  referee_name: string
  created_at: string
  validated_at?: string | null
}

interface AvailableCredit {
  amount: number
  expires_at: string
  days_remaining: number
}

interface ReferralCredit {
  id: string
  credit_type: 'referrer' | 'referee'
  amount: number | null
  status: 'pending' | 'active' | 'used' | 'expired'
  expires_at: string | null
  activated_at: string | null
}

interface ReferralDashboard {
  code: string
  referral_count: number
  is_ambassador: boolean
  available_credit: AvailableCredit | null
  total_earned: number | null
  active_credit: number | null
  referrals: ReferralEntry[]
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
const MAX_REFERRALS = 20
const CREDIT_AMOUNT = 500

const STATUS_LABEL: Record<string, string> = {
  pending: 'En attente',
  first_order_pending: '1ère commande en cours',
  validated: 'Validé',
  blocked: 'Bloqué',
}
const STATUS_BADGE: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  first_order_pending: 'bg-blue-100 text-blue-800',
  validated: 'bg-green-100 text-green-800',
  blocked: 'bg-red-100 text-red-800',
}
const CREDIT_STATUS_LABEL: Record<string, string> = {
  pending: 'En attente',
  active: 'Disponible',
  used: 'Utilisé',
  expired: 'Expiré',
}
const CREDIT_STATUS_BADGE: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  active: 'bg-green-100 text-green-800',
  used: 'bg-gray-100 text-gray-600',
  expired: 'bg-red-100 text-red-800',
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
}

// ─── Component ───────────────────────────────────────────────────────────────
export default function ParrainagePage() {
  const [data, setData] = useState<ReferralDashboard | null>(null)
  const [credits, setCredits] = useState<ReferralCredit[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [codeCopied, setCodeCopied] = useState(false)
  const [validatingCode, setValidatingCode] = useState('')
  const [validateResult, setValidateResult] = useState<{ valid: boolean; message: string } | null>(null)

  useEffect(() => {
    bootstrapAuth().then((token) => {
      if (!token) { setError('Non authentifié'); setLoading(false); return }
      Promise.all([
        fetchAPI<ReferralDashboard>(API_ENDPOINTS.referralDashboard),
        fetchAPI<ReferralCredit[]>(API_ENDPOINTS.referralCredits).catch(() => []),
      ])
        .then(([dashboard, creditsList]) => {
          setData(dashboard)
          setCredits(creditsList)
        })
        .catch(() => setError('Impossible de charger le tableau de bord de parrainage.'))
        .finally(() => setLoading(false))
    })
  }, [])

  const copyCode = () => {
    if (!data) return
    navigator.clipboard.writeText(data.code)
    setCodeCopied(true)
    setTimeout(() => setCodeCopied(false), 2000)
  }

  const share = async () => {
    if (!data) return
    const msg = `Rejoins KikiJones avec mon code parrainage ${data.code} et reçois ${CREDIT_AMOUNT} FCFA de crédit sur ta première commande ! 🎁 https://kikijones.com/register`
    if (navigator.share) {
      await navigator.share({ title: 'KikiJones – Code Parrainage', text: msg })
    } else {
      await navigator.clipboard.writeText(msg)
      alert('Lien copié dans le presse-papier !')
    }
  }

  const validateCode = async () => {
    if (!validatingCode.trim()) return
    try {
      const res = await fetch(API_ENDPOINTS.referralValidate, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: validatingCode.trim().toUpperCase() }),
      })
      const json = await res.json()
      setValidateResult({ valid: json.valid, message: json.message || (json.valid ? 'Code valide' : 'Code invalide') })
    } catch {
      setValidateResult({ valid: false, message: 'Erreur de vérification.' })
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black" />
      </div>
    )
  }

  if (error || !data) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <AlertCircle className="mx-auto mb-2 text-red-500" size={32} />
        <p className="text-red-700">{error || 'Erreur inconnue'}</p>
      </div>
    )
  }

  const progressPct = Math.min((data.referral_count / MAX_REFERRALS) * 100, 100)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black uppercase tracking-tight text-gray-900">Parrainage</h1>
        <p className="text-sm text-gray-500 mt-1">Invitez vos amies et gagnez des crédits</p>
      </div>

      {/* Code card */}
      <div className="bg-black text-white rounded-xl p-6">
        {data.is_ambassador && (
          <div className="flex items-center gap-2 mb-3 bg-yellow-400 text-black px-3 py-1.5 rounded-full w-fit text-xs font-bold uppercase">
            <Star size={14} />
            Ambassadrice KikiJones
          </div>
        )}
        <p className="text-sm text-gray-400 mb-1">Votre code parrainage</p>
        <div className="flex items-center gap-3 mb-4">
          <span className="text-4xl font-black tracking-widest">{data.code}</span>
        </div>
        <div className="flex gap-3">
          <button
            onClick={copyCode}
            className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-100 transition-colors"
          >
            {codeCopied ? <CheckCircle size={16} className="text-green-600" /> : <Copy size={16} />}
            {codeCopied ? 'Copié !' : 'Copier'}
          </button>
          <button
            onClick={share}
            className="flex items-center gap-2 bg-white/10 text-white border border-white/20 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-white/20 transition-colors"
          >
            <Share2 size={16} />
            Partager
          </button>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-gray-100 p-4 text-center shadow-sm">
          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <Users size={20} className="text-purple-600" />
          </div>
          <p className="text-2xl font-black text-gray-900">{data.referral_count}</p>
          <p className="text-xs text-gray-500 mt-1">Amies parrainées</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 text-center shadow-sm">
          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <Gift size={20} className="text-green-600" />
          </div>
          <p className="text-2xl font-black text-gray-900">{(data.available_credit?.amount ?? 0).toLocaleString()}</p>
          <p className="text-xs text-gray-500 mt-1">Crédit FCFA dispo</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 text-center shadow-sm">
          <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
            <Star size={20} className="text-yellow-600" />
          </div>
          <p className="text-2xl font-black text-gray-900">{(data.total_earned ?? 0).toLocaleString()}</p>
          <p className="text-xs text-gray-500 mt-1">Total gagné FCFA</p>
        </div>
      </div>

      {/* Credit expiry */}
      {data.available_credit && (
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 flex items-center gap-3">
          <Clock size={20} className="text-orange-500 flex-shrink-0" />
          <p className="text-sm text-orange-800">
            Votre crédit expire dans <strong>{data.available_credit.days_remaining} jour{data.available_credit.days_remaining > 1 ? 's' : ''}</strong> — utilisez-le avant qu'il disparaisse !
          </p>
        </div>
      )}

      {/* Ambassador progress */}
      {!data.is_ambassador && (
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold text-gray-700">Progression Ambassadrice</p>
            <p className="text-sm text-gray-500">{data.referral_count} / {MAX_REFERRALS}</p>
          </div>
          <div className="w-full bg-gray-100 rounded-full h-2.5 mb-2">
            <div
              className="bg-yellow-400 h-2.5 rounded-full transition-all"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <p className="text-xs text-gray-500">
            Encore <strong>{MAX_REFERRALS - data.referral_count}</strong> parrainage{MAX_REFERRALS - data.referral_count > 1 ? 's' : ''} pour devenir Ambassadrice
          </p>
        </div>
      )}

      {/* How it works */}
      <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
        <h2 className="text-sm font-bold uppercase tracking-wide text-gray-900 mb-4">Comment ça marche</h2>
        <div className="space-y-4">
          {[
            { n: '1', text: 'Partagez votre code unique avec vos amies' },
            { n: '2', text: `Elles s'inscrivent avec votre code → vous recevez toutes les deux ${CREDIT_AMOUNT} FCFA en attente` },
            { n: '3', text: 'Dès leur première commande validée, les crédits sont activés (30 jours de validité)' },
          ].map((step) => (
            <div key={step.n} className="flex items-start gap-3">
              <div className="w-7 h-7 bg-black text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                {step.n}
              </div>
              <p className="text-sm text-gray-600 pt-0.5">{step.text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Validate a code (check someone else's code) */}
      <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
        <h2 className="text-sm font-bold uppercase tracking-wide text-gray-900 mb-3">Vérifier un code parrainage</h2>
        <div className="flex gap-2">
          <input
            type="text"
            value={validatingCode}
            onChange={(e) => { setValidatingCode(e.target.value.toUpperCase()); setValidateResult(null) }}
            placeholder="Ex: KJ-ABC123"
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-black focus:border-black uppercase"
          />
          <button
            onClick={validateCode}
            className="px-4 py-2 bg-black text-white rounded-lg text-sm font-semibold hover:bg-gray-800 transition-colors"
          >
            Vérifier
          </button>
        </div>
        {validateResult && (
          <p className={`mt-2 text-sm flex items-center gap-1.5 ${validateResult.valid ? 'text-green-700' : 'text-red-600'}`}>
            {validateResult.valid ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
            {validateResult.message}
          </p>
        )}
      </div>

      {/* Referrals list */}
      {data.referrals.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100">
            <h2 className="text-sm font-bold uppercase tracking-wide text-gray-900">Mes Amies Parrainées</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {data.referrals.map((f) => (
              <div key={f.id} className="flex items-center justify-between px-5 py-3">
                <div>
                  <p className="text-sm font-medium text-gray-900">{f.referee_name}</p>
                  <p className="text-xs text-gray-400">Inscrite le {formatDate(f.created_at)}</p>
                  {f.validated_at && (
                    <p className="text-xs text-gray-400">Validée le {formatDate(f.validated_at)}</p>
                  )}
                </div>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${STATUS_BADGE[f.status]}`}>
                  {STATUS_LABEL[f.status]}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Credits list */}
      {credits.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100">
            <h2 className="text-sm font-bold uppercase tracking-wide text-gray-900">Mes Crédits</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {credits.map((c) => (
              <div key={c.id} className="flex items-center justify-between px-5 py-3">
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {c.credit_type === 'referrer' ? '🎁 Parrainage envoyé' : '🎉 Code utilisé'}
                    {' — '}
                    <span className="font-bold">{(c.amount ?? 0).toLocaleString()} FCFA</span>
                  </p>
                  {c.expires_at && (
                    <p className="text-xs text-gray-400">Expire le {formatDate(c.expires_at)}</p>
                  )}
                  {c.activated_at && (
                    <p className="text-xs text-gray-400">Activé le {formatDate(c.activated_at)}</p>
                  )}
                </div>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${CREDIT_STATUS_BADGE[c.status]}`}>
                  {CREDIT_STATUS_LABEL[c.status]}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
