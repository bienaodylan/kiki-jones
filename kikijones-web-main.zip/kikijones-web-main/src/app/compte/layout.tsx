'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { LayoutDashboard, Package, Heart, MapPin, Settings, MessageSquare, LogOut, ChevronRight, Bell, Search, Gift, Star, Users } from 'lucide-react'
import { getProfile, getAuthToken, removeAuthToken, User } from '@/lib/api/auth'
import { API_ENDPOINTS, fetchAPI } from '@/lib/api/config'
import { getAccessToken, bootstrapAuth } from '@/lib/auth-store'

const menuItems = [
  { href: '/compte', label: 'Tableau de bord', icon: LayoutDashboard, exact: true },
  { href: '/compte/commandes', label: 'Mes Commandes', icon: Package },
  { href: '/track-order', label: 'Suivre une commande', icon: Search, external: true },
  { href: '/notifications', label: 'Notifications', icon: Bell, external: true },
  { href: '/compte/messages', label: 'Messages', icon: MessageSquare },
  { href: '/compte/favoris', label: 'Mes Favoris', icon: Heart },
  { href: '/compte/adresses', label: 'Mes Adresses', icon: MapPin },
  { href: '/recompenses', label: 'Récompenses', icon: Gift, external: true },  { href: '/compte/parrainage', label: 'Parrainage', icon: Users },  { href: '/roue-chance', label: 'Roue de la Chance', icon: Star, external: true },
  { href: '/compte/parametres', label: 'Paramètres', icon: Settings },
]

export default function CompteLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    // Bootstrap access token from httpOnly cookie, then check auth
    bootstrapAuth().then((token) => {
      if (!token) {
        router.push('/login')
        return
      }
      getProfile(token)
        .then((data) => {
          setUser(data)
          setLoading(false)
        })
        .catch(() => {
          removeAuthToken()
          router.push('/login')
        })
    })
  }, [router])

  const handleLogout = async () => {
    await removeAuthToken()
    router.push('/')
  }

  // Get current page label for mobile breadcrumb
  const currentPage = menuItems.find(item =>
    item.exact ? pathname === item.href : pathname.startsWith(item.href)
  )

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  return (
    <main className="max-w-[1440px] mx-auto px-4 sm:px-6 pb-24 min-h-screen bg-white text-black">
      {/* Page header (theme): eyebrow + title + sign out */}
      <div className="pt-6 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="min-w-0">
          <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-black/55 truncate">{user?.first_name || user?.email}</p>
          <h1 className="text-2xl sm:text-4xl font-bold tracking-[-0.025em] text-black mt-1">Mon compte</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button onClick={handleLogout} className="px-4 py-2.5 bg-[#F7F7F7] text-xs font-bold uppercase tracking-[0.14em] inline-flex items-center gap-2 hover:bg-black hover:text-white transition-colors">
            <LogOut className="w-3.5 h-3.5" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      {/* Horizontal tabs */}
      <nav className="flex flex-wrap gap-x-5 sm:gap-x-8 gap-y-1 mt-2 border-b border-black/10 pb-2">
        {menuItems.map((item) => {
          const active = item.exact ? pathname === item.href : pathname.startsWith(item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`py-2 text-xs font-bold uppercase tracking-[0.16em] whitespace-nowrap shrink-0 ${active ? 'text-black border-b-2 border-black' : 'text-black/55 hover:text-black border-b-2 border-transparent'}`}
            >
              {item.label}
            </Link>
          )
        })}
      </nav>

      <div className="pt-8">{children}</div>
    </main>
  )
}
