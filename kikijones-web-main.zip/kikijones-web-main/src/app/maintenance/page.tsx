export default function MaintenancePage() {
  return (
    <html lang="fr">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>KikiJones - Maintenance</title>
        <style>{`
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0a0a0a;
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .container {
            text-align: center;
            padding: 40px 24px;
            max-width: 520px;
          }
          .logo {
            font-size: 32px;
            font-weight: 900;
            letter-spacing: 6px;
            text-transform: uppercase;
            margin-bottom: 40px;
          }
          .icon {
            font-size: 64px;
            margin-bottom: 24px;
          }
          h1 {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 16px;
            letter-spacing: 1px;
          }
          p {
            font-size: 16px;
            color: #999;
            line-height: 1.6;
            margin-bottom: 12px;
          }
          .highlight {
            color: #e94560;
            font-weight: 600;
          }
          .divider {
            width: 60px;
            height: 3px;
            background: #e94560;
            margin: 32px auto;
            border-radius: 2px;
          }
          .socials {
            display: flex;
            gap: 24px;
            justify-content: center;
            margin-top: 32px;
          }
          .socials a {
            color: #666;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.2s;
          }
          .socials a:hover { color: #e94560; }
          .pulse {
            display: inline-block;
            width: 10px;
            height: 10px;
            background: #e94560;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
          }
          @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(1.3); }
          }
          .status {
            display: inline-flex;
            align-items: center;
            font-size: 13px;
            color: #666;
            margin-top: 24px;
          }
        `}</style>
      </head>
      <body>
        <div className="container">
          <div className="logo">KIKIJONES</div>
          <div className="icon">🚧</div>
          <h1>Site en maintenance</h1>
          <p>
            Nous travaillons actuellement sur des améliorations pour vous offrir 
            une <span className="highlight">meilleure expérience shopping</span>.
          </p>
          <p>Nous serons de retour très bientôt !</p>
          <div className="divider" />
          <div className="status">
            <span className="pulse" />
            Maintenance en cours...
          </div>
        </div>
      </body>
    </html>
  )
}
