'use client'

import { useEffect, useState } from 'react'

export default function PrivacyChoicesPage() {
  const [preferences, setPreferences] = useState({
    necessary: true,
    analytics: false,
    marketing: false,
    personalization: false
  })

  useEffect(() => {
    // Charger les préférences depuis localStorage
    const saved = localStorage.getItem('cookiePreferences')
    if (saved) {
      try {
        setPreferences(JSON.parse(saved))
      } catch {}
    }
  }, [])

  const handleSave = () => {
    localStorage.setItem('cookiePreferences', JSON.stringify(preferences))
    window.dispatchEvent(new Event('cookie-consent-change'))
    alert('Vos préférences ont été enregistrées avec succès!')
  }

  const handleAcceptAll = () => {
    const all = {
      necessary: true,
      analytics: true,
      marketing: true,
      personalization: true
    }
    setPreferences(all)
    localStorage.setItem('cookiePreferences', JSON.stringify(all))
    window.dispatchEvent(new Event('cookie-consent-change'))
    alert('Tous les cookies ont été acceptés!')
  }

  const handleRejectAll = () => {
    const minimal = {
      necessary: true,
      analytics: false,
      marketing: false,
      personalization: false
    }
    setPreferences(minimal)
    localStorage.setItem('cookiePreferences', JSON.stringify(minimal))
    window.dispatchEvent(new Event('cookie-consent-change'))
    alert('Seuls les cookies nécessaires sont activés!')
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-4xl">
          <nav className="text-xs uppercase tracking-wider mb-8 flex items-center gap-2 text-gray-500">
            <a href="/" className="hover:text-black transition-colors">Accueil</a>
            <span>/</span>
            <span className="text-black">Vos Choix de Confidentialité</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-light text-gray-900 tracking-tight">
            Vos Choix de Confidentialité
          </h1>
        </div>
      </div>

      {/* Content Section */}
      <div className="container mx-auto px-4 py-12 md:py-20 max-w-4xl">
        <div className="static-content">
          <p className="text-lg mb-8">
            Gérez vos préférences concernant l'utilisation de cookies et autres technologies de suivi sur kikijones.com
          </p>

          {/* Cookie Categories */}
          <div className="space-y-6">
            {/* Necessary Cookies */}
            <div className="border-l-2 border-black bg-gray-50 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                    Cookies Nécessaires
                    <span className="text-xs bg-black text-white px-2 py-1 rounded">Toujours actifs</span>
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Ces cookies sont essentiels au fonctionnement du site. Ils permettent l'utilisation des fonctionnalités de base comme la sécurité, la gestion du panier et l'accès à votre compte.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.necessary}
                  disabled
                  className="mt-1 w-5 h-5"
                />
              </div>
              <p className="text-xs text-gray-500">
                Exemples : Session, Authentification, Panier d'achat, Préférences de langue
              </p>
            </div>

            {/* Analytics Cookies */}
            <div className="border-l-2 border-gray-300 bg-gray-50 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">Cookies Analytiques</h3>
                  <p className="text-gray-600 text-sm">
                    Ces cookies nous aident à comprendre comment les visiteurs interagissent avec notre site en collectant et rapportant des informations de manière anonyme.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preferences.analytics}
                    onChange={(e) => setPreferences({...preferences, analytics: e.target.checked})}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-xs text-gray-500">
                Service utilisé : PostHog (analyse d'audience anonymisée)
              </p>
            </div>

            {/* Marketing Cookies */}
            <div className="border-l-2 border-gray-300 bg-gray-50 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">Cookies Marketing</h3>
                  <p className="text-gray-600 text-sm">
                    Ces cookies sont utilisés pour afficher des publicités pertinentes pour vous et vos intérêts. Ils servent aussi à limiter le nombre de fois où vous voyez une publicité.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preferences.marketing}
                    onChange={(e) => setPreferences({...preferences, marketing: e.target.checked})}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-xs text-gray-500">
                Aucun pixel publicitaire n'est actuellement utilisé sur ce site.
              </p>
            </div>

            {/* Personalization Cookies */}
            <div className="border-l-2 border-gray-300 bg-gray-50 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">Cookies de Personnalisation</h3>
                  <p className="text-gray-600 text-sm">
                    Ces cookies permettent au site de se souvenir de vos choix (comme votre nom d'utilisateur, langue ou région) et de fournir des fonctionnalités améliorées et plus personnelles.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preferences.personalization}
                    onChange={(e) => setPreferences({...preferences, personalization: e.target.checked})}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-black"></div>
                </label>
              </div>
              <p className="text-xs text-gray-500">
                Exemples : Recommandations de produits, Historique de navigation, Wishlist
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-12 flex flex-col sm:flex-row gap-4">
            <button
              onClick={handleSave}
              className="flex-1 bg-black text-white px-8 py-4 text-sm font-bold uppercase tracking-wider hover:bg-gray-900 transition-colors"
            >
              Enregistrer mes choix
            </button>
            <button
              onClick={handleAcceptAll}
              className="flex-1 bg-white border-2 border-black text-black px-8 py-4 text-sm font-bold uppercase tracking-wider hover:bg-gray-50 transition-colors"
            >
              Tout accepter
            </button>
            <button
              onClick={handleRejectAll}
              className="flex-1 bg-white border-2 border-gray-300 text-gray-700 px-8 py-4 text-sm font-bold uppercase tracking-wider hover:bg-gray-50 transition-colors"
            >
              Tout refuser
            </button>
          </div>

          {/* Additional Information */}
          <div className="mt-12 pt-8 border-t border-gray-200">
            <h2 className="text-2xl font-light mb-4">En savoir plus</h2>
            <p className="text-gray-600 mb-4">
              Pour plus d'informations sur notre utilisation des cookies et de vos données personnelles, consultez notre <a href="/privacy" className="text-black underline">Politique de Confidentialité</a>.
            </p>
            <p className="text-gray-600 mb-4">
              Vous pouvez modifier vos préférences à tout moment en revenant sur cette page ou en cliquant sur "Vos choix de confidentialité" dans le footer de notre site.
            </p>
            <p className="text-sm text-gray-500">
              <strong>Note:</strong> La désactivation de certains cookies peut affecter votre expérience sur le site et limiter certaines fonctionnalités.
            </p>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .static-content {
          color: #1f2937;
          line-height: 1.8;
          font-size: 16px;
        }
        .static-content h2 {
          font-size: 2rem;
          font-weight: 300;
          color: #111827;
          margin-top: 3rem;
          margin-bottom: 1.5rem;
          padding-bottom: 0.75rem;
          border-bottom: 1px solid #e5e7eb;
        }
        .static-content p {
          margin-bottom: 1.5rem;
          color: #4b5563;
        }
        .static-content a {
          color: #000;
          text-decoration: underline;
        }
      `}</style>
    </div>
  )
}
