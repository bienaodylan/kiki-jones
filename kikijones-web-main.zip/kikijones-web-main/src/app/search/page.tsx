'use client'

import { Suspense, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Search, X } from 'lucide-react'
import { getProducts, Product } from '@/lib/api'
import ProductCard from '@/components/products/ProductCard'
import { mapThemeHref } from '@/lib/themeRoutes'

const TRENDING = ['Kiki Men', 'Kiki Luxe', 'Kiki Sport', 'Kiki Curve', 'Robes', 'Combinaison', 'Cyclistes', 'Chaussures', 'Lunettes', 'Jeans Stacked']
const SUGGESTED = [
  { label: 'Acheter par Marque', href: '/brands', hint: 'Men, Luxe, Curve, Sculpt, Sport, Kids' },
  { label: 'Acheter par Catégorie', href: '/categories', hint: 'Robes, Ensembles, Combinaisons, Chaussures' },
  { label: 'Soirée & Cérémonie', href: '/collection/formal', hint: 'Robes de Gala, Tailleurs & Talons' },
  { label: 'Kiki Sport', href: '/brand/kiki-sport', hint: 'Cyclistes & Activewear Respirant' },
  { label: 'Chaussures', href: '/category/shoes', hint: 'Talons, Mocassins & Baskets' },
  { label: 'Lunettes de soleil', href: '/category/sunglasses', hint: 'Acétate Sombre & Optique' },
]

function SearchInner() {
  const router = useRouter()
  const params = useSearchParams()
  const q = (params.get('q') || '').trim()
  const [value, setValue] = useState(q)
  const [results, setResults] = useState<Product[]>([])
  const [loading, setLoading] = useState(false)
  const [sort, setSort] = useState('recommended')
  const [recent, setRecent] = useState<string[]>([])

  useEffect(() => { try { setRecent(JSON.parse(localStorage.getItem('kj_recent_searches') || '[]')) } catch {} }, [])
  useEffect(() => { setValue(q) }, [q])
  useEffect(() => {
    if (!q) { setResults([]); return }
    setLoading(true)
    getProducts({ search: q, page_size: 48, ordering: sort === 'price-asc' ? 'base_price' : sort === 'price-desc' ? '-base_price' : undefined })
      .then((r) => setResults(r.results))
      .catch(() => setResults([]))
      .finally(() => setLoading(false))
    try {
      const next = [q, ...recent.filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 6)
      localStorage.setItem('kj_recent_searches', JSON.stringify(next))
      setRecent(next)
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, sort])

  const submit = (term: string) => { const t = term.trim(); if (t) router.push(`/search?q=${encodeURIComponent(t)}`) }

  return (
    <main className="pb-10 w-full max-w-[1440px] mx-auto px-4 sm:px-6 overflow-x-clip min-h-screen bg-white text-black">
      <div className="pt-4 pb-5 border-b border-black/10 space-y-3.5">
        <p className="text-[10.5px] font-bold uppercase tracking-[0.22em] text-black/45">Rechercher sur KIKI JONES</p>
        <form onSubmit={(e) => { e.preventDefault(); submit(value) }} className="flex items-center gap-3 border-b border-black/30 focus-within:border-black pb-2">
          <Search className="w-[18px] h-[18px] text-black/65 shrink-0" strokeWidth={1.7} />
          <input
            autoFocus
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Robes, Kiki Men, cyclistes, chaussures…"
            aria-label="Recherche"
            className="flex-1 bg-transparent font-light text-black placeholder:text-black/40 focus:outline-none text-lg sm:text-2xl"
          />
          {value && <button type="button" onClick={() => { setValue(''); router.push('/search') }} aria-label="Effacer" className="min-h-[36px] min-w-[36px] flex items-center justify-center text-black/50 hover:text-black"><X className="w-4 h-4" /></button>}
        </form>
        {q && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs">
            <span className="text-black/50 tabular-nums">{results.length} {results.length <= 1 ? 'résultat' : 'résultats'}</span>
            <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Trier les résultats" className="bg-[#F5F5F5] px-3 py-2 text-[11px] font-bold uppercase tracking-[0.12em] focus:outline-none">
              <option value="recommended">Recommandés</option>
              <option value="price-asc">Prix croissant</option>
              <option value="price-desc">Prix décroissant</option>
            </select>
          </div>
        )}
      </div>

      {!q ? (
        <div className="py-12 grid grid-cols-1 md:grid-cols-3 gap-10">
          <div className="space-y-4">
            <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black">Recherches tendances</h2>
            <div className="flex flex-wrap gap-2">
              {TRENDING.map((t) => <button key={t} onClick={() => submit(t)} className="px-4 py-2 border border-black/15 text-xs font-light hover:border-black hover:bg-black hover:text-white transition-colors">{t}</button>)}
            </div>
          </div>
          <div className="space-y-4">
            <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black">Recherches récentes</h2>
            {recent.length === 0 ? <p className="text-xs font-light text-black/50">Aucune recherche récente.</p> : (
              <ul className="space-y-2">{recent.map((r) => <li key={r}><button onClick={() => submit(r)} className="text-sm font-light text-black/80 hover:text-black hover:underline underline-offset-4">{r}</button></li>)}</ul>
            )}
          </div>
          <div className="space-y-4">
            <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black">Parcourir les catégories</h2>
            <ul className="space-y-2.5">
              {SUGGESTED.map((s) => (
                <li key={s.label}>
                  <Link href={mapThemeHref(s.href)} className="text-sm font-light text-black/80 hover:text-black hover:underline underline-offset-4">{s.label}</Link>
                  <p className="text-[11px] font-light text-black/45">{s.hint}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : loading ? (
        <div className="pt-4 grid grid-cols-2 md:grid-cols-4 gap-1.5 sm:gap-2">{Array.from({ length: 8 }).map((_, i) => <div key={i} className="aspect-[4/5] bg-[#F5F5F5] animate-pulse" />)}</div>
      ) : results.length === 0 ? (
        <div className="py-16 text-center space-y-5">
          <h2 className="text-3xl font-bold tracking-[-0.025em] text-black">Aucun résultat pour « {q} »</h2>
          <p className="text-sm font-light text-black/65 max-w-md mx-auto">Vérifiez l’orthographe ou essayez un terme plus général comme « robe », « ensemble » ou « chaussures ».</p>
          <div className="flex flex-wrap justify-center gap-2 pt-2">
            {TRENDING.slice(0, 5).map((t) => <button key={t} onClick={() => submit(t)} className="min-h-[40px] px-4 py-2 border border-black/15 text-xs font-light hover:border-black">{t}</button>)}
          </div>
        </div>
      ) : (
        <div className="pt-4 grid grid-cols-2 md:grid-cols-4 gap-x-1.5 gap-y-4 sm:gap-x-2 sm:gap-y-5 items-stretch">
          {results.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </main>
  )
}

export default function SearchPage() {
  return <Suspense fallback={null}><SearchInner /></Suspense>
}
