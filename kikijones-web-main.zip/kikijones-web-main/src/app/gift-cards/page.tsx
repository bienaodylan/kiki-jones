'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Gift, ArrowLeft, Check, User, Mail, MessageSquare } from 'lucide-react'
import { API_ENDPOINTS, fetchAPI } from '@/lib/api/config'
import { useCurrency } from '@/contexts/CurrencyContext'

const AMOUNT_COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD']

export default function GiftCardsPage() {
  const { formatPrice } = useCurrency()
  const [amounts, setAmounts] = useState<number[]>([])
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null)
  const [recipientName, setRecipientName] = useState('')
  const [recipientEmail, setRecipientEmail] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [amountsLoading, setAmountsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch(API_ENDPOINTS.giftcardAmounts)
      .then(r => r.json())
      .then(data => {
        setAmounts(data.amounts || data || [])
        setAmountsLoading(false)
      })
      .catch(() => {
        setAmounts([5000, 10000, 15000, 20000, 25000, 50000])
        setAmountsLoading(false)
      })
  }, [])

  const handlePurchase = async () => {
    if (!selectedAmount) return
    setLoading(true)
    setError('')

    try {
      const data = await fetchAPI<any>(API_ENDPOINTS.giftcardPurchase, {
        method: 'POST',
        body: JSON.stringify({
          amount: selectedAmount,
          recipient_name: recipientName.trim() || undefined,
          recipient_email: recipientEmail.trim() || undefined,
          message: message.trim() || undefined,
        }),
      })

      if (data.payment_url) {
        window.location.href = data.payment_url
      } else {
        setError('URL de paiement non reçue. Veuillez réessayer.')
      }
    } catch (err: any) {
      if (err?.status === 401) {
        setError('Vous devez être connecté pour acheter une carte cadeau.')
      } else {
        setError(err?.body?.error || err?.message || 'Erreur lors de l\'achat. Veuillez réessayer.')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <div className="bg-black text-white">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-4xl text-center">
          <nav className="text-xs uppercase tracking-wider mb-8 flex items-center justify-center gap-2 text-gray-400">
            <Link href="/" className="hover:text-white transition-colors">Accueil</Link>
            <span>/</span>
            <span className="text-white">Cartes Cadeaux</span>
          </nav>
          <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-6">
            <Gift size={40} className="text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-light tracking-tight mb-4">Offrez du bonheur</h1>
          <p className="text-gray-400 max-w-lg mx-auto">
            Choisissez un montant et offrez une carte cadeau KikiJones à vos proches.
            Paiement sécurisé via Paystack.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
            {error}
            <button onClick={() => setError('')} className="float-right font-bold">&times;</button>
          </div>
        )}

        {/* Amount Selection */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <h2 className="text-xl font-medium mb-6 flex items-center gap-2">
            <span className="text-2xl">💰</span> Choisir un montant
          </h2>

          {amountsLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-black"></div>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {amounts.map((amount, idx) => (
                <button
                  key={amount}
                  onClick={() => setSelectedAmount(amount)}
                  className={`relative p-6 rounded-xl border-2 transition-all duration-200 text-center hover:shadow-md ${
                    selectedAmount === amount
                      ? 'border-black bg-gray-50 shadow-md'
                      : 'border-gray-200 hover:border-gray-400'
                  }`}
                >
                  {selectedAmount === amount && (
                    <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-black flex items-center justify-center">
                      <Check size={14} className="text-white" />
                    </div>
                  )}
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3"
                    style={{ backgroundColor: AMOUNT_COLORS[idx % AMOUNT_COLORS.length] + '20' }}
                  >
                    <Gift size={22} style={{ color: AMOUNT_COLORS[idx % AMOUNT_COLORS.length] }} />
                  </div>
                  <div className="text-xl font-bold">{formatPrice(amount)}</div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Recipient */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <h2 className="text-xl font-medium mb-2 flex items-center gap-2">
            <span className="text-2xl">🎁</span> Destinataire (optionnel)
          </h2>
          <p className="text-sm text-gray-500 mb-6">Laissez vide pour garder la carte pour vous</p>

          <div className="space-y-4">
            <div className="flex items-center gap-3 border border-gray-200 rounded-lg px-4">
              <User size={18} className="text-gray-400 flex-shrink-0" />
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="Nom du destinataire"
                className="w-full py-3 focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-3 border border-gray-200 rounded-lg px-4">
              <Mail size={18} className="text-gray-400 flex-shrink-0" />
              <input
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="Email du destinataire"
                className="w-full py-3 focus:outline-none"
              />
            </div>
            <div className="flex items-start gap-3 border border-gray-200 rounded-lg px-4">
              <MessageSquare size={18} className="text-gray-400 flex-shrink-0 mt-3" />
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Message personnel (optionnel)"
                rows={3}
                className="w-full py-3 focus:outline-none resize-none"
              />
            </div>
          </div>
        </div>

        {/* Summary + CTA */}
        {selectedAmount && (
          <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
            <h2 className="text-xl font-medium mb-4 flex items-center gap-2">
              <span className="text-2xl">🧾</span> Résumé
            </h2>
            <div className="flex justify-between py-2 text-gray-600">
              <span>Carte cadeau</span>
              <span className="font-medium text-black">{formatPrice(selectedAmount)}</span>
            </div>
            {recipientName && (
              <div className="flex justify-between py-2 text-gray-600">
                <span>Pour</span>
                <span className="font-medium text-black">{recipientName}</span>
              </div>
            )}
            <div className="border-t border-gray-200 mt-2 pt-3 flex justify-between text-lg">
              <span className="font-bold">Total à payer</span>
              <span className="font-bold">{formatPrice(selectedAmount)}</span>
            </div>
          </div>
        )}

        <button
          onClick={handlePurchase}
          disabled={!selectedAmount || loading}
          className={`w-full py-4 rounded-lg text-white font-medium text-lg flex items-center justify-center gap-3 transition-all ${
            selectedAmount && !loading
              ? 'bg-black hover:bg-gray-800 cursor-pointer'
              : 'bg-gray-300 cursor-not-allowed'
          }`}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
          ) : (
            <>
              <Gift size={22} />
              {selectedAmount ? `Acheter • ${formatPrice(selectedAmount)}` : 'Sélectionnez un montant'}
            </>
          )}
        </button>

        {/* How it works */}
        <div className="bg-white rounded-xl shadow-sm p-8 mt-12">
          <h2 className="text-xl font-medium mb-6 flex items-center gap-2">
            <span className="text-2xl">ℹ️</span> Comment ça marche ?
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { step: 1, text: 'Choisissez un montant et payez via Paystack' },
              { step: 2, text: 'Recevez votre code carte : KIKI-XXXX-XXXX-XXXX' },
              { step: 3, text: 'Utilisez le code lors du paiement de vos commandes' },
              { step: 4, text: 'Le solde restant est conservé pour vos prochains achats' },
            ].map(({ step, text }) => (
              <div key={step} className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">
                  {step}
                </div>
                <p className="text-gray-600 pt-1">{text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Link to check balance */}
        <div className="text-center mt-8 mb-12">
          <Link
            href="/gift-card-balance"
            className="text-gray-600 hover:text-black underline underline-offset-4 transition-colors"
          >
            Vous avez déjà une carte cadeau ? Vérifier le solde →
          </Link>
        </div>
      </div>
    </div>
  )
}
