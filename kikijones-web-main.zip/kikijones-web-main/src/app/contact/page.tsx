import { Metadata } from 'next'
import StaticPageLayout from '@/components/StaticPageLayout'

export const metadata: Metadata = {
  title: 'Contact | KikiJones',
  description: 'Contactez l\'équipe KikiJones. Service client disponible pour toutes vos questions sur vos commandes, livraisons et retours.',
  openGraph: {
    title: 'Contact | KikiJones',
    description: 'Contactez-nous pour toute question sur vos commandes et livraisons.',
    type: 'website',
  },
}

export default function ContactPage() {
  return <StaticPageLayout slug="contact" />
}
