'use client'

import { useEffect } from 'react'

export default function RouteError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    const msg = String(error?.message || '')
    try {
      if (/ChunkLoadError|Loading chunk|Failed to fetch dynamically imported/i.test(msg) && !sessionStorage.getItem('kj_reloaded_after_update')) {
        sessionStorage.setItem('kj_reloaded_after_update', '1')
        window.location.reload()
      }
    } catch {}
  }, [error])

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full text-center">
        <h1 className="text-6xl font-black text-gray-200 mb-4">Oups</h1>
        <h2 className="text-2xl font-black uppercase tracking-tight text-gray-900 mb-4">
          Petit contretemps
        </h2>
        <p className="text-gray-600 mb-8">
          Cette page n&apos;a pas pu se charger, souvent à cause d&apos;une mise à jour en cours. Réessayez dans un instant.
        </p>
        <div className="flex gap-4 justify-center flex-wrap">
          <button
            onClick={() => reset()}
            className="px-6 py-3 bg-black text-white rounded hover:bg-gray-800 transition-colors font-medium"
          >
            Réessayer
          </button>
          <a
            href="/"
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors font-medium"
          >
            Retour à l&apos;accueil
          </a>
        </div>
      </div>
    </div>
  )
}
