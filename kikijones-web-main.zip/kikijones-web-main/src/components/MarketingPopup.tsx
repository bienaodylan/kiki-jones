'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { X, Sparkles } from 'lucide-react';
import WheelArt from '@/components/WheelArt';
import { API_ENDPOINTS } from '@/lib/api/config';

interface Popup {
  id: string;
  title: string;
  subtitle?: string;
  description: string;
  image?: string;
  image_url?: string;
  cta_text: string;
  cta_link: string;
  cta_style: 'primary' | 'secondary' | 'accent';
  popup_size: 'small' | 'medium' | 'large';
  popup_position: 'center' | 'bottom' | 'corner';
  delay_seconds: number;
  show_frequency: 'once' | 'session' | 'daily' | 'always';
  show_on_exit: boolean;
  background_color: string;
  text_color: string;
  overlay_opacity: number;
}

interface MarketingPopupProps {
  displayOn: 'all' | 'home' | 'products' | 'categories';
  categorySlug?: string;
}

export default function MarketingPopup({ displayOn, categorySlug }: MarketingPopupProps) {
  const [popup, setPopup] = useState<Popup | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [hasExited, setHasExited] = useState(false);

  useEffect(() => {
    fetchPopup();
  }, []);

  // Exit intent listener — separate effect with proper dependencies
  useEffect(() => {
    if (!popup?.show_on_exit || hasExited) return;

    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0) {
        setHasExited(true);
        setIsVisible(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    return () => document.removeEventListener('mouseleave', handleMouseLeave);
  }, [popup, hasExited]);

  const fetchPopup = async () => {
    try {
      const params = new URLSearchParams({ display_on: displayOn });
      if (categorySlug) params.append('category', categorySlug);

      const response = await fetch(`${API_ENDPOINTS.popups}?${params}`);
      if (!response.ok) return;
      const data = await response.json();

      if (Array.isArray(data) && data.length > 0) {
        const popup = data[0];
        
        // Check frequency
        if (shouldShowPopup(popup)) {
          // Delay before showing
          setTimeout(() => {
            if (!popup.show_on_exit) {
              setIsVisible(true);
            }
            setPopup(popup);
            trackView(popup.id);
          }, popup.delay_seconds * 1000);
        }
      }
    } catch (error) {
      console.error('Error fetching popup:', error);
    }
  };

  const shouldShowPopup = (popup: Popup): boolean => {
    const storageKey = `popup_${popup.id}`;
    const lastShown = localStorage.getItem(storageKey);

    if (!lastShown) return true;

    const lastShownTime = parseInt(lastShown);
    const now = Date.now();

    switch (popup.show_frequency) {
      case 'once':
        return false;
      case 'session':
        return !sessionStorage.getItem(storageKey);
      case 'daily':
        const oneDayMs = 24 * 60 * 60 * 1000;
        return now - lastShownTime > oneDayMs;
      case 'always':
        return true;
      default:
        return true;
    }
  };

  const trackView = async (popupId: string) => {
    try {
      await fetch(API_ENDPOINTS.popupView(popupId), {
        method: 'POST',
      });
      
      // Update localStorage/sessionStorage
      localStorage.setItem(`popup_${popupId}`, Date.now().toString());
      sessionStorage.setItem(`popup_${popupId}`, 'shown');
    } catch (error) {
      console.error('Error tracking view:', error);
    }
  };

  const trackClick = async () => {
    if (!popup) return;
    
    try {
      await fetch(API_ENDPOINTS.popupClick(popup.id), {
        method: 'POST',
      });
    } catch (error) {
      console.error('Error tracking click:', error);
    }
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleCtaClick = () => {
    trackClick();
    // Validate URL to prevent open redirect / XSS
    try {
      const url = new URL(popup!.cta_link, window.location.origin);
      // Only allow same-origin or relative URLs
      if (url.origin === window.location.origin) {
        window.location.href = url.href;
      } else {
        // External link — open in new tab for safety
        window.open(url.href, '_blank', 'noopener,noreferrer');
      }
    } catch {
      // Invalid URL, ignore
    }
  };

  if (!popup || !isVisible) return null;

  // The wheel popup gets a dedicated premium layout (drawn wheel instead of the CMS stock picture)
  const isWheel = /roue|wheel/i.test(`${popup.title} ${popup.cta_link}`);
  if (isWheel) {
    return (
      <div
        className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
        style={{ backgroundColor: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(4px)' }}
        onClick={handleClose}
      >
        <div
          className="relative w-full max-w-[400px] grayscale rounded-[28px] overflow-hidden shadow-2xl border border-white/20 bg-black"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={handleClose}
            aria-label="Fermer"
            className="absolute top-3 right-3 z-10 p-2 rounded-none bg-white/15 hover:bg-white/25 transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
          <div className="pt-10 pb-5 bg-black">
            <WheelArt size={176} />
          </div>
          <div className="px-6 pt-4 pb-7 text-center">
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white mb-2">Jeu gratuit • 1 tour par jour</p>
            <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight mb-2">{popup.title}</h2>
            <p className="text-sm text-gray-300 leading-relaxed mb-5">{popup.description}</p>
            <button
              onClick={handleCtaClick}
              className="flex items-center justify-center gap-2 w-full py-3.5 rounded-none font-black text-sm uppercase tracking-wider bg-white text-black  hover:bg-white active:scale-[0.98] transition-all"
            >
              <Sparkles className="w-4 h-4" />
              {popup.cta_text}
            </button>
            <button onClick={handleClose} className="mt-3 text-xs text-gray-400 hover:text-white underline-offset-2 hover:underline">
              Plus tard
            </button>
          </div>
        </div>
      </div>
    );
  }

  const sizeClasses = {
    small: 'max-w-md',
    medium: 'max-w-2xl',
    large: 'max-w-4xl',
  };

  const positionClasses = {
    center: 'items-center justify-center',
    bottom: 'items-end justify-center pb-8',
    corner: 'items-end justify-end p-8',
  };

  const ctaStyleClasses = {
    primary: 'bg-black text-white hover:bg-gray-800',
    secondary: 'bg-white text-black border-2 border-black hover:bg-gray-50',
    accent: 'bg-black text-white hover:bg-black/85',
  };

  return (
    <div 
      className={`fixed inset-0 z-[9999] flex ${positionClasses[popup.popup_position]}`}
      style={{
        backgroundColor: `rgba(0, 0, 0, ${popup.overlay_opacity / 100})`,
      }}
      onClick={handleClose}
    >
      <div
        className={`${sizeClasses[popup.popup_size]} w-full mx-4 relative rounded-none shadow-2xl overflow-hidden`}
        style={{
          backgroundColor: popup.background_color,
          color: popup.text_color,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-none bg-white/90 hover:bg-white transition-colors shadow-lg"
        >
          <X className="w-5 h-5 text-black" />
        </button>

        <div className="flex flex-col md:flex-row">
          {/* Image */}
          {popup.image_url && (
            <div className="relative w-full md:w-1/2 h-64 md:h-auto">
              <Image
                src={popup.image_url}
                alt={popup.title}
                fill
                className="object-cover"
              />
            </div>
          )}

          {/* Content */}
          <div className={`flex-1 p-8 md:p-12 flex flex-col justify-center ${!popup.image_url ? 'text-center' : ''}`}>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">{popup.title}</h2>
            
            {popup.subtitle && (
              <p className="text-lg md:text-xl mb-4 opacity-80">{popup.subtitle}</p>
            )}
            
            <p className="text-base md:text-lg mb-8 leading-relaxed">
              {popup.description}
            </p>

            <button
              onClick={handleCtaClick}
              className={`${ctaStyleClasses[popup.cta_style]} px-8 py-4 rounded-none font-bold text-sm uppercase tracking-wider transition-colors ${!popup.image_url ? 'mx-auto' : ''}`}
            >
              {popup.cta_text}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
