'use client'

import { useState, useEffect } from 'react'
import { Product, getProductBySlug } from '@/lib/api'
import ProductCard from '@/components/products/ProductCard'
import { Clock } from 'lucide-react'

const STORAGE_KEY = 'kikijones_recently_viewed'
const MAX_ITEMS = 12

// Helper to get recently viewed from localStorage
export function getRecentlyViewed(): Product[] {
  if (typeof window === 'undefined') return []
  try {
    const data = localStorage.getItem(STORAGE_KEY)
    return data ? JSON.parse(data) : []
  } catch {
    return []
  }
}

// Helper to add a product to recently viewed
export function addToRecentlyViewed(product: Product) {
  if (typeof window === 'undefined') return
  try {
    const items = getRecentlyViewed()
    // Remove if already exists
    const filtered = items.filter(p => p.id !== product.id)
    // Add to front
    filtered.unshift(product)
    // Keep max items
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered.slice(0, MAX_ITEMS)))
  } catch {
    // ignore storage errors
  }
}

interface RecentlyViewedProps {
  currentProductId?: string
  maxItems?: number
}

export default function RecentlyViewed({ currentProductId, maxItems = 8 }: RecentlyViewedProps) {
  const [products, setProducts] = useState<Product[]>([])

  useEffect(() => {
    let cancelled = false
    const stored = getRecentlyViewed()
    if (stored.length === 0) return

    // The stored copies can be stale: a product may have been removed from the
    // catalog (or its price/stock changed) since it was viewed. Re-fetch each
    // one and drop those that no longer exist, so visitors never see ghosts.
    Promise.all(stored.map(p => getProductBySlug(p.slug))).then(fresh => {
      if (cancelled) return
      const valid = fresh.filter((p): p is Product => !!p && p.is_active !== false)
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(valid))
      } catch {
        // ignore storage errors
      }
      setProducts(valid.filter(p => p.id !== currentProductId).slice(0, maxItems))
    })

    return () => { cancelled = true }
  }, [currentProductId, maxItems])

  if (products.length === 0) return null

  return (
    <section className="py-12">
      <div className="container-custom">
        <div className="flex items-center gap-3 mb-6">
          <Clock size={20} className="text-gray-400" />
          <h2 className="text-xl font-bold uppercase tracking-wide">Récemment consultés</h2>
        </div>
        <div className="overflow-x-auto scrollbar-hide -mx-4 px-4">
          <div className="flex gap-4" style={{ width: 'max-content' }}>
            {products.map((product) => (
              <div key={product.id} className="w-[180px] md:w-[220px] flex-shrink-0">
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
