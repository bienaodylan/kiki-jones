'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, ChevronDown, Heart, Minus, Plus, Ruler, X } from 'lucide-react'
import { Product } from '@/lib/api'
import { useCart } from '@/contexts/CartContext'
import { useWishlist } from '@/contexts/WishlistContext'
import { useCurrency } from '@/contexts/CurrencyContext'
import ProductCard from '@/components/products/ProductCard'

const SIZE_GUIDE = {
  women: [
    { size: 'XS', chest: '78–82 cm', waist: '60–64 cm', hips: '86–90 cm' },
    { size: 'S', chest: '83–87 cm', waist: '65–69 cm', hips: '91–95 cm' },
    { size: 'M', chest: '88–93 cm', waist: '70–75 cm', hips: '96–101 cm' },
    { size: 'L', chest: '94–100 cm', waist: '76–82 cm', hips: '102–108 cm' },
    { size: 'XL', chest: '101–108 cm', waist: '83–90 cm', hips: '109–116 cm' },
  ],
  men: [
    { size: 'S', chest: '90–95 cm', waist: '75–80 cm', hips: '90–95 cm' },
    { size: 'M', chest: '96–101 cm', waist: '81–86 cm', hips: '96–101 cm' },
    { size: 'L', chest: '102–107 cm', waist: '87–92 cm', hips: '102–107 cm' },
    { size: 'XL', chest: '108–114 cm', waist: '93–99 cm', hips: '108–114 cm' },
    { size: 'XXL', chest: '115–121 cm', waist: '100–106 cm', hips: '115–121 cm' },
  ],
  youth: [
    { size: '6-8Y', chest: '62–66 cm', waist: '56–59 cm', hips: '66–71 cm' },
    { size: '8-10Y', chest: '67–72 cm', waist: '60–63 cm', hips: '72–77 cm' },
    { size: '10-12Y', chest: '73–78 cm', waist: '64–67 cm', hips: '78–83 cm' },
    { size: '12-14Y', chest: '79–84 cm', waist: '68–72 cm', hips: '84–89 cm' },
  ],
}

type V = NonNullable<Product['variants']>[number]

/** Product page: the theme's product detail page (3 columns on desktop, swipe gallery on phones). */
export default function ThemeProductPage({ product, related }: { product: Product; related: Product[] }) {
  const router = useRouter()
  const { addToCart } = useCart()
  const { isInWishlist, toggleWishlist } = useWishlist()
  const { formatPrice } = useCurrency()

  const variants = useMemo(() => (product.variants || []).filter((v) => v.size || v.color), [product.variants])
  const images = useMemo(
    () => Array.from(new Set([product.main_image, ...(product.images || []).map((i) => i.image)].filter(Boolean))) as string[],
    [product]
  )

  const [selectedColor, setSelectedColor] = useState('')
  const [selectedSize, setSelectedSize] = useState('')
  const [activeImageIdx, setActiveImageIdx] = useState(0)
  const [qty, setQty] = useState(1)
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false)
  const [sizeGuideTab, setSizeGuideTab] = useState<'women' | 'men' | 'youth'>('women')
  const [openAccordion, setOpenAccordion] = useState<'details' | 'shipping' | null>('details')
  const imageRefs = useRef<(HTMLDivElement | null)[]>([])
  const mobileGalleryRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (variants.length > 0) {
      const first = variants.find((v) => v.in_stock !== false && v.stock > 0) || variants[0]
      setSelectedColor(first.color || '')
      setSelectedSize(first.size || '')
    }
    setQty(1)
    setActiveImageIdx(0)
  }, [product.id, variants])

  useEffect(() => {
    if (images.length <= 1) return
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            const idx = e.target.getAttribute('data-img-index')
            if (idx !== null) setActiveImageIdx(Number(idx))
          }
        }
      },
      { rootMargin: '-35% 0px -45% 0px', threshold: 0.1 }
    )
    imageRefs.current.forEach((el) => el && observer.observe(el))
    return () => observer.disconnect()
  }, [product.id, images])

  const scrollToImage = (idx: number) => {
    setActiveImageIdx(idx)
    imageRefs.current[idx]?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    if (mobileGalleryRef.current) mobileGalleryRef.current.scrollTo({ left: mobileGalleryRef.current.clientWidth * idx, behavior: 'smooth' })
  }

  const colors = Array.from(new Map(variants.filter((v) => v.color).map((v) => [v.color as string, v.color_hex || '#111111'])).entries()).map(([name, hex]) => ({ name, hex }))
  const sizesForColor: V[] = variants.filter((v) => (colors.length ? v.color === selectedColor : true))
  const activeVariant = variants.find((v) => v.color === selectedColor && v.size === selectedSize) || sizesForColor[0] || variants[0]
  const available = activeVariant ? (activeVariant.in_stock === false ? 0 : Math.max(activeVariant.stock, 1)) : product.is_in_stock ? 1 : 0

  const basePrice = parseFloat(product.base_price)
  const salePrice = product.sale_price ? parseFloat(product.sale_price) : null
  const hasDiscount = salePrice !== null && salePrice < basePrice
  const unitPrice = (hasDiscount ? salePrice! : basePrice) + (Number(activeVariant?.price_adjustment) || 0)
  const maxQty: number | null = activeVariant && activeVariant.stock > 0 ? activeVariant.stock : null
  const canPurchase = product.is_in_stock && (variants.length === 0 || (activeVariant && activeVariant.in_stock !== false))
  const wishlisted = isInWishlist(product.id)
  const colorLabel = selectedColor || ''

  const handleAdd = () => {
    if (!canPurchase) return
    addToCart({
      product,
      quantity: qty,
      price: unitPrice,
      variantId: activeVariant?.id,
      selectedSize: activeVariant?.size ?? null,
      selectedColor: activeVariant?.color ?? null,
    })
  }

  const Accordion = ({ id, title, children }: { id: 'details' | 'shipping'; title: string; children: React.ReactNode }) => (
    <div>
      <button type="button" onClick={() => setOpenAccordion(openAccordion === id ? null : id)} className="w-full py-3 flex items-center justify-between text-[11px] font-bold uppercase tracking-[0.16em] text-black cursor-pointer">
        <span>{title}</span>
        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${openAccordion === id ? 'rotate-180' : ''}`} />
      </button>
      {openAccordion === id && <div className="pb-3.5 text-xs font-light text-black/70 space-y-1.5 leading-relaxed">{children}</div>}
    </div>
  )

  return (
    <main className="w-full max-w-[1440px] mx-auto overflow-x-clip px-4 sm:px-6 pb-12 bg-white text-black">
      {/* Phones: full-width swipe gallery */}
      <div className="relative lg:hidden -mx-4 sm:-mx-6 mb-4">
        <div
          ref={mobileGalleryRef}
          onScroll={(e) => {
            const el = e.currentTarget
            if (el.clientWidth > 0) {
              const idx = Math.round(el.scrollLeft / el.clientWidth)
              if (idx !== activeImageIdx) setActiveImageIdx(idx)
            }
          }}
          className="flex overflow-x-auto snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none' }}
        >
          {images.length > 0 ? (
            images.map((img, i) => (
              <div key={i} className="w-full shrink-0 snap-center aspect-[4/5] bg-[#F5F5F5] flex items-center justify-center overflow-hidden">
                <img src={img} alt={`${product.name} vue ${i + 1}`} className="w-full h-full object-cover object-top" />
              </div>
            ))
          ) : (
            <div className="w-full aspect-[4/5] bg-[#F5F5F5] flex items-center justify-center text-sm font-bold tracking-[0.22em] uppercase">KIKI JONES</div>
          )}
        </div>
        {images.length > 1 && (
          <div className="pointer-events-none absolute top-3 right-3 bg-black/70 text-white px-2.5 py-1 text-[10px] font-bold tracking-[0.14em] tabular-nums">{activeImageIdx + 1} / {images.length}</div>
        )}
        {images.length > 1 && (
          <div className="flex items-center justify-center gap-2 pt-3">
            {images.map((_, i) => (
              <button key={i} type="button" onClick={() => scrollToImage(i)} aria-label={`Voir l'image ${i + 1}`} className={`h-1 transition-all ${activeImageIdx === i ? 'w-6 bg-black' : 'w-2 bg-black/20'}`} />
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[minmax(280px,360px)_minmax(0,1fr)_minmax(280px,350px)] xl:grid-cols-[minmax(310px,390px)_minmax(0,1fr)_minmax(300px,370px)] gap-4 xl:gap-6 items-start">
        {/* LEFT: thumbnails, breadcrumb, title, price, description, accordions */}
        <div className="lg:sticky lg:top-16 lg:min-h-[calc(100vh-4rem)] lg:flex lg:flex-col lg:justify-center py-2 lg:py-4 order-1">
          <div className="flex flex-col lg:flex-row gap-4 xl:gap-5 lg:items-start w-full">
            {images.length > 0 && (
              <div className="hidden lg:flex flex-col gap-2 w-16 shrink-0">
                {images.map((img, i) => (
                  <button key={i} type="button" onClick={() => scrollToImage(i)} aria-label={`Voir la photo ${i + 1}`} className={`w-full aspect-[4/5] shrink-0 bg-[#F5F5F5] overflow-hidden transition-all ${activeImageIdx === i ? 'ring-1 ring-black opacity-100' : 'opacity-50 hover:opacity-100'}`}>
                    <img src={img} alt={`${product.name} miniature ${i + 1}`} className="w-full h-full block object-cover object-top" />
                  </button>
                ))}
              </div>
            )}
            <div className="flex-1 min-w-0 space-y-5">
              <div className="flex items-center flex-wrap gap-2 text-[11px] font-light text-black/55">
                <button type="button" onClick={() => router.push(product.category ? `/produits?category=${product.category}` : '/produits')} className="inline-flex items-center gap-1.5 font-bold text-black hover:opacity-65">
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>{product.category_name || 'Boutique'}</span>
                </button>
                <span>/</span>
                <span className="text-black/80">{product.name}</span>
              </div>
              <div className="space-y-2">
                <h1 className="text-2xl xl:text-3xl font-bold tracking-[-0.025em] text-black leading-tight">{product.name}</h1>
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 pt-0.5 tabular-nums">
                  <span className="text-lg xl:text-xl font-bold text-black whitespace-nowrap">{formatPrice(unitPrice)}</span>
                  {hasDiscount && <span className="text-sm font-light text-black/45 line-through whitespace-nowrap">{formatPrice(basePrice)}</span>}
                </div>
              </div>
              <p className="text-xs xl:text-sm font-light text-black/75 leading-relaxed">{product.description || product.short_description}</p>
              <div className="border-t border-black/10 divide-y divide-black/10 pt-1">
                <Accordion id="details" title="Composition & Entretien">
                  <p>Matière contemporaine sélectionnée pour sa respirabilité, son tombé fluide et sa tenue durable.</p>
                  <p>Lavage délicat à froid. Séchage à plat ou sur cintre.</p>
                  {activeVariant?.sku && <p className="text-[11px] text-black/45">SKU: {activeVariant.sku}</p>}
                </Accordion>
                <Accordion id="shipping" title="Livraison & Retours">
                  <p>Livraison standard offerte dès 75 000 FCFA d’achat.</p>
                  <p>Livraison express le jour même ou le lendemain disponible au paiement.</p>
                  <p>Retours et échanges de taille faciles sous 14 jours pour les pièces non portées.</p>
                </Accordion>
              </div>
            </div>
          </div>
        </div>

        {/* MIDDLE: stacked photos (desktop) */}
        <div className="hidden lg:flex lg:min-h-[calc(100vh-4rem)] flex-col justify-center gap-3 py-8 order-2">
          {images.length > 0 ? (
            images.map((img, i) => (
              <div key={i} ref={(el) => { imageRefs.current[i] = el }} data-img-index={i} className="w-full bg-[#F5F5F5] overflow-hidden flex items-center justify-center">
                <img src={img} alt={`${product.name} vue ${i + 1}`} className="w-full h-auto block" />
              </div>
            ))
          ) : (
            <div className="w-full py-32 bg-[#F5F5F5] flex items-center justify-center text-sm font-bold tracking-[0.22em] uppercase">KIKI JONES</div>
          )}
        </div>

        {/* RIGHT: colour, size, quantity, add to bag, wishlist */}
        <div className="lg:sticky lg:top-16 lg:min-h-[calc(100vh-4rem)] lg:flex lg:flex-col lg:justify-center py-2 lg:py-8 order-2 lg:order-3">
          <div className="space-y-6 w-full">
            {colors.length > 0 && (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold uppercase tracking-[0.16em] text-black/55">Couleur</span>
                  <span className="font-medium text-black">{colorLabel}</span>
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  {colors.map((c, cIdx) => {
                    const selected = c.name === colorLabel
                    return (
                      <button
                        key={c.name}
                        type="button"
                        title={c.name}
                        aria-label={c.name}
                        onClick={() => {
                          setSelectedColor(c.name)
                          const match = variants.find((v) => v.color === c.name && v.size === selectedSize)
                          if (!match) {
                            const f = variants.find((v) => v.color === c.name)
                            if (f) setSelectedSize(f.size || '')
                          }
                          const vimg = variants.find((v) => v.color === c.name)?.image
                          const at = vimg ? images.indexOf(vimg) : -1
                          if (at >= 0) scrollToImage(at)
                          else if (colors.length > 1 && images.length > cIdx) scrollToImage(cIdx)
                          setQty(1)
                        }}
                        className={`w-7 h-7 rounded-full border border-black/20 transition-all ${selected ? 'ring-2 ring-black ring-offset-2 ring-offset-white scale-105' : 'opacity-80 hover:opacity-100'}`}
                        style={{ backgroundColor: c.hex }}
                      />
                    )
                  })}
                </div>
              </div>
            )}

            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold uppercase tracking-[0.16em] text-black/55">Taille</span>
                <button type="button" onClick={() => setSizeGuideOpen(true)} className="inline-flex items-center gap-1.5 font-bold uppercase tracking-[0.12em] text-black hover:opacity-65 underline underline-offset-4">
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Guide des tailles</span>
                </button>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {sizesForColor.filter((v) => v.size).map((v) => {
                  const disabled = v.in_stock === false
                  const active = activeVariant?.id === v.id
                  return (
                    <button
                      key={v.id}
                      type="button"
                      disabled={disabled}
                      onClick={() => { setSelectedSize(v.size || ''); setQty(1) }}
                      className={`py-2.5 text-xs font-bold transition-colors ${disabled ? 'bg-black/[0.04] text-black/30 line-through cursor-not-allowed' : active ? 'bg-black text-white' : 'bg-[#F5F5F5] text-black hover:bg-black hover:text-white'}`}
                    >
                      {v.size}
                    </button>
                  )
                })}
              </div>
            </div>

            <div className="space-y-2.5 pt-1">
              <div className="flex items-stretch gap-2 min-w-0">
                <div className="flex items-center border border-black/15 px-0.5 sm:px-1 shrink-0">
                  <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Diminuer la quantité" className="w-9 sm:w-10 h-11 flex items-center justify-center hover:opacity-65"><Minus className="w-3.5 h-3.5" /></button>
                  <span className="w-7 sm:w-8 text-center text-sm font-bold tabular-nums">{qty}</span>
                  <button type="button" disabled={maxQty !== null && qty >= maxQty} onClick={() => setQty((q) => (maxQty !== null ? Math.min(maxQty, q + 1) : q + 1))} aria-label="Augmenter la quantité" className="w-9 sm:w-10 h-11 flex items-center justify-center hover:opacity-65 disabled:opacity-25 disabled:cursor-not-allowed"><Plus className="w-3.5 h-3.5" /></button>
                </div>
                <button type="button" disabled={!canPurchase} onClick={handleAdd} className="flex-1 min-w-0 py-3.5 px-3 sm:px-6 bg-black text-white text-[11px] sm:text-xs font-bold uppercase tracking-[0.14em] sm:tracking-[0.2em] hover:bg-black/85 transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
                  {canPurchase ? 'Ajouter au panier' : 'Épuisé'}
                </button>
              </div>
              {maxQty !== null && maxQty <= 3 && (
                <p className="text-[11px] uppercase tracking-[0.14em] text-black/55">{maxQty === 1 ? 'Dernière pièce disponible dans cette taille' : `Plus que ${maxQty} pièces dans cette taille`}</p>
              )}
              <button type="button" onClick={() => toggleWishlist(product)} className="w-full py-3 px-6 border border-black/20 bg-white text-black text-xs font-bold uppercase tracking-[0.18em] hover:border-black transition-colors inline-flex items-center justify-center gap-2">
                <Heart className="w-3.5 h-3.5" strokeWidth={1.7} fill={wishlisted ? '#000000' : 'none'} />
                <span>{wishlisted ? 'Dans vos favoris' : 'Ajouter aux favoris'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-8 pt-6 border-t border-black/10">
          <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-black/45 mb-0.5">Vous aimerez aussi</p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-[-0.025em] text-black mb-4">Pièces complémentaires</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-1.5 gap-y-4 sm:gap-x-2 sm:gap-y-5 items-stretch">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      {sizeGuideOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/50" onClick={() => setSizeGuideOpen(false)} />
          <div role="dialog" aria-label="Guide des tailles KIKI JONES" className="relative bg-white text-black w-full max-w-xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-black/10 pb-4">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-black/45">Guide KIKI JONES</p>
                <h2 className="text-2xl font-bold tracking-[-0.025em] text-black">Tableau des tailles</h2>
              </div>
              <button type="button" onClick={() => setSizeGuideOpen(false)} aria-label="Fermer le guide des tailles" className="p-1.5 text-black/65 hover:text-black"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex items-center gap-4 border-b border-black/10 text-xs">
              {([{ id: 'women', label: 'Femme' }, { id: 'men', label: 'Homme' }, { id: 'youth', label: 'Filles & Garçons' }] as const).map((t) => (
                <button key={t.id} type="button" onClick={() => setSizeGuideTab(t.id)} className={`pb-2.5 uppercase tracking-[0.14em] ${sizeGuideTab === t.id ? 'font-bold text-black border-b-2 border-black -mb-[1px]' : 'font-light text-black/55 hover:text-black'}`}>{t.label}</button>
              ))}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs tabular-nums">
                <thead>
                  <tr className="border-b border-black/15 text-[10px] font-bold uppercase tracking-[0.16em] text-black/55">
                    <th className="py-2.5 pr-4">Taille</th><th className="py-2.5 pr-4">Poitrine</th><th className="py-2.5 pr-4">Taille</th><th className="py-2.5">Hanches</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-black/10 font-light">
                  {SIZE_GUIDE[sizeGuideTab].map((r) => (
                    <tr key={r.size}><td className="py-3 pr-4 font-bold text-black">{r.size}</td><td className="py-3 pr-4 text-black/75">{r.chest}</td><td className="py-3 pr-4 text-black/75">{r.waist}</td><td className="py-3 text-black/75">{r.hips}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-[11px] font-light text-black/55 leading-relaxed">Les mesures correspondent aux mensurations du corps. Pour une coupe ample, choisissez votre taille habituelle ; pour une coupe plus ajustée, prenez la taille en dessous.</p>
          </div>
        </div>
      )}
    </main>
  )
}
