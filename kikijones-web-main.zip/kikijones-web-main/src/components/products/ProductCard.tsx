'use client'

import { useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { Heart } from 'lucide-react'
import { Product } from '@/lib/api'
import { useCurrency } from '@/contexts/CurrencyContext'
import { useCart } from '@/contexts/CartContext'
import { useWishlist } from '@/contexts/WishlistContext'
import { THEME_BRANDS } from '@/lib/themeBrands'

interface ProductCardProps {
  product: Product
}

/** Product card: the theme's card (4:5 frame, second photo on hover, quick-add size strip on hover, square badge, heart, uppercase name, price + swatches). */
export default function ProductCard({ product }: ProductCardProps) {
  const router = useRouter()
  const { formatPrice } = useCurrency()
  const { addToCart } = useCart()
  const { isInWishlist, toggleWishlist } = useWishlist()
  const [selectedColorHex, setSelectedColorHex] = useState<string | null>(null)

  const wishlisted = isInWishlist(product.id)
  const basePrice = parseFloat(product.base_price)
  const salePrice = product.sale_price ? parseFloat(product.sale_price) : null
  const hasDiscount = salePrice !== null && salePrice < basePrice
  const displayPrice = hasDiscount ? salePrice! : basePrice
  const brand = THEME_BRANDS.find((b) => b.slug === product.brand_slug)

  const swatches = useMemo(() => {
    const colors = (product.variants || []).filter((v) => v.color && v.color_hex).map((v) => ({ name: v.color!, hex: v.color_hex!, image: v.image || null }))
    return Array.from(new Map(colors.map((c) => [c.hex, c])).values())
  }, [product.variants])

  const primaryImage = useMemo(() => {
    if (selectedColorHex) {
      const m = swatches.find((c) => c.hex === selectedColorHex)
      if (m?.image) return m.image
    }
    return product.main_image
  }, [selectedColorHex, swatches, product.main_image])
  const secondaryImage = product.images && product.images.length > 1 ? product.images[1].image : (product.images?.[0]?.image && product.images[0].image !== product.main_image ? product.images[0].image : null)

  const sizeOptions = useMemo(
    () => (product.variants || []).filter((v) => v.size && v.in_stock !== false && (!selectedColorHex || !v.color_hex || v.color_hex === selectedColorHex)),
    [product.variants, selectedColorHex]
  )

  const soldOut = !product.is_in_stock
  const badge = soldOut
    ? { label: 'ÉPUISÉ', cls: 'bg-white/95 text-black/60 border border-black/15' }
    : hasDiscount
    ? { label: 'SOLDES', cls: 'bg-white text-black border border-black/15' }
    : product.is_new
    ? { label: 'NOUVEAU', cls: 'bg-black text-white' }
    : product.is_bestseller
    ? { label: 'BEST-SELLER', cls: 'bg-white text-black border border-black/15' }
    : null

  const quickAdd = (variant: NonNullable<Product['variants']>[number], e: React.MouseEvent) => {
    e.stopPropagation()
    addToCart({
      product,
      quantity: 1,
      price: displayPrice + (Number(variant.price_adjustment) || 0),
      variantId: variant.id,
      selectedSize: variant.size ?? null,
      selectedColor: variant.color ?? null,
    })
  }

  const open = () => router.push(`/produits/${product.slug}`)

  return (
    <article className="group flex flex-col h-full w-full min-w-0 bg-white">
      <div onClick={open} className="relative w-full aspect-[4/5] bg-[#F5F5F5] rounded-none overflow-hidden cursor-pointer shrink-0">
        {primaryImage ? (
          <>
            <img
              src={primaryImage}
              alt={product.name}
              className={`w-full h-full block object-cover object-top transition-all duration-500 ease-out ${secondaryImage ? 'group-hover:opacity-0' : 'group-hover:scale-[1.03]'}`}
            />
            {secondaryImage && (
              <img
                src={secondaryImage}
                alt={`${product.name} — autre vue`}
                className="absolute inset-0 w-full h-full block opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-out object-cover object-top"
              />
            )}
          </>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-[#F5F5F5] text-black/60 p-4 text-center">
            <span className="font-bold text-sm tracking-[0.22em] uppercase text-black">KIKI JONES</span>
            <span className="text-[11px] font-light mt-1 text-black/70">{product.name}</span>
          </div>
        )}

        {badge && (
          <div className="absolute top-2.5 left-2.5 z-10 pointer-events-none">
            <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.14em] ${badge.cls}`}>{badge.label}</span>
          </div>
        )}

        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); toggleWishlist(product) }}
          aria-label={wishlisted ? `Retirer ${product.name} des favoris` : `Ajouter ${product.name} aux favoris`}
          className="absolute top-2.5 right-2.5 z-10 w-8 h-8 bg-white/90 hover:bg-white text-black flex items-center justify-center transition-colors cursor-pointer"
        >
          <Heart className="w-3.5 h-3.5" strokeWidth={1.7} fill={wishlisted ? '#000000' : 'none'} />
        </button>

        {!soldOut && sizeOptions.length > 0 && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="hidden md:flex absolute inset-x-0 bottom-0 bg-white/95 border-t border-black/10 px-2.5 py-2 items-center justify-between gap-1.5 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200"
          >
            <span className="text-[9px] font-bold uppercase tracking-[0.14em] text-black/55 shrink-0">Ajout rapide</span>
            <div className="flex items-center gap-1 flex-wrap justify-end">
              {sizeOptions.map((v) => (
                <button key={v.id} type="button" onClick={(e) => quickAdd(v, e)} className="px-2 py-0.5 text-[10px] font-bold transition-colors bg-black/[0.06] text-black hover:bg-black hover:text-white cursor-pointer">{v.size}</button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="pt-2 pb-0.5 flex-1 min-w-0 flex flex-col justify-between gap-1">
        <div className="space-y-0.5 min-w-0">
          {brand && <p className="text-[9.5px] font-medium uppercase tracking-[0.14em] text-black/45 truncate">{brand.name}</p>}
          <button type="button" onClick={open} className="text-left text-[11px] font-bold uppercase tracking-[0.04em] text-black leading-snug line-clamp-2 min-h-[2.2em] hover:opacity-65 transition-opacity cursor-pointer w-full">{product.name}</button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 min-w-0">
          <div className="flex flex-wrap items-baseline gap-x-1.5 gap-y-0.5 text-[11px] sm:text-[11.5px] tabular-nums min-w-0">
            <span className="font-medium text-black whitespace-nowrap">{formatPrice(displayPrice)}</span>
            {hasDiscount && <span className="text-[10px] sm:text-[10.5px] font-light text-black/45 line-through whitespace-nowrap">{formatPrice(basePrice)}</span>}
          </div>
          {swatches.length > 0 && (
            <div className="flex items-center gap-1.5 shrink-0">
              {swatches.slice(0, 4).map((s) => (
                <button
                  key={s.hex}
                  type="button"
                  title={s.name}
                  aria-label={`Couleur ${s.name}`}
                  onClick={() => setSelectedColorHex(s.hex)}
                  className={`w-3 h-3 rounded-full border border-black/20 transition-transform cursor-pointer ${selectedColorHex === s.hex ? 'ring-1 ring-black ring-offset-1 ring-offset-white scale-110' : ''}`}
                  style={{ backgroundColor: s.hex }}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </article>
  )
}
