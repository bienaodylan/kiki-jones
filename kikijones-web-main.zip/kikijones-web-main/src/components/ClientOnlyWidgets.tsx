'use client'

import dynamic from 'next/dynamic'

const MarketingPopup = dynamic(() => import('@/components/MarketingPopup'), { ssr: false })
const PromoPopup = dynamic(() => import('@/components/PromoPopup'), { ssr: false })
const BackToTop = dynamic(() => import('@/components/ui/BackToTop'), { ssr: false })
const ChatWidget = dynamic(() => import('@/components/chat/ChatWidget'), { ssr: false })

export default function ClientOnlyWidgets() {
  return (
    <>
      <MarketingPopup displayOn="all" />
      <PromoPopup />
      <BackToTop />
      <ChatWidget />
    </>
  )
}
