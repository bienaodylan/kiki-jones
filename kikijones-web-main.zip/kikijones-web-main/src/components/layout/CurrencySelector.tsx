'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { useCurrency, currencies, Currency } from '@/contexts/CurrencyContext'

export default function CurrencySelector() {
  const { currency, setCurrency } = useCurrency()
  const [isOpen, setIsOpen] = useState(false)

  const handleSelect = (curr: Currency) => {
    setCurrency(curr)
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 hover:bg-white/10 transition-colors"
      >
        <span className="text-xl">{currency.flag}</span>
        <span className="font-semibold text-sm uppercase tracking-wider">{currency.symbol}</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} strokeWidth={1.5} />
      </button>

      {isOpen && (
        <>
          {/* Overlay */}
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
          />
          
          {/* Dropdown */}
          <div className="absolute right-0 mt-2 w-64 bg-black border border-white/20 py-2 z-50 max-h-[400px] overflow-y-auto">
            {currencies.map((curr) => {
              const isSelected = currency.code === curr.code
              return (
                <button
                  key={curr.code}
                  onClick={() => handleSelect(curr)}
                  className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-white transition-colors uppercase tracking-wider ${
                    isSelected ? 'bg-white' : 'text-white hover:text-black'
                  }`}
                >
                  <span className="text-2xl">{curr.flag}</span>
                  <div className="flex-1 text-left">
                    <div className={`font-bold text-xs ${isSelected ? 'text-black' : ''}`}>{curr.name}</div>
                    <div className={`text-xs ${isSelected ? 'text-black/60' : 'opacity-60'}`}>{curr.code}</div>
                  </div>
                  <span className={`font-bold ${isSelected ? 'text-black' : ''}`}>{curr.symbol}</span>
                </button>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
