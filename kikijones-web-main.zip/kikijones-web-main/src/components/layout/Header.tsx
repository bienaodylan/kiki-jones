'use client'

import SearchOverlay from './SearchOverlay'
import { withThemeCategories } from '@/lib/themeCategories'
import { PRIMARY_NAV_ITEMS, getFloatingSubnavFr, getMegaMenuFr, primaryNavLabel, type DivisionKey, type MegaMenuKey } from '@/lib/themeNav'
import { mapThemeHref } from '@/lib/themeRoutes'
import React, { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { useRouter, usePathname } from 'next/navigation'
import { Menu, X, ShoppingBag, User, Heart, Search, ChevronDown, ChevronRight, LogOut, Package, Settings, Star, Gift } from 'lucide-react'
import CurrencySelector from './CurrencySelector'
import type { SiteSettings, Announcement } from '@/lib/api/cms'
import { getAnnouncements } from '@/lib/api/cms'
import { getParentCategories, Category } from '@/lib/api'
import { useCart } from '@/contexts/CartContext'
import { getAccessToken, clearAuth, bootstrapAuth } from '@/lib/auth-store'

interface HeaderProps {
  siteSettings?: SiteSettings
}

export default function Header({ siteSettings }: HeaderProps) {
  const { totalItems } = useCart()
  const router = useRouter()
  const pathname = usePathname()
  const isOnCompte = pathname.startsWith('/compte')
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [categories, setCategories] = useState<Category[]>([])
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [expandedCategories, setExpandedCategories] = useState<string[]>([])
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userName, setUserName] = useState('')
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const userMenuRef = useRef<HTMLDivElement>(null)

  // Check auth state
  useEffect(() => {
    const checkAuth = () => {
      const token = getAccessToken()
      const userData = localStorage.getItem('user')
      if (token) {
        setIsLoggedIn(true)
        if (userData) {
          try {
            const u = JSON.parse(userData)
            setUserName(u.first_name || u.email || '')
          } catch {}
        }
      } else {
        setIsLoggedIn(false)
        setUserName('')
      }
    }

    // Bootstrap access token from httpOnly cookie on first load
    bootstrapAuth().then(() => checkAuth())

    const handleAuthChange = () => checkAuth()
    window.addEventListener('auth-change', handleAuthChange)
    window.addEventListener('storage', handleAuthChange)
    return () => {
      window.removeEventListener('auth-change', handleAuthChange)
      window.removeEventListener('storage', handleAuthChange)
    }
  }, [])

  // Close user menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleLogout = async () => {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
      headers: getAccessToken() ? { Authorization: `Bearer ${getAccessToken()}` } : {},
    }).catch(() => {})
    clearAuth()
    setIsLoggedIn(false)
    setUserName('')
    setUserMenuOpen(false)
    router.push('/')
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const q = searchQuery.trim()
    if (!q) return
    router.push(`/search?q=${encodeURIComponent(q)}`)
    setSearchOpen(false)
    setSearchQuery('')
  }

  const siteName = siteSettings?.site_name || 'KIKIJONES'
  const logoUrl = siteSettings?.logo_light
  // Always use the banner text from settings, no fallback
  const topBannerText = siteSettings?.top_banner_text || ''
  const topBannerLink = siteSettings?.top_banner_link || ''
  const topBannerPromoCode = siteSettings?.top_banner_promo_code || ''
  const countdownEnabled = siteSettings?.top_banner_countdown_enabled || false
  const countdownEnd = siteSettings?.top_banner_countdown_end || ''

  // Countdown timer state
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0 })
  const [countdownActive, setCountdownActive] = useState(false)

  useEffect(() => {
    if (!countdownEnabled || !countdownEnd) return

    const updateTimer = () => {
      const now = new Date().getTime()
      const end = new Date(countdownEnd).getTime()
      const diff = end - now

      if (diff <= 0) {
        setCountdownActive(false)
        return
      }

      setCountdownActive(true)
      setTimeLeft({
        hours: Math.floor(diff / (1000 * 60 * 60)),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      })
    }

    updateTimer()
    const timer = setInterval(updateTimer, 1000)
    return () => clearInterval(timer)
  }, [countdownEnabled, countdownEnd])

  const pad = (n: number) => n.toString().padStart(2, '0')

  // Announcements from the dashboard scroll in the top bar, after the main message
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [slide, setSlide] = useState(0)
  useEffect(() => {
    getAnnouncements().then(setAnnouncements).catch(() => {})
  }, [])
  const slideCount = (topBannerText ? 1 : 0) + announcements.length
  useEffect(() => {
    if (slideCount < 2) return
    const t = setInterval(() => setSlide((s) => (s + 1) % slideCount), 5000)
    return () => clearInterval(t)
  }, [slideCount])
  const slideIdx = slideCount ? slide % slideCount : 0
  const showMain = !!topBannerText && slideIdx === 0
  const currentAnnouncement = announcements[slideIdx - (topBannerText ? 1 : 0)]

  useEffect(() => {
    getParentCategories()
      .then((apiData) => {
        const data = withThemeCategories(apiData)
        setCategories(data)
        if (data.length > 0) {
          setActiveCategory(data[0].slug)
        }
      })
      .catch((error) => {
        console.error('Failed to fetch categories:', error)
      })
  }, [])

  // ─── THEME NAVIGATION (exactly the theme's divisions, sub-ribbon, mega menus and mobile directory) ───
  const isHome = pathname === '/'
  const [scrolledSolid, setScrolledSolid] = useState(false)
  const [activeMega, setActiveMega] = useState<MegaMenuKey | null>(null)
  const [hoveredDivision, setHoveredDivision] = useState<DivisionKey | null>(null)
  const [mobileDivision, setMobileDivision] = useState<DivisionKey>('women')
  const [headerH, setHeaderH] = useState(96)
  const headerRef = useRef<HTMLElement>(null)
  const closeTimer = useRef<number | null>(null)

  const DIVISIONS: DivisionKey[] = ['women', 'curve', 'men', 'sport', 'kids']
  const isDivision = (k: string): k is DivisionKey => (DIVISIONS as string[]).includes(k)
  const activeDivision: DivisionKey = hoveredDivision ?? (activeMega && isDivision(activeMega) ? activeMega : 'women')
  const floatingItems = getFloatingSubnavFr(activeDivision)
  // "Catégories" mega menu = the real categories with their sub-categories (created in the shop, even when empty)
  const withRealCategories = (cfg: ReturnType<typeof getMegaMenuFr>) =>
    cfg && cfg.key === 'categories'
      ? {
          ...cfg,
          columns: categories
            .filter((c) => !(c as { virtual?: boolean }).virtual)
            .map((c) => ({
              heading: c.name,
              links: [{ label: 'Tout voir', href: `/categories/${c.slug}` }, ...((c.subcategories || []).map((s) => ({ label: s.name, href: `/categories/${s.slug}` })))],
            })),
        }
      : cfg
  const mega = withRealCategories(getMegaMenuFr(activeMega))
  const mobileMega = getMegaMenuFr(mobileDivision)

  // Real photos (from the shop's categories) for the editorial cards; black card when none yet
  const anyPhoto = ((categories.find((c) => c.display_image || c.image)?.display_image) || (categories.find((c) => c.image)?.image) || null) as string | null

  useEffect(() => {
    const threshold = isHome ? 240 : 10
    const onScroll = () => setScrolledSolid(window.scrollY > threshold)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [isHome])

  useEffect(() => {
    const el = headerRef.current
    if (!el) return
    const ro = new ResizeObserver(() => setHeaderH(el.getBoundingClientRect().height))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  useEffect(() => {
    setActiveMega(null)
    setHoveredDivision(null)
    setIsMenuOpen(false)
  }, [pathname])

  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [isMenuOpen])

  const openMega = (key: MegaMenuKey, division?: DivisionKey) => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current)
    if (division) setHoveredDivision(division)
    setActiveMega(key)
  }
  const scheduleClose = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current)
    closeTimer.current = window.setTimeout(() => { setActiveMega(null); setHoveredDivision(null) }, 160)
  }
  const cancelClose = () => { if (closeTimer.current) window.clearTimeout(closeTimer.current) }

  const isSolid = !isHome || scrolledSolid || activeMega !== null
  // Home: the wordmark starts big in the middle of the hero and docks into the header as the page scrolls
  const [scrollY, setScrollY] = useState(0)
  useEffect(() => {
    if (!isHome) return
    const on = () => setScrollY(window.scrollY)
    on()
    window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [isHome])
  const vh = typeof window !== 'undefined' ? window.innerHeight : 800
  const vw = typeof window !== 'undefined' ? window.innerWidth : 1280
  const dockEnd = Math.max(220, Math.round(vh * 0.44))
  const dockProgress = isHome && activeMega === null ? Math.min(1, scrollY / dockEnd) : 1
  const heroCenterY = Math.max(150, Math.round(vh * 0.47 - 28))
  const startScale = vw >= 1024 ? 2.15 : vw >= 640 ? 1.75 : 1.3
  const dockStyle = isHome
    ? { transform: `translateY(${Math.round(heroCenterY * (1 - dockProgress))}px) scale(${(startScale + (1 - startScale) * dockProgress).toFixed(3)})` }
    : undefined
  const go = (href: string) => { setActiveMega(null); setHoveredDivision(null); setIsMenuOpen(false); router.push(mapThemeHref(href)) }
  const iconBtn = 'relative p-2 inline-flex items-center justify-center hover:opacity-65 transition-opacity cursor-pointer'
  const badgeCls = `absolute top-1 right-0.5 min-w-[14px] h-[14px] px-0.5 rounded-full text-[8.5px] font-bold flex items-center justify-center tabular-nums ${isSolid ? 'bg-black text-white' : 'bg-white text-black'}`

  return (
    <>
      <header
        ref={headerRef}
        onMouseLeave={scheduleClose}
        onMouseEnter={cancelClose}
        style={isHome ? { marginBottom: -headerH } : undefined}
        className={`sticky top-0 left-0 right-0 w-full max-w-full z-40 transition-all duration-300 ${
          isSolid
            ? 'bg-white/75 backdrop-blur-2xl backdrop-saturate-[1.85] text-black shadow-[0_8px_32px_rgba(0,0,0,0.06)] border-b border-black/[0.08]'
            : 'bg-black/15 backdrop-blur-md text-white'
        }`}
      >
        {!isSolid && <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/30 to-transparent pointer-events-none" />}

        {/* ROW 1 */}
        <div className="relative max-w-[1440px] mx-auto px-3.5 sm:px-6 xl:px-10 h-[52px] lg:h-[56px] grid grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] items-center gap-1.5 sm:gap-2 lg:gap-4">
          <div className="flex items-center justify-start min-w-0">
            <div className="flex lg:hidden items-center gap-0.5">
              <button type="button" onClick={() => setIsMenuOpen(true)} aria-label="Ouvrir le menu" className="p-2 -ml-1.5 inline-flex items-center justify-center hover:opacity-70 transition-opacity cursor-pointer">
                <Menu className="w-5 h-5" strokeWidth={1.65} />
              </button>
              <button type="button" onClick={() => { setSearchOpen(true); setTimeout(() => searchInputRef.current?.focus(), 50) }} aria-label="Rechercher" className="p-2 inline-flex items-center justify-center hover:opacity-70 transition-opacity cursor-pointer">
                <Search className="w-[18px] h-[18px]" strokeWidth={1.65} />
              </button>
            </div>
            <nav aria-label="Navigation principale" className="hidden lg:flex items-center justify-start gap-3 xl:gap-4 text-[10px] xl:text-[10.5px] font-bold uppercase tracking-[0.09em] xl:tracking-[0.12em]">
              {PRIMARY_NAV_ITEMS.map((item) => {
                const key = item.key as MegaMenuKey
                const isOpen = activeMega === key
                return (
                  <div
                    key={item.key}
                    onMouseEnter={() => (item.hasMegaMenu ? openMega(key, isDivision(item.key) ? item.key : undefined) : setActiveMega(null))}
                    className="py-4"
                  >
                    <button
                      type="button"
                      onClick={() => go(item.href)}
                      className={`whitespace-nowrap shrink-0 leading-none transition-opacity cursor-pointer ${isOpen ? 'opacity-100 underline underline-offset-[6px] decoration-[1.5px]' : 'opacity-80 hover:opacity-100'}`}
                    >
                      {primaryNavLabel(item.key, item.label)}
                    </button>
                  </div>
                )
              })}
            </nav>
          </div>

          <div className="flex items-center justify-center min-w-0">
            <Link href="/" aria-label={`${siteName} accueil`} style={dockStyle} className="shrink-0 leading-none will-change-transform inline-flex items-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={isSolid ? '/logo-black.png' : '/logo-white.png'} alt={siteName} className="h-6 sm:h-7 xl:h-8 w-auto select-none" />
            </Link>
          </div>

          <div className="flex items-center justify-end gap-0.5 sm:gap-1.5 shrink-0">
            <div className="hidden xl:block text-[10px]"><CurrencySelector /></div>
            <button type="button" onClick={() => { setSearchOpen(true); setTimeout(() => searchInputRef.current?.focus(), 50) }} aria-label="Rechercher" className={`hidden lg:inline-flex ${iconBtn}`}>
              <Search className="w-[17px] h-[17px]" strokeWidth={1.65} />
            </button>
            <Link href={isLoggedIn ? '/compte' : '/login'} aria-label="Mon compte" className={`hidden lg:inline-flex ${iconBtn}`}>
              <User className="w-[17px] h-[17px]" strokeWidth={1.65} />
            </Link>
            <Link href="/wishlist" aria-label="Favoris" className={iconBtn}>
              <Heart className="w-[17px] h-[17px]" strokeWidth={1.65} />
            </Link>
            <Link href="/panier" aria-label={`Panier (${totalItems})`} className={`${iconBtn} -mr-1`}>
              <ShoppingBag className="w-[17px] h-[17px]" strokeWidth={1.65} />
              {totalItems > 0 && <span className={badgeCls}>{totalItems}</span>}
            </Link>
          </div>
        </div>

        {/* ROW 2: floating sub-navigation ribbon (the active division's categories) */}
        <nav
          aria-label="Collections rapides"
          className={`relative border-t transition-all duration-300 ${isSolid ? 'bg-white/45 backdrop-blur-2xl backdrop-saturate-[1.8] border-black/[0.07] text-black' : 'bg-black/[0.28] backdrop-blur-2xl backdrop-saturate-150 border-white/[0.18] border-b border-b-white/10 text-white'}`}
        >
          <div className="max-w-[1440px] mx-auto px-3.5 sm:px-6 xl:px-10 h-9 lg:h-10 flex items-center lg:justify-center gap-4 sm:gap-5 xl:gap-6 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
            {floatingItems.map((sub) => (
              <button
                key={`${activeDivision}-${sub.label}`}
                type="button"
                onMouseEnter={() => { if (sub.megaMenuKey) openMega(sub.megaMenuKey) }}
                onClick={() => go(sub.href)}
                className={`whitespace-nowrap shrink-0 text-[10px] lg:text-[10.5px] uppercase tracking-[0.11em] py-2 leading-none transition-opacity cursor-pointer ${
                  sub.highlight ? 'font-bold underline underline-offset-4' : activeMega === sub.megaMenuKey ? 'font-bold opacity-100 underline underline-offset-[5px]' : 'font-medium opacity-85 hover:opacity-100'
                }`}
              >
                {sub.label}
              </button>
            ))}
          </div>
        </nav>

      </header>

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      {/* Desktop mega menu — columns exactly as in the theme */}
      {/* Frosted backdrop below the header, then the glass panel on top of it (same stacking as the theme) */}
      <div
        style={{ top: headerH }}
        onClick={() => { setActiveMega(null); setHoveredDivision(null) }}
        className={`hidden lg:block fixed inset-x-0 bottom-0 bg-black/15 backdrop-blur-md z-30 transition-opacity duration-200 ${mega ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        aria-hidden
      />
      <div
        onMouseEnter={cancelClose}
        onMouseLeave={scheduleClose}
        style={{ top: headerH }}
        className={`hidden lg:block fixed inset-x-0 z-40 ${mega ? 'pointer-events-auto' : 'pointer-events-none'}`}
        aria-hidden={!mega}
      >
        {mega && (
          <>
            <div className={`bg-white/[0.96] backdrop-blur-2xl backdrop-saturate-[1.85] border-b border-black/10 text-black shadow-[0_32px_64px_-24px_rgba(0,0,0,0.2)] animate-[kjMegaIn_180ms_ease-out]`}>
              <div className="max-w-[1440px] mx-auto px-6 xl:px-10 py-9">
                <div className="grid grid-cols-12 gap-8 items-start">
                  <div className="col-span-9 grid grid-cols-4 gap-x-8 gap-y-6">
                    {mega.columns.map((column) => (
                      <div key={column.heading} className="space-y-3.5">
                        <h3 className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-black pb-2 border-b border-black/10">{column.heading}</h3>
                        <ul className={column.links.length > 9 ? 'grid grid-cols-2 gap-x-4 gap-y-2' : 'space-y-2'}>
                          {column.links.map((link) => (
                            <li key={`${column.heading}-${link.label}`}>
                              <button type="button" onClick={() => go(link.href)} className="text-left text-[12.5px] font-normal text-black hover:text-black hover:underline underline-offset-4 transition-colors cursor-pointer leading-snug">{link.label}</button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                  <div className="col-span-3">
                    <button type="button" onClick={() => go(mega.editorial.href)} className="group block w-full text-left cursor-pointer">
                      <div className="relative aspect-[3/4] w-full overflow-hidden bg-black">
                        {anyPhoto && <Image src={anyPhoto} alt={mega.editorial.title} fill sizes="25vw" className="object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]" />}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
                        <div className="absolute inset-x-0 bottom-0 p-5 text-white space-y-1.5">
                          <p className="text-[9.5px] font-bold uppercase tracking-[0.2em] text-white/80">{mega.editorial.eyebrow}</p>
                          <p className="text-2xl font-bold tracking-[-0.025em] leading-tight text-white">{mega.editorial.title}</p>
                          <span className="inline-flex items-center gap-1.5 pt-1 text-[10px] font-bold uppercase tracking-[0.16em] text-white group-hover:underline underline-offset-4">
                            {mega.editorial.ctaLabel} <ChevronRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Mobile drawer — division tabs, search, then the numbered directory (theme's structure) */}
      <div className={`fixed inset-0 z-50 lg:hidden transition-opacity duration-200 ${isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`} aria-hidden={!isMenuOpen}>
        <div className="absolute inset-0 bg-black/45 backdrop-blur-md" onClick={() => setIsMenuOpen(false)} />
        <aside
          aria-label="Navigation mobile"
          className={`absolute top-0 left-0 bottom-0 w-full sm:max-w-[430px] bg-white/95 backdrop-blur-2xl text-black flex flex-col shadow-2xl transition-transform duration-300 ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}
          style={{ paddingTop: 'env(safe-area-inset-top)' }}
        >
          <div className="px-4 h-[54px] border-b border-black/[0.08] bg-white/80 flex items-center justify-between shrink-0">
            <button type="button" onClick={() => { setIsMenuOpen(false); router.push('/') }} className="inline-flex items-center gap-2 text-black">
              <img src="/logo-black.png" alt="KIKI JONES" className="h-6 w-auto" />
              <span className="h-3 w-px bg-black/20" />
              <span className="text-[10px] font-medium uppercase tracking-[0.18em] text-black/45">Menu</span>
            </button>
            <button type="button" onClick={() => setIsMenuOpen(false)} aria-label="Fermer le menu" className="min-h-[40px] min-w-[40px] -mr-1.5 inline-flex items-center justify-center text-black/75 hover:text-black">
              <X className="w-5 h-5" strokeWidth={1.7} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto overscroll-contain">
            <div className="sticky top-0 z-10 bg-white/90 backdrop-blur-xl border-b border-black/[0.08] px-4 pt-3 pb-3 space-y-2.5">
              <div className="flex items-center gap-1 p-1 rounded-full bg-[#F2F2F2] overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
                {DIVISIONS.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setMobileDivision(d)}
                    className={`relative flex-1 min-w-[60px] min-h-[34px] px-2.5 rounded-full text-[10.5px] uppercase tracking-[0.11em] whitespace-nowrap transition-colors ${mobileDivision === d ? 'bg-black text-white font-bold' : 'text-black/65 font-medium'}`}
                  >
                    {primaryNavLabel(d, d)}
                  </button>
                ))}
              </div>
              <form onSubmit={handleSearch} role="search" className="flex items-center gap-2.5 rounded-xl border border-black/[0.1] bg-[#F7F7F7]/90 px-3.5 min-h-[40px] focus-within:border-black focus-within:bg-white transition-colors">
                <Search className="w-4 h-4 text-black/45 shrink-0" strokeWidth={1.7} />
                <input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Rechercher dans la boutique"
                  aria-label="Rechercher dans la boutique"
                  className="flex-1 bg-transparent text-base text-black placeholder:text-black/45 focus:outline-none py-1"
                />
              </form>
            </div>

            {mobileMega && (
              <div className="px-4 py-4 space-y-7">
                <button type="button" onClick={() => go(mobileMega.editorial.href)} className="group relative w-full aspect-[16/9] overflow-hidden bg-black text-left block">
                  {anyPhoto && <Image src={anyPhoto} alt={mobileMega.editorial.title} fill sizes="430px" className="object-cover object-top transition-transform duration-700 group-hover:scale-[1.03]" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                  <div className="absolute inset-x-3 bottom-3 px-3.5 py-2.5 bg-white/15 backdrop-blur-xl border border-white/25 flex items-center justify-between gap-3 text-white">
                    <div className="min-w-0">
                      <p className="text-[9px] font-bold uppercase tracking-[0.22em] text-white/80">{mobileMega.editorial.eyebrow}</p>
                      <p className="text-lg font-bold tracking-[-0.02em] leading-tight truncate">{mobileMega.editorial.title}</p>
                    </div>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-[0.16em] shrink-0">{mobileMega.editorial.ctaLabel} <ChevronRight className="w-3.5 h-3.5" /></span>
                  </div>
                </button>

                {mobileMega.columns.map((column, i) => (
                  <section key={column.heading} className="space-y-3">
                    <div className="flex items-baseline justify-between border-b border-black/10 pb-2">
                      <div className="flex items-baseline gap-2">
                        <span className="text-[10px] font-bold tabular-nums tracking-[0.16em] text-black/40">{String(i + 1).padStart(2, '0')}</span>
                        <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black">{column.heading}</h3>
                      </div>
                      <span className="text-[10px] uppercase tracking-[0.14em] text-black/40 tabular-nums">{column.links.length}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {column.links.map((link) => (
                        <button key={`${column.heading}-${link.label}`} type="button" onClick={() => go(link.href)} className="group min-h-[50px] px-3 py-2.5 border border-black/[0.1] bg-[#FAFAFA] hover:border-black hover:bg-black hover:text-white flex items-center justify-between gap-2 text-left transition-colors">
                          <span className="text-[12.5px] font-medium leading-snug line-clamp-2">{link.label}</span>
                          <ChevronRight className="w-3.5 h-3.5 shrink-0 transition-transform group-hover:translate-x-0.5" />
                        </button>
                      ))}
                    </div>
                  </section>
                ))}

                <section className="space-y-4">
                  <div className="flex items-baseline gap-2 border-b border-black/10 pb-2">
                    <span className="text-[10px] font-bold tabular-nums tracking-[0.16em] text-black/40">{String(mobileMega.columns.length + 1).padStart(2, '0')}</span>
                    <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black">Catégories &amp; sous-catégories</h3>
                  </div>
                  <div className="space-y-4">
                    {categories.filter((c) => !(c as { virtual?: boolean }).virtual).map((c) => (
                      <div key={c.id} className="border border-black/[0.08] bg-[#FAFAFA]/70 p-3.5 space-y-2.5">
                        <button type="button" onClick={() => { setIsMenuOpen(false); router.push(`/categories/${c.slug}`) }} className="text-[10px] font-bold uppercase tracking-[0.18em] text-black/70">{c.name}</button>
                        {c.subcategories && c.subcategories.length > 0 && (
                          <div className="flex flex-wrap gap-1.5">
                            {c.subcategories.map((sub) => (
                              <button key={sub.id} type="button" onClick={() => { setIsMenuOpen(false); router.push(`/categories/${sub.slug}`) }} className="px-2.5 py-1.5 bg-white border border-black/[0.1] hover:border-black text-[12px]">{sub.name}</button>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </section>

                <section className="space-y-3">
                  <div className="flex items-baseline gap-2 border-b border-black/10 pb-2">
                    <span className="text-[10px] font-bold tabular-nums tracking-[0.16em] text-black/40">{String(mobileMega.columns.length + 2).padStart(2, '0')}</span>
                    <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-black">Aide</h3>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { label: 'Nouveautés', href: '/produits?is_new=true' },
                      { label: 'Cartes cadeaux', href: '/gift-cards' },
                      { label: 'Roue de la chance', href: '/roue-chance' },
                      { label: "Centre d'aide", href: '/centre-aide' },
                      { label: 'Suivre ma commande', href: '/track-order' },
                    ].map((l) => (
                      <button key={l.label} type="button" onClick={() => { setIsMenuOpen(false); router.push(l.href) }} className="px-2.5 py-1.5 bg-white border border-black/[0.1] hover:border-black text-[12px]">{l.label}</button>
                    ))}
                  </div>
                </section>
              </div>
            )}
          </div>

          <div className="px-4 pt-3 pb-[calc(0.85rem+env(safe-area-inset-bottom))] border-t border-black/[0.08] bg-white/90 space-y-2 shrink-0">
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={() => { setIsMenuOpen(false); router.push(isLoggedIn ? '/compte' : '/login') }} className="min-h-[44px] flex items-center justify-center gap-2 py-2 border border-black/15 bg-white text-[11px] font-bold uppercase tracking-[0.14em] hover:border-black">
                <User className="w-3.5 h-3.5" /> {isLoggedIn ? 'Compte' : 'Connexion'}
              </button>
              <button type="button" onClick={() => { setIsMenuOpen(false); router.push('/wishlist') }} className="min-h-[44px] flex items-center justify-center gap-2 py-2 border border-black/15 bg-white text-[11px] font-bold uppercase tracking-[0.14em] hover:border-black">
                <Heart className="w-3.5 h-3.5" /> Favoris
              </button>
            </div>
            {isLoggedIn && (
              <button type="button" onClick={() => { handleLogout(); setIsMenuOpen(false) }} className="w-full min-h-[40px] text-[11px] font-bold uppercase tracking-[0.14em] text-black/60 hover:text-black">Déconnexion</button>
            )}
          </div>
        </aside>
      </div>
    </>
  )
}
