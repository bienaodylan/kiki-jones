'use client'

import { useState } from 'react'
import Link from 'next/link'
import { API_ENDPOINTS } from '@/lib/api/config'

interface NewsletterFormProps {
  siteName: string
}

export default function NewsletterForm({ siteName }: NewsletterFormProps) {
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [message, setMessage] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setStatus('loading')
    try {
      const response = await fetch(API_ENDPOINTS.newsletterSubscribe, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()

      if (response.ok) {
        setStatus('success')
        setMessage('Merci ! Vous êtes inscrit(e) à notre newsletter.')
        setEmail('')
      } else {
        setStatus('error')
        setMessage(data.email?.[0] || 'Une erreur est survenue.')
      }
    } catch {
      setStatus('error')
      setMessage('Erreur de connexion. Réessayez.')
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-black">Rejoindre la liste {siteName}</p>
      <p className="text-xs font-light text-black/65 leading-relaxed max-w-sm">
        Accès anticipé aux nouveautés hebdomadaires et sorties exclusives Kiki Men, Kiki Curve, Kiki Sculpt, Kiki Luxe et Kiki Kids.
      </p>
      {status === 'success' ? (
        <div className="px-4 py-3 rounded-full border border-black/20 bg-black/[0.03] text-xs font-medium text-black">{message}</div>
      ) : (
        <form onSubmit={handleSubmit} className="flex items-center gap-2 w-full max-w-sm min-w-0">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => { setEmail(e.target.value); setStatus('idle') }}
            placeholder="Adresse e-mail"
            aria-label="Adresse e-mail pour la newsletter"
            className="flex-1 min-w-0 w-full bg-white border border-black/25 rounded-full px-4 py-2.5 text-base sm:text-xs font-light text-black placeholder:text-black/40 focus:outline-none focus:border-black"
          />
          <button
            type="submit"
            disabled={status === 'loading'}
            className="shrink-0 px-5 py-2.5 rounded-full bg-black text-white text-[10.5px] font-bold uppercase tracking-[0.14em] hover:bg-black/85 transition-colors disabled:opacity-60"
          >
            {status === 'loading' ? 'Envoi…' : "S'inscrire"}
          </button>
        </form>
      )}
      {status === 'error' && <p className="text-xs text-black/70">{message}</p>}
    </div>
  )
}
