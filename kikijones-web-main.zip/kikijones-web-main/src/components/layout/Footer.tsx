import Link from 'next/link'
import type { SiteSettings } from '@/lib/api/cms'
import NewsletterForm from './NewsletterForm'

interface FooterProps {
  siteSettings?: SiteSettings
}

const linkCls = 'hover:text-black hover:underline underline-offset-4'
const headCls = 'text-[10.5px] font-bold uppercase tracking-[0.18em] text-black'
const listCls = 'space-y-2 text-xs font-light text-black/70'

export default function Footer({ siteSettings }: FooterProps) {
  const siteName = siteSettings?.site_name || 'KIKI JONES'
  const currentYear = new Date().getFullYear()

  return (
    <footer className="w-full max-w-full bg-white text-black border-t border-black/10 overflow-x-clip mt-12 md:mt-20">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 md:px-10 pt-12 pb-10 grid grid-cols-2 md:grid-cols-12 gap-x-6 sm:gap-x-8 gap-y-9">
        <div className="col-span-2 md:col-span-4 pr-0 md:pr-6">
          <NewsletterForm siteName={siteName} />
          <div className="text-[11px] font-light text-black/50 space-y-0.5 pt-4">
            <p>{siteSettings?.email || 'care@kikijones.com'}</p>
            <p>{siteSettings?.phone || '+225 07 00 00 00 00'}</p>
          </div>
        </div>

        <div className="col-span-1 md:col-span-2 space-y-3">
          <p className={headCls}>Par Marque</p>
          <ul className={listCls}>
            <li><Link href="/brands" className={linkCls}>Toutes les marques</Link></li>
            <li><Link href="/produits?brand=kiki-men" className={linkCls}>Kiki Men</Link></li>
            <li><Link href="/produits?brand=kiki-curve" className={linkCls}>Kiki Curve</Link></li>
            <li><Link href="/produits?brand=kiki-sculpt" className={linkCls}>Kiki Sculpt</Link></li>
            <li><Link href="/produits?brand=kiki-luxe" className={linkCls}>Kiki Luxe</Link></li>
            <li><Link href="/produits?brand=kiki-sport" className={linkCls}>Kiki Sport</Link></li>
            <li><Link href="/produits?brand=kiki-kids" className={linkCls}>Kiki Kids</Link></li>
          </ul>
        </div>

        <div className="col-span-1 md:col-span-2 space-y-3">
          <p className={headCls}>Par Catégorie</p>
          <ul className={listCls}>
            <li><Link href="/categories" className={linkCls}>Toutes les catégories</Link></li>
            <li><Link href="/categories/robe" className={linkCls}>Robes &amp; Soirée</Link></li>
            <li><Link href="/categories/ensemble" className={linkCls}>Ensembles</Link></li>
            <li><Link href="/categories/combinaison" className={linkCls}>Combinaisons</Link></li>
            <li><Link href="/categories/sport" className={linkCls}>Sport &amp; Activewear</Link></li>
            <li><Link href="/categories/chaussures" className={linkCls}>Chaussures &amp; Lunettes</Link></li>
          </ul>
        </div>

        <div className="col-span-1 md:col-span-2 space-y-3">
          <p className={headCls}>Service Client</p>
          <ul className={listCls}>
            <li><Link href="/produits?is_new=true" className={linkCls}>Nouveautés</Link></li>
            <li><Link href="/promotions" className={linkCls}>Soldes</Link></li>
            <li><Link href="/compte" className={linkCls}>Mon compte</Link></li>
            <li><Link href="/wishlist" className={linkCls}>Favoris</Link></li>
            <li><Link href="/compte/commandes" className={linkCls}>Mes commandes</Link></li>
            <li><Link href="/livraison" className={linkCls}>Livraison &amp; Expédition</Link></li>
            <li><Link href="/retours" className={linkCls}>Retours &amp; Échanges</Link></li>
          </ul>
        </div>

        <div className="col-span-1 md:col-span-2 space-y-3">
          <p className={headCls}>Maison &amp; Légal</p>
          <ul className={listCls}>
            <li><Link href="/collections" className={linkCls}>Collections</Link></li>
            <li><Link href="/privacy" className={linkCls}>Confidentialité</Link></li>
            <li><Link href="/terms" className={linkCls}>Conditions de vente</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-black/10">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 md:px-10 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left text-[11px] font-light text-black/55">
          <p>&copy; {currentYear} KIKI JONES. Tous droits réservés.</p>
          <p>Franc CFA (FCFA / XOF) &middot; Wave &middot; Orange Money &middot; Visa &middot; Mastercard</p>
        </div>
      </div>

      <div className="w-full overflow-hidden px-3 md:px-6 pb-4 pt-2 select-none pointer-events-none" aria-hidden>
        <img src="/logo-black.png" alt="" className="mx-auto w-[70%] max-w-[1100px] h-auto select-none" />
      </div>
    </footer>
  )
}
