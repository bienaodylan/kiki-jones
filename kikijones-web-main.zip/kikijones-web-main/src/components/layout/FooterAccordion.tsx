'use client'

import { useState } from 'react'
import { Plus, Minus } from 'lucide-react'

/** Footer column: collapsible with a +/- on phones (like the reference), always open on larger screens. */
export default function FooterAccordion({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-white/20 md:border-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="w-full flex items-center justify-between py-4 md:py-0 md:mb-4 md:cursor-default text-left"
      >
        <h3 className="font-bold text-sm uppercase tracking-wider">{title}</h3>
        <span className="md:hidden">{open ? <Minus size={18} /> : <Plus size={18} />}</span>
      </button>
      <div className={`${open ? 'block' : 'hidden'} md:block pb-4 md:pb-0`}>{children}</div>
    </div>
  )
}
