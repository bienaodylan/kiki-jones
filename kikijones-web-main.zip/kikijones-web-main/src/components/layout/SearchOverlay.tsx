'use client'

import { useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight, Clock, Search, TrendingUp, X } from 'lucide-react'
import { getProducts, Product } from '@/lib/api'
import { useCurrency } from '@/contexts/CurrencyContext'
import { mapThemeHref } from '@/lib/themeRoutes'

const TRENDING = ['Kiki Men', 'Kiki Luxe', 'Kiki Sport', 'Kiki Curve', 'Robes', 'Combinaison', 'Cyclistes', 'Chaussures', 'Lunettes', 'Jeans Stacked']
const SUGGESTED = [
  { label: 'Acheter par Marque', href: '/brands', hint: 'Men, Luxe, Curve, Sculpt, Sport, Kids' },
  { label: 'Acheter par Catégorie', href: '/categories', hint: 'Robes, Ensembles, Combinaisons, Chaussures' },
  { label: 'Soirée & Cérémonie', href: '/collection/formal', hint: 'Robes de Gala, Tailleurs & Talons' },
  { label: 'Kiki Sport', href: '/brand/kiki-sport', hint: 'Cyclistes & Activewear Respirant' },
  { label: 'Chaussures', href: '/category/shoes', hint: 'Talons, Mocassins & Baskets' },
  { label: 'Lunettes de soleil', href: '/category/sunglasses', hint: 'Acétate Sombre & Optique' },
]
const KEY = 'kj_recent_searches'

/** Search overlay: the theme's search panel (recent / trending / suggested, then instant results). */
export default function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const router = useRouter()
  const { formatPrice } = useCurrency()
  const inputRef = useRef<HTMLInputElement>(null)
  const [query, setQuery] = useState('')
  const [recent, setRecent] = useState<string[]>([])
  const [results, setResults] = useState<Product[]>([])
  const [loading, setLoading] = useState(false)
  const q = query.trim()

  useEffect(() => { try { setRecent(JSON.parse(localStorage.getItem(KEY) || '[]')) } catch {} }, [open])
  useEffect(() => {
    if (open) { setTimeout(() => inputRef.current?.focus(), 60); document.body.style.overflow = 'hidden' }
    else { document.body.style.overflow = ''; setQuery('') }
    return () => { document.body.style.overflow = '' }
  }, [open])
  useEffect(() => {
    const on = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    if (open) window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [open, onClose])
  useEffect(() => {
    if (q.length < 2) { setResults([]); return }
    setLoading(true)
    const t = setTimeout(() => {
      getProducts({ search: q, page_size: 8 }).then((r) => setResults(r.results)).catch(() => setResults([])).finally(() => setLoading(false))
    }, 250)
    return () => clearTimeout(t)
  }, [q])

  const save = (term: string) => {
    const next = [term, ...recent.filter((x) => x.toLowerCase() !== term.toLowerCase())].slice(0, 6)
    setRecent(next)
    try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
  }
  const submit = (term: string) => {
    const t = term.trim()
    if (!t) return
    save(t); onClose(); router.push(`/search?q=${encodeURIComponent(t)}`)
  }
  const removeRecent = (term: string) => {
    const next = recent.filter((x) => x !== term)
    setRecent(next)
    try { localStorage.setItem(KEY, JSON.stringify(next)) } catch {}
  }

  if (!open) return null
  return (
    <>
      <div className="fixed inset-0 bg-black/45 backdrop-blur-[1px] z-50" onClick={onClose} />
      <div role="dialog" aria-label="Rechercher sur KIKI JONES" className="fixed top-0 inset-x-0 bg-white text-black z-50 border-b border-black/10 shadow-2xl max-h-[88vh] overflow-y-auto">
        <div className="max-w-[1440px] mx-auto px-5 md:px-10 py-6 space-y-8">
          <form onSubmit={(e) => { e.preventDefault(); submit(query) }} className="flex items-center gap-3 border-b border-black pb-3">
            <Search className="w-5 h-5 text-black shrink-0" strokeWidth={1.6} />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Robes, Kiki Men, cyclistes, chaussures…"
              aria-label="Rechercher des produits KIKI JONES"
              className="flex-1 bg-transparent text-base md:text-lg font-light text-black placeholder:text-black/40 focus:outline-none"
            />
            {query && <button type="button" onClick={() => { setQuery(''); inputRef.current?.focus() }} aria-label="Effacer la recherche" className="p-1 text-black/50 hover:text-black"><X className="w-4 h-4" /></button>}
            <button type="button" onClick={onClose} aria-label="Fermer la recherche" className="p-1.5 text-black/70 hover:text-black"><X className="w-5 h-5" strokeWidth={1.6} /></button>
          </form>

          {q.length < 2 ? (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-4">
              <div className="md:col-span-4 space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-black flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-black/50" />Recherches récentes</p>
                  {recent.length > 0 && <button type="button" onClick={() => { setRecent([]); try { localStorage.removeItem(KEY) } catch {} }} className="text-[10px] font-bold uppercase tracking-[0.14em] text-black/45 hover:text-black">Effacer</button>}
                </div>
                {recent.length === 0 ? (
                  <p className="text-xs font-light text-black/45">Vos recherches récentes apparaîtront ici.</p>
                ) : (
                  <ul className="space-y-2">
                    {recent.map((t) => (
                      <li key={t} className="flex items-center justify-between group">
                        <button type="button" onClick={() => submit(t)} className="text-sm font-light text-black/80 hover:text-black hover:underline underline-offset-4">{t}</button>
                        <button type="button" onClick={() => removeRecent(t)} aria-label={`Supprimer ${t}`} className="p-1 text-black/30 hover:text-black"><X className="w-3 h-3" /></button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="md:col-span-4 space-y-3">
                <p className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-black flex items-center gap-2"><TrendingUp className="w-3.5 h-3.5 text-black/50" />Tendances actuelles</p>
                <div className="flex flex-wrap gap-2">
                  {TRENDING.map((t) => <button key={t} type="button" onClick={() => submit(t)} className="px-3.5 py-1.5 border border-black/15 text-xs font-light text-black hover:border-black hover:bg-black hover:text-white transition-colors">{t}</button>)}
                </div>
              </div>

              <div className="md:col-span-4 space-y-3">
                <p className="text-[10.5px] font-bold uppercase tracking-[0.18em] text-black">Catégories suggérées</p>
                <div className="space-y-2">
                  {SUGGESTED.map((s) => (
                    <button key={s.label} type="button" onClick={() => { onClose(); router.push(mapThemeHref(s.href)) }} className="w-full flex items-center justify-between py-1.5 border-b border-black/10 text-xs font-medium text-black/80 hover:text-black text-left">
                      <span>{s.label}<span className="block text-[10.5px] font-light text-black/45">{s.hint}</span></span>
                      <ArrowRight className="w-3.5 h-3.5 text-black/45" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-5 pb-4">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-black/60">Résultats instantanés ({results.length})</p>
                <button type="button" onClick={() => submit(query)} className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-black hover:underline underline-offset-4">Voir tous les résultats <ArrowRight className="w-3.5 h-3.5" /></button>
              </div>
              {loading ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="aspect-[4/5] bg-[#F5F5F5] animate-pulse" />)}</div>
              ) : results.length === 0 ? (
                <div className="py-10 text-center space-y-3">
                  <p className="text-2xl font-bold tracking-[-0.025em] text-black">Aucune pièce trouvée pour « {q} »</p>
                  <p className="text-xs font-light text-black/60">Essayez un autre terme ou parcourez les tendances.</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {results.slice(0, 4).map((p) => {
                    const price = p.sale_price ? parseFloat(p.sale_price) : parseFloat(p.base_price)
                    return (
                      <button key={p.id} type="button" onClick={() => { save(q); onClose(); router.push(`/produits/${p.slug}`) }} className="group text-left space-y-2">
                        <div className="aspect-[4/5] bg-[#F5F5F5] overflow-hidden">
                          {p.main_image && <img src={p.main_image} alt={p.name} className="w-full h-full object-cover object-top group-hover:scale-[1.03] transition-transform duration-300" />}
                        </div>
                        <div className="space-y-0.5">
                          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-black/45 line-clamp-1">{p.category_name}</p>
                          <p className="text-xs font-bold uppercase tracking-[0.05em] text-black line-clamp-1">{p.name}</p>
                          <p className="text-xs font-light text-black/75 tabular-nums">{formatPrice(price)}</p>
                        </div>
                      </button>
                    )
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}
