'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { API_ENDPOINTS } from '@/lib/api/config'
import { getAccessToken, bootstrapAuth } from '@/lib/auth-store'

interface WheelSegment {
  id: string
  label: string
  prize_type: string
  prize_value: number
  color: string
  text_color: string
  icon: string
}

interface WheelConfig {
  id: string
  name: string
  is_active: boolean
  spins_per_day: number
  min_points_to_spin: number
  points_cost_per_spin: number
  background_color: string
  button_color: string
  segments: WheelSegment[]
  can_spin?: boolean
  spins_remaining?: number
}

interface SpinResult {
  success: boolean
  segment_index: number
  prize_type: string
  prize_value: number
  prize_label: string
  coupon_code?: string
  message: string
  spins_remaining: number
}

export default function LuckyWheel() {
  const [wheel, setWheel] = useState<WheelConfig | null>(null)
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<SpinResult | null>(null)
  const [rotation, setRotation] = useState(0)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    bootstrapAuth().then((token) => {
      setIsLoggedIn(!!token)
      fetchWheel(token)
    })
  }, [])

  const fetchWheel = async (token: string | null) => {
    try {
      const headers: HeadersInit = { 'Content-Type': 'application/json' }
      if (token) headers['Authorization'] = `Bearer ${token}`
      const res = await fetch(API_ENDPOINTS.gamificationWheel, { headers })
      if (!res.ok) throw new Error('Roue non disponible')
      const data = await res.json()
      setWheel(data)
    } catch {
      setError("La roue de la chance n'est pas disponible pour le moment.")
    } finally {
      setLoading(false)
    }
  }

  const drawWheel = useCallback(() => {
    if (!canvasRef.current || !wheel || wheel.segments.length === 0) return
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1
    const displaySize = 400
    canvas.width = displaySize * dpr
    canvas.height = displaySize * dpr
    canvas.style.width = displaySize + 'px'
    canvas.style.height = displaySize + 'px'
    ctx.scale(dpr, dpr)

    const center = displaySize / 2
    const radius = center - 12
    const segments = wheel.segments
    const segAngle = (2 * Math.PI) / segments.length

    ctx.clearRect(0, 0, displaySize, displaySize)

    // Outer shadow ring
    ctx.beginPath()
    ctx.arc(center, center, radius + 8, 0, 2 * Math.PI)
    ctx.fillStyle = 'rgba(0,0,0,0.08)'
    ctx.fill()

    // Draw each segment
    segments.forEach((seg, i) => {
      const startAngle = i * segAngle - Math.PI / 2
      const endAngle = startAngle + segAngle

      // Fill segment
      ctx.beginPath()
      ctx.moveTo(center, center)
      ctx.arc(center, center, radius, startAngle, endAngle)
      ctx.closePath()
      // Brand look: black / gold segments, grey for the "nothing" ones
      const isNothing = seg.prize_type === 'nothing'
      const goldTurn = i % 2 === 1 && !(segments.length % 2 === 1 && i === segments.length - 1)
      const darkText = goldTurn && !isNothing
      ctx.fillStyle = isNothing ? '#8A8A8A' : goldTurn ? '#FFFFFF' : '#000000'
      ctx.fill()

      // White border between segments
      ctx.strokeStyle = 'rgba(255,255,255,0.18)'
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw text along the segment
      ctx.save()
      ctx.translate(center, center)
      const midAngle = startAngle + segAngle / 2
      ctx.rotate(midAngle)

      // On the left half of the wheel, the rotated axis points the wrong way —
      // add a half turn and mirror the x offset so labels stay upright in place.
      const normalizedAngle = ((midAngle % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)
      const isUpsideDown = normalizedAngle > Math.PI / 2 && normalizedAngle < (3 * Math.PI) / 2
      if (isUpsideDown) ctx.rotate(Math.PI)
      const xSign = isUpsideDown ? -1 : 1

      // Emoji icon near edge
      ctx.font = '24px sans-serif'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      if (seg.icon) {
        ctx.fillText(seg.icon, xSign * radius * 0.80, 0)
      }

      // Text shadow for readability
      ctx.shadowColor = darkText ? 'rgba(255,255,255,0.35)' : 'rgba(0,0,0,0.6)'
      ctx.shadowBlur = 3
      ctx.shadowOffsetX = 1
      ctx.shadowOffsetY = 1

      // Label - white bold
      ctx.fillStyle = darkText ? '#17171F' : '#FFFFFF'
      ctx.font = 'bold 15px "Inter", "Helvetica Neue", Arial, sans-serif'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      // Long labels wrap onto up to 3 lines instead of being cut
      const words = seg.label.split(/\s+/).filter(Boolean)
      const lines: string[] = []
      let cur = ''
      for (const w of words) {
        if (cur && (cur + ' ' + w).length > 12) {
          lines.push(cur)
          cur = w
        } else {
          cur = cur ? cur + ' ' + w : w
        }
      }
      if (cur) lines.push(cur)
      if (lines.length > 3) {
        const rest = lines.splice(2).join(' ')
        lines.push(rest.length > 13 ? rest.slice(0, 12) + '…' : rest)
      }
      const lineH = 17
      lines.forEach((ln, li) => {
        ctx.fillText(ln, xSign * radius * 0.50, (li - (lines.length - 1) / 2) * lineH)
      })

      // Reset shadow
      ctx.shadowColor = 'transparent'
      ctx.shadowBlur = 0
      ctx.restore()
    })

    // Soft gloss: lighter centre, darker rim
    const gloss = ctx.createRadialGradient(center, center, radius * 0.45, center, center, radius)
    gloss.addColorStop(0, 'rgba(255,255,255,0)')
    gloss.addColorStop(1, 'rgba(0,0,0,0.28)')
    ctx.beginPath()
    ctx.arc(center, center, radius, 0, 2 * Math.PI)
    ctx.fillStyle = gloss
    ctx.fill()

    // Golden outer rim
    ctx.beginPath()
    ctx.arc(center, center, radius, 0, 2 * Math.PI)
    ctx.strokeStyle = '#000000'
    ctx.lineWidth = 5
    ctx.stroke()

    // Studs on the rim
    for (let k = 0; k < 24; k++) {
      const a = (k * 15 * Math.PI) / 180
      ctx.beginPath()
      ctx.arc(center + (radius + 1) * Math.cos(a), center + (radius + 1) * Math.sin(a), 2.6, 0, 2 * Math.PI)
      ctx.fillStyle = k % 2 === 0 ? '#FFFFFF' : '#000000'
      ctx.fill()
    }

    // Inner decorative ring
    ctx.beginPath()
    ctx.arc(center, center, radius - 4, 0, 2 * Math.PI)
    ctx.strokeStyle = 'rgba(212,175,55,0.25)'
    ctx.lineWidth = 1.5
    ctx.stroke()

  }, [wheel])

  useEffect(() => {
    drawWheel()
  }, [drawWheel])

  const spin = async () => {
    if (!wheel || spinning) return
    const token = getAccessToken()
    if (!token) {
      setError('Connectez-vous pour tourner la roue !')
      return
    }
    setSpinning(true)
    setResult(null)
    setError('')

    try {
      const res = await fetch(API_ENDPOINTS.gamificationSpin, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Erreur lors du spin')
        setSpinning(false)
        return
      }

      // -- Correct rotation calculation --
      const segCount = wheel.segments.length
      const segAngle = 360 / segCount
      // Angle of the target segment center (clockwise from 12 o'clock)
      const segCenterAngle = data.segment_index * segAngle + segAngle / 2
      // To land the pointer on this segment: final rotation mod 360 = 360 - segCenterAngle
      const targetMod = ((360 - segCenterAngle) % 360 + 360) % 360
      const currentMod = ((rotation % 360) + 360) % 360
      // Delta to reach targetMod from currentMod
      let delta = targetMod - currentMod
      if (delta < 0) delta += 360
      // 6 full spins + precise delta
      const totalRotation = rotation + 360 * 6 + delta

      setRotation(totalRotation)

      setTimeout(() => {
        setResult(data)
        setSpinning(false)
        fetchWheel(token)
      }, 4500)
    } catch {
      setError('Erreur de connexion. Réessayez.')
      setSpinning(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin rounded-none h-12 w-12 border-b-2 border-black" />
      </div>
    )
  }

  if (error && !wheel) {
    return (
      <div className="text-center py-20">
        <div className="text-6xl mb-4">🎡</div>
        <p className="text-black/55">{error}</p>
      </div>
    )
  }

  if (!wheel || wheel.segments.length === 0) {
    return (
      <div className="text-center py-20">
        <div className="text-6xl mb-4">🎡</div>
        <p className="text-black/55">La roue de la chance sera bientôt disponible !</p>
      </div>
    )
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 grayscale">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-5xl font-bold uppercase tracking-[-0.025em] mb-3">Roue de la chance</h1>
        <p className="text-black/55 text-lg">Tentez votre chance et gagnez des récompenses exclusives !</p>
        {wheel.points_cost_per_spin > 0 && (
          <p className="text-sm text-black/55 mt-2">
            Coût par spin : {wheel.points_cost_per_spin} KikiPoints
          </p>
        )}
      </div>

      <div className="flex flex-col lg:flex-row items-center justify-center gap-16">
        {/* Wheel */}
        <div className="relative flex-shrink-0">
          {/* Pointer */}
          <div className="absolute top-[-8px] left-1/2 -translate-x-1/2 z-20">
            <div
              style={{
                width: 0,
                height: 0,
                borderLeft: '16px solid transparent',
                borderRight: '16px solid transparent',
                borderTop: '36px solid #000000',
                filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))',
              }}
            />
          </div>

          {/* Glow effect */}
          <div
            className="absolute inset-0 rounded-none pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(212,175,55,0.12) 0%, transparent 70%)',
              transform: 'scale(1.15)',
            }}
          />

          {/* Spinning canvas */}
          <div
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: spinning
                ? 'transform 4.5s cubic-bezier(0.17, 0.67, 0.12, 0.99)'
                : 'none',
            }}
          >
            <canvas ref={canvasRef} className="block" />
          </div>

          {/* Centre hub: brand logo on black, does not spin with the wheel */}
          <div
            className="absolute pointer-events-none rounded-none flex items-center justify-center overflow-hidden"
            style={{
              top: '50%',
              left: '50%',
              width: 84,
              height: 84,
              transform: 'translate(-50%, -50%)',
              background: '#000',
              border: '4px solid #000000',
              boxShadow: '0 4px 14px rgba(0,0,0,0.45)',
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icon.png" alt="" width={84} height={84} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col items-center gap-6 min-w-[280px]">
          {isLoggedIn ? (
            <>
              {wheel.spins_remaining !== undefined && (
                <div className="text-center bg-[#F5F5F5] rounded-none px-8 py-5 w-full">
                  <p className="text-5xl font-bold mb-1">{wheel.spins_remaining}</p>
                  <p className="text-sm text-black/55 uppercase tracking-wider">spins restants</p>
                </div>
              )}

              <button
                onClick={spin}
                disabled={spinning || wheel.can_spin === false}
                className="w-full px-10 py-4 text-lg font-bold tracking-widest text-white rounded-none shadow-xl transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:scale-105 hover: active:scale-95"
                style={{ backgroundColor: '#000000' }}
              >
                {spinning ? '🎡 EN COURS...' : '🎯 TOURNER LA ROUE'}
              </button>

              {wheel.can_spin === false && !spinning && (
                <p className="text-sm text-black text-center">
                  {wheel.spins_remaining === 0
                    ? "Vous avez utilisé tous vos spins aujourd'hui !"
                    : `Minimum ${wheel.min_points_to_spin} KikiPoints requis`}
                </p>
              )}
            </>
          ) : (
            <div className="text-center bg-[#F5F5F5] rounded-none p-8 w-full">
              <div className="text-4xl mb-3">🔒</div>
              <p className="text-black/55 mb-5">Connectez-vous pour tourner la roue !</p>
              <a
                href="/login"
                className="inline-block w-full px-8 py-3 bg-black text-white font-semibold rounded-none hover:bg-gray-800 transition-colors text-center"
              >
                Se connecter
              </a>
            </div>
          )}

          {error && (
            <div className="bg-[#F5F5F5] text-black px-5 py-3 rounded-none text-sm w-full text-center border border-black">
              {error}
            </div>
          )}

          {/* Result */}
          {result && (
            <div
              className={`p-6 rounded-none text-center w-full  ${
                result.prize_type !== 'nothing'
                  ? '   border border-black'
                  : 'bg-[#F5F5F5] border border-gray-200'
              }`}
              style={{ animation: 'bounceIn 0.5s ease-out' }}
            >
              <div className="text-5xl mb-3">
                {result.prize_type !== 'nothing' ? '🎉' : '😅'}
              </div>
              <h3 className="text-xl font-bold mb-2">
                {result.prize_type !== 'nothing' ? 'Félicitations !' : 'Pas de chance !'}
              </h3>
              <p className="text-gray-700">{result.message}</p>
              {result.prize_type !== 'nothing' && (
                <p className="mt-2 text-lg font-bold text-black">{result.prize_label}</p>
              )}
              {result.coupon_code && (
                <div className="mt-4 inline-block px-6 py-3 bg-white border-2 border-dashed border-black rounded-none">
                  <span className="text-xs text-black/55 block mb-1">Votre code promo</span>
                  <span className="text-xl font-mono font-bold text-black tracking-wider">
                    {result.coupon_code}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Prize Legend */}
      <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-3">
        {wheel.segments
          .filter((s) => s.prize_type !== 'nothing')
          .map((seg) => (
            <div key={seg.id} className="flex items-center gap-2 px-3 py-2 rounded-none bg-[#F5F5F5]">
              <div className="w-3 h-3 rounded-none flex-shrink-0" style={{ backgroundColor: '#000000' }} />
              <span className="text-sm text-gray-700">{seg.icon} {seg.label}</span>
            </div>
          ))}
      </div>

      {/* Rules */}
      <div className="mt-10 bg-[#F5F5F5] rounded-none p-8">
        <h2 className="text-lg font-bold mb-4">📋 Règles du jeu</h2>
        <ul className="space-y-2 text-sm text-black/55">
          <li>• Vous pouvez tourner la roue <strong>{wheel.spins_per_day}</strong> fois par jour</li>
          {wheel.min_points_to_spin > 0 && (
            <li>• Minimum <strong>{wheel.min_points_to_spin}</strong> KikiPoints requis</li>
          )}
          {wheel.points_cost_per_spin > 0 && (
            <li>• Chaque spin coûte <strong>{wheel.points_cost_per_spin}</strong> KikiPoints</li>
          )}
          <li>• Les réductions gagnées sont automatiquement ajoutées à votre compte</li>
          <li>• Les codes promo sont valables 30 jours</li>
          <li>• Les codes promo sont à utiliser lors du paiement</li>
        </ul>
      </div>

      <style jsx>{`
        @keyframes bounceIn {
          0% { transform: scale(0.3); opacity: 0; }
          50% { transform: scale(1.05); }
          70% { transform: scale(0.95); }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  )
}
