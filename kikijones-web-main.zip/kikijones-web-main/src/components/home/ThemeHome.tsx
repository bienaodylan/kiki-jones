'use client'

import React from 'react'
import { useRouter } from 'next/navigation'
import { Visual } from '@/lib/siteVisuals'

const P = 'px-6 py-2.5 rounded-full bg-white text-black text-[11px] font-bold uppercase tracking-[0.14em] hover:bg-white/90 transition-colors cursor-pointer whitespace-nowrap'
const S = 'px-6 py-2.5 rounded-full bg-white/15 backdrop-blur-sm border border-white/80 text-white text-[11px] font-bold uppercase tracking-[0.14em] hover:bg-white hover:text-black transition-colors cursor-pointer whitespace-nowrap'
const H2 = 'text-3xl sm:text-5xl font-bold uppercase tracking-[-0.025em] text-white leading-[1.02]'
const EYEBROW = 'text-[10.5px] font-bold uppercase tracking-[0.22em] text-white/75'
const IMG = 'w-full h-full object-cover object-top transition-transform duration-700 ease-out'

/** Home page: the theme's homepage, section by section. Every image and text comes from "Visuels du site" in the admin. */
export default function ThemeHome({ visuals }: { visuals: Record<string, Visual> }) {
  const router = useRouter()
  const v = (k: string): Visual => visuals[k]
  const go = (link: string) => router.push(link || '/produits')
  const stop = (e: React.MouseEvent, link: string) => { e.stopPropagation(); go(link) }
  const Btns = ({ x, stopProp }: { x: Visual; stopProp?: boolean }) => (
    <div className="pt-1 flex flex-wrap items-center gap-3">
      {x.button_label && <button type="button" onClick={(e) => (stopProp ? stop(e, x.button_link) : go(x.button_link))} className={P}>{x.button_label}</button>}
      {x.button2_label && <button type="button" onClick={(e) => (stopProp ? stop(e, x.button2_link) : go(x.button2_link))} className={S}>{x.button2_label}</button>}
    </div>
  )
  const hero = v('home_hero'), hero2 = v('home_hero_2')
  const nw = v('home_new'), men = v('home_men'), sc = v('home_sculpt'), lx = v('home_luxe'), kd = v('home_kids'), sp = v('home_sport')
  const cats = [v('home_cat_1'), v('home_cat_2'), v('home_cat_3'), v('home_cat_4')]
  const brands = [1, 2, 3, 4, 5, 6].map((i) => v(`home_brand_${i}`))

  return (
    <main className="w-full max-w-full overflow-x-clip bg-white">
      {/* HERO (split) */}
      <section className="relative w-full overflow-hidden bg-black h-screen min-h-[620px]">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 h-full w-full">
          <div className="relative h-full w-full overflow-hidden bg-black"><img src={hero.image} alt={hero.title} className="w-full h-full object-cover object-top" /></div>
          <div className="relative hidden md:block h-full w-full overflow-hidden bg-black"><img src={hero2.image} alt="" className="w-full h-full object-cover object-top" /></div>
        </div>
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30" />
        <div className="absolute bottom-8 left-5 right-5 md:bottom-12 md:left-10 md:right-10 z-20 max-w-xl space-y-3">
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold uppercase tracking-[-0.025em] text-white leading-[1.0]">{hero.title}</h1>
          {hero.text && <p className="text-xs sm:text-sm font-light text-white/85 leading-relaxed max-w-md">{hero.text}</p>}
          <Btns x={hero} />
        </div>
      </section>

      {/* NEW ARRIVALS (3 photos) */}
      <section className="w-full bg-black">
        <div onClick={() => go(nw.button_link)} className="group relative w-full overflow-hidden bg-black cursor-pointer">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
            <div className="relative aspect-[3/4] md:aspect-[4/5] w-full overflow-hidden bg-black"><img src={nw.image} alt={nw.title} className={`${IMG} group-hover:scale-[1.03]`} /></div>
            <div className="relative hidden md:block aspect-[4/5] w-full overflow-hidden bg-black"><img src={v('home_new_2').image} alt="" className={`${IMG} group-hover:scale-[1.03]`} /></div>
            <div className="relative hidden md:block aspect-[4/5] w-full overflow-hidden bg-black"><img src={v('home_new_3').image} alt="" className={`${IMG} group-hover:scale-[1.03]`} /></div>
          </div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
          <div className="absolute bottom-8 left-5 right-5 md:bottom-12 md:left-10 z-10 max-w-lg space-y-3">
            {nw.eyebrow && <p className={EYEBROW}>{nw.eyebrow}</p>}
            <h2 className={H2}>{nw.title}</h2>
            <Btns x={nw} stopProp />
          </div>
        </div>
      </section>

      {/* CATEGORY STRIP (4 photo tiles) */}
      <section className="w-full bg-black">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-0">
          {cats.map((c, i) => (
            <button key={i} type="button" onClick={() => go(c.button_link)} className="group relative aspect-[3/4] w-full overflow-hidden bg-black text-left cursor-pointer border-r border-white/10 last:border-r-0">
              <img src={c.image} alt={c.title} className={`${IMG} group-hover:scale-[1.04]`} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 md:bottom-7 md:left-6">
                <span className="text-xs sm:text-sm font-bold uppercase tracking-[0.14em] text-white underline decoration-white/75 underline-offset-[6px] group-hover:decoration-white">{c.title}</span>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* KIKI MEN (split) */}
      <section className="w-full bg-black">
        <div onClick={() => go(men.button_link)} className="group relative w-full cursor-pointer overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            <div className="relative aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black"><img src={men.image} alt={men.title} className={`${IMG} group-hover:scale-[1.02]`} /></div>
            <div className="relative hidden md:block aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black"><img src={v('home_men_2').image} alt="" className={`${IMG} group-hover:scale-[1.02]`} /></div>
          </div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
          <div className="absolute bottom-8 left-5 right-5 md:bottom-12 md:left-10 z-10 max-w-lg space-y-3">
            {men.eyebrow && <p className={EYEBROW}>{men.eyebrow}</p>}
            <h2 className={H2}>{men.title}</h2>
            <Btns x={men} stopProp />
          </div>
        </div>
      </section>

      {/* SCULPT & CURVE (triptych) */}
      <section className="w-full bg-black">
        <div className="relative w-full overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
            <div onClick={() => go(sc.button_link)} className="group relative aspect-[3/4] w-full overflow-hidden bg-black cursor-pointer"><img src={sc.image} alt={sc.title} className={`${IMG} group-hover:scale-[1.03]`} /></div>
            <div onClick={() => go(sc.button_link)} className="group relative hidden md:block aspect-[3/4] w-full overflow-hidden bg-black cursor-pointer"><img src={v('home_sculpt_2').image} alt="" className={`${IMG} group-hover:scale-[1.03]`} /></div>
            <div onClick={() => go(sc.button2_link)} className="group relative hidden md:block aspect-[3/4] w-full overflow-hidden bg-black cursor-pointer"><img src={v('home_sculpt_3').image} alt="" className={`${IMG} group-hover:scale-[1.03]`} /></div>
          </div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
          <div className="absolute bottom-8 left-5 right-5 md:bottom-12 md:left-10 z-10 max-w-lg space-y-3">
            {sc.eyebrow && <p className={EYEBROW}>{sc.eyebrow}</p>}
            <h2 className={H2}>{sc.title}</h2>
            <Btns x={sc} />
          </div>
        </div>
      </section>

      {/* KIKI LUXE */}
      <section className="w-full bg-black">
        <div onClick={() => go(lx.button_link)} className="group relative w-full overflow-hidden bg-black cursor-pointer">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            <div className="relative aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black"><img src={lx.image} alt={lx.title} className={`${IMG} group-hover:scale-[1.02]`} /></div>
            <div className="relative hidden md:block aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black"><img src={v('home_luxe_2').image} alt="" className={`${IMG} group-hover:scale-[1.02]`} /></div>
          </div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
          <div className="absolute bottom-8 left-5 right-5 md:bottom-12 md:left-10 z-10 max-w-lg space-y-3">
            {lx.eyebrow && <p className={EYEBROW}>{lx.eyebrow}</p>}
            <h2 className={H2}>{lx.title}</h2>
            <Btns x={lx} stopProp />
          </div>
        </div>
      </section>

      {/* KIDS | SPORT */}
      <section className="w-full bg-black">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          <div onClick={() => go(kd.button_link)} className="group relative aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black cursor-pointer md:border-r md:border-white/10">
            <img src={kd.image} alt={kd.title} className={`${IMG} group-hover:scale-[1.03]`} />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute bottom-8 left-6 right-6 md:bottom-12 md:left-10 space-y-3">
              {kd.eyebrow && <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/75">{kd.eyebrow}</p>}
              <h2 className="text-3xl sm:text-4xl font-bold uppercase tracking-[-0.02em] text-white leading-tight">{kd.title}</h2>
              <Btns x={kd} stopProp />
            </div>
          </div>
          <div onClick={() => go(sp.button_link)} className="group relative aspect-[4/5] md:aspect-[5/6] w-full overflow-hidden bg-black cursor-pointer">
            <img src={sp.image} alt={sp.title} className={`${IMG} group-hover:scale-[1.03]`} />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute bottom-8 left-6 right-6 md:bottom-12 md:left-10 space-y-3">
              {sp.eyebrow && <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/75">{sp.eyebrow}</p>}
              <h2 className="text-3xl sm:text-4xl font-bold uppercase tracking-[-0.02em] text-white leading-tight">{sp.title}</h2>
              <Btns x={sp} stopProp />
            </div>
          </div>
        </div>
      </section>

      {/* SHOP BY BRAND */}
      <section className="w-full bg-white text-black py-10 md:py-14">
        <div className="w-full px-4 sm:px-6 lg:px-10 mb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div className="space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-black/45">KIKI JONES · Nos Maisons</p>
            <h2 className="text-xl sm:text-2xl font-bold uppercase tracking-[0.04em] text-black">Acheter par Marque</h2>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={() => go('/brands')} className="shrink-0 whitespace-nowrap px-4 sm:px-5 py-2 rounded-full border border-black text-[10.5px] font-bold uppercase tracking-[0.14em] text-black hover:bg-black hover:text-white transition-colors cursor-pointer">Toutes les marques</button>
            <button type="button" onClick={() => go('/categories')} className="shrink-0 whitespace-nowrap px-4 sm:px-5 py-2 rounded-full bg-black text-white text-[10.5px] font-bold uppercase tracking-[0.14em] hover:bg-black/85 transition-colors cursor-pointer">Toutes les catégories</button>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 px-4 sm:px-6 lg:px-10">
          {brands.map((b, i) => (
            <button key={i} type="button" onClick={() => go(b.button_link)} className="group text-left cursor-pointer flex flex-col">
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#F5F5F5]"><img src={b.image} alt={b.title} className={`${IMG} group-hover:scale-[1.04]`} /></div>
              <div className="pt-2.5 space-y-0.5">
                <p className="text-xs font-bold uppercase tracking-[0.12em] text-black group-hover:underline underline-offset-4">{b.title}</p>
                <p className="text-[11px] font-light text-black/55 line-clamp-1">{b.text}</p>
              </div>
            </button>
          ))}
        </div>
      </section>
    </main>
  )
}
