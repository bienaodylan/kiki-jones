import { getNewArrivals, Product } from '@/lib/api'
import { SectionConfig } from '@/lib/api/cms'
import NewArrivalsClient from './NewArrivalsClient'

interface NewArrivalsProps {
  initialConfig?: SectionConfig
}

export default async function NewArrivals({ initialConfig }: NewArrivalsProps) {
  let products: Product[] = []
  
  try {
    products = await getNewArrivals(10)
  } catch (error) {
    console.error('Failed to fetch new arrivals:', error)
  }

  return <NewArrivalsClient products={products} initialConfig={initialConfig} />
}
