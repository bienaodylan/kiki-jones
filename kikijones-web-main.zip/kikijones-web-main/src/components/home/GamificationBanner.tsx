'use client'

import { Trophy } from 'lucide-react'
import CmsText from '@/components/ui/CmsText'
import Link from 'next/link'
import { SectionConfig } from '@/lib/api/cms'

interface GamificationBannerProps {
  initialConfig?: SectionConfig
}

export default function GamificationBanner({ initialConfig }: GamificationBannerProps) {
  // Ne pas afficher si désactivé
  if (initialConfig && !initialConfig.is_active) {
    return null
  }

  const title = initialConfig?.title || 'GAGNEZ DES KIKIPOINTS'
  const subtitle = initialConfig?.subtitle || 'Accumulez des points, débloquez des badges et profitez de récompenses exclusives'

  return (
    <section className="bg-white text-black py-16" style={initialConfig?.spacing_styles}>
      <div className="container-custom text-center">
        <Trophy className="mx-auto mb-6" size={48} strokeWidth={1.5} />
        <h2 
          className="text-black mb-4 text-3xl font-black uppercase tracking-wider"
          style={initialConfig?.title_styles as React.CSSProperties}
        >
          <CmsText text={title} />
        </h2>
        <p 
          className="text-gray-600 mb-8 max-w-2xl mx-auto uppercase tracking-wide text-sm"
          style={initialConfig?.subtitle_styles as React.CSSProperties}
        >
          <CmsText text={subtitle} />
        </p>
        <div className="flex justify-center items-center space-x-12 mb-8">
          <div>
            <div className="text-4xl font-black mb-2">+100</div>
            <div className="text-xs uppercase tracking-wider text-gray-600">Points inscription</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-2">-20%</div>
            <div className="text-xs uppercase tracking-wider text-gray-600">Réduction VIP</div>
          </div>
          <div>
            <div className="text-4xl font-black mb-2">🏆</div>
            <div className="text-xs uppercase tracking-wider text-gray-600">Cadeaux exclusifs</div>
          </div>
        </div>
        <Link href="/register" className="inline-block bg-black text-white px-8 py-4 font-bold uppercase tracking-wider text-sm hover:bg-gray-800 transition-colors">
          Créer mon compte
        </Link>
      </div>
    </section>
  )
}
