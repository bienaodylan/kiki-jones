'use client'

import Link from 'next/link'
import CmsText from '@/components/ui/CmsText'
import { Product } from '@/lib/api'
import { SectionConfig } from '@/lib/api/cms'
import ProductCard from '@/components/products/ProductCard'

interface TrendingClientProps {
  products: Product[]
  initialConfig?: SectionConfig
}

export default function TrendingClient({ products, initialConfig }: TrendingClientProps) {
  if (!products.length) return null
  if (initialConfig && !initialConfig.is_active) return null

  const title = initialConfig?.title || 'LES PLUS VENDUS'

  return (
    <section className="w-full bg-white text-black py-10 md:py-14 border-b border-black/10" style={initialConfig?.spacing_styles}>
      <div className="w-full px-4 sm:px-6 lg:px-10 mb-5 flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-black/45">Les plus demandés</p>
          <h2
            className="text-xl sm:text-2xl font-bold uppercase tracking-[0.04em] text-black mt-0.5"
            style={initialConfig?.title_styles as React.CSSProperties}
          >
            <CmsText text={title} />
          </h2>
        </div>
        <Link
          href="/produits"
          className="shrink-0 whitespace-nowrap px-4 sm:px-5 py-2 rounded-full border border-black text-[10.5px] font-bold uppercase tracking-[0.14em] text-black hover:bg-black hover:text-white transition-colors"
        >
          Voir tout
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-x-2 gap-y-4 px-4 sm:px-6 lg:px-10">
        {products.slice(0, 8).map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  )
}
