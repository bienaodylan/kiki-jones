import { getTrendingProducts, Product } from '@/lib/api'
import { SectionConfig } from '@/lib/api/cms'
import TrendingClient from './TrendingClient'

interface TrendingProps {
  initialConfig?: SectionConfig
}

export default async function Trending({ initialConfig }: TrendingProps) {
  let products: Product[] = []
  
  try {
    products = await getTrendingProducts(8)
  } catch (error) {
    console.error('Failed to fetch trending products:', error)
  }

  return <TrendingClient products={products} initialConfig={initialConfig} />
}
