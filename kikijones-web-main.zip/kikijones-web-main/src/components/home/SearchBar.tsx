'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Search, Camera } from 'lucide-react'

export default function SearchBar() {
  const [query, setQuery] = useState('')
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      router.push(`/produits?search=${encodeURIComponent(query.trim())}`)
    }
  }

  return (
    <div className="bg-white border-b border-gray-100">
      <div className="container-custom py-3">
        <form onSubmit={handleSubmit} className="flex items-center bg-gray-50 rounded-lg px-4 py-2.5 hover:bg-gray-100 transition-colors">
          <Search size={20} strokeWidth={1.5} className="text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher des articles..."
            className="flex-1 ml-3 bg-transparent outline-none text-sm placeholder:text-gray-400"
          />
          <button type="submit" className="p-1 hover:bg-gray-200 rounded transition-colors">
            <Search size={20} strokeWidth={1.5} className="text-black" />
          </button>
        </form>
      </div>
    </div>
  )
}
