'use client'

import Link from 'next/link'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useState, useEffect } from 'react'
import { Banner } from '@/lib/api'

interface HeroClientProps {
  slides: Banner[]
}

export default function HeroClient({ slides }: HeroClientProps) {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    if (slides.length === 0) return
    
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 6000)
    return () => clearInterval(timer)
  }, [slides.length])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  if (slides.length === 0) {
    return (
      <section className="relative h-screen flex items-center justify-center bg-black">
        <div className="text-white text-xl">Aucune bannière disponible</div>
      </section>
    )
  }

  return (
    <section className="relative h-[82svh] min-h-[480px] md:h-screen overflow-hidden bg-black">
      {/* Slides */}
      {slides.map((slide, index) => {
        const imageUrl = slide.image_desktop || slide.image_tablet || slide.image_mobile || ''
        const textAlign = slide.text_position === 'center' ? 'text-center mx-auto' : 
                          slide.text_position === 'right' ? 'ml-auto text-right' : ''
        
        return (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ backgroundColor: slide.background_color }}
          >
            {imageUrl && (
            <Image
              src={imageUrl}
              alt={slide.title}
              fill
              className="object-cover"
              priority={index === 0}
            />
            )}
            <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-black/75 via-black/25 md:from-black/50 md:via-black/20 to-transparent" />
            
            <div className="relative h-full flex items-end md:items-center pb-16 md:pb-0">
              <div className="container-custom w-full">
                <div className={`max-w-2xl ${textAlign}`}>
                  <h1 
                    className="text-4xl sm:text-5xl md:text-7xl font-bold mb-3 md:mb-4 tracking-tight leading-tight"
                    style={{ 
                      color: slide.text_color,
                      fontWeight: 700,
                      letterSpacing: '-0.02em'
                    }}
                  >
                    {slide.title}
                  </h1>
                  {slide.subtitle && (
                    <p 
                      className="text-base md:text-lg mb-8 font-normal max-w-xl"
                      style={{ 
                        color: slide.text_color, 
                        opacity: 0.85,
                        letterSpacing: '0.01em',
                        lineHeight: '1.6'
                      }}
                    >
                      {slide.subtitle}
                    </p>
                  )}
                  {slide.button_text && slide.link_url && (
                    <Link 
                      href={slide.link_url} 
                      className="inline-block bg-white text-black rounded-full px-6 md:px-8 py-3 md:py-4 text-sm font-black uppercase tracking-widest hover:bg-black hover:text-white border-2 border-[#c8102e] hover:border-black transition-all duration-300"
                    >
                      {slide.button_text}
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>
        )
      })}

      {/* Navigation Arrows */}
      {slides.length > 1 && (
        <>
          <button 
            onClick={prevSlide}
            className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center transition-all z-10"
          >
            <ChevronLeft className="text-white" size={24} strokeWidth={2} />
          </button>
          <button 
            onClick={nextSlide}
            className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 hover:bg-white/40 backdrop-blur-sm rounded-full flex items-center justify-center transition-all z-10"
          >
            <ChevronRight className="text-white" size={24} strokeWidth={2} />
          </button>

          {/* Slide Indicators */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentSlide ? 'bg-white w-8' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        </>
      )}
    </section>
  )
}
