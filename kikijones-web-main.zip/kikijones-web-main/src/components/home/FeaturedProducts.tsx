import { getFeaturedProducts, Product } from '@/lib/api'
import { SectionConfig, getFeaturedFilterTabs, FeaturedFilterTab } from '@/lib/api/cms'
import FeaturedProductsClient from './FeaturedProductsClient'

interface FeaturedProductsProps {
  initialConfig?: SectionConfig
}

export default async function FeaturedProducts({ initialConfig }: FeaturedProductsProps) {
  let products: Product[] = []
  let filterTabs: FeaturedFilterTab[] = []
  
  try {
    const [productsResult, tabsResult] = await Promise.all([
      getFeaturedProducts(12),
      getFeaturedFilterTabs('web')
    ])
    products = productsResult
    filterTabs = tabsResult
  } catch (error) {
    console.error('Failed to fetch featured products or filter tabs:', error)
  }

  return <FeaturedProductsClient products={products} initialConfig={initialConfig} filterTabs={filterTabs} />
}
