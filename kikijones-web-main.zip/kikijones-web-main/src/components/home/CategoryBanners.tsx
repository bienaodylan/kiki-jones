'use client'

import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { useState, useEffect } from 'react'
import { getBanners, Banner } from '@/lib/api'
import type { SectionConfig } from '@/lib/api/cms'

interface CategoryBannersProps {
  categorySlug?: string
  initialConfig?: SectionConfig
}

export default function CategoryBanners({ categorySlug, initialConfig }: CategoryBannersProps) {
  const [banners, setBanners] = useState<Banner[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Récupérer les bannières filtrées par catégorie
    const fetchBanners = async () => {
      try {
        const data = await getBanners('category', 'web', categorySlug)
        setBanners(data)
      } catch (error) {
        console.error('Failed to fetch category banners:', error)
      } finally {
        setIsLoading(false)
      }
    }
    
    fetchBanners()
  }, [categorySlug])

  if (initialConfig && !initialConfig.is_active) {
    return null
  }

  if (isLoading || !banners.length) {
    return null
  }

  return (
    <section className="bg-white py-6 md:py-10">
      <div className="container-custom">
        {initialConfig?.title && (
          <div style={initialConfig.spacing_styles as React.CSSProperties} className="mb-6">
            <h2 style={initialConfig.title_styles as React.CSSProperties}>{initialConfig.title}</h2>
            {initialConfig.subtitle && (
              <p style={initialConfig.subtitle_styles as React.CSSProperties}>{initialConfig.subtitle}</p>
            )}
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-3">
          {banners.slice(0, 3).map((banner) => {
            const imageUrl = banner.image_mobile || banner.image_tablet || banner.image_desktop
            
            return (
              <Link
                key={banner.id}
                href={banner.link_url || '#'}
                className="group relative h-[350px] overflow-hidden cursor-pointer"
              >
                {/* Image de fond */}
                <Image
                  src={imageUrl}
                  alt={banner.title}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
                
                {/* Contenu */}
                <div 
                  className="absolute inset-0 p-8 flex flex-col justify-end"
                  style={{ color: banner.text_color }}
                >
                  <h3 className="text-3xl font-bold mb-2 uppercase tracking-wider">
                    {banner.title}
                  </h3>
                  {banner.subtitle && (
                    <p className="mb-4 text-sm uppercase tracking-wide" style={{ opacity: 0.9 }}>
                      {banner.subtitle}
                    </p>
                  )}
                  {banner.button_text && (
                    <span className="flex items-center gap-2 bg-white text-black rounded-full px-6 py-3 font-bold w-fit hover:bg-black hover:text-white transition-colors uppercase tracking-wider text-sm">
                      {banner.button_text}
                      <ArrowRight className="w-4 h-4" strokeWidth={2} />
                    </span>
                  )}
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
