import Link from 'next/link'

/** Full-width red strip under the hero (like the reference): the offer of the day + a link. */
export default function PromoStrip() {
  return (
    <Link
      href="/produits"
      className="flex items-center justify-between gap-4 bg-black text-white px-4 md:px-8 py-4 md:py-5"
    >
      <span className="text-lg md:text-3xl font-black uppercase leading-tight tracking-tight">
        Livraison gratuite dès 50 000 FCFA
      </span>
      <span className="shrink-0 text-xs md:text-sm font-bold uppercase tracking-wide">Acheter &gt;</span>
    </Link>
  )
}
