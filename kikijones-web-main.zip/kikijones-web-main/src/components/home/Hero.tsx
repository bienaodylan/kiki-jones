import { getHeroBanners } from '@/lib/api'
import HeroClient from './HeroClient'

// Fallback slides if API fails
const fallbackSlides = [
  {
    id: '1',
    title: 'NOUVEAUTÉS',
    subtitle: 'Les dernières tendances qui font sensation',
    button_text: 'DÉCOUVRIR',
    link_url: '/nouveautes',
    image_desktop: '/images/hero-fallback.jpg',
    text_position: 'left' as const,
    text_color: '#ffffff',
    background_color: '#000000',
    banner_type: 'hero' as const,
    platform: 'both' as const,
    display_order: 1,
    is_active: true
  }
]

export default async function Hero({ categorySlug }: { categorySlug?: string } = {}) {
  let slides
  
  try {
    slides = await getHeroBanners(categorySlug)
    if (!slides || slides.length === 0) {
      slides = fallbackSlides as any
    }
  } catch (error) {
    console.error('Failed to fetch hero banners:', error)
    slides = fallbackSlides as any
  }

  return <HeroClient slides={slides} />
}
