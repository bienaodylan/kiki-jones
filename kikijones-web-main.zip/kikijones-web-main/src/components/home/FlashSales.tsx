'use client'

import Link from 'next/link'
import CmsText from '@/components/ui/CmsText'
import Image from 'next/image'
import { useState, useEffect } from 'react'
import { useCurrency } from '@/contexts/CurrencyContext'
import { getOnSaleProducts, Product } from '@/lib/api'
import { SectionConfig } from '@/lib/api/cms'
import CountdownTimer from '@/components/ui/CountdownTimer'

interface FlashSalesProps {
  initialConfig?: SectionConfig
}

export default function FlashSales({ initialConfig }: FlashSalesProps) {
  const { formatPrice } = useCurrency()
  const [products, setProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)
  
  useEffect(() => {
    async function loadProducts() {
      try {
        const saleProducts = await getOnSaleProducts(6)
        setProducts(saleProducts)
      } catch (error) {
        console.error('Error loading flash sale products:', error)
      } finally {
        setIsLoading(false)
      }
    }
    
    loadProducts()
  }, [])
  
  // Ne pas afficher si désactivé dans le CMS
  if (initialConfig && !initialConfig.is_active) {
    return null
  }
  
  // Nothing on sale: hide the whole block instead of showing an empty black band
  if (!isLoading && products.length === 0) {
    return null
  }

  const title = initialConfig?.title || 'VENTE FLASH'
  const subtitle = initialConfig?.subtitle || 'SE TERMINE DANS'
  
  return (
    <section 
      className="bg-black text-white py-16"
      style={initialConfig?.spacing_styles}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 
              style={initialConfig?.title_styles ? {
                fontFamily: initialConfig.title_styles.fontFamily,
                fontSize: initialConfig.title_styles.fontSize,
                fontWeight: initialConfig.title_styles.fontWeight,
                color: initialConfig.title_styles.color,
                textAlign: initialConfig.title_styles.textAlign as 'left' | 'center' | 'right',
              } : undefined}
              className={!initialConfig ? 'text-4xl md:text-5xl font-black uppercase tracking-tighter' : 'uppercase tracking-tighter'}
            >
              <CmsText text={title} />
            </h2>
            {initialConfig?.countdown_enabled && initialConfig?.countdown_end_date ? (
              <div className="flex items-center gap-3 mt-3">
                <span 
                  style={initialConfig?.subtitle_styles ? {
                    fontFamily: initialConfig.subtitle_styles.fontFamily,
                    fontSize: initialConfig.subtitle_styles.fontSize,
                    fontWeight: initialConfig.subtitle_styles.fontWeight,
                    color: initialConfig.subtitle_styles.color,
                  } : undefined}
                  className={!initialConfig ? 'text-sm text-gray-400 uppercase tracking-wider' : 'uppercase tracking-wider'}
                >
                  <CmsText text={subtitle} />
                </span>
                <CountdownTimer endDate={initialConfig.countdown_end_date} />
              </div>
            ) : (
              <p 
                style={initialConfig?.subtitle_styles ? {
                  fontFamily: initialConfig.subtitle_styles.fontFamily,
                  fontSize: initialConfig.subtitle_styles.fontSize,
                  fontWeight: initialConfig.subtitle_styles.fontWeight,
                  color: initialConfig.subtitle_styles.color,
                } : undefined}
                className={!initialConfig ? 'text-sm text-gray-400 uppercase tracking-wider mt-3' : 'uppercase tracking-wider mt-3'}
              >
                <CmsText text={subtitle} />
              </p>
            )}
          </div>
          <Link href="/promotions" className="hidden md:block text-sm font-bold uppercase tracking-wider border-b-2 border-white hover:text-gray-300 hover:border-gray-300 transition-colors">
            VOIR TOUT
          </Link>
        </div>
        
        {isLoading ? (
          <div className="flex gap-2 md:gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex-shrink-0 w-[160px] md:w-[200px] lg:w-[220px] bg-gray-800 animate-pulse">
                <div className="w-full aspect-[3/4] bg-gray-700"></div>
                <div className="p-3">
                  <div className="h-4 bg-gray-700 rounded mb-2"></div>
                  <div className="h-3 bg-gray-700 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : products.length > 0 ? (
          <div className="overflow-x-scroll scrollbar-hide -mx-4 px-4">
            <div className="flex gap-2 md:gap-3">
              {products.map((product) => (
                <Link 
                  href={`/produits/${product.slug}`} 
                  key={product.id}
                  className="group relative overflow-hidden bg-white flex-shrink-0 w-[160px] md:w-[200px] lg:w-[220px]"
                >
                  <div className="relative w-full aspect-[3/4] overflow-hidden">
                    <Image
                      src={product.main_image || '/placeholder.jpg'}
                      alt={product.name}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {product.discount_percentage > 0 && (
                      <div className="absolute top-2 right-2 bg-black text-white text-xs font-bold px-2 py-1 uppercase">
                        -{Math.round(product.discount_percentage)}%
                      </div>
                    )}
                  </div>
                  <div className="p-3 bg-white text-black">
                    <h3 className="text-xs font-bold uppercase tracking-wide mb-1 truncate">{product.name}</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold">{formatPrice(parseFloat(product.sale_price || product.base_price))}</span>
                      {product.sale_price && (
                        <span className="text-xs text-gray-500 line-through">{formatPrice(parseFloat(product.base_price))}</span>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-400 py-8">
            Aucune promotion disponible pour le moment
          </div>
        )}

        <Link href="/promotions" className="block md:hidden text-center text-sm font-bold uppercase tracking-wider border border-white py-3 mt-6 hover:bg-white hover:text-black transition-all">
          VOIR TOUS LES PRODUITS
        </Link>
      </div>
    </section>
  )
}
