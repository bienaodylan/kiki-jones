'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Percent, Truck, ShieldCheck, ArrowRight } from 'lucide-react'
import { useState, useEffect } from 'react'
import { getPromoBanners, Banner } from '@/lib/api'
import type { SectionConfig } from '@/lib/api/cms'

export default function PromoBanners({ initialConfig }: { initialConfig?: SectionConfig }) {
  const [banners, setBanners] = useState<Banner[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    getPromoBanners()
      .then((data) => {
        setBanners(data)
      })
      .catch((error) => {
        console.error('Failed to fetch promo banners:', error)
      })
      .finally(() => {
        setIsLoading(false)
      })
  }, [])

  if (initialConfig && !initialConfig.is_active) {
    return null
  }

  if (isLoading || !banners.length) {
    return null
  }

  // Prendre jusqu'à 3 banners (1 large, 2 small)
  const largeBanner = banners[0]
  const smallBanners = banners.slice(1, 3)

  return (
    <section className="w-full bg-black">
      <div>
        {initialConfig?.title && (
          <div style={initialConfig.spacing_styles as React.CSSProperties} className="mb-6">
            <h2 style={{ ...(initialConfig.title_styles as React.CSSProperties), color: initialConfig.title_color === '#000000' ? '#ffffff' : initialConfig.title_color }}>{initialConfig.title}</h2>
            {initialConfig.subtitle && (
              <p style={{ ...(initialConfig.subtitle_styles as React.CSSProperties), color: initialConfig.subtitle_color === '#666666' ? '#d1d5db' : initialConfig.subtitle_color }}>{initialConfig.subtitle}</p>
            )}
          </div>
        )}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
          {/* Large Banner */}
          {largeBanner && (
            <Link
              href={largeBanner.link_url || '#'}
              className="group relative aspect-[4/5] md:aspect-[5/6] lg:aspect-auto lg:h-full min-h-[420px] overflow-hidden cursor-pointer"
            >
              {/* Image de fond */}
              <Image
                src={largeBanner.image_mobile || largeBanner.image_tablet || largeBanner.image_desktop}
                alt={largeBanner.title}
                fill
                className="object-cover object-top group-hover:scale-[1.03] transition-transform duration-700"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
              
              {/* Contenu */}
              <div 
                className="absolute inset-x-0 bottom-0 p-6 md:p-10 flex flex-col justify-end space-y-2"
                style={{ color: largeBanner.text_color }}
              >
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold uppercase tracking-[-0.02em] leading-tight text-white">
                  {largeBanner.title}
                </h2>
                {largeBanner.subtitle && (
                  <p className="text-sm md:text-base font-light text-white/85">
                    {largeBanner.subtitle}
                  </p>
                )}
                {largeBanner.description && (
                  <p className="text-xs font-light text-white/85 max-w-md">
                    {largeBanner.description}
                  </p>
                )}
                {largeBanner.button_text && (
                  <span className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-white text-black text-[11px] font-bold uppercase tracking-[0.14em] w-fit hover:bg-white/90 transition-colors">
                    {largeBanner.button_text}
                    <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
                  </span>
                )}
              </div>
            </Link>
          )}
          
          {/* Small Banners */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-0">
            {smallBanners.map((banner) => (
              <Link
                key={banner.id}
                href={banner.link_url || '#'}
                className="group relative aspect-[4/3] lg:aspect-auto lg:h-[50%] min-h-[220px] overflow-hidden cursor-pointer"
              >
                {/* Image de fond */}
                <Image
                  src={banner.image_mobile || banner.image_tablet || banner.image_desktop}
                  alt={banner.title}
                  fill
                  className="object-cover object-top group-hover:scale-[1.03] transition-transform duration-700"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
                
                {/* Contenu */}
                <div 
                  className="absolute inset-0 p-6 flex flex-col justify-center"
                  style={{ color: banner.text_color }}
                >
                  <h3 className="text-xl font-bold uppercase tracking-[-0.01em] text-white">
                    {banner.title}
                  </h3>
                  {banner.subtitle && (
                    <p className="text-xs font-light text-white/85">
                      {banner.subtitle}
                    </p>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}