'use client'

import Link from 'next/link'
import CmsText from '@/components/ui/CmsText'
import Image from 'next/image'
import { Heart, ShoppingBag } from 'lucide-react'
import { useState } from 'react'
import { Product } from '@/lib/api'
import { useCurrency } from '@/contexts/CurrencyContext'
import { SectionConfig, FeaturedFilterTab } from '@/lib/api/cms'

interface FeaturedProductsClientProps {
  products: Product[]
  initialConfig?: SectionConfig
  filterTabs?: FeaturedFilterTab[]
}

export default function FeaturedProductsClient({ products, initialConfig, filterTabs }: FeaturedProductsClientProps) {
  const [activeFilter, setActiveFilter] = useState('all')
  const { formatPrice } = useCurrency()

  // Use CMS filter tabs if available, otherwise fall back to hardcoded
  const defaultFilters = ['All', 'New In', 'Sale', 'Dresses', 'Jeans', 'Sets', 'Tops', 'Bags', 'Shoes']
  const hasCmsTabs = filterTabs && filterTabs.length > 0

  // Filter products based on active filter
  const filteredProducts = (() => {
    if (activeFilter === 'all') return products
    
    if (hasCmsTabs) {
      const activeTab = filterTabs.find(t => t.slug === activeFilter)
      if (!activeTab) return products
      
      switch (activeTab.filter_type) {
        case 'all':
          return products
        case 'new':
          return products.filter(p => p.is_new)
        case 'sale':
          return products.filter(p => p.sale_price)
        case 'category':
          return activeTab.category_name 
            ? products.filter(p => p.category_name.toLowerCase().includes(activeTab.category_name!.toLowerCase()))
            : products
        default:
          return products
      }
    } else {
      // Fallback: hardcoded filter logic
      if (activeFilter === 'new in') return products.filter(p => p.is_new)
      if (activeFilter === 'sale') return products.filter(p => p.sale_price)
      return products.filter(p => p.category_name.toLowerCase().includes(activeFilter.toLowerCase()))
    }
  })()

  if (!products.length) return null

  // Ne pas afficher si désactivé
  if (initialConfig && !initialConfig.is_active) {
    return null
  }

  const subtitle = initialConfig?.subtitle || 'TRENDING NOW'
  const title = initialConfig?.title || 'FEATURED PICKS'

  return (
    <section className="fashion-nova-section bg-white" style={initialConfig?.spacing_styles}>
      <div className="container-custom">
        <div className="text-center mb-8">
          <p 
            className="fashion-nova-subtitle text-gray-500"
            style={initialConfig?.subtitle_styles as React.CSSProperties}
          >
            <CmsText text={subtitle} />
          </p>
          <h2 
            className="fashion-nova-title"
            style={initialConfig?.title_styles as React.CSSProperties}
          >
            <CmsText text={title} />
          </h2>
        </div>

        {/* Filter Tabs - Horizontally scrollable on mobile */}
        <div className="mb-8 border-b border-gray-200">
          <div className="overflow-x-auto scrollbar-hide -mb-px">
            <div className="flex justify-start md:justify-center gap-1 md:gap-2 min-w-max px-1">
              {hasCmsTabs ? (
                filterTabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveFilter(tab.slug)}
                    className={`px-4 md:px-6 py-3 text-xs md:text-sm font-bold uppercase tracking-wider transition-all whitespace-nowrap flex-shrink-0 ${
                      activeFilter === tab.slug
                        ? 'border-b-2 border-black text-black'
                        : 'text-gray-400 hover:text-black'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))
              ) : (
                defaultFilters.map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setActiveFilter(filter.toLowerCase())}
                    className={`px-4 md:px-6 py-3 text-xs md:text-sm font-bold uppercase tracking-wider transition-all whitespace-nowrap flex-shrink-0 ${
                      activeFilter === filter.toLowerCase()
                        ? 'border-b-2 border-black text-black'
                        : 'text-gray-400 hover:text-black'
                    }`}
                  >
                    {filter}
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-2 gap-y-7">
          {filteredProducts.slice(0, 12).map((product) => (
            <div key={product.id} className="group">
              <Link href={`/produits/${product.slug}`} className="block">
                <div className="relative aspect-[3/4] bg-gray-100 overflow-hidden rounded-sm mb-4">
                  {product.main_image ? (
                    <Image
                      src={product.main_image}
                      alt={product.name}
                      fill
                      sizes="(max-width: 768px) 50vw, 25vw"
                      className="object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full bg-gray-200 text-gray-400">
                      <span className="text-xs">Aucune image</span>
                    </div>
                  )}
                  
                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-2">
                    {product.is_new && (
                      <span className="bg-black text-white text-xs font-black px-3 py-1.5 uppercase tracking-wide">
                        NEW
                      </span>
                    )}
                    {product.sale_price && (
                      <span className="bg-black text-white text-xs font-black px-3 py-1.5 uppercase tracking-wide">
                        SALE
                      </span>
                    )}
                  </div>

                  {/* Quick Action Indicator */}
                  <div className="absolute bottom-0 left-0 right-0 bg-black/80 text-white text-center text-xs font-bold py-2 uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">
                    Voir le produit
                  </div>
                </div>

                <div className="space-y-1">
                  <h3 className="text-sm font-bold uppercase tracking-wide truncate group-hover:underline">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2">
                    {product.sale_price ? (
                      <>
                        <span className="font-medium text-black">
                          {formatPrice(parseFloat(product.sale_price))}
                        </span>
                        <span className="text-sm text-gray-400 line-through">
                          {formatPrice(parseFloat(product.base_price))}
                        </span>
                      </>
                    ) : (
                      <span className="font-black">
                        {formatPrice(parseFloat(product.base_price))}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Link
            href="/produits"
            className="inline-block bg-black text-white px-12 py-4 text-sm font-black uppercase tracking-widest hover:bg-gray-800 transition-all"
          >
            VOIR TOUS LES PRODUITS
          </Link>
        </div>
      </div>
    </section>
  )
}
