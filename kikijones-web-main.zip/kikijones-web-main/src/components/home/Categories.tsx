'use client'

import { withThemeCategories } from '@/lib/themeCategories'
import Link from 'next/link'
import Image from 'next/image'
import CmsText from '@/components/ui/CmsText'
import { useState, useEffect } from 'react'
import { getParentCategories, Category } from '@/lib/api'
import { SectionConfig } from '@/lib/api/cms'

interface CategoriesProps {
  initialConfig?: SectionConfig
}

/** "Shop by category": large photo tiles with the name on the picture (same look as the app). */
export default function Categories({ initialConfig }: CategoriesProps) {
  const [categories, setCategories] = useState<Category[]>([])

  const title = initialConfig?.title || 'ACHETER PAR CATÉGORIE'

  useEffect(() => {
    getParentCategories()
      .then((apiData) => {
        const all = withThemeCategories(apiData)
        // real categories (with products/photo) first, then the theme ones still waiting for kikistock
        const real = all.filter((x) => !x.virtual)
        const virtual = all.filter((x) => x.virtual)
        setCategories([...real, ...virtual].slice(0, 8))
      })
      .catch((error) => console.error('Failed to fetch categories:', error))
  }, [])

  if (initialConfig && !initialConfig.is_active) return null
  if (!categories.length) return null

  return (
    <section className="bg-white pt-8 md:pt-12" style={initialConfig?.spacing_styles}>
      <div className="container-custom">
        <div className="flex items-end justify-between mb-4 md:mb-5">
          <h2
            className="text-2xl md:text-4xl font-black uppercase tracking-tight"
            style={initialConfig?.title_styles as React.CSSProperties}
          >
            <CmsText text={title} />
          </h2>
          <Link href="/produits" className="text-xs md:text-sm font-bold uppercase tracking-wide underline underline-offset-4">
            Tout voir
          </Link>
        </div>
        <div
          className="flex gap-1.5 md:gap-2 overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0 md:grid md:grid-cols-4"
          style={{ scrollbarWidth: 'none' }}
        >
          {categories.map((category) => {
            const photo = category.display_image || category.image
            return (
              <Link
                key={category.id}
                href={`/produits?category=${category.slug}`}
                className={`group relative shrink-0 w-[44vw] md:w-auto aspect-[3/4] overflow-hidden ${photo ? 'bg-[#F5F5F5]' : 'bg-black'}`}
              >
                {photo && (
                  <Image
                    src={photo}
                    alt={category.name}
                    fill
                    sizes="(max-width: 768px) 44vw, 25vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                )}
                <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-3 md:p-4">
                  <h3 className="text-white text-base md:text-xl font-black uppercase tracking-wide leading-tight">
                    {category.name}
                  </h3>
                  <span className="text-white/90 text-[11px] md:text-xs font-bold uppercase tracking-widest underline underline-offset-4">
                    Acheter
                  </span>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
