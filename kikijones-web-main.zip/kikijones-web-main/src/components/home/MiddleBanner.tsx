'use client'

import Image from 'next/image'
import Link from 'next/link'
import type { MiddleBanner as MiddleBannerType } from '@/lib/api/cms'

interface MiddleBannerProps {
  banner?: MiddleBannerType
}

export default function MiddleBanner({ banner }: MiddleBannerProps) {
  if (!banner) return null

  const overlayStyle = {
    background: `linear-gradient(to right, rgba(0,0,0,${banner.overlay_opacity / 100}), transparent)`
  }

  const textAlignment = {
    left: 'items-start text-left',
    center: 'items-center text-center',
    right: 'items-end text-right'
  }[banner.text_position]

  return (
    <section className="w-full my-8">
      <div className="relative w-full h-[300px] md:h-[500px] overflow-hidden">
        <Image
          src={banner.image_url}
          alt={banner.title}
          fill
          className="object-cover hover:scale-105 transition-transform duration-500"
          priority={false}
          sizes="100vw"
        />
        <div className="absolute inset-0 flex items-center" style={overlayStyle}>
          <div className={`container mx-auto px-8 md:px-16 flex flex-col ${textAlignment} max-w-2xl`}>
            <h2 
              className="text-3xl md:text-5xl font-bold mb-4"
              style={{ color: banner.text_color }}
            >
              {banner.title}
            </h2>
            <p 
              className="text-lg md:text-xl mb-6"
              style={{ color: banner.text_color }}
            >
              {banner.description}
            </p>
            <Link
              href={banner.button_link}
              className="bg-white text-black rounded-full px-8 py-3 font-bold hover:bg-black hover:text-white transition-colors inline-block uppercase tracking-wide text-sm"
            >
              {banner.button_text}
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
