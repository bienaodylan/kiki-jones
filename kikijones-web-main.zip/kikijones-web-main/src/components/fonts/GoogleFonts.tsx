'use client'

import { useEffect } from 'react'

interface GoogleFontsProps {
  fonts: string[]
}

const fontNameMap: { [key: string]: string } = {
  'inter': 'Inter',
  'roboto': 'Roboto',
  'opensans': 'Open+Sans',
  'lato': 'Lato',
  'montserrat': 'Montserrat',
  'poppins': 'Poppins',
  'playfair': 'Playfair+Display',
  'raleway': 'Raleway',
  'merriweather': 'Merriweather',
  'nunito': 'Nunito',
  'worksans': 'Work+Sans',
  'ubuntu': 'Ubuntu',
}

const fontFamilyMap: { [key: string]: string } = {
  'inter': 'Inter, sans-serif',
  'roboto': 'Roboto, sans-serif',
  'opensans': 'Open Sans, sans-serif',
  'lato': 'Lato, sans-serif',
  'montserrat': 'Montserrat, sans-serif',
  'poppins': 'Poppins, sans-serif',
  'playfair': 'Playfair Display, serif',
  'raleway': 'Raleway, sans-serif',
  'merriweather': 'Merriweather, serif',
  'nunito': 'Nunito, sans-serif',
  'worksans': 'Work Sans, sans-serif',
  'ubuntu': 'Ubuntu, sans-serif',
}

export function GoogleFonts({ fonts }: GoogleFontsProps) {
  useEffect(() => {
    // Get unique fonts
    const uniqueFonts = Array.from(new Set(fonts))
    
    // Skip if no fonts or only Inter (already loaded by default)
    if (uniqueFonts.length === 0 || (uniqueFonts.length === 1 && uniqueFonts[0] === 'inter')) {
      return
    }
    
    // Build Google Fonts URL
    const fontNames = uniqueFonts
      .filter(font => font !== 'inter') // Skip Inter, already loaded
      .map(font => {
        const googleFontName = fontNameMap[font] || fontNameMap['inter']
        // Load multiple weights for flexibility
        return `family=${googleFontName}:wght@300;400;500;600;700;800`
      })
      .join('&')
    
    if (!fontNames) return
    
    const fontUrl = `https://fonts.googleapis.com/css2?${fontNames}&display=swap`
    
    // Check if link already exists
    const existingLink = document.querySelector(`link[href="${fontUrl}"]`)
    if (existingLink) return
    
    // Create and append link element
    const link = document.createElement('link')
    link.href = fontUrl
    link.rel = 'stylesheet'
    link.type = 'text/css'
    document.head.appendChild(link)
    
    return () => {
      // Cleanup: remove link when component unmounts
      if (link.parentNode) {
        link.parentNode.removeChild(link)
      }
    }
  }, [fonts])
  
  return null
}

// Helper function to get CSS font-family value
export function getFontFamily(fontKey: string): string {
  return fontFamilyMap[fontKey] || fontFamilyMap['inter']
}
