// Decorative gold wheel (no text), slowly turning. Used by the wheel popups.
export default function WheelArt({ size = 168 }: { size?: number }) {
  return (
    <div className="relative mx-auto" style={{ width: size, height: size }}>
      <div className="absolute inset-[-18px] rounded-full bg-yellow-400/15 blur-xl" />
      <svg viewBox="0 0 168 168" className="relative w-full h-full animate-[spin_14s_linear_infinite]" aria-hidden="true">
        <circle cx="84" cy="84" r="83" fill="#D99A1E" />
        <circle cx="84" cy="84" r="75" fill="#2A1450" />
        {Array.from({ length: 10 }, (_, i) => {
          const R = 74
          const a0 = ((i * 36 - 90) * Math.PI) / 180
          const a1 = (((i + 1) * 36 - 90) * Math.PI) / 180
          const d = `M84,84 L${84 + R * Math.cos(a0)},${84 + R * Math.sin(a0)} A${R},${R} 0 0 1 ${84 + R * Math.cos(a1)},${84 + R * Math.sin(a1)} Z`
          const fill = i % 2 === 0 ? (i % 4 === 0 ? '#E11D48' : '#7C3AED') : '#FDF2D0'
          return <path key={i} d={d} fill={fill} stroke="#2A1450" strokeWidth="1.5" />
        })}
        {Array.from({ length: 20 }, (_, i) => {
          const a = (i * 18 * Math.PI) / 180
          return <circle key={i} cx={84 + 79 * Math.cos(a)} cy={84 + 79 * Math.sin(a)} r="2.3" fill="#FFE9A0" />
        })}
        <circle cx="84" cy="84" r="18" fill="#F5C542" stroke="#2A1450" strokeWidth="3" />
        <circle cx="84" cy="84" r="6" fill="#2A1450" />
      </svg>
      <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[10px] border-r-[10px] border-t-[20px] border-l-transparent border-r-transparent border-t-yellow-400" />
    </div>
  )
}
