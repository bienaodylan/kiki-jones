﻿'use client'

import { useState, useEffect, useCallback } from 'react'
import { usePathname } from 'next/navigation'
import { X, Gift, Truck, Percent, Copy, Check, ChevronRight, Sparkles, Tag } from 'lucide-react'
import { API_ENDPOINTS } from '@/lib/api/config'
import WheelArt from '@/components/WheelArt'

// -- Coupon offers shown in the popup --
interface CouponOffer {
  id: string
  icon: 'shipping' | 'percent' | 'gift'
  badge?: string
  badgeColor?: string
  title: string
  subtitle: string
  code: string
  condition: string
  maxDiscount?: string
}

const PROMO_OFFERS: CouponOffer[] = [
  {
    id: 'shipping',
    icon: 'shipping',
    badge: 'GRATUIT',
    badgeColor: ' ',
    title: 'Livraison Gratuite',
    subtitle: 'Dès 50 000 FCFA d\'achat',
    code: 'FREESHIP',
    condition: 'Sans minimum sur votre 1ère commande',
  },
  {
    id: 'welcome15',
    icon: 'percent',
    badge: '-15%',
    badgeColor: ' ',
    title: 'Coupon Bienvenue',
    subtitle: 'Sur tout le site',
    code: 'BIENVENUE15',
    condition: 'Sans minimum d\'achat',
    maxDiscount: 'Plafonné à 10 000 FCFA',
  },
  {
    id: 'first10',
    icon: 'gift',
    badge: '-10%',
    badgeColor: ' ',
    title: '1ère Commande',
    subtitle: 'Réduction exclusive',
    code: 'FIRST10',
    condition: 'Valable sur votre 1ère commande',
    maxDiscount: 'Plafonné à 5 000 FCFA',
  },
]

// -- Main Promo Popup --
export default function PromoPopup() {
  // mode: 'hidden' -> nothing shown | 'full' -> full popup | 'mini' -> floating badge
  const [mode, setMode] = useState<'hidden' | 'full' | 'mini'>('hidden')
  const [isClosing, setIsClosing] = useState(false)
  const [copiedCode, setCopiedCode] = useState<string | null>(null)
  const [allCollected, setAllCollected] = useState(false)
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)
  const [subscribing, setSubscribing] = useState(false)
  const pathname = usePathname()
  const isProductPage = /^\/produits\/[^/]+/.test(pathname)
  const [miniPulse, setMiniPulse] = useState(false)

  // Show popup after delay, once per session; returning visitors see mini badge
  useEffect(() => {
    // Always start minimized as a discreet floating badge
    const timer = setTimeout(() => {
      setMode('mini')
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  // Pulse mini badge periodically to catch attention
  useEffect(() => {
    if (mode !== 'mini') return
    const interval = setInterval(() => {
      setMiniPulse(true)
      setTimeout(() => setMiniPulse(false), 1500)
    }, 30000)
    // Initial pulse after 2s
    const initial = setTimeout(() => {
      setMiniPulse(true)
      setTimeout(() => setMiniPulse(false), 1500)
    }, 2000)
    return () => { clearInterval(interval); clearTimeout(initial) }
  }, [mode])

  // Minimize to floating badge instead of fully closing
  const handleMinimize = useCallback(() => {
    setIsClosing(true)
    localStorage.setItem('promo_popup_dismissed', Date.now().toString())
    setTimeout(() => {
      setMode('mini')
      setIsClosing(false)
    }, 300)
  }, [])

  // Expand from mini badge to full popup
  const handleExpand = useCallback(() => {
    setMode('full')
  }, [])

  const handleCopyCode = useCallback((code: string) => {
    navigator.clipboard.writeText(code).then(() => {
      setCopiedCode(code)
      setTimeout(() => setCopiedCode(null), 2000)
    })
  }, [])

  const handleCollectAll = useCallback(() => {
    setAllCollected(true)
    const allCodes = PROMO_OFFERS.map((o) => o.code).join(' | ')
    navigator.clipboard.writeText(allCodes).catch(() => {})
  }, [])

  const handleSubscribe = useCallback(async () => {
    if (!email.trim() || subscribing) return
    setSubscribing(true)
    try {
      const res = await fetch(API_ENDPOINTS.newsletterSubscribe, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), name: '' }),
      })
      if (res.ok) {
        setSubscribed(true)
      }
    } catch {
      // silent fail
    } finally {
      setSubscribing(false)
    }
  }, [email, subscribing])

  if (mode === 'hidden') return null

  const iconMap = {
    shipping: Truck,
    percent: Percent,
    gift: Gift,
  }

  // -- Minimized vertical tab (left edge, discreet) --
  if (mode === 'mini') {
    return (
      <button
        onClick={handleExpand}
        className={`fixed ${isProductPage ? 'bottom-[6rem]' : 'bottom-1/3'} left-0 z-50 group transition-all duration-300`}
        aria-label="Offres promotionnelles"
      >
        <div className="relative flex flex-col items-center bg-black/90 backdrop-blur-sm border border-white/10 border-l-0 rounded-none py-3 px-1.5 shadow-lg hover:bg-black hover:border-white/20 transition-all">
          {/* Icon */}
          <div className="w-7 h-7 rounded-none    flex items-center justify-center mb-1.5">
            <Tag className="w-3.5 h-3.5 text-black" />
          </div>
          {/* Vertical text */}
          <span className="text-white text-[10px] font-bold tracking-widest uppercase" style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }}>
            -15%
          </span>
          {/* Notification dot */}
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-black rounded-none border border-white animate-pulse" />
        </div>
      </button>
    )
  }

  // -- Full popup --
  return (
    <div
      className={`fixed inset-0 z-[9999] flex items-center justify-center p-4 transition-opacity duration-300 ${
        isClosing ? 'opacity-0' : 'opacity-100'
      }`}
      style={{ backgroundColor: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
      onClick={handleMinimize}
    >
      <div
        className={`relative w-full max-w-[420px] grayscale max-h-[90vh] overflow-hidden rounded-none shadow-2xl transition-all duration-500 ${
          isClosing ? 'scale-95 opacity-0' : 'scale-100 opacity-100'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* -- Background gradient -- */}
        <div className="absolute inset-0    " />

        {/* -- Decorative particles -- */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
        </div>

        {/* -- Content -- */}
        <div className="relative z-10 overflow-y-auto max-h-[90vh]">
          {/* Minimize button */}
          <button
            onClick={handleMinimize}
            className="absolute top-3 right-3 z-20 p-2 rounded-none bg-white/10 hover:bg-white/20 transition-colors backdrop-blur-sm"
            title="Réduire"
          >
            <X className="w-4 h-4 text-white" />
          </button>

          {/* -- Header: the wheel -- */}
          <div className="pt-8 pb-3 px-6 text-center">
            <div className="mb-3"><WheelArt size={168} /></div>
            <p className="text-[10px] font-black uppercase tracking-[0.18em] text-white mb-1">Jeu gratuit • 1 tour par jour</p>
            <h2 className="text-2xl font-black text-white tracking-tight">La grande roue de la chance</h2>
            <p className="text-sm text-gray-300 mt-1">Gagnez des points, des coupons et des cadeaux.</p>
            <a
              href="/roue-chance"
              className="mt-4 flex items-center justify-center gap-2 w-full py-3.5 rounded-none font-black text-sm uppercase tracking-wider bg-white text-black  hover:bg-white active:scale-[0.98] transition-all"
            >
              <Sparkles className="w-4 h-4" />
              Tourner la roue
            </a>
            <p className="mt-5 text-[11px] font-bold uppercase tracking-wider text-gray-400">Vos codes de bienvenue</p>
          </div>

          {/* -- Coupon Cards -- */}
          <div className="px-5 space-y-2.5 pb-3">
            {PROMO_OFFERS.map((offer) => {
              const Icon = iconMap[offer.icon]
              const isCopied = copiedCode === offer.code

              return (
                <div
                  key={offer.id}
                  className={`relative overflow-hidden rounded-none transition-all duration-300 ${
                    allCollected
                      ? '   border border-white/20'
                      : 'bg-white/[0.07] border border-white/10 hover:bg-white/[0.12]'
                  }`}
                >
                  <div className="absolute left-[72px] top-0 bottom-0 w-px border-l border-dashed border-white/20" />

                  <div className="flex items-center">
                    <div className="flex flex-col items-center justify-center w-[72px] py-3 flex-shrink-0">
                      <div className={`w-10 h-10 rounded-none  ${offer.badgeColor} flex items-center justify-center shadow-lg`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      {offer.badge && (
                        <span className="mt-1 text-[10px] font-black text-white tracking-wider">
                          {offer.badge}
                        </span>
                      )}
                    </div>

                    <div className="flex-1 py-3 pr-2 min-w-0">
                      <p className="text-white text-sm font-bold leading-tight truncate">
                        {offer.title}
                      </p>
                      <p className="text-gray-400 text-[11px] leading-tight mt-0.5">
                        {offer.subtitle}
                      </p>
                      <p className="text-gray-500 text-[10px] mt-1">
                        {offer.condition}
                        {offer.maxDiscount && (
                          <span className="text-white/70"> · {offer.maxDiscount}</span>
                        )}
                      </p>
                    </div>

                    <div className="pr-3 flex-shrink-0">
                      <button
                        onClick={() => handleCopyCode(offer.code)}
                        className={`flex items-center gap-1 px-2.5 py-1.5 rounded-none text-[10px] font-bold uppercase tracking-wider transition-all ${
                          isCopied
                            ? 'bg-white text-white border border-white/20'
                            : allCollected
                            ? 'bg-white text-white border border-white/20'
                            : 'bg-white/10 text-white/80 border border-white/20 hover:bg-white/20'
                        }`}
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3 h-3" />
                            Copié
                          </>
                        ) : allCollected ? (
                          <>
                            <Check className="w-3 h-3" />
                            {offer.code}
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            {offer.code}
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* -- Collect All Button -- */}
          <div className="px-5 pt-1 pb-3">
            {!allCollected ? (
              <button
                onClick={handleCollectAll}
                className="w-full py-3.5 rounded-none font-black text-sm uppercase tracking-wider transition-all
                      text-black
                    
                  shadow-lg shadow-orange-500/25 active:scale-[0.98]"
              >
                <span className="flex items-center justify-center gap-2">
                  <Gift className="w-4 h-4" />
                  Collecter Tous les Coupons
                  <ChevronRight className="w-4 h-4" />
                </span>
              </button>
            ) : (
              <div className="w-full py-3 rounded-none text-center bg-white border border-white/20">
                <span className="flex items-center justify-center gap-2 text-white text-sm font-bold">
                  <Check className="w-4 h-4" />
                  Coupons collectés ! Utilisez-les au checkout
                </span>
              </div>
            )}
          </div>

          {/* -- Newsletter Subscribe -- */}
          <div className="px-5 pb-6">
            <div className="bg-white/[0.05] rounded-none border border-white/10 p-4">
              {!subscribed ? (
                <>
                  <p className="text-white text-xs font-bold mb-2 text-center">
                    📬 Inscrivez-vous pour recevoir des offres exclusives
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSubscribe()}
                      placeholder="votre@email.com"
                      className="flex-1 bg-white/10 border border-white/20 rounded-none px-3 py-2 text-white text-xs placeholder:text-gray-500 focus:outline-none focus:border-white/40"
                    />
                    <button
                      onClick={handleSubscribe}
                      disabled={subscribing || !email.trim()}
                      className="bg-white text-black px-4 py-2 rounded-none text-xs font-bold uppercase tracking-wider hover:bg-gray-200 transition-colors disabled:opacity-50"
                    >
                      {subscribing ? '...' : 'OK'}
                    </button>
                  </div>
                </>
              ) : (
                <p className="text-white text-xs font-bold text-center">
                  ✅ Inscription réussie ! Vérifiez votre email.
                </p>
              )}
            </div>

            <p className="text-[9px] text-gray-600 text-center mt-3 leading-relaxed">
              Offre limitée. Coupons valables 30 jours. Non cumulables avec d&apos;autres promotions.
              <br />
              Conditions et réductions appliquées au checkout.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
