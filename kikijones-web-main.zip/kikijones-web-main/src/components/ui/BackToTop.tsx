'use client'

import { useState, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import { ArrowUp } from 'lucide-react'

export default function BackToTop() {
  const [isVisible, setIsVisible] = useState(false)
  const pathname = usePathname()
  const isProductPage = /^\/produits\/[^/]+/.test(pathname)

  useEffect(() => {
    const toggleVisibility = () => {
      setIsVisible(window.scrollY > 400)
    }

    window.addEventListener('scroll', toggleVisibility, { passive: true })
    return () => window.removeEventListener('scroll', toggleVisibility)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <button
      onClick={scrollToTop}
      className={`fixed ${isProductPage ? 'bottom-[5rem]' : 'bottom-6'} left-6 z-40 w-12 h-12 bg-black text-white rounded-full shadow-lg flex items-center justify-center transition-all duration-300 hover:bg-gray-800 hover:scale-110 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'
      }`}
      aria-label="Retour en haut"
    >
      <ArrowUp size={20} strokeWidth={2} />
    </button>
  )
}
