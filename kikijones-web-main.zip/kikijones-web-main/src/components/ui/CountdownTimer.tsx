'use client'

import { useState, useEffect } from 'react'

interface CountdownTimerProps {
  endDate: Date | string
  className?: string
}

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
}

export default function CountdownTimer({ endDate, className = '' }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const end = typeof endDate === 'string' ? new Date(endDate) : endDate
      const now = new Date()
      const difference = end.getTime() - now.getTime()

      if (difference <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0 }
      }

      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      }
    }

    // Initial calculation
    setTimeLeft(calculateTimeLeft())

    // Update every second
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft())
    }, 1000)

    return () => clearInterval(timer)
  }, [endDate])

  const formatNumber = (num: number): string => {
    return num.toString().padStart(2, '0')
  }

  return (
    <div className={`flex gap-1 ${className}`}>
      {timeLeft.days > 0 && (
        <>
          <span className="bg-white text-black text-sm font-bold px-3 py-1.5 min-w-[40px] text-center">
            {formatNumber(timeLeft.days)}
          </span>
          <span className="text-white font-bold">:</span>
        </>
      )}
      <span className="bg-white text-black text-sm font-bold px-3 py-1.5 min-w-[40px] text-center">
        {formatNumber(timeLeft.hours)}
      </span>
      <span className="text-white font-bold">:</span>
      <span className="bg-white text-black text-sm font-bold px-3 py-1.5 min-w-[40px] text-center">
        {formatNumber(timeLeft.minutes)}
      </span>
      <span className="text-white font-bold">:</span>
      <span className="bg-white text-black text-sm font-bold px-3 py-1.5 min-w-[40px] text-center">
        {formatNumber(timeLeft.seconds)}
      </span>
    </div>
  )
}
