import { Zap, Flame, Sparkles, Gift, Tag, Star, Clock } from 'lucide-react'

const EMOJI_RE = /[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}]/gu
const ICONS: Record<string, any> = {
  '⚡': Zap, '🔥': Flame, '✨': Sparkles, '🆕': Sparkles, '🎁': Gift, '🏷': Tag, '💰': Tag, '⭐': Star, '🌟': Star, '⏰': Clock, '⏳': Clock,
}

/** Renders CMS text: the leading emoji becomes a line icon (current text colour), other emojis are dropped. */
export default function CmsText({ text }: { text?: string | null }) {
  if (!text) return null
  const first = (text.match(EMOJI_RE) || [])[0]?.replace(/️/g, '')
  const Icon = first ? ICONS[first] : undefined
  const clean = text.replace(EMOJI_RE, '').replace(/\s{2,}/g, ' ').trim()
  if (!Icon) return <>{clean}</>
  return (
    <span className="inline-flex items-center gap-2 align-middle">
      <Icon className="shrink-0" style={{ width: '0.9em', height: '0.9em' }} strokeWidth={1.8} aria-hidden />
      <span>{clean}</span>
    </span>
  )
}
