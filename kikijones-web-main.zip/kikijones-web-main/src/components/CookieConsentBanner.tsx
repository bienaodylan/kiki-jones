'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'

const STORAGE_KEY = 'cookiePreferences'

interface CookiePreferences {
  necessary: boolean
  analytics: boolean
  marketing: boolean
  personalization: boolean
}

function savePreferences(prefs: CookiePreferences) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs))
  window.dispatchEvent(new Event('cookie-consent-change'))
}

export default function CookieConsentBanner() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    // Only show if the visitor has never saved a preference before
    const saved = localStorage.getItem(STORAGE_KEY)
    if (!saved) {
      setVisible(true)
    }
  }, [])

  if (!visible) return null

  const handleAcceptAll = () => {
    savePreferences({ necessary: true, analytics: true, marketing: true, personalization: true })
    setVisible(false)
  }

  const handleRejectNonEssential = () => {
    savePreferences({ necessary: true, analytics: false, marketing: false, personalization: false })
    setVisible(false)
  }

  return (
    <div
      role="dialog"
      aria-label="Préférences de cookies"
      className="fixed bottom-0 left-0 right-0 z-[100] bg-white border-t border-gray-200 shadow-[0_-2px_10px_rgba(0,0,0,0.08)]"
    >
      <div className="container mx-auto px-4 py-3 md:py-4 flex flex-col md:flex-row items-start md:items-center gap-3 md:gap-4">
        <p className="text-xs md:text-sm text-gray-700 flex-1">
          Nous utilisons des cookies strictement nécessaires au fonctionnement du site. Avec votre accord,
          nous utilisons aussi des cookies analytiques pour comprendre l'utilisation du site. Vous pouvez
          accepter, refuser, ou{' '}
          <Link href="/privacy-choices" className="underline font-medium text-black">
            gérer vos préférences
          </Link>
          .
        </p>
        <div className="grid grid-cols-2 sm:flex sm:items-center gap-2 sm:gap-3 shrink-0 w-full md:w-auto">
          <button
            onClick={handleRejectNonEssential}
            className="px-3 sm:px-4 py-2.5 text-xs font-bold uppercase tracking-wider border-2 border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors whitespace-nowrap"
          >
            Tout refuser
          </button>
          <Link
            href="/privacy-choices"
            className="px-3 sm:px-4 py-2.5 text-xs font-bold uppercase tracking-wider border-2 border-black text-black hover:bg-gray-50 transition-colors whitespace-nowrap"
          >
            Gérer
          </Link>
          <button
            onClick={handleAcceptAll}
            className="col-span-2 sm:col-span-1 px-4 py-2.5 text-xs font-bold uppercase tracking-wider bg-black text-white hover:bg-gray-900 transition-colors whitespace-nowrap"
          >
            Tout accepter
          </button>
        </div>
      </div>
    </div>
  )
}
