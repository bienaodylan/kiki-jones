/**
 * SectionHeader - Composant réutilisable pour les en-têtes de section
 * Utilise les configurations du CMS pour le style dynamique
 */
'use client'

import { useEffect, useState } from 'react'
import CmsText from '@/components/ui/CmsText'
import { getSectionConfig, SectionConfig } from '@/lib/api/cms'

interface SectionHeaderProps {
  section: string
  defaultTitle?: string
  defaultSubtitle?: string
  className?: string
}

export default function SectionHeader({
  section,
  defaultTitle,
  defaultSubtitle,
  className = ''
}: SectionHeaderProps) {
  const [config, setConfig] = useState<SectionConfig | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadConfig() {
      try {
        const sectionConfig = await getSectionConfig(section, 'web')
        setConfig(sectionConfig)
      } catch (error) {
        console.error(`Error loading config for ${section}:`, error)
      } finally {
        setIsLoading(false)
      }
    }

    loadConfig()
  }, [section])

  // Utiliser les valeurs par défaut si pas de config
  const title = config?.title || defaultTitle
  const subtitle = config?.subtitle || defaultSubtitle

  if (isLoading) {
    return (
      <div className={`animate-pulse ${className}`}>
        <div className="h-8 bg-gray-200 rounded w-64 mb-2"></div>
        <div className="h-4 bg-gray-200 rounded w-96"></div>
      </div>
    )
  }

  if (!title) return null

  return (
    <div
      className={className}
      style={config?.spacing_styles ? {
        marginTop: config.spacing_styles.marginTop,
        marginBottom: config.spacing_styles.marginBottom,
        paddingLeft: config.spacing_styles.paddingLeft,
        paddingRight: config.spacing_styles.paddingRight,
      } : undefined}
    >
      <h2
        style={config?.title_styles ? {
          fontFamily: config.title_styles.fontFamily,
          fontSize: config.title_styles.fontSize,
          fontWeight: config.title_styles.fontWeight,
          color: config.title_styles.color,
          textAlign: config.title_styles.textAlign as any,
        } : undefined}
        className={!config ? 'text-3xl font-bold text-gray-900' : ''}
      >
        <CmsText text={title} />
      </h2>
      
      {subtitle && (
        <p
          style={config?.subtitle_styles ? {
            fontFamily: config.subtitle_styles.fontFamily,
            fontSize: config.subtitle_styles.fontSize,
            fontWeight: config.subtitle_styles.fontWeight,
            color: config.subtitle_styles.color,
          } : undefined}
          className={!config ? 'mt-2 text-gray-600' : ''}
        >
          <CmsText text={subtitle} />
        </p>
      )}
    </div>
  )
}
