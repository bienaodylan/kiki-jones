'use client'

import { useEffect, Suspense } from 'react'
import posthog from 'posthog-js'
import { PostHogProvider as PHProvider, usePostHog } from 'posthog-js/react'
import { usePathname, useSearchParams } from 'next/navigation'

function PostHogPageView() {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const posthogClient = usePostHog()

  useEffect(() => {
    if (!pathname || !posthogClient) return
    if (!hasAnalyticsConsent() || !posthog.__loaded) return
    let url = window.origin + pathname
    const search = searchParams.toString()
    if (search) url += '?' + search
    posthogClient.capture('$pageview', { $current_url: url })
  }, [pathname, searchParams, posthogClient])

  return null
}

/**
 * Returns true only if the visitor has explicitly saved consent preferences
 * with analytics enabled. Returns false if no preference has been saved yet
 * (i.e. no opt-out-by-default / no tracking-before-consent).
 */
function hasAnalyticsConsent(): boolean {
  if (typeof window === 'undefined') return false
  try {
    const saved = localStorage.getItem('cookiePreferences')
    if (!saved) return false
    const prefs = JSON.parse(saved)
    return prefs?.analytics === true
  } catch {
    return false
  }
}

function initPostHogIfConsented() {
  if (typeof window === 'undefined') return
  if (posthog.__loaded) return
  if (!hasAnalyticsConsent()) return

  const key = process.env.NEXT_PUBLIC_POSTHOG_KEY
  const host = process.env.NEXT_PUBLIC_POSTHOG_HOST || 'https://us.i.posthog.com'
  if (!key) return

  posthog.init(key, {
    api_host: host,
    person_profiles: 'identified_only',
    capture_pageview: false, // handled manually below for App Router route changes
  })
}

export default function PostHogProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    initPostHogIfConsented()

    // Re-check when the user saves/updates their cookie preferences
    // (privacy-choices page and the consent banner both fire this event)
    const handleConsentChange = () => initPostHogIfConsented()
    window.addEventListener('cookie-consent-change', handleConsentChange)
    window.addEventListener('storage', handleConsentChange)
    return () => {
      window.removeEventListener('cookie-consent-change', handleConsentChange)
      window.removeEventListener('storage', handleConsentChange)
    }
  }, [])

  return (
    <PHProvider client={posthog}>
      <Suspense fallback={null}>
        <PostHogPageView />
      </Suspense>
      {children}
    </PHProvider>
  )
}
