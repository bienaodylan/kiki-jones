'use client'

import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useState } from 'react'
import { CurrencyProvider } from '@/contexts/CurrencyContext'
import { CartProvider } from '@/contexts/CartContext'
import { WishlistProvider } from '@/contexts/WishlistContext'
import PostHogProvider from './PostHogProvider'
import CookieConsentBanner from '@/components/CookieConsentBanner'

export default function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 60 * 1000, // 1 minute
        refetchOnWindowFocus: false,
      },
    },
  }))

  return (
    <PostHogProvider>
      <CartProvider>
        <WishlistProvider>
          <CurrencyProvider>
            <QueryClientProvider client={queryClient}>
              {children}
              <CookieConsentBanner />
            </QueryClientProvider>
          </CurrencyProvider>
        </WishlistProvider>
      </CartProvider>
    </PostHogProvider>
  )
}
