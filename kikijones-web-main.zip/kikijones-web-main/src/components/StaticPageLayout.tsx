'use client'

import { useEffect, useState } from 'react'
import { sanitizeHTML } from '@/lib/sanitize'
import { API_ENDPOINTS } from '@/lib/api/config'

interface StaticPage {
  id: string
  title: string
  slug: string
  content: string
  meta_title: string
  meta_description: string
  updated_at: string
}

interface StaticPageLayoutProps {
  slug: string
}

export default function StaticPageLayout({ slug }: StaticPageLayoutProps) {
  const [page, setPage] = useState<StaticPage | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchPage = async () => {
      try {
        setLoading(true)
        const response = await fetch(`${API_ENDPOINTS.pages}${slug}/`)

        if (!response.ok) {
          setError('Page non trouvée')
          return
        }

        const data = await response.json()
        setPage(data)
        
        if (data.meta_title) {
          document.title = data.meta_title
        }
      } catch (err) {
        setError('Erreur de chargement')
      } finally {
        setLoading(false)
      }
    }

    fetchPage()
  }, [slug])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    )
  }

  if (error || !page) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center px-4">
          <h1 className="text-6xl font-light mb-6 text-gray-900">404</h1>
          <p className="text-lg text-gray-600 mb-8">{error || 'Page non trouvée'}</p>
          <a 
            href="/" 
            className="inline-block px-8 py-3 bg-black text-white text-sm font-medium uppercase tracking-wider hover:bg-gray-900 transition-colors"
          >
            Retour à l'accueil
          </a>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-white">
        <div className="max-w-3xl mx-auto px-5 md:px-10 pt-12 pb-6">
          <nav className="text-[10.5px] font-bold uppercase tracking-[0.24em] mb-3 flex items-center gap-2 text-black/50">
            <a href="/" className="hover:text-black transition-colors">Accueil</a>
            <span>/</span>
            <span className="text-black">{page.title}</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl font-bold tracking-[-0.025em] text-black">
            {page.title}
          </h1>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-3xl mx-auto px-5 md:px-10 pb-24">
        <div 
          className="static-content"
          dangerouslySetInnerHTML={{ __html: sanitizeHTML(page.content) }} 
        />
      </div>

      <style jsx global>{`
        .static-content {
          color: rgba(0,0,0,0.8);
          line-height: 1.8;
          font-size: 15px; font-weight: 300;
        }

        .static-content h2 { text-transform: uppercase; letter-spacing: 0.08em;
          font-size: 1.125rem;
          font-weight: 700;
          color: #000;
          margin-top: 3rem;
          margin-bottom: 1.5rem;
          padding-bottom: 0.75rem;
          border-bottom: 1px solid rgba(0,0,0,0.1);
          letter-spacing: -0.025em;
        }

        .static-content h3 {
          font-size: 1rem;
          font-weight: 700;
          color: #000;
          margin-top: 2.5rem;
          margin-bottom: 1rem;
          letter-spacing: -0.015em;
        }

        .static-content h4 {
          font-size: 1.125rem;
          font-weight: 500;
          color: #000;
          margin-top: 2rem;
          margin-bottom: 0.75rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          font-size: 0.875rem;
        }

        .static-content p {
          margin-bottom: 1.5rem;
          color: rgba(0,0,0,0.8);
        }

        .static-content a {
          color: #000;
          text-decoration: underline;
          text-decoration-thickness: 1px;
          text-underline-offset: 2px;
          transition: color 0.2s;
        }

        .static-content a:hover {
          color: rgba(0,0,0,0.8);
        }

        .static-content ul, .static-content ol {
          margin-bottom: 1.5rem;
          padding-left: 1.5rem;
        }

        .static-content li {
          margin-bottom: 0.75rem;
          color: rgba(0,0,0,0.8);
          line-height: 1.7;
        }

        .static-content strong {
          font-weight: 600;
          color: #000;
        }

        .static-content em {
          font-style: italic;
        }

        .static-content blockquote {
          border-left: 3px solid #000;
          padding-left: 1.5rem;
          margin: 2rem 0;
          font-style: italic;
          color: #6b7280;
        }

        .static-content img {
          max-width: 100%;
          height: auto;
          margin: 2rem 0;
        }

        .static-content hr {
          border: none;
          border-top: 1px solid #e5e7eb;
          margin: 3rem 0;
        }

        .static-content table {
          width: 100%;
          border-collapse: collapse;
          margin: 2rem 0;
        }

        .static-content th {
          background-color: #f9fafb;
          padding: 0.75rem 1rem;
          text-align: left;
          font-weight: 500;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: #000;
          border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .static-content td {
          padding: 0.75rem 1rem;
          border-bottom: 1px solid #f3f4f6;
          color: rgba(0,0,0,0.8);
        }

        .static-content code {
          background-color: #f3f4f6;
          padding: 0.125rem 0.375rem;
          border-radius: 0.25rem;
          font-size: 0.875em;
          font-family: monospace;
        }

        .static-content pre {
          background-color: rgba(0,0,0,0.8);
          color: #f9fafb;
          padding: 1.5rem;
          border-radius: 0.5rem;
          overflow-x: auto;
          margin: 2rem 0;
        }

        .static-content pre code {
          background-color: transparent;
          padding: 0;
          color: inherit;
        }

        /* Sections spéciales */
        .static-content .contact-methods,
        .static-content .faq-grid,
        .static-content .info-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 2rem;
          margin: 3rem 0;
        }

        .static-content .contact-card,
        .static-content .faq-item,
        .static-content .info-card {
          background-color: #f9fafb;
          padding: 2rem;
          border-radius: 0;
          border-left: 2px solid #000;
          transition: transform 0.2s, box-shadow 0.2s;
        }

        .static-content .contact-card:hover,
        .static-content .faq-item:hover,
        .static-content .info-card:hover {
          transform: translateX(4px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        .static-content .contact-icon {
          font-size: 1.125rem;
          margin-bottom: 1rem;
          display: block;
        }

        .static-content .contact-hours {
          font-size: 0.875rem;
          color: #9ca3af;
          margin-top: 0.5rem;
        }

        .static-content form {
          margin: 3rem 0;
        }

        .static-content .form-group {
          margin-bottom: 1.5rem;
        }

        .static-content label {
          display: block;
          font-weight: 500;
          font-size: 0.875rem;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: #000;
          margin-bottom: 0.5rem;
        }

        .static-content input[type="text"],
        .static-content input[type="email"],
        .static-content input[type="tel"],
        .static-content select,
        .static-content textarea {
          width: 100%;
          padding: 0.75rem 1rem;
          border: 1px solid #d1d5db;
          background-color: #fff;
          font-size: 1rem;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .static-content input:focus,
        .static-content select:focus,
        .static-content textarea:focus {
          outline: none;
          border-color: #000;
          box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.05);
        }

        .static-content button[type="submit"],
        .static-content .submit-btn {
          background-color: #000;
          color: #fff;
          padding: 1rem 3rem;
          border: none;
          font-size: 0.875rem;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          cursor: pointer;
          transition: background-color 0.2s;
          width: 100%;
          margin-top: 1rem;
        }

        .static-content button[type="submit"]:hover,
        .static-content .submit-btn:hover {
          background-color: rgba(0,0,0,0.8);
        }

        .static-content .form-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
        }

        @media (max-width: 768px) {
          .static-content {
            font-size: 15px;
          }

          .static-content h2 {
            font-size: 1.75rem;
            margin-top: 2rem;
          }

          .static-content h3 {
            font-size: 1.25rem;
            margin-top: 1.5rem;
          }

          .static-content .contact-methods,
          .static-content .faq-grid,
          .static-content .info-grid {
            grid-template-columns: 1fr;
            gap: 1.5rem;
          }

          .static-content .form-row {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  )
}
