'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import {
  MessageCircle, X, Send, Loader2, ShoppingCart,
  ExternalLink, RotateCcw, CreditCard, ChevronRight,
  Package, MapPin, Phone, CheckCircle, Copy, Check, Headphones
} from 'lucide-react'
import { bootstrapAuth } from '@/lib/auth-store'
import { isAuthenticated } from '@/lib/api/auth'
import {
  getOrCreateConversation, getConversation, sendMessage as sendHumanMessage,
  type Message as HumanMessage,
} from '@/lib/api/chat'
import { useRouter } from 'next/navigation'
import { API_BASE_URL } from '@/lib/api/config'

const AGENT_API = `${API_BASE_URL}/agent`
const SESSION_KEY_STORAGE = 'kj_agent_session'

// ── Types ─────────────────────────────────────────────────────────────────────
interface AgentResponse {
  type: 'text' | 'product_card' | 'order_recap' | 'payment_link' | 'action_buttons'
  content: string
  payload?: Record<string, unknown>
}

interface ChatMessage {
  id: string
  role: 'user' | 'agent'
  responses: AgentResponse[]
  timestamp: Date
}

interface ProductVariant {
  id: string
  size: string
  color: string
  price: number
  stock: number
}

interface ProductCard {
  id: string
  name: string
  price: number
  image_url: string
  category: string
  variants: ProductVariant[]
  available_sizes: string[]
  available_colors: string[]
}

interface ActionButton {
  label: string
  action: string
}

// ── Session key ───────────────────────────────────────────────────────────────
function getOrCreateSessionKey(): string {
  if (typeof window === 'undefined') return crypto.randomUUID()
  let key = localStorage.getItem(SESSION_KEY_STORAGE)
  if (!key) {
    key = crypto.randomUUID()
    localStorage.setItem(SESSION_KEY_STORAGE, key)
  }
  return key
}

// ── API helper ────────────────────────────────────────────────────────────────
async function sendToAgent(sessionKey: string, message: string): Promise<{ state: string; responses: AgentResponse[] }> {
  const res = await fetch(`${AGENT_API}/chat/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_key: sessionKey, message }),
  })
  if (!res.ok) throw new Error(`API ${res.status}`)
  return res.json()
}

async function triggerCheckout(sessionKey: string): Promise<{ state: string; responses: AgentResponse[] }> {
  const res = await fetch(`${AGENT_API}/checkout/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ session_key: sessionKey }),
  })
  if (!res.ok) throw new Error(`API ${res.status}`)
  return res.json()
}

// ── Sub-components ────────────────────────────────────────────────────────────

function ProductCardMessage({ data, onSelect }: { data: ProductCard; onSelect: (text: string) => void }) {
  const [selectedSize, setSelectedSize] = useState('')
  const [selectedColor, setSelectedColor] = useState('')

  const handleOrder = () => {
    const parts = [data.name]
    if (selectedSize)  parts.push(`taille ${selectedSize}`)
    if (selectedColor) parts.push(`couleur ${selectedColor}`)
    onSelect(parts.join(' '))
  }

  return (
    <div className="bg-white border border-gray-200 rounded-none overflow-hidden shadow-sm max-w-[240px]">
      {data.image_url && (
        <div className="relative h-36 bg-gray-100">
          <Image src={data.image_url} alt={data.name} fill className="object-cover" unoptimized />
        </div>
      )}
      <div className="p-3 space-y-2">
        <p className="font-semibold text-gray-900 text-sm leading-tight">{data.name}</p>
        <p className="text-[#000000] font-bold text-sm">{data.price.toLocaleString('fr-CI')} XOF</p>

        {data.available_sizes.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {data.available_sizes.map(s => (
              <button key={s} onClick={() => setSelectedSize(s)}
                className={`px-2 py-0.5 text-xs rounded border font-medium transition-colors ${
                  selectedSize === s ? 'bg-[#000000] text-white border-[#000000]' : 'border-gray-300 text-gray-700 hover:border-[#000000]'
                }`}>
                {s}
              </button>
            ))}
          </div>
        )}

        {data.available_colors.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {data.available_colors.map(c => (
              <button key={c} onClick={() => setSelectedColor(c)}
                className={`px-2 py-0.5 text-xs rounded border font-medium transition-colors ${
                  selectedColor === c ? 'bg-[#000000] text-white border-[#000000]' : 'border-gray-300 text-gray-700 hover:border-[#000000]'
                }`}>
                {c}
              </button>
            ))}
          </div>
        )}

        <button onClick={handleOrder}
          className="w-full bg-[#000000] hover:bg-[#262626] text-white text-xs font-semibold py-1.5 rounded-none flex items-center justify-center gap-1 transition-colors">
          <ShoppingCart size={12} /> Commander
        </button>
      </div>
    </div>
  )
}

function OrderRecapMessage({ data, onConfirm, onCancel }: {
  data: Record<string, unknown>
  onConfirm: () => void
  onCancel: () => void
}) {
  const items = (data.items as Array<Record<string, unknown>>) || []
  const subtotal     = Number(data.subtotal || 0)
  const shipping     = Number(data.shipping_cost || 0)
  const total        = Number(data.total || subtotal + shipping)

  return (
    <div className="bg-amber-50 border border-amber-200 rounded-none p-3 space-y-3 max-w-[260px]">
      <div className="flex items-center gap-2">
        <Package size={14} className="text-[#000000]" />
        <span className="font-semibold text-sm text-gray-900">Récap de commande</span>
      </div>

      <div className="space-y-1.5">
        {items.map((it, i) => (
          <div key={i} className="flex justify-between text-xs text-gray-700">
            <span className="flex-1 mr-2">{String(it.qty)}x {String(it.product_name)} {String(it.size || '')} {String(it.color || '')}</span>
            <span className="font-medium whitespace-nowrap">{(Number(it.unit_price) * Number(it.qty)).toLocaleString('fr-CI')} XOF</span>
          </div>
        ))}
        <div className="border-t border-amber-200 pt-1.5 flex justify-between text-xs text-gray-600">
          <span>Livraison</span><span>{shipping.toLocaleString('fr-CI')} XOF</span>
        </div>
        <div className="flex justify-between text-sm font-bold text-gray-900">
          <span>Total</span><span>{total.toLocaleString('fr-CI')} XOF</span>
        </div>
      </div>

      <div className="text-xs text-gray-600 space-y-1">
        <div className="flex items-start gap-1">
          <MapPin size={11} className="mt-0.5 shrink-0 text-[#000000]" />
          <span>{String(data.delivery_name || '')} — {String(data.delivery_address || '')}, {String(data.delivery_commune || '')}</span>
        </div>
        <div className="flex items-center gap-1">
          <Phone size={11} className="shrink-0 text-[#000000]" />
          <span>{String(data.payer_phone || '')}</span>
        </div>
      </div>

      <div className="flex gap-2">
        <button onClick={onConfirm}
          className="flex-1 bg-[#000000] text-white text-xs font-semibold py-1.5 rounded-none hover:bg-[#262626] transition-colors flex items-center justify-center gap-1">
          <CheckCircle size={11} /> Confirmer
        </button>
        <button onClick={onCancel}
          className="flex-1 bg-gray-200 text-gray-700 text-xs font-semibold py-1.5 rounded-none hover:bg-gray-300 transition-colors">
          Annuler
        </button>
      </div>
    </div>
  )
}

function PaymentLinkMessage({ content, payload }: { content: string; payload: Record<string, unknown> }) {
  const [copied, setCopied] = useState(false)
  const amount  = Number(payload.amount || 0)
  const orderNo = String(payload.order_number || '')
  const url     = content || String(payload.payment_url || '')

  const copyLink = () => {
    navigator.clipboard.writeText(url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="bg-green-50 border border-green-200 rounded-none p-3 space-y-2 max-w-[260px]">
      <div className="flex items-center gap-2">
        <CreditCard size={14} className="text-black" />
        <span className="font-semibold text-sm text-gray-900">Lien de paiement</span>
      </div>
      {orderNo && <p className="text-xs text-gray-600">Commande #{orderNo}</p>}
      <p className="text-[#000000] font-bold text-sm">{amount.toLocaleString('fr-CI')} XOF</p>

      <div className="flex gap-1.5">
        <a href={url} target="_blank" rel="noopener noreferrer"
          className="flex-1 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold py-2 rounded-none flex items-center justify-center gap-1 transition-colors">
          <ExternalLink size={11} /> Payer maintenant
        </a>
        <button onClick={copyLink}
          className="p-2 bg-gray-100 hover:bg-gray-200 rounded-none text-gray-600 transition-colors">
          {copied ? <Check size={13} className="text-black" /> : <Copy size={13} />}
        </button>
      </div>

      <p className="text-xs text-gray-500 flex items-center gap-1">
        <RotateCcw size={10} />
        Expiré ? Tapez <strong>nouveau lien</strong>
      </p>
    </div>
  )
}

function ActionButtonsMessage({ payload, onAction }: { payload: Record<string, unknown>; onAction: (text: string, action: string) => void }) {
  const buttons = (payload.buttons as ActionButton[]) || []
  return (
    <div className="flex flex-wrap gap-2">
      {buttons.map((btn, i) => (
        <button key={i} onClick={() => onAction(btn.label, btn.action)}
          className="bg-white border border-[#000000] text-[#000000] text-xs font-semibold px-3 py-1.5 rounded-none hover:bg-amber-50 transition-colors flex items-center gap-1">
          {btn.label} <ChevronRight size={11} />
        </button>
      ))}
    </div>
  )
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function TextMessage({ content }: { content: string }) {
  // Bold: **text**, italics: _text_, line breaks
  const parts = content.split('\n')
  return (
    <div className="space-y-0.5">
      {parts.map((line, i) => {
        const formatted = escapeHtml(line)
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/_(.*?)_/g, '<em>$1</em>')
        return <p key={i} className="text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: formatted || '&nbsp;' }} />
      })}
    </div>
  )
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function ChatWidget() {
  const pathname = usePathname()
  const router = useRouter()
  const [isOpen, setIsOpen]           = useState(false)
  const [messages, setMessages]       = useState<ChatMessage[]>([])
  const [inputText, setInputText]     = useState('')
  const [isLoading, setIsLoading]     = useState(false)
  const [sessionKey, setSessionKey]   = useState('')
  const [agentState, setAgentState]   = useState('IDLE')
  const [unread, setUnread]           = useState(0)

  // Human support mode
  const [mode, setMode]                     = useState<'bot' | 'agent'>('bot')
  const [conversationId, setConversationId] = useState<string | null>(null)
  const [humanMessages, setHumanMessages]   = useState<HumanMessage[]>([])
  const [humanLoading, setHumanLoading]     = useState(false)
  const [needsLogin, setNeedsLogin]         = useState(false)
  const prevHumanCountRef = useRef(0)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef       = useRef<HTMLInputElement>(null)

  // Hide on admin pages — computed here, applied after all hooks below (Rules of Hooks)
  const hidden = pathname?.startsWith('/admin') || pathname?.startsWith('/compte')

  // Init session on client
  useEffect(() => {
    setSessionKey(getOrCreateSessionKey())
  }, [])

  // Welcome message on first open
  useEffect(() => {
    if (isOpen && messages.length === 0 && sessionKey) {
      const welcome: AgentResponse = {
        type: 'text',
        content: 'Bonjour ! 👋 Je suis l\'assistant Kiki Jones.\n\nDites-moi ce que vous cherchez (ex: _robe noire taille M_, _commander des sneakers_) et je m\'occupe de tout !'
      }
      const actionResp: AgentResponse = {
        type: 'action_buttons',
        content: '',
        payload: {
          buttons: [
            { label: '🛍 Voir les nouveautés', action: 'SEARCH_NEW' },
            { label: '📦 Suivre ma commande', action: 'TRACK_ORDER' },
            { label: '💬 Contacter le support', action: 'SUPPORT' },
          ]
        }
      }
      setMessages([{
        id: crypto.randomUUID(),
        role: 'agent',
        responses: [welcome, actionResp],
        timestamp: new Date(),
      }])
    }
    if (isOpen) {
      setUnread(0)
      inputRef.current?.focus()
    }
  }, [isOpen, sessionKey])

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  const appendAgentMessage = (responses: AgentResponse[]) => {
    setMessages(prev => [...prev, {
      id: crypto.randomUUID(),
      role: 'agent',
      responses,
      timestamp: new Date(),
    }])
    if (!isOpen) setUnread(n => n + 1)
  }

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || !sessionKey || isLoading) return
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      responses: [{ type: 'text', content: text }],
      timestamp: new Date(),
    }
    setMessages(prev => [...prev, userMsg])
    setInputText('')
    setIsLoading(true)
    try {
      const result = await sendToAgent(sessionKey, text)
      setAgentState(result.state)
      appendAgentMessage(result.responses)
    } catch {
      appendAgentMessage([{ type: 'text', content: '❌ Erreur de connexion. Vérifiez votre réseau et réessayez.' }])
    } finally {
      setIsLoading(false)
    }
  }, [sessionKey, isLoading, isOpen])

  const switchToAgent = useCallback(async () => {
    const token = await bootstrapAuth()
    if (!token || !isAuthenticated()) {
      setNeedsLogin(true)
      setMode('agent')
      return
    }
    setMode('agent')
    setHumanLoading(true)
    try {
      const convo = await getOrCreateConversation()
      setConversationId(convo.id)
      setHumanMessages(convo.messages || [])
      prevHumanCountRef.current = (convo.messages || []).length
    } catch {
      setHumanMessages([])
    } finally {
      setHumanLoading(false)
    }
  }, [])

  const sendHumanChatMessage = useCallback(async (text: string) => {
    if (!text.trim() || !conversationId || humanLoading) return
    setInputText('')
    setHumanLoading(true)
    try {
      const msg = await sendHumanMessage(conversationId, text)
      setHumanMessages(prev => [...prev, msg])
      prevHumanCountRef.current += 1
    } catch {
      // keep input cleared silently; user can retype if it failed
    } finally {
      setHumanLoading(false)
    }
  }, [conversationId, humanLoading])

  const handleActionButton = useCallback(async (label: string, action: string) => {
    if (action === 'CHECKOUT') {
      setIsLoading(true)
      const userMsg: ChatMessage = {
        id: crypto.randomUUID(), role: 'user',
        responses: [{ type: 'text', content: label }], timestamp: new Date(),
      }
      setMessages(prev => [...prev, userMsg])
      try {
        const result = await triggerCheckout(sessionKey)
        setAgentState(result.state)
        appendAgentMessage(result.responses)
      } catch {
        await sendMessage(label)
      } finally {
        setIsLoading(false)
      }
    } else if (action === 'SEARCH_NEW') {
      await sendMessage('nouveautés')
    } else if (action === 'TRACK_ORDER') {
      await sendMessage('suivre ma commande')
    } else if (action === 'SUPPORT') {
      await switchToAgent()
    } else if (action === 'ADD_MORE') {
      await sendMessage('ajouter un autre article')
    } else {
      await sendMessage(label)
    }
  }, [sessionKey, sendMessage, switchToAgent])

  const handleConfirmRecap = useCallback(() => sendMessage('oui'), [sendMessage])
  const handleCancelRecap  = useCallback(() => sendMessage('non'), [sendMessage])
  const handleVariantSelect = useCallback((text: string) => sendMessage(text), [sendMessage])

  const handleSend = () => {
    if (mode === 'agent') sendHumanChatMessage(inputText)
    else sendMessage(inputText)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
  }

  // Poll for new human-agent messages while that conversation is open.
  // Stops after repeated failures instead of retrying forever against a
  // conversation that's gone (closed, deleted) or an unreachable API.
  useEffect(() => {
    if (mode !== 'agent' || !conversationId || !isOpen) return
    let consecutiveFailures = 0
    const interval = setInterval(async () => {
      try {
        const detail = await getConversation(conversationId)
        consecutiveFailures = 0
        const msgs = detail.messages || []
        if (msgs.length > prevHumanCountRef.current) {
          setUnread(n => n + (msgs.length - prevHumanCountRef.current))
        }
        setHumanMessages(msgs)
        prevHumanCountRef.current = msgs.length
      } catch {
        consecutiveFailures += 1
        if (consecutiveFailures >= 3) {
          clearInterval(interval)
          setConversationId(null)
        }
      }
    }, 10000)
    return () => clearInterval(interval)
  }, [mode, conversationId, isOpen])

  const renderResponse = (resp: AgentResponse, msgId: string, idx: number) => {
    const key = `${msgId}-${idx}`
    switch (resp.type) {
      case 'product_card':
        return <ProductCardMessage key={key} data={resp.payload as unknown as ProductCard} onSelect={handleVariantSelect} />
      case 'order_recap':
        return <OrderRecapMessage key={key} data={resp.payload || {}} onConfirm={handleConfirmRecap} onCancel={handleCancelRecap} />
      case 'payment_link':
        return <PaymentLinkMessage key={key} content={resp.content} payload={resp.payload || {}} />
      case 'action_buttons':
        return <ActionButtonsMessage key={key} payload={resp.payload || {}} onAction={handleActionButton} />
      default:
        return <TextMessage key={key} content={resp.content} />
    }
  }

  if (hidden) return null

  return (
    <>
      {/* ── Bubble ── */}
      <button
        onClick={() => setIsOpen(o => !o)}
        className="fixed bottom-5 right-3 sm:right-5 z-[90] w-12 h-12 bg-black hover:bg-black/85 text-white shadow-xl flex items-center justify-center transition-colors"
        aria-label="Assistant Kiki Jones"
      >
        {isOpen ? <X size={22} /> : <MessageCircle size={22} />}
        {!isOpen && unread > 0 && (
          <span className="absolute -top-1 -right-1 bg-black text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
            {unread}
          </span>
        )}
      </button>

      {/* ── Chat Panel ── */}
      {isOpen && (
        <div className="fixed z-[80] right-3 sm:right-5 bottom-[4.75rem] w-[calc(100vw-1.5rem)] max-w-[340px] h-[min(68dvh,500px)] bg-white flex flex-col overflow-hidden border border-black/15 shadow-2xl">
          {/* Header */}
          <div className="bg-black px-4 py-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <MessageCircle size={16} className="text-white" />
              </div>
              <div>
                <p className="font-semibold text-white text-sm leading-none">
                  {mode === 'agent' ? 'Support Client' : 'Assistant Kiki Jones'}
                </p>
                <p className="text-white/80 text-xs mt-0.5 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-white rounded-full inline-block"></span>
                  {mode === 'agent' ? 'Équipe support' : 'En ligne'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {mode === 'agent' && (
                <button
                  onClick={() => { setMode('bot'); setNeedsLogin(false) }}
                  className="text-white/80 hover:text-white text-xs font-medium underline underline-offset-2"
                >
                  Assistant
                </button>
              )}
              <button onClick={() => setIsOpen(false)} aria-label="Fermer le chat" className="w-10 h-10 -mr-2 flex items-center justify-center text-white hover:bg-white/10 transition-colors">
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {mode === 'agent' ? (
              needsLogin ? (
                <div className="flex flex-col items-center justify-center h-full text-center gap-3 py-8">
                  <Headphones size={32} className="text-[#000000]" />
                  <p className="text-sm text-gray-700 font-medium">Connectez-vous pour discuter avec notre équipe</p>
                  <button
                    onClick={() => { setIsOpen(false); router.push('/login') }}
                    className="bg-[#000000] hover:bg-[#262626] text-white text-sm font-semibold px-4 py-2 rounded-none transition-colors"
                  >
                    Se connecter
                  </button>
                </div>
              ) : (
                <>
                  {humanMessages.length === 0 && !humanLoading && (
                    <p className="text-sm text-gray-500 text-center py-4">Démarrez la conversation avec notre équipe.</p>
                  )}
                  {humanMessages.map(msg => (
                    <div key={msg.id} className={`flex ${!msg.is_from_admin ? 'justify-end' : 'justify-start'}`}>
                      {msg.is_from_admin && (
                        <div className="w-6 h-6 bg-[#000000] rounded-full flex items-center justify-center shrink-0 mr-2 mt-1">
                          <Headphones size={12} className="text-white" />
                        </div>
                      )}
                      <div className={`flex flex-col gap-1 max-w-[85%] ${!msg.is_from_admin ? 'items-end' : 'items-start'}`}>
                        <div className={!msg.is_from_admin
                          ? 'bg-[#000000] text-white px-3 py-2 rounded-none rounded-tr-sm text-sm'
                          : 'bg-white border border-gray-200 px-3 py-2 rounded-none rounded-tl-sm text-sm text-gray-800'}>
                          <TextMessage content={msg.content} />
                        </div>
                        <span className="text-[10px] text-gray-400">
                          {new Date(msg.created_at).toLocaleTimeString('fr-CI', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  ))}
                </>
              )
            ) : (
              messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'agent' && (
                    <div className="w-6 h-6 bg-[#000000] rounded-full flex items-center justify-center shrink-0 mr-2 mt-1">
                      <MessageCircle size={12} className="text-white" />
                    </div>
                  )}
                  <div className={`flex flex-col gap-2 max-w-[85%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                    {msg.responses.map((resp, i) => (
                      <div key={i} className={msg.role === 'user'
                        ? 'bg-[#000000] text-white px-3 py-2 rounded-none rounded-tr-sm text-sm'
                        : ''}>
                        {msg.role === 'user'
                          ? <TextMessage content={resp.content} />
                          : renderResponse(resp, msg.id, i)
                        }
                      </div>
                    ))}
                    <span className="text-[10px] text-gray-400">
                      {msg.timestamp.toLocaleTimeString('fr-CI', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))
            )}

            {(mode === 'agent' ? humanLoading : isLoading) && (
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-[#000000] rounded-full flex items-center justify-center">
                  <MessageCircle size={12} className="text-white" />
                </div>
                <div className="bg-white border border-gray-200 rounded-none px-3 py-2 flex items-center gap-2 shadow-sm">
                  <Loader2 size={14} className="text-[#000000] animate-spin" />
                  <span className="text-sm text-gray-500">En train de répondre…</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          {!(mode === 'agent' && needsLogin) && (
            <div className="border-t border-gray-200 bg-white px-3 pt-2.5 pb-2.5 flex items-center gap-2">
              <input
                ref={inputRef}
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={mode === 'agent' ? 'Votre message...' : 'Que cherchez-vous ?'}
                disabled={mode === 'agent' ? humanLoading : isLoading}
                className="flex-1 text-base md:text-sm text-gray-900 placeholder-gray-400 outline-none bg-gray-50 rounded-none px-3 py-2 border border-gray-200 focus:border-[#000000] transition-colors disabled:opacity-50"
              />
              <button
                onClick={handleSend}
                disabled={!inputText.trim() || (mode === 'agent' ? humanLoading : isLoading)}
                className="w-9 h-9 bg-[#000000] hover:bg-[#262626] disabled:bg-gray-300 text-white rounded-none flex items-center justify-center transition-colors"
              >
                <Send size={15} />
              </button>
            </div>
          )}

          {/* Footer */}
          <div className="bg-gray-50 border-t border-gray-100 px-4 py-1.5 text-center">
            <span className="text-[10px] text-gray-400">Kiki Jones · Commandez en quelques secondes</span>
          </div>
        </div>
      )}
    </>
  )
}
