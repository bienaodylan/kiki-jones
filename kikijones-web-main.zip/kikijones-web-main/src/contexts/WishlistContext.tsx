'use client'

import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react'
import { Product, API_ENDPOINTS, fetchAPI } from '@/lib/api'
import { bootstrapAuth, getAccessToken, onAuthChange } from '@/lib/auth-store'

interface WishlistContextType {
  items: Product[]
  isInWishlist: (productId: string) => boolean
  toggleWishlist: (product: Product) => void
  removeFromWishlist: (productId: string) => void
  clearWishlist: () => void
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined)
const LOCAL_KEY = 'kikijones_wishlist'

function loadLocalWishlist(): Product[] {
  try {
    const saved = localStorage.getItem(LOCAL_KEY)
    return saved ? JSON.parse(saved) : []
  } catch {
    return []
  }
}

export function WishlistProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Product[]>([])
  const [isLoaded, setIsLoaded] = useState(false)
  const isSyncedRef = useRef(false)
  const isSyncingRef = useRef(false)

  const syncFromAccount = async () => {
    if (isSyncingRef.current) return
    isSyncingRef.current = true
    const localItems = loadLocalWishlist()
    try {
      if (localItems.length > 0) {
        const merged = await fetchAPI<any[]>(API_ENDPOINTS.wishlistMerge, {
          method: 'POST',
          body: JSON.stringify({ product_ids: localItems.map((p) => p.id) }),
        })
        setItems(merged.map((row) => row.product_details))
        localStorage.removeItem(LOCAL_KEY)
      } else {
        const rows = await fetchAPI<any[]>(API_ENDPOINTS.wishlist)
        setItems(rows.map((row) => row.product_details))
      }
      isSyncedRef.current = true
    } catch (e) {
      console.error('Failed to sync wishlist with account:', e)
      setItems(localItems)
    } finally {
      isSyncingRef.current = false
    }
  }

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const token = await bootstrapAuth()
      if (cancelled) return
      if (token) {
        await syncFromAccount()
      } else {
        setItems(loadLocalWishlist())
      }
      setIsLoaded(true)
    })()

    const unsubscribe = onAuthChange(() => {
      const token = getAccessToken()
      if (token && !isSyncedRef.current) {
        syncFromAccount()
      } else if (!token && isSyncedRef.current) {
        isSyncedRef.current = false
        setItems([])
      }
    })

    return () => {
      cancelled = true
      unsubscribe()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (isLoaded && !isSyncedRef.current) {
      localStorage.setItem(LOCAL_KEY, JSON.stringify(items))
    }
  }, [items, isLoaded])

  const isInWishlist = (productId: string) => items.some((p) => p.id === productId)

  const toggleWishlist = (product: Product) => {
    const alreadySaved = isInWishlist(product.id)
    setItems((current) => (alreadySaved ? current.filter((p) => p.id !== product.id) : [...current, product]))

    if (isSyncedRef.current) {
      fetchAPI(API_ENDPOINTS.wishlist, {
        method: 'POST',
        body: JSON.stringify({ product: product.id }),
      }).catch((e) => console.error('Failed to toggle account wishlist:', e))
    }
  }

  const removeFromWishlist = (productId: string) => {
    if (isInWishlist(productId)) {
      const product = items.find((p) => p.id === productId)
      if (product) toggleWishlist(product)
    }
  }

  const clearWishlist = () => {
    setItems([])
    if (isSyncedRef.current) {
      // No bulk-clear endpoint — remove one by one via toggle semantics
      items.forEach((p) => {
        fetchAPI(API_ENDPOINTS.wishlist, {
          method: 'POST',
          body: JSON.stringify({ product: p.id }),
        }).catch(() => {})
      })
    } else {
      localStorage.setItem(LOCAL_KEY, JSON.stringify([]))
    }
  }

  return (
    <WishlistContext.Provider value={{ items, isInWishlist, toggleWishlist, removeFromWishlist, clearWishlist }}>
      {children}
    </WishlistContext.Provider>
  )
}

export function useWishlist() {
  const context = useContext(WishlistContext)
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider')
  }
  return context
}
