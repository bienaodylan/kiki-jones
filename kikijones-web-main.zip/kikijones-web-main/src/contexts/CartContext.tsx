'use client'

import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react'
import { Product, API_ENDPOINTS, fetchAPI } from '@/lib/api'
import { bootstrapAuth, getAccessToken, onAuthChange } from '@/lib/auth-store'
import { getWithTtl, setWithTtl, TTL } from '@/lib/ttlStorage'

export interface CartItem {
  cartItemId?: string // backend Cart row id — present once synced to the account
  product: Product
  variantId?: string
  selectedColor?: string | null
  selectedSize?: string | null
  quantity: number
  price: number
}

interface CartContextType {
  items: CartItem[]
  addToCart: (item: Omit<CartItem, 'id'>) => void
  removeFromCart: (productId: string, variantId?: string) => void
  updateQuantity: (productId: string, quantity: number, variantId?: string) => void
  clearCart: () => void
  totalItems: number
  totalPrice: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)
const LOCAL_KEY = 'kikijones_cart'

function loadLocalCart(): CartItem[] {
  return getWithTtl<CartItem[]>(LOCAL_KEY, TTL.SEVEN_DAYS) || []
}

function mapServerItem(row: any): CartItem {
  const p = row.product_details
  const priceAdj = row.variant_details?.price_adjustment ? parseFloat(row.variant_details.price_adjustment) : 0
  const basePrice = p.sale_price ? parseFloat(p.sale_price) : parseFloat(p.base_price)
  return {
    cartItemId: row.id,
    product: p,
    variantId: row.variant || undefined,
    selectedColor: row.variant_details?.color || null,
    selectedSize: row.variant_details?.size || null,
    quantity: row.quantity,
    price: basePrice + priceAdj,
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isLoaded, setIsLoaded] = useState(false)
  const isSyncedRef = useRef(false)

  const isSyncingRef = useRef(false)

  const syncFromAccount = async () => {
    if (isSyncingRef.current) return
    isSyncingRef.current = true
    const localItems = loadLocalCart()
    try {
      if (localItems.length > 0) {
        const merged = await fetchAPI<any[]>(`${API_ENDPOINTS.cart}merge/`, {
          method: 'POST',
          body: JSON.stringify({
            items: localItems.map((i) => ({
              product_id: i.product.id,
              variant_id: i.variantId || null,
              quantity: i.quantity,
            })),
          }),
        })
        setItems(merged.map(mapServerItem))
        localStorage.removeItem(LOCAL_KEY)
      } else {
        const rows = await fetchAPI<any[]>(API_ENDPOINTS.cart)
        setItems(rows.map(mapServerItem))
      }
      isSyncedRef.current = true
    } catch (e) {
      console.error('Failed to sync cart with account:', e)
      setItems(localItems)
    } finally {
      isSyncingRef.current = false
    }
  }

  // Initial load: guest cart from localStorage, or account cart (with guest merge) if logged in
  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const token = await bootstrapAuth()
      if (cancelled) return
      if (token) {
        await syncFromAccount()
      } else {
        setItems(loadLocalCart())
      }
      setIsLoaded(true)
    })()

    // React to login/logout happening later in the same session
    const unsubscribe = onAuthChange(() => {
      const token = getAccessToken()
      if (token && !isSyncedRef.current) {
        syncFromAccount()
      } else if (!token && isSyncedRef.current) {
        isSyncedRef.current = false
        setItems([])
      }
    })

    return () => {
      cancelled = true
      unsubscribe()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Persist to localStorage only while acting as a guest (not account-synced)
  useEffect(() => {
    if (isLoaded && !isSyncedRef.current) {
      setWithTtl(LOCAL_KEY, items)
    }
  }, [items, isLoaded])

  const addToCart = (newItem: Omit<CartItem, 'id'>) => {
    setItems((currentItems) => {
      const existingIndex = currentItems.findIndex(
        (item) => String(item.product.id) === String(newItem.product.id) && item.variantId === newItem.variantId
      )
      if (existingIndex > -1) {
        const updated = [...currentItems]
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + newItem.quantity,
        }
        return updated
      }
      return [...currentItems, newItem]
    })

    if (isSyncedRef.current) {
      fetchAPI(API_ENDPOINTS.cart, {
        method: 'POST',
        body: JSON.stringify({
          product: newItem.product.id,
          variant: newItem.variantId || null,
          quantity: newItem.quantity,
        }),
      })
        .then(() => syncFromAccount())
        .catch((e) => console.error('Failed to add item to account cart:', e))
    }
  }

  const removeFromCart = (productId: string, variantId?: string) => {
    const target = items.find((item) => item.product.id === productId && item.variantId === variantId)
    setItems((currentItems) =>
      currentItems.filter((item) => !(item.product.id === productId && item.variantId === variantId))
    )
    if (isSyncedRef.current && target?.cartItemId) {
      fetchAPI(`${API_ENDPOINTS.cart}${target.cartItemId}/`, { method: 'DELETE' }).catch((e) =>
        console.error('Failed to remove item from account cart:', e)
      )
    }
  }

  const updateQuantity = (productId: string, quantity: number, variantId?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, variantId)
      return
    }
    const target = items.find((item) => item.product.id === productId && item.variantId === variantId)
    setItems((currentItems) =>
      currentItems.map((item) =>
        item.product.id === productId && item.variantId === variantId ? { ...item, quantity } : item
      )
    )
    if (isSyncedRef.current && target?.cartItemId) {
      fetchAPI(`${API_ENDPOINTS.cart}${target.cartItemId}/`, {
        method: 'PATCH',
        body: JSON.stringify({ quantity }),
      }).catch((e) => console.error('Failed to update account cart quantity:', e))
    }
  }

  const clearCart = () => {
    setItems([])
    if (isSyncedRef.current) {
      fetchAPI(`${API_ENDPOINTS.cart}clear/`, { method: 'POST' }).catch((e) =>
        console.error('Failed to clear account cart:', e)
      )
    } else {
      setWithTtl(LOCAL_KEY, [])
    }
  }

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  const totalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <CartContext.Provider
      value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return context
}
