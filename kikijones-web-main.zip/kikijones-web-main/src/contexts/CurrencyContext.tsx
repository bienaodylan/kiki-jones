'use client'

import { createContext, useContext, useState, ReactNode } from 'react'

export type Currency = {
  code: string
  symbol: string
  name: string
  rate: number // Taux de conversion depuis XOF
  flag: string
}

// TODO: These rates are approximate and hardcoded. In production, fetch live rates
// from an exchange rate API (e.g., Open Exchange Rates, Fixer.io) and cache them.
// Rates last updated: 2024-01 (approximate values)
export const currencies: Currency[] = [
  { code: 'XOF', symbol: 'CFA', name: 'Franc CFA', rate: 1, flag: '🇨🇮' },
  { code: 'EUR', symbol: '€', name: 'Euro', rate: 0.0015, flag: '🇪🇺' },
  { code: 'USD', symbol: '$', name: 'Dollar US', rate: 0.0017, flag: '🇺🇸' },
  { code: 'GBP', symbol: '£', name: 'Livre Sterling', rate: 0.0013, flag: '🇬🇧' },
  { code: 'MAD', symbol: 'DH', name: 'Dirham Marocain', rate: 0.016, flag: '🇲🇦' },
  { code: 'NGN', symbol: '₦', name: 'Naira Nigérian', rate: 0.70, flag: '🇳🇬' },
]

type CurrencyContextType = {
  currency: Currency
  setCurrency: (currency: Currency) => void
  convertPrice: (priceInXOF: number) => number
  formatPrice: (priceInXOF: number) => string
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined)

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrency] = useState<Currency>(currencies[0]) // XOF par défaut

  const convertPrice = (priceInXOF: number) => {
    return priceInXOF * currency.rate
  }

  const formatPrice = (priceInXOF: number) => {
    if (priceInXOF === undefined || priceInXOF === null || isNaN(priceInXOF)) return ''
    const converted = convertPrice(priceInXOF)
    
    // Format selon la devise
    if (currency.code === 'XOF' || currency.code === 'NGN') {
      return `${Math.round(converted).toLocaleString('fr-FR')} ${currency.symbol}`
    }
    
    return `${converted.toFixed(2)} ${currency.symbol}`
  }

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, convertPrice, formatPrice }}>
      {children}
    </CurrencyContext.Provider>
  )
}

export function useCurrency() {
  const context = useContext(CurrencyContext)
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider')
  }
  return context
}
