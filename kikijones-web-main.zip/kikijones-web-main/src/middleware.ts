import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Routes that require authentication
// /track-order and /gift-card-balance don't exist in this codebase (checked src/app —
// no such routes), so they're intentionally omitted here.
const PROTECTED_ROUTES = ['/compte', '/notifications', '/checkout', '/recompenses', '/roue-chance']

// Routes that should NEVER be blocked by maintenance
const MAINTENANCE_WHITELIST = ['/maintenance', '/_next', '/favicon.ico', '/api']

export function middleware(request: NextRequest) {
  const { searchParams, pathname } = request.nextUrl

  // --- Maintenance bypass ---
  const bypassKey = searchParams.get('bypass')
  const bypassSecret = process.env.MAINTENANCE_BYPASS_SECRET

  if (bypassKey && bypassSecret && bypassKey === bypassSecret) {
    const url = request.nextUrl.clone()
    url.searchParams.delete('bypass')

    const response = NextResponse.redirect(url)
    response.cookies.set('maintenance_bypass', bypassKey, {
      path: '/',
      maxAge: 60 * 60 * 24 * 7,
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
    })
    return response
  }

  // --- Maintenance mode ---
  const isMaintenanceMode = process.env.MAINTENANCE_MODE === 'true'
  if (isMaintenanceMode) {
    const isWhitelisted = MAINTENANCE_WHITELIST.some(
      (route) => pathname === route || pathname.startsWith(route + '/') || pathname.startsWith(route)
    )
    const hasBypassCookie = request.cookies.get('maintenance_bypass')?.value === bypassSecret

    if (!isWhitelisted && !hasBypassCookie) {
      const maintenanceUrl = request.nextUrl.clone()
      maintenanceUrl.pathname = '/maintenance'
      maintenanceUrl.search = ''
      const requestHeaders = new Headers(request.headers)
      requestHeaders.set('x-maintenance-mode', '1')
      return NextResponse.rewrite(maintenanceUrl, {
        request: { headers: requestHeaders },
      })
    }
  }

  // --- Auth guard for protected routes ---
  const isProtected = PROTECTED_ROUTES.some(
    (route) => pathname === route || pathname.startsWith(route + '/')
  )

  if (isProtected) {
    // Check httpOnly refresh_token cookie — unforgeable by client JS
    const hasSession = request.cookies.get('refresh_token')?.value
    if (!hasSession) {
      const loginUrl = request.nextUrl.clone()
      loginUrl.pathname = '/login'
      loginUrl.searchParams.set('redirect', pathname)
      return NextResponse.redirect(loginUrl)
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}
