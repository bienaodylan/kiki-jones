/**
 * Custom hook for using CMS section configurations
 */
'use client'

import { useEffect, useState } from 'react'
import { getSectionConfig, getSectionConfigs, SectionConfig } from '@/lib/api/cms'

/**
 * Hook pour récupérer une configuration de section spécifique
 */
export function useSectionConfig(section: string, platform: 'web' | 'mobile' = 'web') {
  const [config, setConfig] = useState<SectionConfig | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    let mounted = true

    async function loadConfig() {
      try {
        setIsLoading(true)
        const data = await getSectionConfig(section, platform)
        
        if (mounted) {
          setConfig(data)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err : new Error('Failed to load config'))
          setConfig(null)
        }
      } finally {
        if (mounted) {
          setIsLoading(false)
        }
      }
    }

    loadConfig()

    return () => {
      mounted = false
    }
  }, [section, platform])

  return { config, isLoading, error }
}

/**
 * Hook pour récupérer toutes les configurations d'une plateforme
 */
export function useSectionConfigs(platform: 'web' | 'mobile' = 'web') {
  const [configs, setConfigs] = useState<SectionConfig[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    let mounted = true

    async function loadConfigs() {
      try {
        setIsLoading(true)
        const data = await getSectionConfigs(platform)
        
        if (mounted) {
          setConfigs(data)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err : new Error('Failed to load configs'))
          setConfigs([])
        }
      } finally {
        if (mounted) {
          setIsLoading(false)
        }
      }
    }

    loadConfigs()

    return () => {
      mounted = false
    }
  }, [platform])

  /**
   * Helper pour trouver une config par section
   */
  const getConfig = (section: string) => {
    return configs.find(c => c.section === section)
  }

  return { configs, getConfig, isLoading, error }
}

/**
 * Hook pour les styles CSS d'une section
 */
export function useSectionStyles(section: string, platform: 'web' | 'mobile' = 'web') {
  const { config, isLoading, error } = useSectionConfig(section, platform)

  const titleStyles = config?.title_styles || {}
  const subtitleStyles = config?.subtitle_styles || {}
  const spacingStyles = config?.spacing_styles || {}
  const containerStyles = {
    ...spacingStyles,
    display: config?.is_active === false ? 'none' : undefined,
  }

  return {
    titleStyles,
    subtitleStyles,
    spacingStyles,
    containerStyles,
    config,
    isLoading,
    error,
  }
}
