'use client'

import { useEffect, useRef } from 'react'

/**
 * Returns an AbortSignal that is aborted when the component unmounts
 * or when deps change (creating a new signal each time).
 * 
 * Usage:
 *   const signal = useAbortSignal([dep1, dep2])
 *   useEffect(() => {
 *     fetch(url, { signal }).then(...)
 *   }, [signal])
 */
export function useAbortSignal(deps: unknown[] = []): AbortSignal {
  const controllerRef = useRef<AbortController>(new AbortController())

  useEffect(() => {
    // Create a fresh controller on mount / deps change
    controllerRef.current = new AbortController()
    const controller = controllerRef.current

    return () => {
      controller.abort()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return controllerRef.current.signal
}

/**
 * Returns an AbortController ref that auto-aborts on unmount.
 * Call getSignal() to get the current signal for fetch calls.
 * 
 * Usage:
 *   const { getSignal } = useAbortController()
 *   useEffect(() => {
 *     const signal = getSignal()
 *     fetchAPI(url, { signal }).then(...)
 *     // auto-aborted on unmount
 *   }, [...])
 */
export function useAbortController() {
  const controllerRef = useRef<AbortController | null>(null)

  useEffect(() => {
    return () => {
      controllerRef.current?.abort()
    }
  }, [])

  const getSignal = (): AbortSignal => {
    // Abort any previous in-flight request
    controllerRef.current?.abort()
    controllerRef.current = new AbortController()
    return controllerRef.current.signal
  }

  return { getSignal }
}
