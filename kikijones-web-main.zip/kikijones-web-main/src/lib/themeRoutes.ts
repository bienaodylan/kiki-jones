import { slugifyName } from '@/lib/themeCategories'

const THEME_TO_SHOP_NAME: Record<string, string> = {
  dresses: 'Robe',
  'matching-sets': 'Ensemble',
  shirts: 'Chemise',
  tops: 'Chemise',
  jumpsuits: 'Combinaison',
  jeans: 'Jean',
  pants: 'Pantalon',
  bottoms: 'Short',
  activewear: 'Sport',
  shoes: 'Chaussures',
  sunglasses: 'Lunettes de soleil',
  bags: 'Sac',
  jewelry: 'Bijoux',
}

/** Slug de catégorie de la boutique pour un slug du thème (ex. « dresses » → « robe »). */
export function shopSlugFor(themeSlug: string): string {
  return slugifyName(THEME_TO_SHOP_NAME[themeSlug] || themeSlug)
}

/** Nom d'une catégorie à partir de son slug boutique (pour les pages de catégories encore vides). */
export function shopNameForSlug(slug: string): string | null {
  for (const n of new Set([...Object.values(THEME_TO_SHOP_NAME), 'T-shirt', 'Polo', 'Sweat', 'Corset & Body'])) {
    if (slugifyName(n) === slug) return n
  }
  return null
}

/** Convertit un lien du thème (/women/dresses, /category/shoes, /brand/kiki-men…) en lien de la boutique. */
export function mapThemeHref(href: string): string {
  if (!href || href === '/') return '/'
  if (href.startsWith('/categories/') || href.startsWith('/produits') || href.startsWith('/promotions')) return href
  const parts = href.split('/').filter(Boolean)
  const [a, b] = parts
  if (a === 'category' && b) return `/categories/${shopSlugFor(b)}`
  if (['women', 'men', 'girls', 'boys'].includes(a)) {
    if (!b) return '/produits'
    if (b === 'new-in') return '/produits?is_new=true'
    if (b === 'best-sellers') return '/produits?ordering=popular'
    return `/categories/${shopSlugFor(b)}`
  }
  if (a === 'brands') return '/brands'
  if (a === 'collections') return '/collections'
  if (a === 'categories') return '/categories'
  if (a === 'brand' && b) return `/produits?brand=${b}`
  if (a === 'collection' && b) return `/produits?collection=${b}`
  if (a === 'new-in') return '/produits?is_new=true'
  if (a === 'sale') return '/promotions'
  return '/produits'
}
