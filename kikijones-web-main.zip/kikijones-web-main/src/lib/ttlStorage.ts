/**
 * Lightweight TTL wrapper around localStorage.
 * Wraps a value with a `savedAt` timestamp on write, and discards it on read
 * if it has exceeded the given max age — so stale cart/coupon/order data
 * doesn't linger in the browser forever.
 */

interface TtlEnvelope<T> {
  value: T
  savedAt: number
}

export function setWithTtl<T>(key: string, value: T): void {
  try {
    const envelope: TtlEnvelope<T> = { value, savedAt: Date.now() }
    localStorage.setItem(key, JSON.stringify(envelope))
  } catch {
    // ignore (storage disabled/full)
  }
}

/**
 * Reads a TTL-wrapped value. Returns null (and clears the key) if it's
 * missing, malformed, or older than maxAgeMs.
 *
 * For backward compatibility, also accepts raw (non-enveloped) JSON values
 * previously written without a TTL wrapper — those are treated as fresh
 * (no `savedAt` to compare against) so existing users aren't logged out
 * of their cart on the first deploy of this change.
 */
export function getWithTtl<T>(key: string, maxAgeMs: number): T | null {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return null
    const parsed = JSON.parse(raw)

    if (parsed && typeof parsed === 'object' && 'savedAt' in parsed && 'value' in parsed) {
      const envelope = parsed as TtlEnvelope<T>
      if (Date.now() - envelope.savedAt > maxAgeMs) {
        localStorage.removeItem(key)
        return null
      }
      return envelope.value
    }

    // Legacy unwrapped value — accept as-is.
    return parsed as T
  } catch {
    return null
  }
}

export const TTL = {
  ONE_HOUR: 60 * 60 * 1000,
  ONE_DAY: 24 * 60 * 60 * 1000,
  SEVEN_DAYS: 7 * 24 * 60 * 60 * 1000,
}
