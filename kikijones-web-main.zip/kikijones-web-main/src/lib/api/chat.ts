/**
 * Chat & Disputes API Service
 */

import { fetchAPI, API_ENDPOINTS } from './config'
import { getAuthToken } from './auth'

// Types
export interface Message {
  id: string
  conversation: string
  sender_name: string
  content: string
  is_from_admin: boolean
  is_read: boolean
  attachment: string | null
  created_at: string
}

export interface Conversation {
  id: string
  subject: string
  status: 'active' | 'waiting' | 'resolved' | 'closed'
  order_number: string | null
  last_message: Message | null
  unread_count: number
  has_dispute: boolean
  created_at: string
  updated_at: string
}

export interface ConversationDetail extends Conversation {
  messages: Message[]
  agent_name: string | null
}

export interface Dispute {
  id: string
  dispute_number: string
  order_number: string
  reason: string
  reason_display: string
  description: string
  status: string
  status_display: string
  priority: string
  priority_display: string
  resolution_type: string | null
  resolution_note: string | null
  refund_amount: string | null
  conversation_id: string
  created_at: string
  resolved_at: string | null
}

export type DisputeReason =
  | 'not_received'
  | 'wrong_item'
  | 'damaged'
  | 'quality'
  | 'size'
  | 'late_delivery'
  | 'missing_item'
  | 'other'

function authHeaders() {
  const token = getAuthToken()
  if (!token) throw new Error('Non authentifié')
  return { Authorization: `Bearer ${token}` }
}

/**
 * Get all conversations for the current user
 */
export async function getConversations(): Promise<Conversation[]> {
  const data = await fetchAPI<any>(API_ENDPOINTS.conversations, {
    headers: authHeaders(),
  })
  return Array.isArray(data) ? data : (data.results || [])
}

/**
 * Get conversation detail with messages
 */
export async function getConversation(id: string): Promise<ConversationDetail> {
  return fetchAPI<ConversationDetail>(
    API_ENDPOINTS.conversationDetail(id),
    { headers: authHeaders() }
  )
}

/**
 * Create a new conversation
 */
export async function createConversation(data: {
  subject: string
  message: string
  order_id?: string
}): Promise<ConversationDetail> {
  return fetchAPI<ConversationDetail>(API_ENDPOINTS.conversations, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(data),
  })
}

/**
 * Get the current user's active/waiting conversation, or create one
 */
export async function getOrCreateConversation(): Promise<ConversationDetail> {
  return fetchAPI<ConversationDetail>(API_ENDPOINTS.conversationGetOrCreate, {
    method: 'POST',
    headers: authHeaders(),
  })
}

/**
 * Send a message in a conversation
 */
export async function sendMessage(
  conversationId: string,
  content: string,
  attachment?: File
): Promise<Message> {
  const token = getAuthToken()
  if (!token) throw new Error('Non authentifié')

  if (attachment) {
    const formData = new FormData()
    formData.append('content', content)
    formData.append('attachment', attachment)
    return fetchAPI<Message>(
      API_ENDPOINTS.conversationMessages(conversationId),
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      }
    )
  }

  return fetchAPI<Message>(
    API_ENDPOINTS.conversationMessages(conversationId),
    {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ content }),
    }
  )
}

/**
 * Get all disputes for the current user
 */
export async function getDisputes(): Promise<Dispute[]> {
  const data = await fetchAPI<any>(API_ENDPOINTS.disputes, {
    headers: authHeaders(),
  })
  return Array.isArray(data) ? data : (data.results || [])
}

/**
 * Get dispute detail
 */
export async function getDispute(id: string): Promise<Dispute> {
  return fetchAPI<Dispute>(API_ENDPOINTS.disputeDetail(id), {
    headers: authHeaders(),
  })
}

/**
 * Create a new dispute
 */
export async function createDispute(data: {
  order_id: string
  reason: DisputeReason
  description: string
  evidence?: File
}): Promise<Dispute> {
  const token = getAuthToken()
  if (!token) throw new Error('Non authentifié')

  const formData = new FormData()
  formData.append('order_id', data.order_id)
  formData.append('reason', data.reason)
  formData.append('description', data.description)
  if (data.evidence) {
    formData.append('evidence', data.evidence)
  }

  return fetchAPI<Dispute>(API_ENDPOINTS.disputes, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: formData,
  })
}
