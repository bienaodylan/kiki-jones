/**
 * Authentication API Service
 */

import { fetchAPI, API_ENDPOINTS } from './config'
import { getAccessToken, setAccessToken, clearAuth } from '@/lib/auth-store'

export interface User {
  id: number
  email: string
  first_name: string
  last_name: string
  phone?: string
  address?: string
  city?: string
  country?: string
  postal_code?: string
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData {
  email: string
  password: string
  first_name: string
  last_name: string
  phone?: string
}

export interface AuthResponse {
  tokens: { access: string; refresh: string }
  user: User
}

/**
 * Login user
 */
export async function login(credentials: LoginCredentials): Promise<AuthResponse> {
  return fetchAPI<AuthResponse>(API_ENDPOINTS.login, {
    method: 'POST',
    body: JSON.stringify(credentials),
  })
}

/**
 * Register new user
 */
export async function register(data: RegisterData): Promise<AuthResponse> {
  return fetchAPI<AuthResponse>(API_ENDPOINTS.register, {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

/**
 * Get current user profile
 */
export async function getProfile(token: string): Promise<User> {
  return fetchAPI<User>(API_ENDPOINTS.profile, {
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  })
}

/**
 * Update user profile
 */
export async function updateProfile(token: string, data: Partial<User>): Promise<User> {
  return fetchAPI<User>(API_ENDPOINTS.profileUpdate, {
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(data),
  })
}

/**
 * Check if user is authenticated (in-memory token present)
 */
export function isAuthenticated(): boolean {
  if (typeof window === 'undefined') return false
  return !!getAccessToken()
}

/**
 * Get stored auth token (from memory)
 */
export function getAuthToken(): string | null {
  return getAccessToken()
}

/**
 * Store auth token (in memory only — never localStorage)
 */
export function setAuthToken(token: string): void {
  setAccessToken(token)
}

/**
 * Remove auth token (logout) — clears memory + httpOnly cookie via API route
 */
export async function removeAuthToken(): Promise<void> {
  const token = getAccessToken()
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    }).catch(() => {})
  } catch {
    // Best-effort
  }
  clearAuth()
}

/**
 * Request password reset email
 */
export async function forgotPassword(email: string): Promise<{ message: string }> {
  return fetchAPI<{ message: string }>(API_ENDPOINTS.forgotPassword, {
    method: 'POST',
    body: JSON.stringify({ email }),
  })
}
