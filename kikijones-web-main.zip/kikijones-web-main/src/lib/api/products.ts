/**
 * Products API Service
 */

import { fetchWithRevalidate, fetchAPI, API_ENDPOINTS, ApiResponse } from './config'

export interface Product {
  id: string
  name: string
  slug: string
  description: string
  short_description?: string
  category: string
  category_name: string
  main_image: string | null
  images: Array<{
    id: string
    image: string
    alt_text?: string
    display_order: number
  }>
  variants?: Array<{
    id: string
    sku: string
    size?: string
    color?: string
    color_hex?: string
    stock: number
    in_stock: boolean
    price_adjustment: number
    image?: string | null
  }>
  base_price: string
  sale_price?: string | null
  discount_percentage: number
  final_price: number
  total_stock: number
  is_external_stock?: boolean
  is_in_stock: boolean
  is_active: boolean
  is_featured: boolean
  is_new: boolean
  is_bestseller?: boolean
  brand_slug?: string
  complementary_products?: Product[]
  views_count: number
  sales_count: number
  average_rating: string
  reviews_count: number
  created_at: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description?: string
  parent?: string | null
  image?: string | null
  display_image?: string | null
  is_active: boolean
  display_order: number
  subcategories?: Category[]
}

/**
 * Get all products with optional filters
 */
export async function getProducts(params?: {
  category?: string
  brand?: string
  collection?: string
  is_featured?: boolean
  is_new?: boolean
  is_bestseller?: boolean
  search?: string
  ordering?: string
  page?: number
  page_size?: number
  color?: string
  size?: string
  min_price?: number
  max_price?: number
}): Promise<{ results: Product[]; count: number; next: string | null }> {
  const searchParams = new URLSearchParams()
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, value.toString())
      }
    })
  }
  
  const url = `${API_ENDPOINTS.products}?${searchParams.toString()}`
  const response = await fetchWithRevalidate<ApiResponse<Product>>(url, 60) // 60s cache
  
  return {
    results: response.results || [],
    count: response.count || 0,
    next: response.next || null
  }
}

export interface FilterColor {
  name: string
  hex: string
}

export interface FilterOptions {
  colors: FilterColor[]
  sizes: string[]
}

/**
 * Get available filter options (colors, sizes) for products
 */
export async function getFilterOptions(categoryId?: string): Promise<FilterOptions> {
  const searchParams = new URLSearchParams()
  if (categoryId) {
    searchParams.append('category', categoryId)
  }
  const url = `${API_ENDPOINTS.products}filter_options/?${searchParams.toString()}`
  const response = await fetchWithRevalidate<FilterOptions>(url, 120)
  return response
}

/**
 * Get featured products
 */
export async function getFeaturedProducts(limit: number = 8): Promise<Product[]> {
  const { results } = await getProducts({ is_featured: true })
  return results.slice(0, limit)
}

/**
 * Get new arrivals
 */
export async function getNewArrivals(limit: number = 8): Promise<Product[]> {
  const { results } = await getProducts({ 
    is_new: true,
    ordering: '-created_at'
  })
  return results.slice(0, limit)
}

/**
 * Get bestsellers
 */
export async function getBestsellers(limit: number = 8): Promise<Product[]> {
  const { results } = await getProducts({ is_bestseller: true })
  return results.slice(0, limit)
}

/**
 * Get trending products (bestsellers)
 */
export async function getTrendingProducts(limit: number = 8): Promise<Product[]> {
  return getBestsellers(limit)
}

/**
 * Get products on sale (Flash Sales)
 */
export async function getOnSaleProducts(limit: number = 6): Promise<Product[]> {
  try {
    const url = `${API_ENDPOINTS.products}on_sale/`
    const data = await fetchWithRevalidate<Product[]>(url, 120)
    return Array.isArray(data) ? data.slice(0, limit) : []
  } catch (error) {
    console.error('Error fetching on sale products:', error)
    return []
  }
}

/**
 * Get product by slug
 */
export async function getProductBySlug(slug: string): Promise<Product | null> {
  try {
    const url = `${API_ENDPOINTS.products}${slug}/`
    const response = await fetchWithRevalidate<Product>(url, 60) // 60s cache
    return response
  } catch (error) {
    console.error('Error fetching product by slug:', error)
    return null
  }
}

/**
 * Get product by ID
 */
export async function getProductById(id: number): Promise<Product> {
  return fetchWithRevalidate<Product>(API_ENDPOINTS.productDetail(id.toString()), 60) // 60s cache
}

/**
 * Get all categories
 */
export async function getCategories(): Promise<Category[]> {
  const response = await fetchWithRevalidate<Category[] | ApiResponse<Category>>(
    API_ENDPOINTS.categories,
    120 // 2min cache
  )
  
  // Handle both array response (no pagination) and paginated response
  if (Array.isArray(response)) {
    return response
  }
  
  return response.results || []
}

/**
 * Get active categories only
 */
export async function getActiveCategories(): Promise<Category[]> {
  const categories = await getCategories()
  return categories.filter(c => c.is_active)
}

/**
 * Get category by slug
 * Throws on API errors (429, 500) so callers can distinguish from "not found"
 */
export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  const categories = await getCategories()
  return categories.find(c => c.slug === slug) || null
}

/**
 * Get parent categories (top-level) with their subcategories
 */
export async function getParentCategories(): Promise<Category[]> {
  // Use API filter to get only parent categories
  const response = await fetchAPI<Category[] | ApiResponse<Category>>(
    `${API_ENDPOINTS.categories}?parent__isnull=true`
  )
  
  // Handle both array response (no pagination) and paginated response
  if (Array.isArray(response)) {
    return response.filter(c => !c.parent)
  }
  
  return response.results || []
}

/**
 * Get products by category
 */
export async function getProductsByCategory(
  categorySlug: string,
  limit?: number
): Promise<Product[]> {
  const { results } = await getProducts({ category: categorySlug })
  return limit ? results.slice(0, limit) : results
}
