/**
 * API Configuration and Base Client
 */

import { getAccessToken, setAccessToken, clearAuth } from '@/lib/auth-store'

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'https://admin.kikijones.com/api'

// Derive media base URL from API URL (strip /api suffix)
const MEDIA_BASE_URL = API_BASE_URL.replace(/\/api\/?$/, '')

export { API_BASE_URL, MEDIA_BASE_URL }

/**
 * Get full URL for a media path (image, etc.)
 * If the path is already absolute, return it as-is.
 */
export function getMediaUrl(path: string | null | undefined): string {
  if (!path) return ''
  if (path.startsWith('http')) return path
  return `${MEDIA_BASE_URL}${path}`
}

export const API_ENDPOINTS = {
  // Products
  products: `${API_BASE_URL}/products/products/`,
  productDetail: (id: string) => `${API_BASE_URL}/products/products/${id}/`,
  categories: `${API_BASE_URL}/products/categories/`,
  
  // CMS
  cms: `${API_BASE_URL}/cms`,
  banners: `${API_BASE_URL}/cms/banners/`,
  homeSections: `${API_BASE_URL}/cms/home-sections/`,
  config: `${API_BASE_URL}/cms/config/`,
  announcements: `${API_BASE_URL}/cms/announcements/`,
  pages: `${API_BASE_URL}/cms/pages/`,
  siteSettings: `${API_BASE_URL}/cms/settings/`,
  
  // Auth
  login: `${API_BASE_URL}/auth/login/`,
  register: `${API_BASE_URL}/auth/register/`,
  profile: `${API_BASE_URL}/auth/profile/`,
  profileUpdate: `${API_BASE_URL}/auth/profile/update/`,
  logout: `${API_BASE_URL}/auth/logout/`,
  forgotPassword: `${API_BASE_URL}/auth/forgot-password/`,
  resetPassword: `${API_BASE_URL}/auth/reset-password/`,
  changePassword: `${API_BASE_URL}/auth/change-password/`,
  deleteAccount: `${API_BASE_URL}/auth/delete-account/`,
  
  // Gamification
  gamificationPoints: `${API_BASE_URL}/gamification/my-points/`,
  gamificationWheel: `${API_BASE_URL}/gamification/wheel/`,
  gamificationSpin: `${API_BASE_URL}/gamification/wheel/spin/`,
  gamificationSpinHistory: `${API_BASE_URL}/gamification/wheel/history/`,
  gamificationCheckin: `${API_BASE_URL}/gamification/checkin/`,
  gamificationCheckinStatus: `${API_BASE_URL}/gamification/checkin/status/`,
  gamificationMysteryBoxes: `${API_BASE_URL}/gamification/mystery-boxes/`,
  gamificationOpenBox: (boxId: string) => `${API_BASE_URL}/gamification/mystery-boxes/${boxId}/open/`,
  gamificationRules: `${API_BASE_URL}/gamification/rules/`,
  gamificationTiers: `${API_BASE_URL}/gamification/tiers/`,
  gamificationRewards: `${API_BASE_URL}/gamification/rewards/`,

  // Chat & Disputes
  conversations: `${API_BASE_URL}/chat/conversations/`,
  conversationGetOrCreate: `${API_BASE_URL}/chat/conversations/get_or_create/`,
  conversationDetail: (id: string) => `${API_BASE_URL}/chat/conversations/${id}/`,
  conversationMessages: (id: string) => `${API_BASE_URL}/chat/conversations/${id}/messages/`,
  disputes: `${API_BASE_URL}/chat/disputes/`,
  disputeDetail: (id: string) => `${API_BASE_URL}/chat/disputes/${id}/`,

  // Orders
  orders: `${API_BASE_URL}/orders/`,
  orderDetail: (id: string) => `${API_BASE_URL}/orders/${id}/`,

  // Addresses
  addresses: `${API_BASE_URL}/auth/addresses/`,
  addressCreate: `${API_BASE_URL}/auth/addresses/create/`,
  addressDetail: (id: string) => `${API_BASE_URL}/auth/addresses/${id}/`,

  // Wishlist
  wishlist: `${API_BASE_URL}/products/wishlist/`,
  wishlistMerge: `${API_BASE_URL}/products/wishlist/merge/`,

  // Cart
  cart: `${API_BASE_URL}/products/cart/`,

  // Reviews
  reviews: `${API_BASE_URL}/reviews/`,
  productReviews: (productId: string) => `${API_BASE_URL}/reviews/?product=${productId}`,
  canReview: (productId: string) => `${API_BASE_URL}/reviews/can-review/${productId}/`,

  // Notifications
  notifications: `${API_BASE_URL}/notifications/`,
  notificationsUnreadCount: `${API_BASE_URL}/notifications/unread-count/`,

  // Promotions
  validateCoupon: `${API_BASE_URL}/promotions/validate-coupon/`,
  myCoupons: `${API_BASE_URL}/promotions/my-coupons/`,

  // CMS extras
  popups: `${API_BASE_URL}/cms/popups/`,
  popupView: (id: string) => `${API_BASE_URL}/cms/popups/${id}/view/`,
  popupClick: (id: string) => `${API_BASE_URL}/cms/popups/${id}/click/`,
  newsletterSubscribe: `${API_BASE_URL}/cms/newsletter/subscribe/`,

  // Payments
  initPayment: (orderId: string) => `${API_BASE_URL}/orders/${orderId}/init_payment/`,

  // Gift Cards
  giftcardAmounts: `${API_BASE_URL}/giftcards/amounts/`,
  giftcardPurchase: `${API_BASE_URL}/giftcards/purchase/`,
  giftcardCheckBalance: `${API_BASE_URL}/giftcards/check-balance/`,
  giftcardRedeem: `${API_BASE_URL}/giftcards/redeem/`,
  giftcardMyCards: `${API_BASE_URL}/giftcards/my-cards/`,

  // Referral
  referralDashboard: `${API_BASE_URL}/referral/dashboard/`,
  referralValidate: `${API_BASE_URL}/referral/validate/`,
  referralCredits: `${API_BASE_URL}/referral/credits/`,
  referralStats: `${API_BASE_URL}/referral/stats/`,
}

export interface ApiResponse<T> {
  count?: number
  next?: string | null
  previous?: string | null
  results?: T[]
  data?: T
}

/**
 * Generic fetch wrapper with error handling and automatic token refresh
 */
let refreshPromise: Promise<string | null> | null = null

async function refreshAccessToken(): Promise<string | null> {
  if (typeof window === 'undefined') return null

  try {
    const res = await fetch('/api/auth/refresh', {
      method: 'POST',
      credentials: 'include',
    })
    if (!res.ok) throw new Error('Refresh failed')
    const data = await res.json()
    setAccessToken(data.access)
    return data.access
  } catch {
    clearAuth()
    return null
  }
}

export async function fetchAPI<T>(
  url: string,
  options: RequestInit = {}
): Promise<T> {
  const { headers: optHeaders, body, ...restOptions } = options
  const isFormData = typeof FormData !== 'undefined' && body instanceof FormData
  const defaultHeaders: Record<string, string> = isFormData
    ? {}
    : { 'Content-Type': 'application/json' }
  
  // Auto-attach auth token if available (from in-memory store)
  if (typeof window !== 'undefined') {
    const token = getAccessToken()
    if (token) {
      defaultHeaders['Authorization'] = `Bearer ${token}`
    }
  }
  
  const defaultOptions: RequestInit = {
    ...restOptions,
    body,
    headers: {
      ...defaultHeaders,
      ...(optHeaders as Record<string, string>),
    },
  }

  try {
    let response = await fetch(url, defaultOptions)
    
    // Auto-refresh token on 401 (single concurrent refresh via shared promise)
    if (response.status === 401 && typeof window !== 'undefined') {
      if (!refreshPromise) {
        refreshPromise = refreshAccessToken().finally(() => { refreshPromise = null })
      }
      const newToken = await refreshPromise
      
      if (newToken) {
        const retryHeaders = {
          ...defaultHeaders,
          ...(optHeaders as Record<string, string>),
          'Authorization': `Bearer ${newToken}`,
        }
        response = await fetch(url, { ...restOptions, body, headers: retryHeaders })
      }
    }
    
    if (!response.ok) {
      // Parse error body for meaningful messages from backend
      let errorBody: any = null
      try { errorBody = await response.json() } catch { /* no JSON body */ }
      const msg = errorBody?.error || errorBody?.detail || errorBody?.message
        || `${response.status} ${response.statusText}`
      const err = new Error(`API Error: ${msg}`) as any
      err.status = response.status
      err.body = errorBody
      throw err
    }
    
    return await response.json()
  } catch (error) {
    console.error('API Fetch Error:', error)
    throw error
  }
}

/**
 * Fetch with Next.js revalidation
 */
export async function fetchWithRevalidate<T>(
  url: string,
  revalidate: number = 300 // 5 minutes default
): Promise<T> {
  return fetchAPI<T>(url, {
    next: { revalidate, tags: ['api-data'] },
  })
}
