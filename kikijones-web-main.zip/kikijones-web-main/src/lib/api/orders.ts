/**
 * Orders API Service
 */

import { fetchAPI, API_ENDPOINTS, ApiResponse } from './config'
import { getAuthToken } from './auth'

export interface OrderItem {
  id: string
  product: {
    id: string
    name: string
    slug: string
    images: { id: string; image: string }[]
  }
  product_name: string
  variant_details: string
  variant_sku: string
  quantity: number
  unit_price: string
  subtotal: string
  total_price: string
}

export interface OrderStatusHistory {
  id: string
  status: string
  note: string
  changed_by_name: string
  created_at: string
}

export interface Order {
  id: string
  order_number: string
  status: string
  payment_status: string
  payment_method: string
  subtotal: string
  shipping_cost: string
  tax_amount: string
  discount_amount: string
  total_amount: string
  currency: string
  coupon_code: string | null
  shipping_first_name: string
  shipping_last_name: string
  shipping_email: string
  shipping_phone: string
  shipping_address_line1: string
  shipping_address_line2: string
  shipping_city: string
  shipping_state: string
  shipping_postal_code: string
  shipping_country: string
  customer_notes: string
  tracking_number: string | null
  carrier: string | null
  shipped_at: string | null
  delivered_at: string | null
  order_items: OrderItem[]
  status_history_list: OrderStatusHistory[]
  created_at: string
  updated_at: string
}

function authHeaders(): Record<string, string> {
  const token = getAuthToken()
  return token ? { 'Authorization': `Bearer ${token}` } : {}
}

/**
 * Get all orders for the authenticated user
 */
export async function getOrders(): Promise<ApiResponse<Order>> {
  return fetchAPI<ApiResponse<Order>>(API_ENDPOINTS.orders, {
    headers: authHeaders(),
  })
}

/**
 * Get a single order by ID
 */
export async function getOrder(id: string): Promise<Order> {
  return fetchAPI<Order>(API_ENDPOINTS.orderDetail(id), {
    headers: authHeaders(),
  })
}

export interface TrackingStep {
  status: string
  label: string
  done: boolean
  current: boolean
  date: string | null
}

export interface TrackingInfo {
  order_number: string
  status: string
  tracking_number: string | null
  carrier: string | null
  shipped_at: string | null
  delivered_at: string | null
  estimated_delivery: string | null
  steps: TrackingStep[]
  history: OrderStatusHistory[]
}

/**
 * Get order tracking info
 */
export async function getOrderTracking(id: string): Promise<TrackingInfo> {
  return fetchAPI<TrackingInfo>(`${API_ENDPOINTS.orderDetail(id)}tracking/`, {
    headers: authHeaders(),
  })
}

/**
 * Search order by order number (for public tracking)
 */
export async function searchOrderByNumber(orderNumber: string): Promise<Order | null> {
  try {
    const cleanNumber = orderNumber.trim().toUpperCase()
    const result = await fetchAPI<ApiResponse<Order>>(`${API_ENDPOINTS.orders}?order_number=${encodeURIComponent(cleanNumber)}`, {
      headers: authHeaders(),
    })
    // Verify the returned order actually matches the requested number
    const order = result.results?.[0] || null
    if (order && order.order_number.toUpperCase() !== cleanNumber) {
      return null // Wrong order returned, treat as not found
    }
    return order
  } catch {
    return null
  }
}

/**
 * Get order status display label
 */
export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    pending: 'En attente',
    confirmed: 'Confirmée',
    processing: 'En préparation',
    shipped: 'Expédiée',
    delivered: 'Livrée',
    cancelled: 'Annulée',
    refunded: 'Remboursée',
  }
  return labels[status] || status
}

/**
 * Get order status color
 */
export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    processing: 'bg-indigo-100 text-indigo-800',
    shipped: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
    refunded: 'bg-gray-100 text-gray-800',
  }
  return colors[status] || 'bg-gray-100 text-gray-800'
}
