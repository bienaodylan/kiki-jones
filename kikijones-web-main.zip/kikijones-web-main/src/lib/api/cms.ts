/**
 * CMS API Service
 */

import { fetchWithRevalidate, API_ENDPOINTS, ApiResponse } from './config'

export interface Banner {
  id: string
  title: string
  subtitle?: string
  description?: string
  banner_type: 'hero' | 'promo' | 'category' | 'flash' | 'info'
  platform: 'both' | 'web' | 'mobile'
  image_desktop: string
  image_tablet?: string
  image_mobile?: string
  button_text?: string
  link_url: string
  text_color: string
  background_color: string
  text_position: 'left' | 'center' | 'right'
  display_order: number
  is_active: boolean
}

export interface HomeSection {
  id: string
  title: string
  subtitle?: string
  section_type: 'featured_products' | 'new_arrivals' | 'best_sellers' | 'trending' | 'categories' | 'flash_sales' | 'custom'
  products: any[]
  display_order: number
  items_to_show: number
  layout: 'grid' | 'carousel' | 'list'
  is_active: boolean
  platform: 'both' | 'web' | 'mobile'
}

export interface Announcement {
  id: string
  message: string
  announcement_type: 'info' | 'warning' | 'success' | 'promo'
  link_text?: string
  link_url?: string
  background_color: string
  text_color: string
  platform: 'both' | 'web' | 'mobile'
}

export interface SectionConfig {
  id: string
  platform: 'web' | 'mobile'
  section: string
  title: string
  subtitle: string
  title_font_family: string
  title_font_size: number
  title_font_weight: string
  title_color: string
  title_align: 'left' | 'center' | 'right'
  subtitle_font_family: string
  subtitle_font_size: number
  subtitle_font_weight: string
  subtitle_color: string
  margin_top: number
  margin_bottom: number
  padding_horizontal: number
  countdown_enabled: boolean
  countdown_end_date?: string
  is_active: boolean
  display_order: number
  title_styles: {
    fontFamily: string
    fontSize: string
    fontWeight: string
    color: string
    textAlign: string
  }
  subtitle_styles: {
    fontFamily: string
    fontSize: string
    fontWeight: string
    color: string
  }
  spacing_styles: {
    marginTop: string
    marginBottom: string
    paddingLeft: string
    paddingRight: string
  }
}

export interface AppConfig {
  [key: string]: string
}

export interface SiteSettings {
  logo_light?: string
  logo_dark?: string
  favicon?: string
  site_name: string
  site_tagline?: string
  email?: string
  phone?: string
  whatsapp?: string
  top_banner_text?: string
  top_banner_link?: string
  top_banner_promo_code?: string
  top_banner_countdown_enabled?: boolean
  top_banner_countdown_end?: string
  facebook_url?: string
  instagram_url?: string
  twitter_url?: string
  tiktok_url?: string
  pinterest_url?: string
  meta_title?: string
  meta_description?: string
  meta_keywords?: string
  maintenance_mode: boolean
  maintenance_message?: string
  maintenance_link?: string
  maintenance_bypass_key?: string
}

/**
 * Get banners by type
 */
export async function getBanners(
  type?: 'hero' | 'promo' | 'category' | 'flash' | 'info',
  platform: 'web' | 'mobile' = 'web',
  categorySlug?: string
): Promise<Banner[]> {
  const params = new URLSearchParams({ platform })
  if (type) params.append('type', type)
  if (categorySlug) params.append('category', categorySlug)
  
  const url = `${API_ENDPOINTS.banners}?${params.toString()}`
  const response = await fetchWithRevalidate<ApiResponse<Banner>>(url, 120) // 2min cache
  
  return response.results || []
}

/**
 * Get hero banners for homepage or category page
 */
export async function getHeroBanners(categorySlug?: string): Promise<Banner[]> {
  return getBanners('hero', 'web', categorySlug)
}

/**
 * Get promo banners
 */
export async function getPromoBanners(): Promise<Banner[]> {
  return getBanners('promo', 'web')
}

/**
 * Get category banners
 */
export async function getCategoryBanners(): Promise<Banner[]> {
  return getBanners('category', 'web')
}

/**
 * Get home sections
 */
export async function getHomeSections(): Promise<HomeSection[]> {
  const params = new URLSearchParams({ platform: 'web' })
  const url = `${API_ENDPOINTS.homeSections}?${params.toString()}`
  const response = await fetchWithRevalidate<ApiResponse<HomeSection>>(url, 120) // 2min cache
  
  return response.results || []
}

/**
 * Get section by type
 */
export async function getSectionByType(type: string): Promise<HomeSection | null> {
  const sections = await getHomeSections()
  return sections.find(s => s.section_type === type) || null
}

/**
 * Get app configuration
 */
export async function getAppConfig(): Promise<AppConfig> {
  return fetchWithRevalidate<AppConfig>(API_ENDPOINTS.config, 3600) // 1 hour cache
}

/**
 * Get active announcements
 */
export async function getAnnouncements(): Promise<Announcement[]> {
  const params = new URLSearchParams({ platform: 'web' })
  const url = `${API_ENDPOINTS.announcements}?${params.toString()}`
  const response = await fetchWithRevalidate<ApiResponse<Announcement> | Announcement[]>(url, 60) // 1min cache

  // This endpoint returns a plain list (not paginated)
  return Array.isArray(response) ? response : response.results || []
}

/**
 * Get site settings (logo, contact info, etc.)
 */
export async function getSiteSettings(): Promise<SiteSettings> {
  return fetchWithRevalidate<SiteSettings>(API_ENDPOINTS.siteSettings, 300) // 5min cache
}

/**
 * Get section configurations for platform
 */
export async function getSectionConfigs(platform: 'web' | 'mobile' = 'web'): Promise<SectionConfig[]> {
  const params = new URLSearchParams({ platform })
  const url = `${API_ENDPOINTS.cms}/section-configs/?${params.toString()}`
  const response = await fetchWithRevalidate<ApiResponse<SectionConfig>>(url, 120) // 2min cache
  
  return response.results || []
}

/**
 * Get specific section configuration
 */
export async function getSectionConfig(
  section: string,
  platform: 'web' | 'mobile' = 'web'
): Promise<SectionConfig | null> {
  const params = new URLSearchParams({ platform, section })
  const url = `${API_ENDPOINTS.cms}/section-configs/?${params.toString()}`
  const response = await fetchWithRevalidate<ApiResponse<SectionConfig>>(url, 120) // 2min cache
  
  return response.results?.[0] || null
}

export interface MiddleBanner {
  id: string
  title: string
  description: string
  button_text: string
  button_link: string
  image: string
  image_url: string
  text_color: string
  text_position: 'left' | 'center' | 'right'
  overlay_opacity: number
  is_active: boolean
  display_order: number
}

/**
 * Get active middle banners
 */
export async function getMiddleBanners(categorySlug?: string): Promise<MiddleBanner[]> {
  const params = categorySlug ? `?category=${categorySlug}` : ''
  const url = `${API_ENDPOINTS.cms}/middle-banners/${params}`
  const response = await fetchWithRevalidate<MiddleBanner[]>(url, 60)
  return response || []
}

export interface FeaturedFilterTab {
  id: string
  label: string
  slug: string
  filter_type: 'all' | 'new' | 'sale' | 'category'
  filter_type_display: string
  category_slug: string | null
  category_name: string | null
  display_order: number
  is_active: boolean
  platform: 'both' | 'web' | 'mobile'
}

/**
 * Get featured product filter tabs from CMS
 */
export async function getFeaturedFilterTabs(platform: 'web' | 'mobile' = 'web'): Promise<FeaturedFilterTab[]> {
  const url = `${API_ENDPOINTS.cms}/featured-filter-tabs/?platform=${platform}`
  const response = await fetchWithRevalidate<FeaturedFilterTab[]>(url, 120) // 2min cache
  return response || []
}
