/**
 * In-memory auth token store.
 * Tokens are NEVER written to localStorage — only held in JS memory.
 * On page reload the access token is restored via /api/auth/refresh
 * which reads the httpOnly refresh-token cookie.
 */

let accessToken: string | null = null
const listeners: Array<() => void> = []

/** Subscribe to auth changes (returns unsubscribe fn) */
export function onAuthChange(fn: () => void): () => void {
  listeners.push(fn)
  return () => {
    const idx = listeners.indexOf(fn)
    if (idx !== -1) listeners.splice(idx, 1)
  }
}

function notify() {
  listeners.forEach((fn) => fn())
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('auth-change'))
  }
}

export function getAccessToken(): string | null {
  return accessToken
}

export function setAccessToken(token: string | null): void {
  accessToken = token
  notify()
}

export function clearAuth(): void {
  accessToken = null
  if (typeof window !== 'undefined') {
    localStorage.removeItem('user')
  }
  notify()
}

/** Bootstrap: restore access token from httpOnly refresh cookie via server route */
let bootstrapPromise: Promise<string | null> | null = null

export function bootstrapAuth(): Promise<string | null> {
  if (typeof window === 'undefined') return Promise.resolve(null)
  if (accessToken) return Promise.resolve(accessToken)
  if (bootstrapPromise) return bootstrapPromise
  // Visitor never logged in: the server has no session cookie, so skip the call (it would only answer 401)
  if (!document.cookie.includes('is_logged_in=')) return Promise.resolve(null)

  bootstrapPromise = fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
    .then(async (res) => {
      if (!res.ok) {
        clearAuth()
        return null
      }
      const data = await res.json()
      accessToken = data.access
      notify()
      return data.access as string
    })
    .catch(() => {
      clearAuth()
      return null
    })
    .finally(() => {
      bootstrapPromise = null
    })

  return bootstrapPromise
}
