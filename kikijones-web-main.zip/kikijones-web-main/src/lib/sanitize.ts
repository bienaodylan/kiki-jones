// NOTE: Do NOT import isomorphic-dompurify here — it depends on jsdom which
// pulls in html-encoding-sniffer → @exodus/bytes (ESM-only), causing
// ERR_REQUIRE_ESM during Next.js static generation.
//
// Strategy:
//   Server-side (SSR/SSG build time): CMS content is admin-controlled → pass through.
//   Client-side: sanitize with browser-native DOMPurify (no jsdom, no ESM conflict).

const PURIFY_CONFIG = {
  ALLOWED_TAGS: [
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'br', 'hr',
    'ul', 'ol', 'li', 'a', 'strong', 'b', 'em', 'i', 'u',
    'blockquote', 'pre', 'code', 'span', 'div', 'img',
    'table', 'thead', 'tbody', 'tr', 'th', 'td',
    'figure', 'figcaption', 'section', 'article',
  ],
  ALLOWED_ATTR: [
    'href', 'target', 'rel', 'src', 'alt', 'title', 'width', 'height',
    'class', 'id', 'colspan', 'rowspan',
  ],
  ADD_ATTR: ['target'],
}

/**
 * Sanitize HTML content to prevent XSS attacks.
 * Safe for use with dangerouslySetInnerHTML.
 *
 * Server / build time → content is from the Django CMS (admin-controlled, trusted).
 * Browser → sanitized with DOMPurify (browser-native, zero Node.js dependencies).
 */
export function sanitizeHTML(html: string): string {
  if (typeof window === 'undefined') {
    // Server-side: no jsdom required — CMS content is admin-generated
    return html
  }
  // Browser-only: dompurify uses window.DOMParser natively (no jsdom)
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const DOMPurify = require('dompurify') as { sanitize: (html: string, cfg: object) => string }
  return DOMPurify.sanitize(html, PURIFY_CONFIG)
}
