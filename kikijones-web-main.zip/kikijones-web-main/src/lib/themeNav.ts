/* eslint-disable */
// Navigation du thème KIKI JONES (copie des données du thème, libellés français inclus).
// Les photos du thème ne sont pas reprises : les cartes éditoriales utilisent la photo d'une catégorie réelle.

export interface MegaMenuLink {
  label: string;
  href: string;
}

export interface MegaMenuColumn {
  heading: string;
  links: MegaMenuLink[];
}

export type DivisionKey = 'women' | 'curve' | 'men' | 'sport' | 'kids';

export type MegaMenuKey =
  | 'women'
  | 'curve'
  | 'men'
  | 'sport'
  | 'kids'
  | 'brands'
  | 'categories'
  | 'dresses'
  | 'matching-sets'
  | 'tops'
  | 'bottoms'
  | 'shoes'
  | 'accessories';

export interface MegaMenuConfig {
  key: MegaMenuKey;
  label: string;
  href: string;
  columns: MegaMenuColumn[];
  editorial: {
    eyebrow: string;
    title: string;
    ctaLabel: string;
    href: string;
    imageUrl: string;
  };
}

export interface FloatingSubNavItem {
  label: string;
  href: string;
  megaMenuKey?: MegaMenuKey;
  highlight?: boolean;
}

export interface BrandLine {
  slug: 'kiki-men' | 'kiki-luxe' | 'kiki-sculpt' | 'kiki-curve' | 'kiki-sport' | 'kiki-kids';
  name: string;
  shortLabel: string;
  tagline: string;
  description: string;
  heroImage: string;
  secondaryImage: string;
  audiences: ('women' | 'men' | 'girls' | 'boys' | 'unisex')[];
}

export interface ProductCategoryTile {
  slug: string;
  name: string;
  subtitle: string;
  description: string;
  imageUrl: string;
  matchSubCategories?: string[];
}

export interface EditorialCollection {
  slug: string;
  seasonTag: string;
  title: string;
  shortTitle: string;
  subtitle: string;
  description: string;
  campaignImage: string;
  secondaryImage?: string;
  audiences: ('women' | 'men' | 'girls' | 'boys')[];
  featured?: boolean;
}


const KJ_IMAGES: Record<string, string> = new Proxy({}, { get: () => '' }) as any

export const PRODUCT_CATEGORIES: ProductCategoryTile[] = [
  {
    slug: 'dresses',
    name: 'Dresses',
    subtitle: 'Maxi · Mini · Formal · Resort',
    description:
      'Satin kaftans, embroidered strapless gowns, rhinestone evening maxis, and asymmetrical going-out minis.',
    imageUrl: '/assets/fashionnova/campaigns/fn_campaign_women_dress.jpg',
    matchSubCategories: ['dresses', 'skirts'],
  },
  {
    slug: 'matching-sets',
    name: 'Matching Sets',
    subtitle: 'Two-Piece Co-ords & Suits',
    description:
      'Pleated pant sets, floral jacquard suit sets, crinkle men co-ords, seamless zip sets, and kids outfits.',
    imageUrl: '/assets/fashionnova/paris-pleated-pant-set__0.jpg',
    matchSubCategories: ['matching-sets'],
  },
  {
    slug: 'shoes',
    name: 'Shoes',
    subtitle: 'Heels · Loafers · Sneakers',
    description:
      'Platform stilettos, patent slingback pumps, polished buckle loafers, and monochrome street sneakers.',
    imageUrl: '/assets/fashionnova/unmatched-energy-platform-stiletto-heels__0.jpg',
    matchSubCategories: ['shoes'],
  },
  {
    slug: 'sunglasses',
    name: 'Sunglasses',
    subtitle: 'Eyewear & Frames',
    description:
      'Sharp dark acetate sunglasses and clean architectural optical frames for sun-soaked days.',
    imageUrl: '/assets/fashionnova/first-in-line-sunglasses__0.jpg',
    matchSubCategories: ['sunglasses'],
  },
  {
    slug: 'shirts',
    name: 'Shirts & Tops',
    subtitle: 'Button-Ups · Corsets · Tees',
    description:
      'Statement open-collar shirts, structured corsets, sculpting bodysuits, and boxy street tees.',
    imageUrl: '/assets/fashionnova/crinkle-accordion-button-up-shirt__0.jpg',
    matchSubCategories: ['shirts', 'tops', 't-shirts', 'polos'],
  },
  {
    slug: 'jumpsuits',
    name: 'Jumpsuits & Rompers',
    subtitle: 'Short-Sleeve & Denim Rompers',
    description:
      'Tailored short-sleeve rompers, fitted denim rompers, and effortless warm-weather one-pieces.',
    imageUrl: '/assets/fashionnova/in-office-short-sleeve-romper__0.jpg',
    matchSubCategories: ['jumpsuits'],
  },
  {
    slug: 'jeans',
    name: 'Jeans & Pants',
    subtitle: 'Stacked · Flare · Tailored',
    description:
      'Slim stacked flare denim, waxed pleated flare trousers, and crisp streetwear bottoms.',
    imageUrl: '/assets/fashionnova/undercover-slim-stacked-flare-jeans__0.jpg',
    matchSubCategories: ['jeans', 'pants'],
  },
  {
    slug: 'bottoms',
    name: 'Shorts & Bottoms',
    subtitle: 'Denim Jorts · Crochet · Skirts',
    description:
      '90s denim jorts, cargo denim shorts, crochet micro shorts, and double-lined mini skirts.',
    imageUrl: '/assets/fashionnova/basic-90s-denim-jorts__0.jpg',
    matchSubCategories: ['bottoms', 'shorts', 'skirts'],
  },
  {
    slug: 'activewear',
    name: 'Activewear & Sport',
    subtitle: 'Biker Shorts · Studio · Athletic',
    description:
      'Seamless biker shorts, tricot lounge shorts, and breathable active tees built for warm-climate training.',
    imageUrl: '/assets/fashionnova/campaigns/fn_campaign_sport_crop.jpg',
    matchSubCategories: ['activewear'],
  },
  {
    slug: 'bags',
    name: 'Bags',
    subtitle: 'Clutches & Crossbody',
    description: 'Structured faux-leather mini clutches and sleek statement evening bags.',
    imageUrl: '/assets/fashionnova/lil-link-mini-faux-leather-clutch__0.jpg',
    matchSubCategories: ['bags'],
  },
  {
    slug: 'jewelry',
    name: 'Jewelry',
    subtitle: 'Earrings & Bracelets',
    description: 'Sculpted drop earrings and stacked bracelet sets designed to finish any look.',
    imageUrl: '/assets/fashionnova/cove-island-2-piece-bracelet-set__0.jpg',
    matchSubCategories: ['jewelry'],
  },
];

/**
 * Fashion Nova–inspired Top Division Navigation Bar (Row 1)
 */
export const PRIMARY_NAV_ITEMS: {
  key: 'women' | 'curve' | 'men' | 'sport' | 'kids' | 'brands' | 'categories';
  label: string;
  href: string;
  hasMegaMenu: boolean;
}[] = [
  { key: 'women', label: 'Women', href: '/women', hasMegaMenu: true },
  { key: 'curve', label: 'Curve', href: '/brand/kiki-curve', hasMegaMenu: true },
  { key: 'men', label: 'Men', href: '/men', hasMegaMenu: true },
  { key: 'sport', label: 'Sport', href: '/brand/kiki-sport', hasMegaMenu: true },
  { key: 'kids', label: 'Kids', href: '/brand/kiki-kids', hasMegaMenu: true },
  { key: 'brands', label: 'Brands', href: '/brands', hasMegaMenu: true },
  { key: 'categories', label: 'Categories', href: '/categories', hasMegaMenu: true },
];

/**
 * Fashion Nova–style Floating Category Sub-Navigation Ribbon (Row 2)
 * Dynamically updates per active division — strictly warm-climate collections for Africa
 * (Zero Winter, Zero Coats/Puffers, Zero Sweaters/Fleece, Zero Holiday/Snow shops).
 */
export const FLOATING_SUBNAV_BY_DIVISION: Record<DivisionKey, FloatingSubNavItem[]> = {
  women: [
    { label: 'New In', href: '/new-in' },
    { label: 'Dresses', href: '/category/dresses', megaMenuKey: 'dresses' },
    { label: 'Matching Sets', href: '/category/matching-sets', megaMenuKey: 'matching-sets' },
    { label: 'Tops & Corsets', href: '/women/tops', megaMenuKey: 'tops' },
    { label: 'Jumpsuits', href: '/category/jumpsuits' },
    { label: 'Jeans & Bottoms', href: '/category/bottoms', megaMenuKey: 'bottoms' },
    { label: 'Formal', href: '/collection/formal' },
    { label: 'After Dark', href: '/collection/after-dark' },
    { label: 'Shoes', href: '/category/shoes', megaMenuKey: 'shoes' },
    { label: 'Accessories', href: '/accessories', megaMenuKey: 'accessories' },
    { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
    { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
    { label: 'Sale', href: '/sale', highlight: true },
  ],
  curve: [
    { label: 'All Curve', href: '/brand/kiki-curve' },
    { label: 'New In', href: '/new-in' },
    { label: 'Dresses', href: '/category/dresses', megaMenuKey: 'dresses' },
    { label: 'Matching Sets', href: '/category/matching-sets', megaMenuKey: 'matching-sets' },
    { label: 'Formal & Gowns', href: '/collection/formal' },
    { label: 'After Dark', href: '/collection/after-dark' },
    { label: 'Tops & Corsets', href: '/women/tops', megaMenuKey: 'tops' },
    { label: 'Bottoms', href: '/category/bottoms', megaMenuKey: 'bottoms' },
    { label: 'Shoes', href: '/category/shoes', megaMenuKey: 'shoes' },
    { label: 'Accessories', href: '/accessories', megaMenuKey: 'accessories' },
    { label: 'Sale', href: '/sale', highlight: true },
  ],
  men: [
    { label: 'All Men', href: '/men' },
    { label: 'New In', href: '/men/new-in' },
    { label: 'Shirts', href: '/men/shirts', megaMenuKey: 'tops' },
    { label: 'Matching Sets', href: '/men/matching-sets', megaMenuKey: 'matching-sets' },
    { label: 'Tees & Tops', href: '/men/tops', megaMenuKey: 'tops' },
    { label: 'Jeans', href: '/men/jeans', megaMenuKey: 'bottoms' },
    { label: 'Pants & Shorts', href: '/men/pants', megaMenuKey: 'bottoms' },
    { label: 'Shoes', href: '/men/shoes', megaMenuKey: 'shoes' },
    { label: 'Night Out', href: '/collection/after-dark' },
    { label: 'Street Heat', href: '/collection/street-collection' },
    { label: 'Sunglasses', href: '/category/sunglasses', megaMenuKey: 'accessories' },
    { label: 'Sale', href: '/sale', highlight: true },
  ],
  sport: [
    { label: 'All Sport', href: '/brand/kiki-sport' },
    { label: 'Activewear', href: '/category/activewear' },
    { label: 'Biker Shorts', href: '/category/activewear' },
    { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
    { label: 'Women Sport', href: '/women/activewear' },
    { label: 'Men Sport', href: '/men/activewear' },
    { label: 'Sneakers', href: '/category/shoes', megaMenuKey: 'shoes' },
    { label: 'Sale', href: '/sale', highlight: true },
  ],
  kids: [
    { label: 'All Kids', href: '/brand/kiki-kids' },
    { label: 'Girls', href: '/girls' },
    { label: 'Girls Sets', href: '/girls/matching-sets' },
    { label: 'Boys', href: '/boys' },
    { label: 'Boys Sets', href: '/boys/matching-sets' },
    { label: 'New In', href: '/new-in' },
    { label: 'Street Heat', href: '/collection/street-collection' },
    { label: 'Sale', href: '/sale', highlight: true },
  ],
};

export const MEGA_MENUS: Record<MegaMenuKey, MegaMenuConfig> = {
  women: {
    key: 'women',
    label: 'Women',
    href: '/women',
    columns: [
      {
        heading: 'Clothing',
        links: [
          { label: 'Shop All Women', href: '/women' },
          { label: 'New Arrivals', href: '/women/new-in' },
          { label: 'Dresses', href: '/women/dresses' },
          { label: 'Matching Sets', href: '/women/matching-sets' },
          { label: 'Tops & Corsets', href: '/women/tops' },
          { label: 'Jumpsuits & Rompers', href: '/category/jumpsuits' },
          { label: 'Shorts & Jorts', href: '/category/bottoms' },
          { label: 'Activewear & Biker Shorts', href: '/category/activewear' },
        ],
      },
      {
        heading: 'Women Brands',
        links: [
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'Kiki Curve', href: '/brand/kiki-curve' },
          { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
          { label: 'Kiki Sport', href: '/brand/kiki-sport' },
        ],
      },
      {
        heading: 'Warm-Climate Edits',
        links: [
          { label: 'After Dark / Going Out', href: '/collection/after-dark' },
          { label: 'Formal & Occasion', href: '/collection/formal' },
          { label: 'Sun & Resort Sets', href: '/collection/summer-drop' },
          { label: 'The Essentials', href: '/collection/essentials' },
          { label: 'Sale & Offers', href: '/sale' },
        ],
      },
      {
        heading: 'Shoes & Accessories',
        links: [
          { label: 'Heels & Sneakers', href: '/category/shoes' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
          { label: 'Bags & Clutches', href: '/category/bags' },
          { label: 'Jewelry', href: '/category/jewelry' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Women · New Season',
      title: 'Evening & Resort Silhouettes',
      ctaLabel: 'Shop Women',
      href: '/women',
      imageUrl: KJ_IMAGES.heroCampaign,
    },
  },
  curve: {
    key: 'curve',
    label: 'Curve',
    href: '/brand/kiki-curve',
    columns: [
      {
        heading: 'Kiki Curve Clothing',
        links: [
          { label: 'Shop All Curve', href: '/brand/kiki-curve' },
          { label: 'Going-Out Dresses', href: '/category/dresses' },
          { label: 'Matching Lounge Sets', href: '/category/matching-sets' },
          { label: 'Formal & Evening Gowns', href: '/collection/formal' },
          { label: 'Corsets & Bodysuits', href: '/brand/kiki-sculpt' },
        ],
      },
      {
        heading: 'Featured Edits',
        links: [
          { label: 'After Dark Edit', href: '/collection/after-dark' },
          { label: 'Sun & Resort', href: '/collection/summer-drop' },
          { label: 'Active & Biker Shorts', href: '/brand/kiki-sport' },
          { label: 'New Arrivals', href: '/new-in' },
        ],
      },
      {
        heading: 'Finish The Look',
        links: [
          { label: 'Platform Heels', href: '/category/shoes' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
          { label: 'Mini Clutches', href: '/category/bags' },
          { label: 'Jewelry', href: '/category/jewelry' },
        ],
      },
      {
        heading: 'House Brands',
        links: [
          { label: 'Kiki Curve', href: '/brand/kiki-curve' },
          { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'All Brands', href: '/brands' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Kiki Curve · Confident Fit',
      title: 'After Dark & Formal Curve',
      ctaLabel: 'Shop Kiki Curve',
      href: '/brand/kiki-curve',
      imageUrl: KJ_IMAGES.curveGownCampaign,
    },
  },
  men: {
    key: 'men',
    label: 'Men',
    href: '/men',
    columns: [
      {
        heading: 'Kiki Men',
        links: [
          { label: 'Shop All Men', href: '/men' },
          { label: 'All Kiki Men', href: '/brand/kiki-men' },
          { label: 'New In Men', href: '/men/new-in' },
          { label: 'Best Sellers', href: '/men/best-sellers' },
          { label: 'Men Sale', href: '/sale' },
        ],
      },
      {
        heading: 'Warm-Climate Clothing',
        links: [
          { label: 'Night-Out Shirts', href: '/men/shirts' },
          { label: 'Two-Piece Sets & Shorts', href: '/men/matching-sets' },
          { label: 'Boxy & Graphic Tees', href: '/men/tops' },
          { label: 'Stacked Flare Jeans', href: '/men/jeans' },
          { label: 'Waxed Flare Pants', href: '/men/pants' },
          { label: 'Men Sport & Active', href: '/brand/kiki-sport' },
        ],
      },
      {
        heading: 'Shoes & Accessories',
        links: [
          { label: 'Loafers & Footwear', href: '/men/shoes' },
          { label: 'All Shoes', href: '/category/shoes' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
          { label: 'Jewelry', href: '/category/jewelry' },
        ],
      },
      {
        heading: 'Collections',
        links: [
          { label: 'After Dark Edit', href: '/collection/after-dark' },
          { label: 'Street Heat', href: '/collection/street-collection' },
          { label: 'Sun & Resort', href: '/collection/summer-drop' },
          { label: 'Active & Sport', href: '/collection/sport' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Kiki Men · Warm Climate',
      title: 'Statement Shirts & Street',
      ctaLabel: 'Shop Kiki Men',
      href: '/brand/kiki-men',
      imageUrl: KJ_IMAGES.menEditorial,
    },
  },
  sport: {
    key: 'sport',
    label: 'Sport',
    href: '/brand/kiki-sport',
    columns: [
      {
        heading: 'Kiki Sport',
        links: [
          { label: 'Shop All Sport', href: '/brand/kiki-sport' },
          { label: 'All Activewear', href: '/category/activewear' },
          { label: 'Seamless Biker Shorts', href: '/category/activewear' },
          { label: 'Sport Collection', href: '/collection/sport' },
        ],
      },
      {
        heading: 'By Audience',
        links: [
          { label: 'Women Activewear', href: '/women/activewear' },
          { label: 'Men Sport & Tees', href: '/men/activewear' },
          { label: 'Kiki Sculpt Compression', href: '/brand/kiki-sculpt' },
        ],
      },
      {
        heading: 'Pair With',
        links: [
          { label: 'Everyday Sneakers', href: '/category/shoes' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
          { label: 'Matching Sets', href: '/category/matching-sets' },
        ],
      },
      {
        heading: 'More Labels',
        links: [
          { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'All Brands', href: '/brands' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Kiki Sport · Heat-Ready',
      title: 'Breathable Active & Studio',
      ctaLabel: 'Shop Kiki Sport',
      href: '/brand/kiki-sport',
      imageUrl: KJ_IMAGES.sportFeature,
    },
  },
  kids: {
    key: 'kids',
    label: 'Kids',
    href: '/brand/kiki-kids',
    columns: [
      {
        heading: 'Kiki Kids',
        links: [
          { label: 'All Kiki Kids', href: '/brand/kiki-kids' },
          { label: 'Girls Matching Sets', href: '/girls' },
          { label: 'Boys Matching Sets', href: '/boys' },
          { label: 'Kids Sale', href: '/sale' },
        ],
      },
      {
        heading: 'Girls',
        links: [
          { label: 'Shop All Girls', href: '/girls' },
          { label: 'Girls Pant Sets', href: '/girls/matching-sets' },
          { label: 'New In Girls', href: '/girls/new-in' },
        ],
      },
      {
        heading: 'Boys',
        links: [
          { label: 'Shop All Boys', href: '/boys' },
          { label: 'Boys Jogger Sets', href: '/boys/matching-sets' },
          { label: 'New In Boys', href: '/boys/new-in' },
        ],
      },
      {
        heading: 'More Labels',
        links: [
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'Kiki Sport', href: '/brand/kiki-sport' },
          { label: 'All Brands', href: '/brands' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Kiki Kids · Girls & Boys',
      title: 'Fresh Youth Street Sets',
      ctaLabel: 'Shop Kiki Kids',
      href: '/brand/kiki-kids',
      imageUrl: KJ_IMAGES.girlsEditorial,
    },
  },
  brands: {
    key: 'brands',
    label: 'Shop by Brand',
    href: '/brands',
    columns: [
      {
        heading: 'KIKI JONES House Brands',
        links: [
          { label: 'All Brands', href: '/brands' },
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'Kiki Curve', href: '/brand/kiki-curve' },
          { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
          { label: 'Kiki Sport', href: '/brand/kiki-sport' },
          { label: 'Kiki Kids', href: '/brand/kiki-kids' },
        ],
      },
      {
        heading: 'Featured Edits',
        links: [
          { label: 'New Arrivals', href: '/new-in' },
          { label: 'After Dark Edit', href: '/collection/after-dark' },
          { label: 'Formal & Occasion', href: '/collection/formal' },
          { label: 'Sun & Resort Sets', href: '/collection/summer-drop' },
          { label: 'Street Heat', href: '/collection/street-collection' },
          { label: 'Active & Sport', href: '/collection/sport' },
        ],
      },
      {
        heading: 'Popular Categories',
        links: [
          { label: 'Dresses', href: '/category/dresses' },
          { label: 'Matching Sets', href: '/category/matching-sets' },
          { label: 'Jumpsuits & Rompers', href: '/category/jumpsuits' },
          { label: 'Shoes', href: '/category/shoes' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
        ],
      },
      {
        heading: 'Shop by Audience',
        links: [
          { label: 'Women', href: '/women' },
          { label: 'Curve', href: '/brand/kiki-curve' },
          { label: 'Men', href: '/men' },
          { label: 'Sport', href: '/brand/kiki-sport' },
          { label: 'Girls & Boys', href: '/brand/kiki-kids' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'House of Labels',
      title: '6 Signature Brands',
      ctaLabel: 'Explore All Brands',
      href: '/brands',
      imageUrl: KJ_IMAGES.womenSatinEvening,
    },
  },
  categories: {
    key: 'categories',
    label: 'Shop by Category',
    href: '/categories',
    columns: [
      {
        heading: 'Apparel',
        links: [
          { label: 'All Categories', href: '/categories' },
          { label: 'Dresses', href: '/category/dresses' },
          { label: 'Matching Sets', href: '/category/matching-sets' },
          { label: 'Shirts & Tops', href: '/category/shirts' },
          { label: 'Jumpsuits & Rompers', href: '/category/jumpsuits' },
          { label: 'Jeans & Pants', href: '/category/jeans' },
          { label: 'Shorts & Bottoms', href: '/category/bottoms' },
          { label: 'Activewear & Sport', href: '/category/activewear' },
        ],
      },
      {
        heading: 'Shoes & Accessories',
        links: [
          { label: 'Shoes & Heels', href: '/category/shoes' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
          { label: 'Bags & Clutches', href: '/category/bags' },
          { label: 'Jewelry', href: '/category/jewelry' },
        ],
      },
      {
        heading: 'Shop by Brand',
        links: [
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'Kiki Curve', href: '/brand/kiki-curve' },
          { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
          { label: 'Kiki Sport', href: '/brand/kiki-sport' },
          { label: 'Kiki Kids', href: '/brand/kiki-kids' },
        ],
      },
      {
        heading: 'Collections',
        links: [
          { label: 'All Collections', href: '/collections' },
          { label: 'After Dark Edit', href: '/collection/after-dark' },
          { label: 'Formal & Occasion', href: '/collection/formal' },
          { label: 'The Essentials', href: '/collection/essentials' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Shop by Piece',
      title: 'Shoes, Shades & Wardrobe',
      ctaLabel: 'Explore Categories',
      href: '/categories',
      imageUrl: KJ_IMAGES.shoesFeature,
    },
  },
  // Floating ribbon category mega-menus (Fashion Nova style)
  dresses: {
    key: 'dresses',
    label: 'Dresses',
    href: '/category/dresses',
    columns: [
      {
        heading: 'Dress Styles',
        links: [
          { label: 'All Dresses', href: '/category/dresses' },
          { label: 'Formal & Gowns', href: '/collection/formal' },
          { label: 'Going-Out & After Dark', href: '/collection/after-dark' },
          { label: 'Resort & Kaftan Dresses', href: '/collection/summer-drop' },
          { label: 'Curve Dresses', href: '/brand/kiki-curve' },
        ],
      },
      {
        heading: 'One-Pieces & Sets',
        links: [
          { label: 'Jumpsuits & Rompers', href: '/category/jumpsuits' },
          { label: 'Matching Sets', href: '/category/matching-sets' },
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
        ],
      },
      {
        heading: 'Complete The Look',
        links: [
          { label: 'Platform Heels & Pumps', href: '/category/shoes' },
          { label: 'Evening Clutches', href: '/category/bags' },
          { label: 'Statement Jewelry', href: '/category/jewelry' },
        ],
      },
      {
        heading: 'Trending',
        links: [
          { label: 'New Arrivals', href: '/new-in' },
          { label: 'Sale', href: '/sale' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Kiki Luxe · Dresses',
      title: 'Gowns, Maxis & Minis',
      ctaLabel: 'Shop Dresses',
      href: '/category/dresses',
      imageUrl: KJ_IMAGES.formalFeature,
    },
  },
  'matching-sets': {
    key: 'matching-sets',
    label: 'Matching Sets',
    href: '/category/matching-sets',
    columns: [
      {
        heading: 'Two-Piece Sets',
        links: [
          { label: 'All Matching Sets', href: '/category/matching-sets' },
          { label: 'Women Pleated & Suit Sets', href: '/women/matching-sets' },
          { label: 'Curve Lounge Sets', href: '/brand/kiki-curve' },
          { label: 'Men Crinkle & Short Sets', href: '/men/matching-sets' },
          { label: 'Kids Pant & Jogger Sets', href: '/brand/kiki-kids' },
        ],
      },
      {
        heading: 'Warm-Weather Edits',
        links: [
          { label: 'Sun & Resort Sets', href: '/collection/summer-drop' },
          { label: 'Formal Suit Sets', href: '/collection/formal' },
          { label: 'Street Heat', href: '/collection/street-collection' },
        ],
      },
      {
        heading: 'Related Categories',
        links: [
          { label: 'Jumpsuits & Rompers', href: '/category/jumpsuits' },
          { label: 'Activewear & Sport', href: '/category/activewear' },
          { label: 'Shoes', href: '/category/shoes' },
        ],
      },
      {
        heading: 'Brands',
        links: [
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'Kiki Kids', href: '/brand/kiki-kids' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Effortless Co-ords',
      title: 'Two-Piece Matching Sets',
      ctaLabel: 'Shop Matching Sets',
      href: '/category/matching-sets',
      imageUrl: KJ_IMAGES.womenResortSet,
    },
  },
  tops: {
    key: 'tops',
    label: 'Tops & Shirts',
    href: '/category/shirts',
    columns: [
      {
        heading: 'Women Tops',
        links: [
          { label: 'All Shirts & Tops', href: '/category/shirts' },
          { label: 'Corsets & Bodysuits', href: '/women/tops' },
          { label: 'Kiki Sculpt Compression', href: '/brand/kiki-sculpt' },
        ],
      },
      {
        heading: 'Men Shirts & Tees',
        links: [
          { label: 'Night-Out Button-Up Shirts', href: '/men/shirts' },
          { label: 'Vintage & Boxy Tees', href: '/men/tops' },
          { label: 'All Kiki Men', href: '/brand/kiki-men' },
        ],
      },
      {
        heading: 'Pair With',
        links: [
          { label: 'Stacked Flare Jeans', href: '/category/jeans' },
          { label: 'Denim Jorts & Shorts', href: '/category/bottoms' },
          { label: 'Biker Shorts', href: '/category/activewear' },
        ],
      },
      {
        heading: 'Edits',
        links: [
          { label: 'After Dark Edit', href: '/collection/after-dark' },
          { label: 'New Arrivals', href: '/new-in' },
          { label: 'Sale', href: '/sale' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Sculpt & Statement',
      title: 'Corsets, Shirts & Tees',
      ctaLabel: 'Shop Tops',
      href: '/category/shirts',
      imageUrl: KJ_IMAGES.sculptFeature,
    },
  },
  bottoms: {
    key: 'bottoms',
    label: 'Jeans & Bottoms',
    href: '/category/bottoms',
    columns: [
      {
        heading: 'Denim & Trousers',
        links: [
          { label: 'All Jeans & Pants', href: '/category/jeans' },
          { label: 'Men Stacked Flare Jeans', href: '/men/jeans' },
          { label: 'Waxed Flare Pants', href: '/men/pants' },
        ],
      },
      {
        heading: 'Shorts & Warm-Weather Bottoms',
        links: [
          { label: 'All Shorts & Bottoms', href: '/category/bottoms' },
          { label: '90s & Cargo Denim Jorts', href: '/category/bottoms' },
          { label: 'Seamless Biker Shorts', href: '/category/activewear' },
        ],
      },
      {
        heading: 'Brands',
        links: [
          { label: 'Kiki Sculpt', href: '/brand/kiki-sculpt' },
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'Kiki Sport', href: '/brand/kiki-sport' },
        ],
      },
      {
        heading: 'Pair With',
        links: [
          { label: 'Shirts & Corsets', href: '/category/shirts' },
          { label: 'Shoes & Sneakers', href: '/category/shoes' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Denim & Shorts',
      title: 'Stacked Jeans & Jorts',
      ctaLabel: 'Shop Bottoms',
      href: '/category/bottoms',
      imageUrl: KJ_IMAGES.bottomsFeature,
    },
  },
  shoes: {
    key: 'shoes',
    label: 'Shoes',
    href: '/category/shoes',
    columns: [
      {
        heading: 'Footwear',
        links: [
          { label: 'Shop All Shoes', href: '/category/shoes' },
          { label: 'Women Heels & Pumps', href: '/category/shoes' },
          { label: 'Men Loafers & Slip-Ons', href: '/men/shoes' },
          { label: 'Everyday Sneakers', href: '/brand/kiki-sculpt' },
        ],
      },
      {
        heading: 'By Brand',
        links: [
          { label: 'Kiki Luxe Heels', href: '/brand/kiki-luxe' },
          { label: 'Kiki Men Footwear', href: '/brand/kiki-men' },
          { label: 'Kiki Sculpt Sneakers', href: '/brand/kiki-sculpt' },
        ],
      },
      {
        heading: 'Finish With',
        links: [
          { label: 'Bags & Clutches', href: '/category/bags' },
          { label: 'Sunglasses', href: '/category/sunglasses' },
          { label: 'Jewelry', href: '/category/jewelry' },
        ],
      },
      {
        heading: 'Edits',
        links: [
          { label: 'Shoes, Shades & Objects', href: '/collection/exclusive-drop' },
          { label: 'Formal & Occasion', href: '/collection/formal' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Footwear Edit',
      title: 'Stilettos, Loafers & Sneakers',
      ctaLabel: 'Shop All Shoes',
      href: '/category/shoes',
      imageUrl: KJ_IMAGES.shoesFeature,
    },
  },
  accessories: {
    key: 'accessories',
    label: 'Accessories',
    href: '/accessories',
    columns: [
      {
        heading: 'Accessories',
        links: [
          { label: 'Shop All Accessories', href: '/accessories' },
          { label: 'Sunglasses & Frames', href: '/category/sunglasses' },
          { label: 'Bags & Mini Clutches', href: '/category/bags' },
          { label: 'Earrings & Bracelets', href: '/category/jewelry' },
        ],
      },
      {
        heading: 'Footwear',
        links: [
          { label: 'All Shoes', href: '/category/shoes' },
          { label: 'Platform Heels', href: '/category/shoes' },
          { label: 'Men Loafers', href: '/men/shoes' },
        ],
      },
      {
        heading: 'Curated Edits',
        links: [
          { label: 'Shoes, Shades & Objects', href: '/collection/exclusive-drop' },
          { label: 'After Dark Edit', href: '/collection/after-dark' },
          { label: 'Formal & Occasion', href: '/collection/formal' },
        ],
      },
      {
        heading: 'Shop by Brand',
        links: [
          { label: 'Kiki Luxe', href: '/brand/kiki-luxe' },
          { label: 'Kiki Men', href: '/brand/kiki-men' },
          { label: 'All Categories', href: '/categories' },
        ],
      },
    ],
    editorial: {
      eyebrow: 'Finishing Touches',
      title: 'Sunglasses, Clutches & Jewelry',
      ctaLabel: 'Shop Accessories',
      href: '/accessories',
      imageUrl: KJ_IMAGES.sunglassesFeature,
    },
  },
};


const PRIMARY_NAV_FR: Record<string, string> = {
  women: 'Femme',
  curve: 'Curve',
  men: 'Homme',
  sport: 'Sport',
  kids: 'Enfants',
  brands: 'Marques',
  categories: 'Catégories',
};

const LABEL_MAP_FR: Record<string, string> = {
  // Divisions & Nav
  Women: 'Femme',
  Curve: 'Curve',
  Men: 'Homme',
  Sport: 'Sport',
  Kids: 'Enfants',
  Brands: 'Marques',
  Categories: 'Catégories',
  Girls: 'Filles',
  Boys: 'Garçons',
  Accessories: 'Accessoires',
  'Shop by Brand': 'Par Marque',
  'Shop by Category': 'Par Catégorie',
  'All Brands': 'Toutes les marques',
  'All Categories': 'Toutes les catégories',
  'All Collections': 'Toutes les collections',

  // Floating subnav & links
  'New In': 'Nouveautés',
  'New Arrivals': 'Nouveautés',
  Dresses: 'Robes',
  'Matching Sets': 'Ensembles',
  'Tops & Corsets': 'Hauts & Corsets',
  'Tops & Shirts': 'Hauts & Chemises',
  'Shirts & Tops': 'Chemises & Hauts',
  Jumpsuits: 'Combinaisons',
  'Jumpsuits & Rompers': 'Combinaisons & Combi-shorts',
  'Jeans & Bottoms': 'Jeans & Bas',
  'Jeans & Pants': 'Jeans & Pantalons',
  'Shorts & Bottoms': 'Shorts & Bas',
  'Activewear & Sport': 'Sport & Activewear',
  Formal: 'Soirée & Gala',
  'Formal & Gowns': 'Robes de Gala',
  'Formal & Occasion': 'Soirée & Cérémonie',
  'After Dark': 'After Dark',
  'After Dark / Going Out': 'After Dark / Sorties',
  'After Dark Edit': 'Édition After Dark',
  Shoes: 'Chaussures',
  'Shoes & Heels': 'Chaussures & Talons',
  Sunglasses: 'Lunettes de soleil',
  Bags: 'Sacs',
  'Bags & Clutches': 'Sacs & Pochettes',
  'Bags & Mini Clutches': 'Sacs & Mini Pochettes',
  Jewelry: 'Bijoux',
  Sale: 'Soldes',
  'Sale & Offers': 'Soldes & Offres',
  'All Curve': 'Tout Curve',
  'All Men': 'Tout Homme',
  'All Sport': 'Tout Sport',
  'All Kids': 'Tout Enfants',
  'All Dresses': 'Toutes les robes',
  'All Matching Sets': 'Tous les ensembles',
  'All Shirts & Tops': 'Toutes les chemises & hauts',
  'All Jeans & Pants': 'Tous les jeans & pantalons',
  'All Shorts & Bottoms': 'Tous les shorts & bas',
  'All Shoes': 'Toutes les chaussures',
  'All Activewear': 'Tout le sport',
  'All Kiki Men': 'Tout Kiki Men',
  'All Kiki Kids': 'Tout Kiki Kids',
  'Shop All Women': 'Toute la mode Femme',
  'Shop All Curve': 'Tout Kiki Curve',
  'Shop All Men': 'Toute la mode Homme',
  'Shop All Sport': 'Tout Kiki Sport',
  'Shop All Girls': 'Toute la mode Filles',
  'Shop All Boys': 'Toute la mode Garçons',
  'Shop All Shoes': 'Toutes les chaussures',
  'Shop All Accessories': 'Tous les accessoires',
  Shirts: 'Chemises',
  'Tees & Tops': 'T-Shirts & Hauts',
  Jeans: 'Jeans',
  'Pants & Shorts': 'Pantalons & Shorts',
  'Night Out': 'Soirée',
  'Street Heat': 'Street Heat',
  Activewear: 'Sport',
  'Biker Shorts': 'Cyclistes',
  'Women Sport': 'Sport Femme',
  'Men Sport': 'Sport Homme',
  Sneakers: 'Baskets',
  'Girls Sets': 'Ensembles Filles',
  'Boys Sets': 'Ensembles Garçons',
  Bottoms: 'Bas',

  // MegaMenu headings
  Clothing: 'Vêtements',
  'Women Brands': 'Marques Femme',
  'Warm-Climate Edits': 'Sélections Soleil',
  'Shoes & Accessories': 'Chaussures & Accessoires',
  'Kiki Curve Clothing': 'Vêtements Kiki Curve',
  'Featured Edits': 'Sélections Phares',
  'Finish The Look': 'Compléter le Look',
  'House Brands': 'Nos Maisons',
  'Warm-Climate Clothing': 'Prêt-à-Porter Climat Chaud',
  Collections: 'Collections',
  'By Audience': 'Par Univers',
  'Pair With': 'À Associer Avec',
  'More Labels': 'Autres Marques',
  'KIKI JONES House Brands': 'Les Maisons KIKI JONES',
  'Popular Categories': 'Catégories Populaires',
  'Shop by Audience': 'Par Public',
  Apparel: 'Prêt-à-Porter',
  'Dress Styles': 'Styles de Robes',
  'One-Pieces & Sets': 'Une-Pièce & Ensembles',
  'Complete The Look': 'Compléter la Tenue',
  Trending: 'Tendances',
  'Two-Piece Sets': 'Ensembles Deux Pièces',
  'Warm-Weather Edits': 'Sélections Chaleur',
  'Related Categories': 'Catégories Associées',
  'Women Tops': 'Hauts Femme',
  'Men Shirts & Tees': 'Chemises & T-Shirts Homme',
  Edits: 'Éditions',
  'Denim & Trousers': 'Denim & Pantalons',
  'Shorts & Warm-Weather Bottoms': 'Shorts & Bas Légers',
  Footwear: 'Chaussures',
  'By Brand': 'Par Marque',
  'Finish With': 'Finitions',
  'Curated Edits': 'Sélections',

  // MegaMenu inner links
  'Shorts & Jorts': 'Shorts & Jorts',
  'Activewear & Biker Shorts': 'Sport & Cyclistes',
  'Sun & Resort Sets': 'Ensembles Soleil & Resort',
  'Sun & Resort': 'Soleil & Resort',
  'The Essentials': 'Les Essentiels',
  'Heels & Sneakers': 'Talons & Baskets',
  'Going-Out Dresses': 'Robes de Sortie',
  'Matching Lounge Sets': 'Ensembles Détente',
  'Formal & Evening Gowns': 'Robes de Soirée & Gala',
  'Corsets & Bodysuits': 'Corsets & Bodys',
  'Active & Biker Shorts': 'Sport & Cyclistes',
  'Platform Heels': 'Talons Plateformes',
  'Mini Clutches': 'Mini Pochettes',
  'New In Men': 'Nouveautés Homme',
  'Best Sellers': 'Best-Sellers',
  'Men Sale': 'Soldes Homme',
  'Night-Out Shirts': 'Chemises de Soirée',
  'Two-Piece Sets & Shorts': 'Ensembles & Shorts',
  'Boxy & Graphic Tees': 'T-Shirts Boxy & Graphiques',
  'Stacked Flare Jeans': 'Jeans Évasés Stacked',
  'Waxed Flare Pants': 'Pantalons Cirés Évasés',
  'Men Sport & Active': 'Sport Homme',
  'Loafers & Footwear': 'Mocassins & Chaussures',
  'Active & Sport': 'Sport & Activewear',
  'Seamless Biker Shorts': 'Cyclistes Sans Couture',
  'Sport Collection': 'Collection Sport',
  'Women Activewear': 'Sport Femme',
  'Men Sport & Tees': 'Sport & T-Shirts Homme',
  'Kiki Sculpt Compression': 'Compression Kiki Sculpt',
  'Everyday Sneakers': 'Baskets du Quotidien',
  'Girls Matching Sets': 'Ensembles Filles',
  'Boys Matching Sets': 'Ensembles Garçons',
  'Kids Sale': 'Soldes Enfants',
  'Girls Pant Sets': 'Ensembles Pantalon Filles',
  'New In Girls': 'Nouveautés Filles',
  'Boys Jogger Sets': 'Ensembles Jogger Garçons',
  'New In Boys': 'Nouveautés Garçons',
  'Girls & Boys': 'Filles & Garçons',
  'Going-Out & After Dark': 'Sorties & After Dark',
  'Resort & Kaftan Dresses': 'Robes Resort & Caftans',
  'Curve Dresses': 'Robes Curve',
  'Platform Heels & Pumps': 'Talons Plateformes & Escarpins',
  'Evening Clutches': 'Pochettes de Soirée',
  'Statement Jewelry': 'Bijoux d’Exception',
  'Women Pleated & Suit Sets': 'Ensembles Plissés & Tailleurs Femme',
  'Curve Lounge Sets': 'Ensembles Détente Curve',
  'Men Crinkle & Short Sets': 'Ensembles Plissés & Shorts Homme',
  'Kids Pant & Jogger Sets': 'Ensembles Pantalon & Jogger Enfants',
  'Formal Suit Sets': 'Ensembles Tailleur Gala',
  'Night-Out Button-Up Shirts': 'Chemises Boutonnées Soirée',
  'Vintage & Boxy Tees': 'T-Shirts Vintage & Boxy',
  'Men Stacked Flare Jeans': 'Jeans Évasés Stacked Homme',
  '90s & Cargo Denim Jorts': 'Jorts Denim 90s & Cargo',
  'Shirts & Corsets': 'Chemises & Corsets',
  'Shoes & Sneakers': 'Chaussures & Baskets',
  'Women Heels & Pumps': 'Talons & Escarpins Femme',
  'Men Loafers & Slip-Ons': 'Mocassins & Slip-Ons Homme',
  'Kiki Luxe Heels': 'Talons Kiki Luxe',
  'Kiki Men Footwear': 'Chaussures Kiki Men',
  'Kiki Sculpt Sneakers': 'Baskets Kiki Sculpt',
  'Shoes, Shades & Objects': 'Chaussures, Lunettes & Objets',
  'Sunglasses & Frames': 'Lunettes de Soleil & Montures',
  'Earrings & Bracelets': 'Boucles d’Oreilles & Bracelets',
  'Men Loafers': 'Mocassins Homme',

  // Editorial MegaMenu cards
  'Women · New Season': 'Femme · Nouvelle Saison',
  'Evening & Resort Silhouettes': 'Silhouettes Soirée & Resort',
  'Shop Women': 'Découvrir Femme',
  'Kiki Curve · Confident Fit': 'Kiki Curve · Coupe Assumée',
  'After Dark & Formal Curve': 'Curve Soirée & Gala',
  'Shop Kiki Curve': 'Découvrir Kiki Curve',
  'Kiki Men · Warm Climate': 'Kiki Men · Climat Chaud',
  'Statement Shirts & Street': 'Chemises & Streetwear',
  'Shop Kiki Men': 'Découvrir Kiki Men',
  'Kiki Sport · Heat-Ready': 'Kiki Sport · Respirant',
  'Breathable Active & Studio': 'Activewear & Studio',
  'Shop Kiki Sport': 'Découvrir Kiki Sport',
  'Kiki Kids · Girls & Boys': 'Kiki Kids · Filles & Garçons',
  'Fresh Youth Street Sets': 'Ensembles Street Junior',
  'Shop Kiki Kids': 'Découvrir Kiki Kids',
  'House of Labels': 'Nos Maisons',
  '6 Signature Brands': '6 Marques Signatures',
  'Explore All Brands': 'Explorer les Marques',
  'Shop by Piece': 'Par Type de Pièce',
  'Shoes, Shades & Wardrobe': 'Chaussures, Lunettes & Garde-Robe',
  'Explore Categories': 'Explorer les Catégories',
  'Kiki Luxe · Dresses': 'Kiki Luxe · Robes',
  'Gowns, Maxis & Minis': 'Robes Longues, Maxis & Minis',
  'Shop Dresses': 'Découvrir les Robes',
  'Effortless Co-ords': 'Ensembles Coordonnés',
  'Two-Piece Matching Sets': 'Ensembles Deux Pièces',
  'Shop Matching Sets': 'Découvrir les Ensembles',
  'Sculpt & Statement': 'Sculpt & Caractère',
  'Corsets, Shirts & Tees': 'Corsets, Chemises & T-Shirts',
  'Shop Tops': 'Découvrir les Hauts',
  'Denim & Shorts': 'Denim & Shorts',
  'Stacked Jeans & Jorts': 'Jeans Stacked & Jorts',
  'Shop Bottoms': 'Découvrir les Bas',
  'Footwear Edit': 'Sélection Chaussures',
  'Stilettos, Loafers & Sneakers': 'Talons, Mocassins & Baskets',
  'Finishing Touches': 'Touches Finales',
  'Sunglasses, Clutches & Jewelry': 'Lunettes, Pochettes & Bijoux',
  'Shop Accessories': 'Découvrir les Accessoires',
};


export function translateLabel(label: string): string {
  return LABEL_MAP_FR[label] || label
}
export function primaryNavLabel(key: string, defaultLabel: string): string {
  return PRIMARY_NAV_FR[key] || translateLabel(defaultLabel)
}
export function getFloatingSubnavFr(division: DivisionKey): FloatingSubNavItem[] {
  const list = FLOATING_SUBNAV_BY_DIVISION[division] || FLOATING_SUBNAV_BY_DIVISION.women
  return list.map((i) => ({ ...i, label: translateLabel(i.label) }))
}
export function getMegaMenuFr(key: MegaMenuKey | null): MegaMenuConfig | null {
  if (!key) return null
  const cfg = MEGA_MENUS[key]
  if (!cfg) return null
  return {
    ...cfg,
    label: translateLabel(cfg.label),
    columns: cfg.columns.map((c) => ({ heading: translateLabel(c.heading), links: c.links.map((l) => ({ ...l, label: translateLabel(l.label) })) })),
    editorial: { ...cfg.editorial, eyebrow: translateLabel(cfg.editorial.eyebrow), title: translateLabel(cfg.editorial.title), ctaLabel: translateLabel(cfg.editorial.ctaLabel) },
  }
}
