/**
 * Font utilities for converting CMS font keys to CSS font-family values
 */

export const fontFamilyMap: { [key: string]: string } = {
  'inter': 'Inter, sans-serif',
  'roboto': 'Roboto, sans-serif',
  'opensans': 'Open Sans, sans-serif',
  'lato': 'Lato, sans-serif',
  'montserrat': 'Montserrat, sans-serif',
  'poppins': 'Poppins, sans-serif',
  'playfair': 'Playfair Display, serif',
  'raleway': 'Raleway, sans-serif',
  'merriweather': 'Merriweather, serif',
  'nunito': 'Nunito, sans-serif',
  'worksans': 'Work Sans, sans-serif',
  'ubuntu': 'Ubuntu, sans-serif',
}

/**
 * Get CSS font-family value from CMS font key
 */
export function getFontFamily(fontKey: string): string {
  return fontFamilyMap[fontKey] || fontFamilyMap['inter']
}

/**
 * Apply font-family to style object
 */
export function applyFontFamily(styles: any, fontKey: string): any {
  return {
    ...styles,
    fontFamily: getFontFamily(fontKey)
  }
}
