import type { Category } from '@/lib/api'

/**
 * Catégories du thème KIKI JONES (ordre et regroupement de la boutique).
 * Le slug est celui que kikistock génère à la création de la catégorie (nom sans accent, en minuscules,
 * séparé par des tirets) : dès qu'une catégorie portant ce nom est créée dans kikistock, elle prend la
 * place de l'entrée « virtuelle » ci-dessous (photo et produits compris).
 */
export const THEME_GROUPS: { heading: string; names: string[] }[] = [
  { heading: 'Vêtements', names: ['Robe', 'Ensemble', 'Chemise', 'T-shirt', 'Polo', 'Sweat', 'Corset & Body', 'Combinaison', 'Jean', 'Pantalon', 'Short', 'Sport'] },
  { heading: 'Chaussures & accessoires', names: ['Chaussures', 'Lunettes de soleil', 'Sac', 'Bijoux'] },
]

export function slugifyName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/[\s_-]+/g, '-')
}

export type ThemeCategory = Category & { group: string; virtual?: boolean }

/** Fusionne les catégories réelles (API) avec celles du thème, dans l'ordre du thème. Les catégories
 *  réelles inconnues du thème sont ajoutées à la fin du groupe « Autres ». */
export function withThemeCategories(apiCats: Category[]): ThemeCategory[] {
  const bySlug = new Map(apiCats.map((c) => [c.slug, c]))
  const used = new Set<string>()
  const out: ThemeCategory[] = []
  let order = 0
  for (const g of THEME_GROUPS) {
    for (const name of g.names) {
      const slug = slugifyName(name)
      const real = bySlug.get(slug)
      if (real) {
        used.add(slug)
        out.push({ ...real, group: g.heading })
      } else {
        out.push({ id: `theme-${slug}`, name, slug, is_active: true, display_order: order, group: g.heading, virtual: true })
      }
      order++
    }
  }
  for (const c of apiCats) {
    if (!used.has(c.slug)) out.push({ ...c, group: 'Autres' })
  }
  return out
}

/** Famille d'une catégorie (slug), par ex. « Vêtements » pour « t-shirt ». */
export function familyOf(slug: string): string | null {
  for (const g of THEME_GROUPS) {
    if (g.names.some((n) => slugifyName(n) === slug)) return g.heading
  }
  return null
}
