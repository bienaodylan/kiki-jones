import { API_BASE_URL } from '@/lib/api/config'
import { THEME_COLLECTIONS, ThemeCollection } from '@/lib/themeCollections'

interface ApiCollection { slug: string; title: string; season_tag: string; subtitle: string; description: string; audiences: string; image: string | null }

/** Collections from the shop (admin > Collections). Falls back to the theme's list if the API is unreachable or empty. */
export async function loadCollections(): Promise<ThemeCollection[]> {
  try {
    const r = await fetch(`${API_BASE_URL}/products/collections/`)
    if (!r.ok) throw new Error('bad status')
    const d = await r.json()
    const list: ApiCollection[] = Array.isArray(d) ? d : d.results || []
    if (list.length === 0) return THEME_COLLECTIONS
    return list.map((c) => ({
      slug: c.slug,
      seasonTag: c.season_tag,
      title: c.title,
      subtitle: c.subtitle,
      description: c.description,
      image: c.image || THEME_COLLECTIONS.find((t) => t.slug === c.slug)?.image || '',
      audiences: c.audiences,
    }))
  } catch {
    return THEME_COLLECTIONS
  }
}
