import { API_BASE_URL } from '@/lib/api/config'

export interface Visual { image: string; eyebrow: string; title: string; text: string; button_label: string; button_link: string; button2_label: string; button2_link: string }
export type Visuals = Record<string, Partial<Visual>>

const M = 'https://admin.kikijones.com/media/theme/'
const d = (file: string, o: Partial<Visual> = {}): Visual => ({ image: M + file, eyebrow: '', title: '', text: '', button_label: '', button_link: '', button2_label: '', button2_link: '', ...o })

/** Default content of the home page (used when the admin has not changed a slot, or when the API is unreachable). */
export const DEFAULT_VISUALS: Record<string, Visual> = {
  home_hero: d('alexis-rhinestone-maxi-dress__0.jpg', { title: 'NOUVELLE SAISON', text: 'Silhouettes contemporaines pour climats chauds signées Kiki Men, Kiki Luxe, Kiki Curve, Kiki Sculpt, Kiki Sport et Kiki Kids.', button_label: 'Découvrir les nouveautés', button_link: '/produits?is_new=true', button2_label: 'Par Marque', button2_link: '/brands' }),
  home_hero_2: d('crinkle-accordion-button-up-shirt__0.jpg'),
  home_new: d('fn_campaign_women_dress.jpg', { eyebrow: 'Nouvel arrivage · Collection Soleil', title: 'Nouveautés', button_label: 'Découvrir', button_link: '/produits?is_new=true', button2_label: 'Soirée & Cérémonie', button2_link: '/produits?collection=formal' }),
  home_new_2: d('in-office-short-sleeve-romper__0.jpg'),
  home_new_3: d('paris-pleated-pant-set__0.jpg'),
  home_cat_1: d('fn_campaign_women_dress.jpg', { title: 'Robes', button_link: '/categories/robe' }),
  home_cat_2: d('paris-pleated-pant-set__0.jpg', { title: 'Ensembles', button_link: '/categories/ensemble' }),
  home_cat_3: d('unmatched-energy-platform-stiletto-heels__0.jpg', { title: 'Chaussures', button_link: '/categories/chaussures' }),
  home_cat_4: d('first-in-line-sunglasses__0.jpg', { title: 'Lunettes de soleil', button_link: '/categories/lunettes-de-soleil' }),
  home_men: d('saints-and-sinners-full-button-shirt__0.jpg', { eyebrow: 'Par Marque · Mode Homme', title: 'Kiki Men', button_label: 'Découvrir', button_link: '/produits?brand=kiki-men', button2_label: 'Chaussures Homme', button2_link: '/categories/chaussures' }),
  home_men_2: d('undercover-slim-stacked-flare-jeans__0.jpg'),
  home_sculpt: d('jackie-lace-strapless-corset-bodysuit__0.jpg', { eyebrow: 'Coupe Sculptée · Seconde Peau', title: 'Kiki Sculpt & Curve', button_label: 'Voir Kiki Sculpt', button_link: '/produits?brand=kiki-sculpt', button2_label: 'Voir Kiki Curve', button2_link: '/produits?brand=kiki-curve' }),
  home_sculpt_2: d('nova-sculpt-seamless-strong-compression-zip-front-thigh-shaping-bodysuit__0.jpg'),
  home_sculpt_3: d('zoe-asymmetrical-lace-trim-mini-dress__0.jpg'),
  home_luxe: d('shine-bright-embroidered-strapless-gown__0.jpg', { eyebrow: 'Gala · Soirée · Resort', title: 'Kiki Luxe', button_label: 'Découvrir', button_link: '/produits?brand=kiki-luxe', button2_label: 'Voir les robes', button2_link: '/categories/robe' }),
  home_luxe_2: d('fn_campaign_curve_gown.jpg'),
  home_kids: d('mini-be-amazing-pant-set__0.jpg', { eyebrow: 'Filles & Garçons', title: 'Kiki Kids', button_label: 'Boutique Enfants', button_link: '/produits?brand=kiki-kids' }),
  home_sport: d('fn_campaign_sport_crop.jpg', { eyebrow: 'Activewear Respirant', title: 'Kiki Sport', button_label: 'Voir Sport', button_link: '/produits?brand=kiki-sport', button2_label: 'Cyclistes', button2_link: '/categories/sport' }),
  home_brand_1: d('crinkle-accordion-button-up-shirt__0.jpg', { title: 'Kiki Men', text: 'Mode Homme Audacieuse · Streetwear & Soirée Climat Chaud', button_link: '/produits?brand=kiki-men' }),
  home_brand_2: d('alexis-rhinestone-maxi-dress__0.jpg', { title: 'Kiki Luxe', text: 'Soirée, Gala & Resort · Robes, Combinaisons & Talons', button_link: '/produits?brand=kiki-luxe' }),
  home_brand_3: d('fn_campaign_curve_mini.jpg', { title: 'Kiki Curve', text: 'Silhouettes Assumées · Robes de Sortie & Ensembles', button_link: '/produits?brand=kiki-curve' }),
  home_brand_4: d('jackie-lace-strapless-corset-bodysuit__0.jpg', { title: 'Kiki Sculpt', text: 'Compression Seconde Peau · Corsets, Jorts & Baskets', button_link: '/produits?brand=kiki-sculpt' }),
  home_brand_5: d('fn_campaign_sport_crop.jpg', { title: 'Kiki Sport', text: 'Activewear Respirant · Cyclistes & Performance', button_link: '/produits?brand=kiki-sport' }),
  home_brand_6: d('mini-be-amazing-pant-set__0.jpg', { title: 'Kiki Kids', text: 'Filles & Garçons · Ensembles Street & Quotidien Junior', button_link: '/produits?brand=kiki-kids' }),
}

/** Admin values win over defaults, field by field (an empty field falls back to the default). */
export function mergeVisuals(api: Visuals | null | undefined): Record<string, Visual> {
  const out: Record<string, Visual> = {}
  for (const k of Object.keys(DEFAULT_VISUALS)) {
    const base = DEFAULT_VISUALS[k]
    const o = (api && api[k]) || {}
    out[k] = {
      image: o.image || base.image,
      eyebrow: o.eyebrow || base.eyebrow, title: o.title || base.title, text: o.text || base.text,
      button_label: o.button_label || base.button_label, button_link: o.button_link || base.button_link,
      button2_label: o.button2_label || base.button2_label, button2_link: o.button2_link || base.button2_link,
    }
  }
  return out
}

export async function getSiteVisuals(): Promise<Record<string, Visual>> {
  try {
    const r = await fetch(`${API_BASE_URL}/cms/site-visuals/`, { cache: "no-store" })
    if (!r.ok) throw new Error('bad status')
    return mergeVisuals(await r.json())
  } catch {
    return mergeVisuals(null)
  }
}
