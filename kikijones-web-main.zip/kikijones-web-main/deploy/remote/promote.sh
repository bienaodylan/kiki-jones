#!/bin/bash
# Mise en production : copie le build TESTE de la preprod vers la prod (sans rebuild).
# Args : PROD_DIR STAGING_DIR BACKUP_DIR PROD_PORT PROD_SERVICE KEEP_BACKUPS
set -uo pipefail
PROD=$1; STAGING=$2; BK_DIR=$3; PORT=$4; SERVICE=$5; KEEP=$6
FLAG=/var/www/maintenance/building

old=$(grep '^sha=' "$PROD/.deploy-info" 2>/dev/null | cut -d= -f2); old=${old:-initial}
BK="$BK_DIR/$(date +%Y%m%d-%H%M%S)-${old:0:7}"
echo "> sauvegarde de la prod actuelle -> $BK"
# exit 2 = echec AVANT toute modification de la prod (pas de retour arriere a faire)
cp -al "$PROD" "$BK" || { rm -rf "$BK"; echo "ECHEC : sauvegarde impossible, rien n'a ete modifie"; exit 2; }
echo "$BK" > "$BK_DIR/LAST"

trap 'rm -f "$FLAG"' EXIT
touch "$FLAG"   # nginx affiche la page de maintenance pendant les quelques secondes de bascule
echo "> copie du build de la preprod vers la prod"
rsync -a --delete \
  --exclude='/.env.local' --exclude='/.git/' --exclude='/.last-build.log' \
  "$STAGING/" "$PROD/" || { echo "ECHEC : copie"; exit 1; }
chown -R www-data:www-data "$PROD"

echo "> redemarrage de $SERVICE"
systemctl restart "$SERVICE"
for i in $(seq 1 60); do
  curl -s -o /dev/null --max-time 2 "http://127.0.0.1:$PORT/" && break
  sleep 1
done
rm -f "$FLAG"
curl -s -o /dev/null --max-time 5 "http://127.0.0.1:$PORT/" || { journalctl -u "$SERVICE" -n 30 --no-pager; echo "ECHEC : la prod ne redemarre pas"; exit 1; }

ls -1dt "$BK_DIR"/2* 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm -rf
echo "  prod redemarree"
