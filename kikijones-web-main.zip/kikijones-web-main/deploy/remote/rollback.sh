#!/bin/bash
# Retour arriere de la prod vers une sauvegarde (la derniere par defaut).
# Args : PROD_DIR BACKUP_DIR PROD_PORT PROD_SERVICE [DOSSIER_SAUVEGARDE | list]
set -uo pipefail
PROD=$1; BK_DIR=$2; PORT=$3; SERVICE=$4; BK=${5:-}
FLAG=/var/www/maintenance/building

if [ "$BK" = list ]; then
  echo "Sauvegardes disponibles (la plus recente en premier) :"
  for d in $(ls -1dt "$BK_DIR"/2* 2>/dev/null); do echo "  $(basename "$d")"; done
  exit 0
fi
[ -z "$BK" ] && BK=$(cat "$BK_DIR/LAST" 2>/dev/null)
[ -d "$BK" ] || BK="$BK_DIR/$BK"
[ -d "$BK" ] || { echo "ECHEC : sauvegarde introuvable"; exit 1; }

echo "> restauration de $BK"
trap 'rm -f "$FLAG"' EXIT
touch "$FLAG"
rsync -a --delete --exclude='/.env.local' --exclude='/.git/' "$BK/" "$PROD/" || { echo "ECHEC : copie"; exit 1; }
chown -R www-data:www-data "$PROD"
systemctl restart "$SERVICE"
for i in $(seq 1 60); do
  curl -s -o /dev/null --max-time 2 "http://127.0.0.1:$PORT/" && break
  sleep 1
done
rm -f "$FLAG"
curl -s -o /dev/null --max-time 5 "http://127.0.0.1:$PORT/" || { echo "ECHEC : la prod ne redemarre pas"; exit 1; }
echo "  prod restauree depuis $(basename "$BK")"
