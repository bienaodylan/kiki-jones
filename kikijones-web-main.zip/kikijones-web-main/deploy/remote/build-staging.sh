#!/bin/bash
# Build + redemarrage de la preproduction. Le code a deja ete copie par rsync.
# Args : STAGING_DIR STAGING_PORT STAGING_SERVICE SHA DIRTY
set -uo pipefail
DIR=$1; PORT=$2; SERVICE=$3; SHA=$4; DIRTY=$5
cd "$DIR" || exit 1
LOG="$DIR/.last-build.log"
info() { printf 'sha=%s\ndirty=%s\ndate=%s\nstatus=%s\n' "$SHA" "$DIRTY" "$(date '+%Y-%m-%d %H:%M:%S')" "$1" > "$DIR/.deploy-info"; }
as_www() { runuser -u www-data -- env HOME=/var/www "$@"; }

info building
chown -R www-data:www-data "$DIR"

hash=$(sha256sum package-lock.json | cut -d' ' -f1)
if [ ! -x node_modules/.bin/next ] || [ "$(cat .deps-hash 2>/dev/null)" != "$hash" ]; then
  echo "> npm ci (dependances nouvelles ou modifiees)..."
  if ! as_www npm ci --no-audit --no-fund > "$LOG" 2>&1; then
    tail -40 "$LOG"; info failed; echo "ECHEC : npm ci"; exit 1
  fi
  echo "$hash" > .deps-hash
fi

echo "> next build (verification TypeScript + lint + compilation)..."
start=$(date +%s)
if ! as_www npm run build > "$LOG" 2>&1; then
  grep -nE 'Type error|Error:|error|Failed' "$LOG" | head -30
  echo '--- fin du journal ---'; tail -25 "$LOG"
  info failed; echo "ECHEC : le build ne passe pas (journal complet : $LOG)"; exit 1
fi
echo "  build OK en $(( $(date +%s) - start )) s"

systemctl restart "$SERVICE"
for i in $(seq 1 45); do
  curl -s -o /dev/null --max-time 2 "http://127.0.0.1:$PORT/" && break
  sleep 1
done
if ! curl -s -o /dev/null --max-time 5 "http://127.0.0.1:$PORT/"; then
  journalctl -u "$SERVICE" -n 30 --no-pager; info failed; echo "ECHEC : le service ne demarre pas"; exit 1
fi
info built
echo "  preprod demarree sur 127.0.0.1:$PORT"
