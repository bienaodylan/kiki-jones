#!/bin/bash
# Tests automatiques d'une instance du site (preprod ou prod), executes sur le VPS.
# Args : BASE_URL ENV_DIR   (ex : http://127.0.0.1:3001 /var/www/kikijones-staging)
set -uo pipefail
BASE=$1; ENV_DIR=$2
API=$(grep -E '^NEXT_PUBLIC_API_URL=' "$ENV_DIR/.env.local" | cut -d= -f2- | tr -d '"\r')
API=${API:-https://admin.kikijones.com/api}
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
pass=0; fail=0

# check <chemin> <code attendu> [texte qui doit apparaitre]
check() {
  local path=$1 expect=$2 must=${3:-} res code t msg=""
  res=$(curl -s -o "$TMP/body" -w '%{http_code} %{time_total}' --max-time 40 "$BASE$path")
  code=${res% *}; t=${res#* }
  if [ "$code" != "$expect" ]; then
    msg="code $code (attendu $expect)"
  elif [ "$expect" = 200 ]; then
    if grep -qE 'Application error: a (client|server)-side exception|Internal Server Error' "$TMP/body"; then
      msg="page d'erreur affichee"
    elif [ -n "$must" ] && ! grep -qi -- "$must" "$TMP/body"; then
      msg="texte '$must' absent"
    fi
  fi
  if [ -z "$msg" ]; then pass=$((pass+1)); printf '  OK     %-38s %s  %ss\n' "$path" "$code" "$t"
  else fail=$((fail+1)); printf '  ECHEC  %-38s %s\n' "$path" "$msg"; fi
}

echo "Tests sur $BASE"
check /                 200 '</html>'
check /produits         200 '</html>'
check /nouveautes       200 '</html>'
check /categories       200 '</html>'
check /collections      200 '</html>'
check /brands           200 '</html>'
check /gift-cards       200 '</html>'
check /panier           200 '</html>'
check /login            200 '</html>'
check /register         200 '</html>'
check '/search?q=robe'  200 '</html>'
check /terms            200 '</html>'
check /privacy          200 '</html>'
check /robots.txt       200 'User-agent'
check /sitemap.xml      200 '<urlset'
check /compte           307
check /checkout         307
check /page-qui-nexiste-pas-xyz 404

# Une vraie fiche produit, prise dans l'API
slug=$(curl -s --max-time 20 "$API/products/products/?page_size=1" | python3 -c 'import sys,json
d=json.load(sys.stdin); r=d.get("results", d) if isinstance(d, dict) else d
print(r[0]["slug"] if r else "")' 2>/dev/null)
if [ -n "$slug" ]; then check "/produits/$slug" 200 '</html>'
else fail=$((fail+1)); echo "  ECHEC  API produits injoignable ($API)"; fi

# Les fichiers JS/CSS du build referencés par l'accueil doivent etre servis
curl -s --max-time 30 "$BASE/" > "$TMP/home"
assets=$(grep -oE '/_next/static/[^"'"'"' )]+\.(js|css)' "$TMP/home" | sort -u | head -6)
if [ -z "$assets" ]; then fail=$((fail+1)); echo "  ECHEC  aucun fichier /_next/static dans l'accueil"; fi
for a in $assets; do check "$a" 200; done

echo "Resultat : $pass OK, $fail ECHEC"
[ "$fail" -eq 0 ]
