#!/bin/bash
# Installation (idempotente) de la preproduction sur le VPS.
# Args : PROD_DIR STAGING_DIR BACKUP_DIR STAGING_PORT STAGING_SERVICE
set -euo pipefail
PROD_DIR=$1; STAGING_DIR=$2; BACKUP_DIR=$3; PORT=$4; SERVICE=$5

mkdir -p "$STAGING_DIR" "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
if [ ! -f "$STAGING_DIR/.env.local" ]; then
  cp "$PROD_DIR/.env.local" "$STAGING_DIR/.env.local"
  echo "- .env.local copie depuis la production"
fi
chown -R www-data:www-data "$STAGING_DIR"

cat > "/etc/systemd/system/$SERVICE.service" <<EOF
[Unit]
Description=KikiJones Next.js - preproduction (accessible uniquement en local sur le VPS)
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=$STAGING_DIR
Environment=NODE_ENV=production
ExecStart=$STAGING_DIR/node_modules/.bin/next start -H 127.0.0.1 -p $PORT
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=$SERVICE

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1
echo "OK : preprod prete ($STAGING_DIR, 127.0.0.1:$PORT, service $SERVICE)"
