# Circuit de déploiement — kikijones-web

```
 votre PC (WSL)                     VPS 169.58.255.1
 ──────────────                     ─────────────────────────────────────────────
 modifications ──deploy/staging.sh──▶ PRÉPROD  /var/www/kikijones-staging
                                      service kikijones-staging, 127.0.0.1:3001
                                      (non publique) build + tests automatiques
                                              │
                 deploy/prod.sh ──────────────┘ copie du build TESTÉ (pas de rebuild)
                                              ▼
                                      PROD     /var/www/kikijones-demo
                                      service kikijones-demo, :3000
                                      demo.kikijones.com / kikijones.com
                                      sauvegarde avant bascule, tests, retour
                                      arrière automatique si échec
```

## Utilisation (depuis `~/Projets/KikiJones_COMPLET_passation/kikijones-web`)

| Commande | Rôle |
|---|---|
| `deploy/staging.sh` | Envoie le code actuel (même non commité) en préprod, build (TypeScript + lint), redémarre, lance les tests. Ne touche jamais la prod. |
| `deploy/tunnel.sh` | Tunnel SSH pour voir la préprod sur http://localhost:3001 |
| `deploy/test.sh [staging\|prod]` | Relance les tests automatiques |
| `deploy/prod.sh` | Met en prod **le build validé en préprod**. Refuse si le commit n'y a pas été testé. Demande « oui ». |
| `deploy/rollback.sh [list\|nom]` | Remet la version précédente de la prod (5 sauvegardes gardées dans `/var/www/kikijones-backups`) |
| `deploy/setup.sh` | Installation unique de la préprod (déjà faite) |

Déroulé type :
1. Modifier le code.
2. `deploy/staging.sh` → corriger jusqu'à « PRÉPROD OK », regarder le rendu via `deploy/tunnel.sh`.
3. `git add -A && git commit -m "..."`, puis `deploy/staging.sh` (valide le commit exact).
4. `deploy/prod.sh` → bascule (quelques secondes de page de maintenance), tests, étiquette `prod-AAAAMMJJ-HHMMSS` poussée sur GitHub.

## Tests automatiques (`remote/smoke-test.sh`)
Pages principales en 200 sans page d'erreur (accueil, produits, catégories, collections, marques, cartes cadeaux, panier, connexion, inscription, recherche, CGU, confidentialité, robots.txt, sitemap.xml), une vraie fiche produit prise dans l'API, redirection vers la connexion pour `/compte` et `/checkout`, 404 pour une page inexistante, et fichiers JS/CSS du build servis.

## À savoir
- La préprod utilise la **même API et la même base que la prod** (`.env.local` copié). Ne pas y passer de vraie commande ni de paiement.
- Les secrets (`.env.local`) restent sur le serveur, jamais dans git.
- `kikijones.com` est encore derrière le drapeau de maintenance (`/var/www/maintenance/enabled`) ; ce circuit ne le modifie pas.
