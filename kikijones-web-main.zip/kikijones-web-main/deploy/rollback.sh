#!/bin/bash
# Retour arriere de la production.
# Usage : deploy/rollback.sh            -> derniere sauvegarde (version d'avant la derniere mise en prod)
#         deploy/rollback.sh list       -> liste des sauvegardes
#         deploy/rollback.sh <nom>      -> une sauvegarde precise
set -uo pipefail
source "$(dirname "$0")/config.sh"
if [ "${1:-}" = list ]; then
  remote rollback.sh "$PROD_DIR" "$BACKUP_DIR" "$PROD_PORT" "$PROD_SERVICE" list; exit
fi
say "Retour arriere de la production"
remote rollback.sh "$PROD_DIR" "$BACKUP_DIR" "$PROD_PORT" "$PROD_SERVICE" "${1:-}" || die "retour arriere"
say "Tests sur la production"
remote smoke-test.sh "http://127.0.0.1:$PROD_PORT" "$PROD_DIR" || die "tests en echec apres retour arriere"
ok "Production restauree."
