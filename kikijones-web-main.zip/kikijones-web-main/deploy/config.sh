# Configuration commune du circuit de deploiement (sourcee par les autres scripts).
VPS_HOST="root@169.58.255.1"
SSH_KEY="$HOME/.ssh/kikijones_vps"

PROD_DIR="/var/www/kikijones-demo"        # site en production (service kikijones-demo)
PROD_PORT=3000
PROD_SERVICE="kikijones-demo"
PROD_URL="https://demo.kikijones.com"

STAGING_DIR="/var/www/kikijones-staging"  # preproduction (service kikijones-staging)
STAGING_PORT=3001
STAGING_SERVICE="kikijones-staging"

BACKUP_DIR="/var/www/kikijones-backups"   # sauvegardes de la prod avant chaque mise en ligne
KEEP_BACKUPS=5

SSH_OPTS=(-i "$SSH_KEY" -o BatchMode=yes -o IdentitiesOnly=yes -o ConnectTimeout=15)
DEPLOY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(cd "$DEPLOY_DIR/.." && pwd)"

vps() { ssh "${SSH_OPTS[@]}" "$VPS_HOST" "$@"; }
# Execute un script de deploy/remote/ sur le VPS : remote <script> [args...]
remote() { local s="$1"; shift; ssh "${SSH_OPTS[@]}" "$VPS_HOST" "bash -s -- $*" < "$DEPLOY_DIR/remote/$s"; }

say()  { printf '\n\033[1m== %s\033[0m\n' "$*"; }
ok()   { printf '\033[32m%s\033[0m\n' "$*"; }
die()  { printf '\033[31mERREUR : %s\033[0m\n' "$*" >&2; exit 1; }
