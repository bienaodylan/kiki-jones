#!/bin/bash
# Installation unique de la preproduction sur le VPS (sans effet sur la prod).
set -uo pipefail
source "$(dirname "$0")/config.sh"
say "Installation de la preprod sur le VPS"
remote setup.sh "$PROD_DIR" "$STAGING_DIR" "$BACKUP_DIR" "$STAGING_PORT" "$STAGING_SERVICE" || die "installation"
