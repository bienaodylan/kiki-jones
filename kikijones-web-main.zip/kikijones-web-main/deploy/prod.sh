#!/bin/bash
# ETAPE 2 : met en PRODUCTION exactement le build valide en preprod.
# Refuse si le commit n'a pas ete teste en preprod. Retour arriere automatique si les tests echouent.
# Usage : deploy/prod.sh [--yes]
set -uo pipefail
source "$(dirname "$0")/config.sh"
cd "$REPO_DIR"
YES=no; [ "${1:-}" = "--yes" ] && YES=yes

[ -z "$(git status --porcelain)" ] || die "modifications non commitees. Commitez, relancez deploy/staging.sh, puis deploy/prod.sh"
SHA=$(git rev-parse HEAD)

info=$(vps "cat $STAGING_DIR/.deploy-info 2>/dev/null")
s_sha=$(sed -n 's/^sha=//p' <<<"$info"); s_dirty=$(sed -n 's/^dirty=//p' <<<"$info"); s_status=$(sed -n 's/^status=//p' <<<"$info")
if [ "$s_sha" != "$SHA" ] || [ "$s_dirty" != no ] || [ "$s_status" != ok ]; then
  die "la preprod n'a pas valide le commit ${SHA:0:7} (preprod : ${s_sha:0:7}, modifs=${s_dirty:-?}, statut=${s_status:-?}). Lancez d'abord deploy/staging.sh"
fi

say "Mise en production du commit ${SHA:0:7} (valide en preprod)"
prod_sha=$(vps "sed -n 's/^sha=//p' $PROD_DIR/.deploy-info 2>/dev/null")
if [ -n "$prod_sha" ] && git cat-file -e "$prod_sha" 2>/dev/null; then
  echo "Changements depuis la derniere mise en prod (${prod_sha:0:7}) :"; git log --oneline "$prod_sha..$SHA"
else
  echo "Derniers commits :"; git log --oneline -5
fi
if [ "$YES" = no ]; then
  read -r -p "Taper 'oui' pour mettre en production : " a
  [ "$a" = oui ] || die "annule"
fi

remote promote.sh "$PROD_DIR" "$STAGING_DIR" "$BACKUP_DIR" "$PROD_PORT" "$PROD_SERVICE" "$KEEP_BACKUPS"
rc=$?
if [ $rc -eq 2 ]; then die "mise en prod annulee avant toute modification"; fi
if [ $rc -ne 0 ]; then
  say "Echec de la bascule : retour arriere automatique"
  remote rollback.sh "$PROD_DIR" "$BACKUP_DIR" "$PROD_PORT" "$PROD_SERVICE"
  die "mise en prod echouee, la version precedente a ete restauree"
fi

say "Tests sur la production"
if ! remote smoke-test.sh "http://127.0.0.1:$PROD_PORT" "$PROD_DIR"; then
  say "Tests en echec : retour arriere automatique"
  remote rollback.sh "$PROD_DIR" "$BACKUP_DIR" "$PROD_PORT" "$PROD_SERVICE"
  die "tests en echec en prod, la version precedente a ete restauree"
fi
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 "$PROD_URL/")
[ "$code" = 200 ] && ok "  $PROD_URL repond 200" || echo "Attention : $PROD_URL repond $code depuis l'exterieur"

vps "sed 's/^status=.*/status=prod/' $STAGING_DIR/.deploy-info > $PROD_DIR/.deploy-info"
tag="prod-$(date +%Y%m%d-%H%M%S)"
if git tag -a "$tag" -m "Mise en production ${SHA:0:7}" && git push -q origin HEAD "$tag"; then
  echo "Commit pousse sur GitHub avec l'etiquette $tag"
else
  echo "Attention : le push GitHub a echoue (la prod est quand meme a jour)"
fi
ok "EN PRODUCTION : ${SHA:0:7}. Retour arriere possible avec deploy/rollback.sh"
