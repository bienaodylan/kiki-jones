#!/bin/bash
# ETAPE 1 : envoie le code actuel (meme non commite) en PREPROD, le construit et le teste.
# La production n'est jamais touchee par ce script.
set -uo pipefail
source "$(dirname "$0")/config.sh"
cd "$REPO_DIR"

SHA=$(git rev-parse HEAD)
DIRTY=no; [ -n "$(git status --porcelain)" ] && DIRTY=yes
say "Preprod : commit ${SHA:0:7}$([ "$DIRTY" = yes ] && echo ' + modifications non commitees')"

say "1/3 Copie du code vers le VPS ($STAGING_DIR)"
rsync -az --delete -e "ssh ${SSH_OPTS[*]}" \
  --exclude='/.git/' --exclude='/node_modules/' --exclude='/.next/' --exclude='.env*' \
  --exclude='*:Zone.Identifier' --exclude='*.tsbuildinfo' --exclude='/deploy/' \
  --exclude='/.deploy-info' --exclude='/.deps-hash' --exclude='/.last-build.log' \
  ./ "$VPS_HOST:$STAGING_DIR/" || die "copie rsync"

say "2/3 Build sur le VPS"
remote build-staging.sh "$STAGING_DIR" "$STAGING_PORT" "$STAGING_SERVICE" "$SHA" "$DIRTY" \
  || die "le build de la preprod a echoue (la prod n'a pas ete touchee)"

say "3/3 Tests automatiques"
if remote smoke-test.sh "http://127.0.0.1:$STAGING_PORT" "$STAGING_DIR"; then
  vps "sed -i 's/^status=.*/status=ok/' $STAGING_DIR/.deploy-info"
  ok "PREPROD OK : build et tests valides."
  if [ "$DIRTY" = yes ]; then
    echo "Pour mettre en prod : commitez (git add -A && git commit -m '...'), relancez deploy/staging.sh puis deploy/prod.sh"
  else
    echo "Pour mettre en prod : deploy/prod.sh"
  fi
  echo "Pour voir la preprod dans le navigateur : deploy/tunnel.sh puis http://localhost:$STAGING_PORT"
else
  vps "sed -i 's/^status=.*/status=tests_failed/' $STAGING_DIR/.deploy-info"
  die "des tests echouent en preprod : corrigez avant de mettre en prod"
fi
