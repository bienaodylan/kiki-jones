#!/bin/bash
# Relance les tests automatiques. Usage : deploy/test.sh [staging|prod]
set -uo pipefail
source "$(dirname "$0")/config.sh"
case "${1:-staging}" in
  staging) remote smoke-test.sh "http://127.0.0.1:$STAGING_PORT" "$STAGING_DIR" ;;
  prod)    remote smoke-test.sh "http://127.0.0.1:$PROD_PORT" "$PROD_DIR" ;;
  *) die "usage : deploy/test.sh [staging|prod]" ;;
esac
