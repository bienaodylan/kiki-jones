#!/bin/bash
# Ouvre la preprod dans votre navigateur via un tunnel SSH (elle n'est pas publique).
set -uo pipefail
source "$(dirname "$0")/config.sh"
echo "Preprod accessible sur http://localhost:$STAGING_PORT  (laisser ce terminal ouvert, Ctrl+C pour fermer)"
exec ssh "${SSH_OPTS[@]}" -N -o ExitOnForwardFailure=yes -L "$STAGING_PORT:127.0.0.1:$STAGING_PORT" "$VPS_HOST"
